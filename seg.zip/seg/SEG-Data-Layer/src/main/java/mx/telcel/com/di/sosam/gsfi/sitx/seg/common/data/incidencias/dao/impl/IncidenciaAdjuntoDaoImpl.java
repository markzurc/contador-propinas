package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.impl;

import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.T3SIND_INCI_ADJU;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaAdjuntoDao;

@Repository
public class IncidenciaAdjuntoDaoImpl implements IIncidenciaAdjuntoDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(IncidenciaAdjuntoDaoImpl.class);

    private static final String SQL_NEXT_ID =
            "SELECT NVL(MAX(ID_ADJU), 0) + 1 FROM BDDSEG01.T3SIND_INCI_ADJU";

    private static final String JPQL_FIND_BY_INCIDENCIA =
            "SELECT a FROM T3SIND_INCI_ADJU a " +
            "WHERE a.idIncidencia = :idIncidencia " +
            "AND a.activo = 'S' " +
            "ORDER BY a.fechaAlta DESC, a.idAdjunto DESC";

    private static final String JPQL_FIND_ACTIVO_BY_INCIDENCIA_AND_NOMBRE =
            "SELECT a FROM T3SIND_INCI_ADJU a " +
            "WHERE a.idIncidencia = :idIncidencia " +
            "AND a.nombreArchivo = :nombreArchivo " +
            "AND a.activo = 'S'";

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void persist(T3SIND_INCI_ADJU adj) {
        entityManager.persist(adj);
    }

    @Override
    public T3SIND_INCI_ADJU merge(T3SIND_INCI_ADJU entity) {
        if (entity == null) {
            return null;
        }
        return entityManager.merge(entity);
    }

    @Override
    public List<T3SIND_INCI_ADJU> findByIncidencia(Long idIncidencia) {
        if (idIncidencia == null) {
            return Collections.emptyList();
        }

        TypedQuery<T3SIND_INCI_ADJU> query = entityManager.createQuery(JPQL_FIND_BY_INCIDENCIA, T3SIND_INCI_ADJU.class);
        query.setParameter("idIncidencia", idIncidencia);

        return query.getResultList();
    }

    @Override
    public T3SIND_INCI_ADJU findActivoByIncidenciaAndNombre(Long idIncidencia, String nombreArchivo) {
        if (idIncidencia == null || isBlank(nombreArchivo)) {
            return null;
        }

        TypedQuery<T3SIND_INCI_ADJU> query = entityManager.createQuery(
                JPQL_FIND_ACTIVO_BY_INCIDENCIA_AND_NOMBRE,
                T3SIND_INCI_ADJU.class);

        query.setParameter("idIncidencia", idIncidencia);
        query.setParameter("nombreArchivo", nombreArchivo.trim());

        List<T3SIND_INCI_ADJU> resultados = query.setMaxResults(1).getResultList();
        return resultados.isEmpty() ? null : resultados.get(0);
    }

    @Override
    public void remove(T3SIND_INCI_ADJU entity) {
        if (entity == null) {
            return;
        }
        T3SIND_INCI_ADJU managed = entityManager.contains(entity) ? entity : entityManager.merge(entity);
        entityManager.remove(managed);
    }

    @Override
    public Long obtenerSiguienteId() {
        try {
            Object resultado = entityManager.createNativeQuery(SQL_NEXT_ID).getSingleResult();
            return (resultado != null) ? ((Number) resultado).longValue() : 1L;
        } catch (Exception e) {
            LOGGER.warn("No fue posible obtener el siguiente ID de adjunto; regresando 1.", e);
            return 1L;
        }
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}

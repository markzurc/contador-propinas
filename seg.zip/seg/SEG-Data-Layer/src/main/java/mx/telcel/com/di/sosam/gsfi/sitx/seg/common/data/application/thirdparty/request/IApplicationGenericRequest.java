package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.application.thirdparty.request;

/**
 * 
 * <h1>IApplicationGenericRequest</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 24/04/2015
 *
 */
public interface IApplicationGenericRequest{
	/**
	 * <p>Method that returns the name of the bean spring to which the request belongs</p>
	 * @return
	 */
	public String getBeanNameSpring();
}

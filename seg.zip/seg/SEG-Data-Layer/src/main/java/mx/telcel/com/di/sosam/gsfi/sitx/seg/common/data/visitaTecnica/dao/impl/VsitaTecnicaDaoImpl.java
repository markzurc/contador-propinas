package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.visitaTecnica.dao.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.stereotype.Repository;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegcHerrVistTecn;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegcPersVistTecn;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegdSoliArch;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3segoVisiTecnSoli;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcPara;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SoliArchDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.visitaTecnica.dao.IVisitaTecnicaDao;

@Repository
public class VsitaTecnicaDaoImpl   extends GenericFunctionDaoImpl  implements IVisitaTecnicaDao{

	private Logger LOGGER = LogManager.getLogger(VsitaTecnicaDaoImpl.class);
	private static final String UPDATE_SOLICITUD = "T3SEGO_SOLI.UPDATE_SOLICITUD";
	@Override
	public void guardarVisitaTecnica(T3segoVisiTecnSoli personalVisita) {
			 Session session = getSession();
			 session.saveOrUpdate(personalVisita);
	}
	@Override
	public void guardarPersonal(T3SegcPersVistTecn personalVisita) {
		Session session = getSession();
		session.saveOrUpdate(personalVisita);
	}
	
	@Override
	public void guardarHerramienta(T3SegcHerrVistTecn herramientalVisita) {
		Session session = getSession();
		session.saveOrUpdate(herramientalVisita);
	}
	@Override
	public  void actualizarSolicitud(String folio,String transicion) {
		Session session = getSession();
		Query query = session.getNamedQuery(UPDATE_SOLICITUD).setString("ESTATUS", transicion).setString("FOLIO", folio);
		query.executeUpdate();
	}
	
	@Override
	public void guardarArchivo(T3SegdSoliArch archivo) {
		 Session session = getSession();
		session.saveOrUpdate(archivo);
	}

	@Override
	public List<T3SegcPersVistTecn> getPersonal(String folioSolicitud,String grupoOperador) {
		try {
			 Session session = getSession();
			 String hql="FROM T3SegcPersVistTecn where grupoOperador=:GRUPO_OPERADOR AND idFolio=:FOLIO_SOLICITUD " ;
			 Query query=session.createQuery(hql);
			 query.setParameter("GRUPO_OPERADOR", grupoOperador);
			 query.setParameter("FOLIO_SOLICITUD", folioSolicitud);
			 
			return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar el personal de la visita tecnica: " + e.getMessage());
			return new ArrayList<>();
		}
	}

	

	@Override
	public List<T3SegcHerrVistTecn> getHerramientas(String folioSolicitud, String grupoOperador) {
		try {
			 Session session = getSession();
			 String hql="FROM T3SegcHerrVistTecn where grupoOperador=:GRUPO_OPERADOR AND idFolio=:FOLIO_SOLICITUD " ;
			 Query query=session.createQuery(hql);
			 query.setParameter("GRUPO_OPERADOR", grupoOperador);
			 query.setParameter("FOLIO_SOLICITUD", folioSolicitud);
			 
			return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar las herramientas de la visita tecnica: " + e.getMessage());
			
			return new ArrayList<>();
		}
	}




	@Override
	public List<SoliArchDto> getArchivos(String folioSolicitud, Integer idSeccion, String descripcion) {
		try {
			 Session session = getSession();
			 StringBuilder sql= new StringBuilder();
			 sql.append("SELECT id_archivo AS \"idArchivo\", ruta AS \"ruta\", ")
			 .append("descripcion AS \"descripcion\", nombre_archivo AS \"nombreArch\",")
			 .append("tamanio AS \"tamanio\",TO_CHAR(fecha_Carga, 'DD/MM/YYYY HH:MI:SS a.m.')  AS \"fechaCarga\",")
			 .append("revision AS \"revision\", id_seccion AS \"idSeccion\",")
		     .append("id_folio AS \"folio\",")
		     .append("USUARIO.NOMBRE || ' ' || USUARIO.APELLIDO_PATERNO || ' ' || USUARIO.APELLIDO_MATERNO AS \"nombreUsu\" ")
		     .append("FROM BDDSEG01.T3SEGD_SOLI_ARCH SOLICITUD_ARCHIVO " )
		     .append("INNER JOIN  BDDSEG01.T3SEGO_USUA USUARIO ON SOLICITUD_ARCHIVO.USUARIO = USUARIO.USUARIO ")
		     .append("WHERE id_folio=:FOLIO_SOLICITUD  AND id_seccion=:ID_SECCION  ")
			 .append("AND LOWER(descripcion) = LOWER(:DESCRIPCION)");
		     Query query= session.createSQLQuery(sql.toString())
		        		.addScalar("idArchivo",StandardBasicTypes.INTEGER)
		        		.addScalar("ruta",StandardBasicTypes.STRING)
		        		.addScalar("descripcion",StandardBasicTypes.STRING)
		        		.addScalar("nombreArch",StandardBasicTypes.STRING)
		        		.addScalar("tamanio",StandardBasicTypes.STRING)
		        		.addScalar("fechaCarga",StandardBasicTypes.STRING)
		        		.addScalar("revision",StandardBasicTypes.STRING)
		        		.addScalar("nombreUsu",StandardBasicTypes.STRING)
		        		.addScalar("idSeccion",StandardBasicTypes.INTEGER)
		        		.addScalar("folio",StandardBasicTypes.STRING)
		        		.setResultTransformer(Transformers.aliasToBean(SoliArchDto.class));
			 query.setParameter("FOLIO_SOLICITUD", folioSolicitud);
			 query.setParameter("ID_SECCION", idSeccion);
			 query.setParameter("DESCRIPCION", descripcion);
			 
			 return query.list();
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Error al consultar los archivos de la visita tecnica: " + e.getMessage());
			
			return new ArrayList<>();
		}
	}


	
	
	
	@Override
	public T3segoVisiTecnSoli getSolicitudVisita(String folioSolicitud) {
		try {
			 Session session = getSession();
			 String hql="FROM T3segoVisiTecnSoli where idFolio=:FOLIO_SOLICITUD " ;
			 Query query=session.createQuery(hql);
			 query.setParameter("FOLIO_SOLICITUD", folioSolicitud);
			    return (T3segoVisiTecnSoli) query.uniqueResult(); // Devuelve un solo objeto
		} catch (Exception e) {
			LOGGER.error("Error al consultar el personal de la visita tecnica: " + e.getMessage());
			return null;
		}
	}
	
	@Override
	public void eliminarPersonal(T3SegcPersVistTecn personalVisita) {
		Session session = getSession();
		Integer id = personalVisita.getIdPersonalVisita(); 
		T3SegcPersVistTecn entidad = (T3SegcPersVistTecn) session.get(T3SegcPersVistTecn.class, id);
		session.delete(entidad); 
		
	}

	@Override
	public void eliminarHerramienta(T3SegcHerrVistTecn herramientalVisita) {
		Session session = getSession();
	   Integer id = herramientalVisita.getIdHerramientaVisitaTecnica(); 
		T3SegcHerrVistTecn entidad = (T3SegcHerrVistTecn) session.get(T3SegcHerrVistTecn.class, id);
		session.delete(entidad); 
	}
	
	@Override
	public void eliminarArchivo(Integer idArchivo) {
		Session session = getSession();
			   String hql = "DELETE FROM T3SegdSoliArch WHERE idArchivo = :archivoId";
		        Query query = session.createQuery(hql);
		        query.setParameter("archivoId", idArchivo);
		        query.executeUpdate();
		       
		
	}
	
	@Override
	public List<String> getTipoHerramientas() {
		Session session = getSession();
		try {
			 Query query= session.createSQLQuery("select DESCRIPCION FROM bddseg01.t3segc_tipo_herra");
 
			return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar los tipos de antenas");
			return Collections.<String>emptyList();
		}
	}
}

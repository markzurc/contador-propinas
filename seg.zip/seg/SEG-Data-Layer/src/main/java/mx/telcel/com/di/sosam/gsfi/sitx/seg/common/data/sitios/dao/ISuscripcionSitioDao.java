package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao;

import java.util.Set;

public interface ISuscripcionSitioDao {

  
    void registrarSuscripcion(String concesionarioId, String sitioId, String usuarioAlta);

    Set<String> listarSitiosSuscritos(String concesionarioId);

    boolean existeSuscripcionActiva(String concesionarioId, String sitioId);
    
    void cancelarSuscripcion(String concesionarioId, String sitioId, String usuarioBaja);
}

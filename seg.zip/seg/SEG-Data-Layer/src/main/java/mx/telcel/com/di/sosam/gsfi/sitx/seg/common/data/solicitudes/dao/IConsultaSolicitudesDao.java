package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dao;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SolicitudDto;

public interface IConsultaSolicitudesDao {
	public List<SolicitudDto> getListaSolicitudes(Integer operador, Integer idRol);
	public Integer getOperadorUsuario(Integer idUsuario);
	public Boolean getValidarOperador(Integer rol);
}

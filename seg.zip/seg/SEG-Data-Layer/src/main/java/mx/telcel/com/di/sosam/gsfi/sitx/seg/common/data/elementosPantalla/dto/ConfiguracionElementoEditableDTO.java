package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto;


public class ConfiguracionElementoEditableDTO {
	private Integer idElementoPantalla;
	private Integer idTipoValidacion;  
	private String nombreValidacion;
	private String valoresEsperado;
	private String nombreCampo;
	public Integer getIdElementoPantalla() {
		return idElementoPantalla;
	}
	public void setIdElementoPantalla(Integer idElementoPantalla) {
		this.idElementoPantalla = idElementoPantalla;
	}
	public Integer getIdTipoValidacion() {
		return idTipoValidacion;
	}
	public void setIdTipoValidacion(Integer idTipoValidacion) {
		this.idTipoValidacion = idTipoValidacion;
	}
	public String getNombreValidacion() {
		return nombreValidacion;
	}
	public void setNombreValidacion(String nombreValidacion) {
		this.nombreValidacion = nombreValidacion;
	}
	public String getValoresEsperado() {
		return valoresEsperado;
	}
	public void setValoresEsperado(String valoresEsperado) {
		this.valoresEsperado = valoresEsperado;
	}
	public String getNombreCampo() {
		return nombreCampo;
	}
	public void setNombreCampo(String nombreCampo) {
		this.nombreCampo = nombreCampo;
	}	
	
	
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.T3SIND_INCI_ADJU;

public interface IIncidenciaAdjuntoDao {

    void persist(T3SIND_INCI_ADJU adj);

    T3SIND_INCI_ADJU merge(T3SIND_INCI_ADJU entity);

    List<T3SIND_INCI_ADJU> findByIncidencia(Long idIncidencia);

    T3SIND_INCI_ADJU findActivoByIncidenciaAndNombre(Long idIncidencia, String nombreArchivo);

    void remove(T3SIND_INCI_ADJU entity);
    Long obtenerSiguienteId();
}

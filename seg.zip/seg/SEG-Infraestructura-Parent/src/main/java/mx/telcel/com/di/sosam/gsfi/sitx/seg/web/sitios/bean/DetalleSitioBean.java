package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.sitios.bean;

import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.map.DefaultMapModel;
import org.primefaces.model.map.LatLng;
import org.primefaces.model.map.MapModel;
import org.primefaces.model.map.Marker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.elementosPantalla.IElementosPantallaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.IConsultaSitiosService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.solicitudes.ISolicitudesService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ElementosPantallaDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ServicioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SolicitudDto;

@Controller("detalleSitioBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class DetalleSitioBean implements Serializable {
	
	private static final long serialVersionUID = -2226579370912559241L;
	private static final Logger LOGGER = LogManager.getLogger(DetalleSitioBean.class.getName());
	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;
	@Autowired
//	private IConsultaSitiosService consultaSitiosServiceImpl;
	private ISolicitudesService consultaServiciosServiceImpl;
	@Autowired
	private IElementosPantallaService elementosPantalla;
	private String servicioSelect;
	SolicitudDto sitioConSolicitud = new SolicitudDto();
	
	private SitioDto parametroSitio;
	private String coordenadas;
	private MapModel simpleModel;
	private String key;
	private String selectServicio;
	private List<ServicioDto> listaServicios;
	private List<ElementosPantallaDTO> listElemPantalla;
	Map<String, Integer> map =	new HashMap<String,Integer>();
	
	private boolean renderedCrearSoli;

	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		UserDetailsVo userDetailsVo = (UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		 String nombreEstadoVista = rc.getCurrentState().getId();
		try {
			servicioSelect = "";
			renderedCrearSoli = true;
			sitioConSolicitud = consultaServiciosServiceImpl.getSitioConSolicitudCrea(parametroSitio, consultaServiciosServiceImpl.getGpoOperUsuById(userDetailsVo.getIdUsuario().toString()));			
			
			map.put("idRolUsuario", userDetailsVo.getIdRol());
			if (sitioConSolicitud != null) {
				map.put("idEstatusOrden", Integer.valueOf(sitioConSolicitud.getIdEstado()));
			}else {
				map.put("idEstatusOrden", 0); //Se  le asigna 0 por default, no hay solicitud generada para este sitio
			}
			
			listElemPantalla = elementosPantalla.getElementosPermitidosPantalla(nombreEstadoVista, userDetailsVo.getIdRol(), map );

			
			
//			listaServicios = consultaSitiosServiceImpl.getListaServicios();
			listaServicios = consultaServiciosServiceImpl.getListaServicios();
			//listaServicios.add("Visita T�cnica");
			simpleModel = new DefaultMapModel();
			String latitud = "";
			String longitud = "";
			ConfigurationUtilsVo configurationUtilsVo=configurationUtilsBusiness.getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.KEY_API_MAPS);
			key = configurationUtilsVo.getValor();
			if(parametroSitio.getLatitud().trim().contains(" ")){
				latitud = getLatitudDecimal(parametroSitio.getLatitud().trim());
			} else {
				latitud = parametroSitio.getLatitud();
			}
			if(parametroSitio.getLongitud().toString().contains(" ")){
				longitud = getLongitudDecimal(parametroSitio.getLongitud().trim());
			} else {
				longitud = parametroSitio.getLongitud();
			}		
			LatLng coord1 = new LatLng(Double.parseDouble(latitud), Double.parseDouble(longitud));
			coordenadas = latitud+", "+longitud;
			simpleModel.addOverlay(new Marker(coord1, parametroSitio.getNombre()));
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al cargar la Detalle de Sitios");
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","Ocurri� un error al cargar los datos del Detalle de Sitio"));
		}
	}
	
	private String getLatitudDecimal(String latitud) {
		FacesContext context = FacesContext.getCurrentInstance();
		String latitudDecimal = "";
		String[] coord = latitud.replaceAll(",", "\\.").split(" ");
		if(coord.length == 3){
			double d = Double.parseDouble(coord[0].replaceAll("\\.", ""));
			double m = Double.parseDouble(coord[1].replaceAll("\\.", ""));
			String seg = coord[2].substring(0,2);
			double s = Double.parseDouble(seg.replaceAll("\\.", ""));
			double signo = 1;
	        double resultado = signo * (Math.abs(d) + (m / 60.0) + (s / 3600.0));	
	        BigDecimal lat = new BigDecimal(""+resultado).setScale(8,BigDecimal.ROUND_HALF_UP);
	        latitudDecimal = String.valueOf(lat);
		} else {
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","No es posible convertir la latidud del Sitio"));			
		}
		return latitudDecimal;
	}

		
	private String getLongitudDecimal(String longitud) {
		FacesContext context = FacesContext.getCurrentInstance();
		String longitudDecimal = "";
		String[] coord = longitud.replaceAll(",", "\\.").split(" ");
		if(coord.length == 3){
			double d = Double.parseDouble(coord[0].replaceAll("\\.", ""));
			double m = Double.parseDouble(coord[1].replaceAll("\\.", ""));
			String seg = coord[2].substring(0,2);
			double s = Double.parseDouble(seg.replaceAll("\\.", ""));
			double signo = -1;
	        double resultado = signo * (Math.abs(d) + (m / 60.0) + (s / 3600.0));
	        BigDecimal lon = new BigDecimal(""+resultado).setScale(8,BigDecimal.ROUND_HALF_UP);
	        longitudDecimal = String.valueOf(lon);
		} else {
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","No es posible convertir la longitud del Sitio"));			
		}
		return longitudDecimal;
	}
	
	public void procesarSeleccion() {
	    System.out.println("Servicio seleccionado: " + servicioSelect);
	    if (!servicioSelect.equals("null")) {
			renderedCrearSoli = false;
		} else {
			renderedCrearSoli = true;
		}
	}
	
    public void limpia() {
    	servicioSelect = "";
    	renderedCrearSoli = true;
    }
	
	public boolean getVisible(String nombreComponente) {
		boolean visible=false;
		for(ElementosPantallaDTO elemento : listElemPantalla) {
			if(elemento.getIdElemento().equals(nombreComponente)) {
				visible=elemento.isVisible();
			}
		}
		return visible;
	}
	
	public boolean getEditable(String nombreComponente) {
		boolean visible=false;
		for(ElementosPantallaDTO elemento : listElemPantalla) {
			if(elemento.getIdElemento().equals(nombreComponente)) {
				visible=elemento.isEditable();
			}
		}
		return visible;
	}
	
	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}

	/**
	 * @return the simpleModel
	 */
	public MapModel getSimpleModel() {
		return simpleModel;
	}

	/**
	 * @return the coordenadas
	 */
	public String getCoordenadas() {
		return coordenadas;
	}

	/**
	 * @param coordenadas the coordenadas to set
	 */
	public void setCoordenadas(String coordenadas) {
		this.coordenadas = coordenadas;
	}

	/**
	 * @return the parametroSitio
	 */
	public SitioDto getParametroSitio() {
		return parametroSitio;
	}

	/**
	 * @param parametroSitio the parametroSitio to set
	 */
	public void setParametroSitio(SitioDto parametroSitio) {
		this.parametroSitio = parametroSitio;
	}

	/**
	 * @return the listaServicios
	 */
	public List<ServicioDto> getListaServicios() {
		return listaServicios;
	}

	/**
	 * @param listaServicios the listaServicios to set
	 */
	public void setListaServicios(List<ServicioDto> listaServicios) {
		this.listaServicios = listaServicios;
	}

	/**
	 * @return the selectServicio
	 */
	public String getSelectServicio() {
		return selectServicio;
	}

	/**
	 * @param selectServicio the selectServicio to set
	 */
	public void setSelectServicio(String selectServicio) {
		this.selectServicio = selectServicio;
	}
	
	public String getServicioSelect() {
		return servicioSelect;
	}

	public void setServicioSelect(String servicioSelect) {
		this.servicioSelect = servicioSelect;
	}

	public SolicitudDto getSitioConSolicitud() {
		return sitioConSolicitud;
	}

	public void setSitioConSolicitud(SolicitudDto sitioConSolicitud) {
		this.sitioConSolicitud = sitioConSolicitud;
	}
	
	public boolean getRenderedCrearSoli() {
		return renderedCrearSoli;
	}

	public void setRenderedCrearSoli(boolean renderedCrearSoli) {
		this.renderedCrearSoli = renderedCrearSoli;
	}
}

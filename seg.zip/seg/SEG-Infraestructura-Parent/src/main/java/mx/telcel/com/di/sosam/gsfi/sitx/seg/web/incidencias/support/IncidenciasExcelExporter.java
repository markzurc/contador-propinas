package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.incidencias.support;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaBitacoraDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaGestionDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants;

public class IncidenciasExcelExporter {

    private static final String PATRON_FECHA = "dd/MM/yyyy HH:mm:ss";

    public byte[] exportarBitacoraIncidencia(IncidenciaGestionDto incidenciaSeleccionada,
                                            List<IncidenciaBitacoraDto> bitacoraIncidenciaSeleccionada,
                                            String concesionarioUsuario) throws Exception {

        XSSFWorkbook workbook = new XSSFWorkbook();
        try {
            Sheet sheet = workbook.createSheet("Bit�cora Incidencia");
            sheet.setDisplayGridlines(false);
            sheet.setPrintGridlines(false);

            XSSFCellStyle styleTitulo = Constants.getLevelStyle(workbook, Constants.INDEX1);
            styleTitulo.setAlignment(CellStyle.ALIGN_CENTER);

            XSSFCellStyle styleHeader = Constants.getLevelStyle(workbook, Constants.INDEX2);
            styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
            styleHeader.setBorderBottom(CellStyle.BORDER_THIN);
            styleHeader.setBorderTop(CellStyle.BORDER_THIN);
            styleHeader.setBorderLeft(CellStyle.BORDER_THIN);
            styleHeader.setBorderRight(CellStyle.BORDER_THIN);

            XSSFCellStyle styleDato = Constants.getLevelStyle(workbook, Constants.INDEX5);
            styleDato.setBorderBottom(CellStyle.BORDER_THIN);
            styleDato.setBorderTop(CellStyle.BORDER_THIN);
            styleDato.setBorderLeft(CellStyle.BORDER_THIN);
            styleDato.setBorderRight(CellStyle.BORDER_THIN);

            int rowNum = 0;

            Row rowTitulo = sheet.createRow(rowNum++);
            Cell celdaTitulo = rowTitulo.createCell(0);
            celdaTitulo.setCellValue("BIT�CORA DETALLE DE INCIDENCIA");
            celdaTitulo.setCellStyle(styleTitulo);
            sheet.addMergedRegion(new CellRangeAddress(rowTitulo.getRowNum(), rowTitulo.getRowNum(), 0, 7));

            Row header = sheet.createRow(rowNum++);
            int col = 0;
            String[] titulos = new String[] {
                    "Folio", "Operador", "Usuario", "Empresa", "Estatus Actual",
                    "Fecha movimiento", "Responsabilidad Actual", "Comentario"
            };
            for (String titulo : titulos) {
                Cell c = header.createCell(col++);
                c.setCellValue(titulo);
                c.setCellStyle(styleHeader);
            }

            for (IncidenciaBitacoraDto mov : bitacoraIncidenciaSeleccionada) {
                Row row = sheet.createRow(rowNum++);
                int c = 0;

                String folio = (incidenciaSeleccionada != null && incidenciaSeleccionada.getFolio() != null)
                        ? incidenciaSeleccionada.getFolio()
                        : "";

                String operadorExcel = obtenerOperadorMovimiento(mov);

                String usuarioExcel = (incidenciaSeleccionada != null && incidenciaSeleccionada.getUsuarioCreacion() != null)
                        ? incidenciaSeleccionada.getUsuarioCreacion()
                        : "";

                String empresaExcel;
                if (incidenciaSeleccionada != null && incidenciaSeleccionada.getConcesionario() != null) {
                    empresaExcel = incidenciaSeleccionada.getConcesionario();
                } else if (concesionarioUsuario != null) {
                    empresaExcel = concesionarioUsuario;
                } else {
                    empresaExcel = "";
                }

                String estatusActual = (mov != null && mov.getEstatusNuevo() != null) ? mov.getEstatusNuevo() : "";

                String fechaStr = "";
                if (mov != null && mov.getFechaEvento() != null) {
                    fechaStr = formatearFechaBitacora(mov);
                }

                String responsabilidad = obtenerResponsabilidadMovimiento(mov);

                String comentario = (mov != null && mov.getComentario() != null) ? mov.getComentario() : "";

                Cell cFolio = row.createCell(c++);
                cFolio.setCellValue(folio);
                cFolio.setCellStyle(styleDato);

                Cell cOperador = row.createCell(c++);
                cOperador.setCellValue(operadorExcel);
                cOperador.setCellStyle(styleDato);

                Cell cUsuario = row.createCell(c++);
                cUsuario.setCellValue(usuarioExcel);
                cUsuario.setCellStyle(styleDato);

                Cell cEmpresa = row.createCell(c++);
                cEmpresa.setCellValue(empresaExcel);
                cEmpresa.setCellStyle(styleDato);

                Cell cEst = row.createCell(c++);
                cEst.setCellValue(estatusActual);
                cEst.setCellStyle(styleDato);

                Cell cFecha = row.createCell(c++);
                cFecha.setCellValue(fechaStr);
                cFecha.setCellStyle(styleDato);

                Cell cResp = row.createCell(c++);
                cResp.setCellValue(responsabilidad);
                cResp.setCellStyle(styleDato);

                Cell cCom = row.createCell(c++);
                cCom.setCellValue(comentario);
                cCom.setCellStyle(styleDato);
            }

            for (int i = 0; i < 8; i++) {
                sheet.autoSizeColumn(i);
            }

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            workbook.write(baos);
            return baos.toByteArray();

        } finally {
            try { workbook.close(); } catch (Exception ignore) {}
        }
    }

    public byte[] exportarGestionIncidencias(List<IncidenciaGestionDto> listaIncidencias) throws Exception {
        XSSFWorkbook workbook = new XSSFWorkbook();
        try {
            Sheet sheet = workbook.createSheet("Gesti�n incidencias");
            sheet.setDisplayGridlines(false);
            sheet.setPrintGridlines(false);

            XSSFCellStyle styleTitulo = Constants.getLevelStyle(workbook, Constants.INDEX1);
            styleTitulo.setAlignment(CellStyle.ALIGN_CENTER);

            XSSFCellStyle styleHeader = Constants.getLevelStyle(workbook, Constants.INDEX2);
            styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
            styleHeader.setBorderBottom(CellStyle.BORDER_THIN);
            styleHeader.setBorderTop(CellStyle.BORDER_THIN);
            styleHeader.setBorderLeft(CellStyle.BORDER_THIN);
            styleHeader.setBorderRight(CellStyle.BORDER_THIN);

            XSSFCellStyle styleDato = Constants.getLevelStyle(workbook, Constants.INDEX5);
            styleDato.setBorderBottom(CellStyle.BORDER_THIN);
            styleDato.setBorderTop(CellStyle.BORDER_THIN);
            styleDato.setBorderLeft(CellStyle.BORDER_THIN);
            styleDato.setBorderRight(CellStyle.BORDER_THIN);

            int rowNum = 0;

            Row rowTitulo = sheet.createRow(rowNum++);
            Cell celdaTitulo = rowTitulo.createCell(0);
            celdaTitulo.setCellValue("GESTI�N DE INCIDENCIAS");
            celdaTitulo.setCellStyle(styleTitulo);
            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 7));

            Row header = sheet.createRow(rowNum++);
            int col = 0;

            String[] titulos = new String[] {
                    "Folio", "ID Sitio", "Nombre Sitio", "Concesionario", "Pendiente por",
                    "Estatus", "Usuario creaci�n", "Fecha creaci�n"
            };

            for (String titulo : titulos) {
                Cell c = header.createCell(col++);
                c.setCellValue(titulo);
                c.setCellStyle(styleHeader);
            }

            for (IncidenciaGestionDto dto : listaIncidencias) {
                Row row = sheet.createRow(rowNum++);
                int c = 0;

                Cell cFolio = row.createCell(c++);
                cFolio.setCellValue(dto.getFolio() != null ? dto.getFolio() : "");
                cFolio.setCellStyle(styleDato);

                Cell cIdSitio = row.createCell(c++);
                cIdSitio.setCellValue(dto.getIdSitio() != null ? dto.getIdSitio() : "");
                cIdSitio.setCellStyle(styleDato);

                Cell cNombreSitio = row.createCell(c++);
                cNombreSitio.setCellValue(dto.getNombreSitio() != null ? dto.getNombreSitio() : "");
                cNombreSitio.setCellStyle(styleDato);

                Cell cConcesionario = row.createCell(c++);
                cConcesionario.setCellValue(dto.getConcesionario() != null ? dto.getConcesionario() : "");
                cConcesionario.setCellStyle(styleDato);

                Cell cPendiente = row.createCell(c++);
                cPendiente.setCellValue(dto.getPendientePor() != null ? dto.getPendientePor() : "");
                cPendiente.setCellStyle(styleDato);

                Cell cEstatus = row.createCell(c++);
                cEstatus.setCellValue(dto.getEstatus() != null ? dto.getEstatus() : "");
                cEstatus.setCellStyle(styleDato);

                Cell cUsu = row.createCell(c++);
                cUsu.setCellValue(dto.getUsuarioCreacion() != null ? dto.getUsuarioCreacion() : "");
                cUsu.setCellStyle(styleDato);

                Cell cFecha = row.createCell(c++);
                cFecha.setCellValue(dto.getFechaCreacion() != null ? dto.getFechaCreacion() : "");
                cFecha.setCellStyle(styleDato);
            }

            for (int i = 0; i < 8; i++) {
                sheet.autoSizeColumn(i);
            }

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            workbook.write(baos);
            return baos.toByteArray();

        } finally {
            try { workbook.close(); } catch (Exception ignore) {}
        }
    }

    public byte[] exportarCatalogoErroresCargaMasiva(List<Map<String, String>> errores,
                                                    List<Map<String, String>> capturados) throws Exception {

        XSSFWorkbook workbook = new XSSFWorkbook();
        try {
            org.apache.poi.ss.usermodel.Sheet sheet = workbook.createSheet("Errores de carga");
            sheet.setDisplayGridlines(false);
            sheet.setPrintGridlines(false);

            XSSFCellStyle styleTitulo = Constants.getLevelStyle(workbook, Constants.INDEX1);
            styleTitulo.setAlignment(CellStyle.ALIGN_CENTER);
            styleTitulo.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
            XSSFCellStyle styleHeader = Constants.getLevelStyle(workbook, Constants.INDEX2);
            styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
            styleHeader.setBorderBottom(CellStyle.BORDER_THIN);
            styleHeader.setBorderTop(CellStyle.BORDER_THIN);
            styleHeader.setBorderLeft(CellStyle.BORDER_THIN);
            styleHeader.setBorderRight(CellStyle.BORDER_THIN);

            XSSFCellStyle styleDato = Constants.getLevelStyle(workbook, Constants.INDEX5);
            styleDato.setBorderBottom(CellStyle.BORDER_THIN);
            styleDato.setBorderTop(CellStyle.BORDER_THIN);
            styleDato.setBorderLeft(CellStyle.BORDER_THIN);
            styleDato.setBorderRight(CellStyle.BORDER_THIN);

            int rowIdx = 0;

            org.apache.poi.ss.usermodel.Row r0 = sheet.createRow(rowIdx++);
            org.apache.poi.ss.usermodel.Cell c0 = r0.createCell(0);
            c0.setCellValue("CAT�LOGO DE ERRORES DE CARGA MASIVA DE INCIDENCIAS");
            c0.setCellStyle(styleTitulo);
            sheet.addMergedRegion(new org.apache.poi.ss.util.CellRangeAddress(0, 0, 0, 14));

            org.apache.poi.ss.usermodel.Row rh = sheet.createRow(rowIdx++);
            String[] headers = new String[] {
                    "N�mero de rengl�n", "ID de sitio (capturado)", "Error presentado en  ID de sitio",
                    "Tipo de incidencia (capturado)", "Error presentado en  incidencia",
                    "Descripci�n detallada (capturada)", "Error presentado en  descripci�n",
                    "Nombre de quien reporta (capturado)", "Error presentado en  nombre de quien reporta",
                    "Correo de quien reporta (capturado)", "Error presentado en correo de quien reporta",
                    "Concesionario (capturado)", "Error presentado en concesionario",
                    "Estatus (capturado)", "Error presentado en estatus"
            };

            for (int i = 0; i < headers.length; i++) {
                org.apache.poi.ss.usermodel.Cell ch = rh.createCell(i);
                ch.setCellValue(headers[i]);
                ch.setCellStyle(styleHeader);
            }

            for (int i = 0; i < errores.size(); i++) {
                Map<String, String> err = errores.get(i);
                Map<String, String> cap = capturados.get(i);

                org.apache.poi.ss.usermodel.Row rd = sheet.createRow(rowIdx++);

                setCell(rd, 0, cap.get("renglon"), styleDato);

                setCell(rd, 1, cap.get("idSitio"), styleDato);
                setCell(rd, 2, err.get("idSitio"), styleDato);

                setCell(rd, 3, cap.get("tipo"), styleDato);
                setCell(rd, 4, err.get("tipo"), styleDato);

                setCell(rd, 5, cap.get("desc"), styleDato);
                setCell(rd, 6, err.get("desc"), styleDato);

                setCell(rd, 7, cap.get("nombre"), styleDato);
                setCell(rd, 8, err.get("nombre"), styleDato);

                setCell(rd, 9, cap.get("correo"), styleDato);
                setCell(rd, 10, err.get("correo"), styleDato);

                setCell(rd, 11, cap.get("conces"), styleDato);
                setCell(rd, 12, err.get("conces"), styleDato);

                setCell(rd, 13, cap.get("estatus"), styleDato);
                setCell(rd, 14, err.get("estatus"), styleDato);
            }

            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            workbook.write(baos);
            return baos.toByteArray();

        } finally {
            try { workbook.close(); } catch (Exception ignore) {}
        }
    }

    

    private String obtenerTextoFecha(IncidenciaBitacoraDto movimiento) {
        if (movimiento == null || movimiento.getFechaEvento() == null) {
            return "";
        }
        return movimiento.getFechaEvento().toString();
    }

    private String obtenerTextoEstatus(IncidenciaBitacoraDto movimiento) {
        if (movimiento == null || movimiento.getEstatusNuevo() == null) {
            return "";
        }
        return movimiento.getEstatusNuevo();
    }

    private String obtenerTextoUsuario(IncidenciaBitacoraDto movimiento) {
        if (movimiento == null || movimiento.getUsuarioMovimiento() == null) {
            return "";
        }
        return movimiento.getUsuarioMovimiento();
    }

    private String obtenerTextoComentario(IncidenciaBitacoraDto movimiento) {
        if (movimiento == null || movimiento.getComentario() == null) {
            return "";
        }
        return movimiento.getComentario();
    }
    
    private void setCell(org.apache.poi.ss.usermodel.Row row, int col, String val, XSSFCellStyle style) {
        org.apache.poi.ss.usermodel.Cell c = row.createCell(col);
        c.setCellValue(val != null ? val : "");
        c.setCellStyle(style);
    }

    private String formatearFechaBitacora(IncidenciaBitacoraDto mov) {
        if (mov == null || mov.getFechaEvento() == null) {
            return "";
        }
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(PATRON_FECHA);
            return sdf.format(mov.getFechaEvento());
        } catch (Exception e) {
            return mov.getFechaEvento().toString();
        }
    }

    private String obtenerOperadorMovimiento(IncidenciaBitacoraDto movimiento) {
        if (movimiento == null) {
            return "";
        }
        if ("CREADA".equalsIgnoreCase(movimiento.getEstatusNuevo())) {
            return "";
        }
        return (movimiento.getUsuarioMovimiento() == null) ? "" : movimiento.getUsuarioMovimiento().trim();
    }

    private String obtenerResponsabilidadMovimiento(IncidenciaBitacoraDto movimiento) {
        if (movimiento == null || movimiento.getResponsabilidad() == null) {
            return "";
        }
        return movimiento.getResponsabilidad();
    }
}

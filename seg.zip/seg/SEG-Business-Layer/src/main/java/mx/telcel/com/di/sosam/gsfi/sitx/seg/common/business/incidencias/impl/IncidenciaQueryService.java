package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.ISuscripcionSitioService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.T3SINB_INCI_MOVI;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.T3SINO_INCI;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaBitacoraDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaBitacoraDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaGestionDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.IConsultaSitiosDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;
import javax.persistence.Query;

@Service
public class IncidenciaQueryService {

	private static final Logger log = LoggerFactory.getLogger(IncidenciaQueryService.class);

	private static final long ESTATUS_CREADA = 1L;
	private static final long ESTATUS_EN_ATENCION = 2L;
	private static final long ESTATUS_RECHAZADA = 3L;
	private static final long ESTATUS_FINALIZADA = 4L;

	@PersistenceContext
	private EntityManager entityManager;


	private static final String FECHA_PATTERN = "dd/MM/yyyy HH:mm:ss";

	@Autowired
	private IIncidenciaDao incidenciaDao;

	@Autowired
	private IIncidenciaBitacoraDao bitacoraDao;

	@Autowired
	@Qualifier("consultaSitiosDao")
	private IConsultaSitiosDao consultaSitiosDao;

	@Autowired(required = false)
	private ISuscripcionSitioService suscripcionSitioService;

	@Transactional(readOnly = true)
	public List<?> listarSitiosEnOperacionVisibles() {
		return obtenerListaSitiosOperacion();

	}

	@Transactional(readOnly = true)
	public List<?> listarSitiosSuscritosParaAltaIncidencia(String concesionarioUsuario) {

		List<SitioDto> sitiosVisibles = obtenerListaSitiosOperacion();
		if (sitiosVisibles == null || sitiosVisibles.isEmpty()) {
			return Collections.emptyList();
		}

		if (isBlank(concesionarioUsuario)) {
			log.warn(
					"concesionarioIdentificador vacio; se regresa lista vacia para no mostrar sitios sin suscripcion.");
			return Collections.emptyList();
		}

		if (suscripcionSitioService == null) {
			log.warn(
					"suscripcionSitioService no disponible; se regresa lista vacia para no mostrar sitios sin suscripcion. concesionario={}",
					concesionarioUsuario);
			return Collections.emptyList();
		}

		Set<String> sitiosSuscritos = suscripcionSitioService.listarSitiosSuscritos(concesionarioUsuario.trim());
		if (sitiosSuscritos == null || sitiosSuscritos.isEmpty()) {
			return Collections.emptyList();
		}

		Set<String> setSuscritos = new HashSet<String>();
		for (String s : sitiosSuscritos) {
			if (!isBlank(s)) {
				setSuscritos.add(s.trim());
			}
		}
		if (setSuscritos.isEmpty()) {
			return Collections.emptyList();
		}

		List<SitioDto> resultado = new ArrayList<SitioDto>();
		for (SitioDto sitio : sitiosVisibles) {
			if (sitio == null || isBlank(sitio.getSitio())) {
				continue;
			}

			String id = sitio.getSitio().trim();
			if (setSuscritos.contains(id)) {
				resultado.add(sitio);
			}
		}

		return resultado;
	}

	private Map<Long, String> construirMapaTiposIncidencia() {
	    Map<Long, String> mapa = new HashMap<Long, String>();

	    if (entityManager == null) {
	        return mapa;
	    }

	    try {
	        TypedQuery<Object[]> query = entityManager.createQuery(
	            "SELECT t.id, t.descripcion FROM T3SINC_INCI_TIPO t WHERE t.activo = 'S' ORDER BY t.id",
	            Object[].class
	        );

	        List<Object[]> rows = query.getResultList();
	        if (rows == null) {
	            return mapa;
	        }

	        for (Object[] row : rows) {
	            if (row == null || row.length < 2 || row[0] == null) {
	                continue;
	            }

	            Long id = (row[0] instanceof Long) ? (Long) row[0] : Long.valueOf(row[0].toString());
	            String desc = (row[1] != null) ? row[1].toString() : null;

	            if (id != null && desc != null && !desc.trim().isEmpty()) {
	                mapa.put(id, desc.trim());
	            }
	        }
	    } catch (Exception ex) {
	        log.warn("No se pudo construir el mapa de tipos de incidencia.", ex);
	    }

	    return mapa;
	}

	@Transactional(readOnly = true)
	public List<String> catalogoTiposIncidencia() {
	    if (entityManager == null) {
	        return Collections.emptyList();
	    }

	    TypedQuery<String> query = entityManager.createQuery(
	            "SELECT t.descripcion FROM T3SINC_INCI_TIPO t " +
	            "WHERE t.activo = 'S' ORDER BY t.id",
	            String.class
	    );

	    List<String> tipos = query.getResultList();
	    return (tipos != null) ? tipos : Collections.<String>emptyList();
	}

	
	@Transactional(readOnly = true)
	public Long obtenerIdTipoIncidenciaDesdeCatalogo(String tipoEntrada) {
	    if (entityManager == null || isBlank(tipoEntrada)) {
	        return null;
	    }

	    String valor = tipoEntrada.trim().toUpperCase();

	    TypedQuery<Long> query = entityManager.createQuery(
	            "SELECT t.id FROM T3SINC_INCI_TIPO t " +
	            "WHERE t.activo = 'S' AND (UPPER(t.descripcion) = :valor OR UPPER(t.clave) = :valor)",
	            Long.class
	    );
	    query.setParameter("valor", valor);

	    List<Long> ids = query.getResultList();
	    return (ids != null && !ids.isEmpty()) ? ids.get(0) : null;
	}

	
	@Transactional(readOnly = true)
	public List<IncidenciaGestionDto> buscarIncidenciasMantenimiento(String folio, String sitioId, String estatus) {
	    List<T3SINO_INCI> incidencias = incidenciaDao.findAll();
	    if (incidencias == null || incidencias.isEmpty()) {
	        return Collections.emptyList();
	    }

	    Long estatusIdFiltro = mapEstatusEntradaAId(estatus);

	    List<T3SINO_INCI> filtradas = new ArrayList<T3SINO_INCI>();
	    Set<String> idsSitioNecesarios = new HashSet<String>();

	    for (T3SINO_INCI inci : incidencias) {
	        if (inci == null) {
	            continue;
	        }
	        if (!cumpleFiltroTexto(inci.getFolio(), folio)) {
	            continue;
	        }
	        if (!cumpleFiltroTexto(inci.getIdSitio(), sitioId)) {
	            continue;
	        }
	        if (estatusIdFiltro != null && (inci.getIdEstatusIncidencia() == null
	                || estatusIdFiltro.longValue() != inci.getIdEstatusIncidencia().longValue())) {
	            continue;
	        }

	        filtradas.add(inci);

	        if (!isBlank(inci.getIdSitio())) {
	            idsSitioNecesarios.add(inci.getIdSitio().trim());
	        }
	    }

	    if (filtradas.isEmpty()) {
	        return Collections.emptyList();
	    }

	    Map<String, String> mapaSitios;
	    try {
	        mapaSitios = construirMapaNombreSitioPorIds(idsSitioNecesarios);
	    } catch (Exception ex) {
	        log.warn("Fall� la consulta optimizada de nombres de sitio; se usa fallback.", ex);
	        mapaSitios = construirMapaNombreSitio(); 
	    }

	    Map<Long, String> mapaTipos = construirMapaTiposIncidencia();

	    List<IncidenciaGestionDto> resultado = new ArrayList<IncidenciaGestionDto>();
	    for (T3SINO_INCI inci : filtradas) {
	        resultado.add(construirDto(inci, mapaSitios, mapaTipos));
	    }

	    return resultado;
	}


	
	@Transactional(readOnly = true)
	public List<IncidenciaGestionDto> buscarIncidenciasConcesionario(String folio, String sitioId, String estatus,
	        String concesionario) {

	    if (isBlank(concesionario)) {
	        return Collections.emptyList();
	    }

	    List<T3SINO_INCI> incidencias = incidenciaDao.findAllByConcesionario(concesionario.trim());
	    if (incidencias == null || incidencias.isEmpty()) {
	        return Collections.emptyList();
	    }

	    Long estatusIdFiltro = mapEstatusEntradaAId(estatus);

	    List<T3SINO_INCI> filtradas = new ArrayList<T3SINO_INCI>();
	    Set<String> idsSitioNecesarios = new HashSet<String>();

	    for (T3SINO_INCI inci : incidencias) {
	        if (inci == null) {
	            continue;
	        }
	        if (!cumpleFiltroTexto(inci.getFolio(), folio)) {
	            continue;
	        }
	        if (!cumpleFiltroTexto(inci.getIdSitio(), sitioId)) {
	            continue;
	        }
	        if (estatusIdFiltro != null && (inci.getIdEstatusIncidencia() == null
	                || estatusIdFiltro.longValue() != inci.getIdEstatusIncidencia().longValue())) {
	            continue;
	        }

	        filtradas.add(inci);

	        if (!isBlank(inci.getIdSitio())) {
	            idsSitioNecesarios.add(inci.getIdSitio().trim());
	        }
	    }

	    if (filtradas.isEmpty()) {
	        return Collections.emptyList();
	    }

	    Map<String, String> mapaSitios;
	    try {
	        mapaSitios = construirMapaNombreSitioPorIds(idsSitioNecesarios);
	    } catch (Exception ex) {
	        log.warn("Fall� la consulta optimizada de nombres de sitio; se usa fallback.", ex);
	        mapaSitios = construirMapaNombreSitio();
	    }

	    Map<Long, String> mapaTipos = construirMapaTiposIncidencia();

	    List<IncidenciaGestionDto> resultado = new ArrayList<IncidenciaGestionDto>();
	    for (T3SINO_INCI inci : filtradas) {
	        resultado.add(construirDto(inci, mapaSitios, mapaTipos));
	    }

	    return resultado;
	}

	
	@Transactional(readOnly = true)
	public List<IncidenciaBitacoraDto> obtenerBitacoraIncidencia(Long idIncidencia) {
		if (idIncidencia == null) {
			return Collections.emptyList();
		}

		List<T3SINB_INCI_MOVI> movimientos = bitacoraDao.findByIncidenciaId(idIncidencia);
		List<IncidenciaBitacoraDto> dtos = new ArrayList<IncidenciaBitacoraDto>();

		for (T3SINB_INCI_MOVI mov : movimientos) {
			if (mov == null)
				continue;
			IncidenciaBitacoraDto dto = new IncidenciaBitacoraDto();
			dto.setId(mov.getId());
			dto.setIdIncidencia(mov.getIdIncidencia());

			String estNuevo = mov.getEstatusNuevo();
			if (estNuevo == null || estNuevo.trim().isEmpty()) {
				estNuevo = mapEstatusIdAClave(mov.getIdEstatusIncidencia());
			}
			dto.setEstatusNuevo(estNuevo);

			

			dto.setUsuarioMovimiento(mov.getUsuarioMovimiento());
			dto.setFechaEvento(mov.getFechaEvento());
			dto.setComentario(mov.getComentario()); 

			if (mov.getIdResponsabilidad() != null) {
				dto.setResponsabilidad(mov.getIdResponsabilidad() == 1L ? "Concesionario" : "Mantenimiento");
			}
			dtos.add(dto);
		}
		return dtos;
	}

	@Transactional(readOnly = true)
	public String obtenerCorreoExternoPorUsuario(Integer idUsuario, Integer idRol) {
		return incidenciaDao.obtenerCorreoExternoPorUsuario(idUsuario, idRol);
	}

	@Transactional(readOnly = true)
	public void validarSitioActivo(String sitioCodigo) {
		try {
			if (!existeYActivoSitio(sitioCodigo)) {
				throw new IllegalArgumentException("El sitio no existe o no se encuentra activo.");
			}
		} catch (IllegalArgumentException ex) {
			throw ex;
		} catch (Exception ex) {
			log.warn("Validaci�n sitio fallida.", ex);
		}
	}

	private List<SitioDto> obtenerListaSitiosOperacion() {
		List<SitioDto> sitios = consultaSitiosDao.getListaSitios();
		return (sitios != null) ? sitios : Collections.<SitioDto>emptyList();
	}

	private boolean existeYActivoSitio(String sitioId) {
		if (isBlank(sitioId)) {
			return false;
		}

		List<SitioDto> sitios = obtenerListaSitiosOperacion();
		for (SitioDto sitio : sitios) {
			if (sitio == null) {
				continue;
			}

			String id = sitio.getSitio();
			if (id != null && sitioId.trim().equalsIgnoreCase(id)) {
				String disp = sitio.getDisponible();
				if (disp == null || disp.trim().isEmpty()) {
					return true;
				}
				return "SI".equalsIgnoreCase(disp) || "S".equalsIgnoreCase(disp) || "1".equals(disp)
						|| "ACTIVO".equalsIgnoreCase(disp);
			}
		}
		return false;
	}
	
	
	private String mapTipoIdAEtiqueta(Long idTipo) {
	    if (idTipo == null) {
	        return null;
	    }
	    if (entityManager == null) {
	        return String.valueOf(idTipo);
	    }

	    try {
	        TypedQuery<String> query = entityManager.createQuery(
	                "SELECT t.descripcion FROM T3SINC_INCI_TIPO t " +
	                "WHERE t.activo = 'S' AND t.id = :idTipo",
	                String.class
	        );
	        query.setParameter("idTipo", idTipo);

	        List<String> res = query.getResultList();
	        if (res != null && !res.isEmpty() && res.get(0) != null) {
	            return res.get(0);
	        }
	    } catch (Exception ex) {
	        log.warn("No se pudo resolver tipo incidencia desde cat�logo. idTipo={}", idTipo, ex);
	    }

	    return String.valueOf(idTipo);
	}
	private IncidenciaGestionDto construirDto(T3SINO_INCI incidencia, Map<String, String> mapaSitios,
	        Map<Long, String> mapaTipos) {

	    IncidenciaGestionDto dto = new IncidenciaGestionDto();

	    dto.setIdIncidencia(incidencia.getId());
	    dto.setFolio(incidencia.getFolio());
	    dto.setIdSitio(incidencia.getIdSitio());
	    dto.setOrigenAlta(incidencia.getOrigenAlta());

	    String nombreSitio = (mapaSitios != null && !isBlank(incidencia.getIdSitio()))
	            ? mapaSitios.get(incidencia.getIdSitio())
	            : null;

	    dto.setNombreSitio(!isBlank(nombreSitio) ? nombreSitio : incidencia.getIdSitio());

	    dto.setConcesionario(incidencia.getIdConcesionario());
	    dto.setEstatus(mapEstatusIdAClave(incidencia.getIdEstatusIncidencia()));
	    dto.setPendientePor(resolverPendientePorId(incidencia.getIdEstatusIncidencia()));

	    Long idTipo = incidencia.getIdTipoIncidencia();
	    String tipo = (mapaTipos != null && idTipo != null) ? mapaTipos.get(idTipo) : null;
	    dto.setTipo(!isBlank(tipo) ? tipo : (idTipo != null ? String.valueOf(idTipo) : null));

	    dto.setDescripcion(incidencia.getDescripcion());

	    if (incidencia.getFechaAlta() != null) {
	        dto.setFechaCreacion(new SimpleDateFormat(FECHA_PATTERN).format(incidencia.getFechaAlta()));
	    }

	    String usuario = !isBlank(incidencia.getNombreReporta())
	            ? incidencia.getNombreReporta()
	            : incidencia.getUsuarioAlta();

	    dto.setUsuarioCreacion(!isBlank(usuario) ? usuario : "USUARIO DESCONOCIDO");
	    dto.setCorreoUsuarioCreacion(!isBlank(incidencia.getCorreoReporta()) ? incidencia.getCorreoReporta() : "");

	    return dto;
	}


	private boolean cumpleFiltroTexto(String valor, String filtro) {
	    if (isBlank(filtro)) {
	        return true;
	    }
	    if (valor == null) {
	        return false;
	    }
	    return valor.contains(filtro.trim());
	}


	private Map<String, String> construirMapaNombreSitio() {
	    Map<String, String> mapa = new HashMap<String, String>();
	    try {
	        List<SitioDto> sitiosVisibles = obtenerListaSitiosOperacion();
	        if (sitiosVisibles != null) {
	            for (Object item : sitiosVisibles) {
	                if (item instanceof SitioDto) {
	                    SitioDto s = (SitioDto) item;
	                    if (s != null && !isBlank(s.getSitio())) {
	                        mapa.put(s.getSitio(), s.getNombre());
	                    }
	                }
	            }
	        }
	    } catch (Exception e) {
	        log.warn("Error construyendo mapa de sitios", e);
	    }
	    return mapa;
	}
	@SuppressWarnings("unchecked")
	private Map<String, String> construirMapaNombreSitioPorIds(Set<String> idsSitio) {
	    Map<String, String> mapa = new HashMap<String, String>();

	    if (entityManager == null || idsSitio == null || idsSitio.isEmpty()) {
	        return mapa;
	    }

	    List<String> ids = new ArrayList<String>();
	    for (String id : idsSitio) {
	        if (!isBlank(id)) {
	            ids.add(id.trim());
	        }
	    }
	    if (ids.isEmpty()) {
	        return mapa;
	    }

	    final int CHUNK = 900; 
	    for (int offset = 0; offset < ids.size(); offset += CHUNK) {
	        int toIndex = Math.min(offset + CHUNK, ids.size());
	        List<String> batch = ids.subList(offset, toIndex);

	        StringBuilder sql = new StringBuilder();
	        sql.append("SELECT SITIO, NOMBRE FROM BDDSEG01.T3SEGC_SITI WHERE SITIO IN (");
	        for (int i = 0; i < batch.size(); i++) {
	            if (i > 0) {
	                sql.append(",");
	            }
	            sql.append("?");
	        }
	        sql.append(")");

	        Query q = entityManager.createNativeQuery(sql.toString());
	        for (int i = 0; i < batch.size(); i++) {
	            q.setParameter(i + 1, batch.get(i));
	        }

	        List rows = q.getResultList();
	        if (rows == null) {
	            continue;
	        }

	        for (Object r : rows) {
	            if (!(r instanceof Object[])) {
	                continue;
	            }
	            Object[] row = (Object[]) r;

	            if (row.length < 2 || row[0] == null) {
	                continue;
	            }

	            String sitio = row[0].toString().trim();
	            String nombre = (row[1] != null) ? row[1].toString() : null;

	            if (!isBlank(sitio)) {
	                mapa.put(sitio, nombre);
	            }
	        }
	    }

	    return mapa;
	}


	private String resolverPendientePorId(Long idEstatus) {
	    if (idEstatus == null) {
	        return "-";
	    }

	    long v = idEstatus.longValue();

	    if (v == ESTATUS_CREADA) {
	        return "Mantenimiento";
	    }
	    if (v == ESTATUS_EN_ATENCION) {
	        return "Mantenimiento";
	    }

	    if (v == ESTATUS_RECHAZADA || v == ESTATUS_FINALIZADA) {
	        return "-";
	    }

	    return "-";
	}


	private Long mapEstatusEntradaAId(String estatus) {
		if (isBlank(estatus))
			return null;
		String e = estatus.trim().toUpperCase();
		if (e.contains("CREAD"))
			return ESTATUS_CREADA;
		if (e.contains("ATEN"))
			return ESTATUS_EN_ATENCION;
		if (e.contains("RECHAZ"))
			return ESTATUS_RECHAZADA;
		if (e.contains("FINAL"))
			return ESTATUS_FINALIZADA;
		return null;
	}

	private String mapEstatusIdAClave(Long idEstatus) {
		if (idEstatus == null)
			return null;
		long v = idEstatus.longValue();
		if (v == ESTATUS_CREADA)
			return "CREADA";
		if (v == ESTATUS_EN_ATENCION)
			return "EN ATENCI�N";
		if (v == ESTATUS_RECHAZADA)
			return "RECHAZADA";
		if (v == ESTATUS_FINALIZADA)
			return "FINALIZADA";
		return String.valueOf(v);
	}



	private boolean isBlank(String s) {
		return s == null || s.trim().isEmpty();
	}
}

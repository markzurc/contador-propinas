package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias;

import java.io.IOException;
import java.util.List;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaAdjuntoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaBitacoraDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaGestionDto;

public interface IIncidenciaService {

	class AdjuntoUi {
		private String nombre;
		private long tamanio;
		private byte[] bytes;

		public AdjuntoUi(String nombre, long tamanio, byte[] bytes) {
			this.nombre = nombre;
			this.tamanio = tamanio;
			this.bytes = bytes;
		}

		public String getNombre() {
			return nombre;
		}

		public long getTamanio() {
			return tamanio;
		}

		public byte[] getBytes() {
			return bytes;
		}
	}

	List<?> listarSitiosSuscritosParaAltaIncidencia(String concesionarioUsuario);

	Long crearIncidencia(String sitioCodigo, String tipo, String descripcion, List<AdjuntoUi> adjuntos,
			String usuarioCreacion, String correoUsuarioCreacion, String concesionarioCreacion);

	void validarAlta(String sitioCodigo, String tipo, String descripcion, List<AdjuntoUi> adjuntos);

	void avanzarIncidencia(Long idIncidencia, String accion, String comentario, Long idUsuarioMovimiento);

	void validarAdjunto(String nombre, String contentType, long size);

	List<IncidenciaAdjuntoDto> obtenerAdjuntosIncidencia(Long idIncidencia);

	List<?> listarSitiosEnOperacionVisibles();

	List<String> catalogoTiposIncidencia();

	long obtenerMaxBytesAdjunto();

	String generarFolioIncidencia(Long idIncidencia);

	int obtenerMaxArchivos();

	String obtenerRegexExtensiones();

	String obtenerFormatosHumanos();

	List<IncidenciaGestionDto> buscarIncidenciasMantenimiento(String folio, String sitioId, String estatus);

	List<IncidenciaGestionDto> buscarIncidenciasConcesionario(String folio, String sitioId, String estatus,
			String concesionario);

	List<IncidenciaBitacoraDto> obtenerBitacoraIncidencia(Long idIncidencia);

	void eliminarEvidenciaIncidencia(Long idIncidencia, String nombreArchivo, Long idUsuarioMovimiento)
			throws IOException;

	void adjuntarEvidenciaIncidencia(Long idIncidencia, AdjuntoUi adjunto, Long idUsuarioMovimiento) throws IOException;

	Long crearIncidenciaExternaCargaMasiva(String sitioCodigo, String tipo, String descripcion, String usuarioCreacion,
			String correoUsuarioCreacion, String concesionarioCreacion, String estatusInicial);

	byte[] leerBytesArchivo(String rutaDirectorio, String nombreArchivo) throws IOException;

	String obtenerCorreoExternoPorUsuario(Integer idUsuario, Integer idRol);
}
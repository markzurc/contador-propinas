package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.data.transformer;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.hibernate.transform.ResultTransformer;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.data.dto.UserSPMLDto;
/**
 * <h1>UserDetailsSpmlTransformer</h1>
 * <p>
 * </p>
 * @author hhernanm
 * @version 1.0
 * 
 *
 */
public class UserDetailsSpmlTransformer implements ResultTransformer{

	private static final long serialVersionUID = -5809668891609872640L;

	@Override
	public Object transformTuple(Object[] tuple, String[] aliases) {
		
		UserSPMLDto spmlDto = null;
	
		if(tuple.length != 0){
			Integer idUsuario = ((BigDecimal) tuple[0]).intValue();
			String nombre = (String)tuple[1];
			String apellidoPaterno = (String)tuple[2];
			String apellidoMaterno = (String)tuple[3];
			String usuarioCreacion = (String)tuple[4];
			Integer idTipoUsuario = ((BigDecimal)tuple[5]).intValue();
			Date fechaCreacion = (Date) tuple[6];
			
			String numeroEmpleado = (String)tuple[7];
			String idRegion = (String)tuple[8];
			String jefe = (String)tuple[9];
			String codigoJefe = (String)tuple[10];
			String puesto = (String)tuple[11];
			String codigoPuesto = (String)tuple[12];
			String correo = (String)tuple[13];
		
			Integer idRol = ((BigDecimal) tuple[14]).intValue();
			
			String apellidos  = (String)tuple[15];
			String centCost   = (String)tuple[16];
			String clavDepto  = (String)tuple[17];
			String clavDire   = (String)tuple[18];
			
			String clavGere     = (String)tuple[19];
			String clavSubdir   = (String)tuple[20];
			String departamento = (String)tuple[21];
			String descanso1    = (String)tuple[22];
			
			String descanso2	= (String)tuple[23];    
			String direccion	= (String)tuple[24];
			String fechaIngreso	= (String)tuple[25];
			String fullname		= (String)tuple[26];
			
			String gerencia		= (String)tuple[27];
			String region		= (String)tuple[28];
			String subdireccion	= (String)tuple[29];
			String spmlTipo		= (String)tuple[30];
			String turno		= (String)tuple[31];

			String ubicacion	= (String)tuple[32];
			String universal	= (String)tuple[33];
			String empresa		= (String)tuple[34];
			String folioSua		= (String)tuple[35];
			
			String tipoUsuarioIdm	= (String)tuple[36];
			String estatusIdm		= (String)tuple[37];
			String estatusRh		= (String)tuple[38];
			String mov1Idm			= (String)tuple[39];
			
			String mov2Idm	= (String)tuple[40];
			String mov3Idm	= (String)tuple[41];
			String mov4Idm	= (String)tuple[42];
			String mov5Idm	= (String)tuple[43];
			
			String rfc = (String)tuple[44];
			Integer idEstatus = ((BigDecimal) tuple[45]).intValue();
			Date fechaModificacion = (Date)tuple[46];
			String usuarioModificacion = (String)tuple[47];
			
			spmlDto = new UserSPMLDto(nombre, apellidoPaterno, apellidoMaterno,
					numeroEmpleado, idRol, idRegion, jefe, codigoJefe, puesto, 
					codigoPuesto, correo, fechaCreacion, usuarioCreacion,idUsuario,idTipoUsuario,
					apellidos, centCost , clavDepto, clavDire,
					clavGere, clavSubdir, departamento, descanso1,
					descanso2, direccion, fechaIngreso, fullname,
					gerencia, region, subdireccion, spmlTipo, turno,
					ubicacion, universal, empresa, folioSua,
					tipoUsuarioIdm, estatusIdm, estatusRh, mov1Idm,
					mov2Idm, mov3Idm, mov4Idm, mov5Idm,
					rfc, idEstatus,  fechaModificacion, usuarioModificacion);
			
		}
		return spmlDto;
		
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List collection) {
		return collection;
	}

}

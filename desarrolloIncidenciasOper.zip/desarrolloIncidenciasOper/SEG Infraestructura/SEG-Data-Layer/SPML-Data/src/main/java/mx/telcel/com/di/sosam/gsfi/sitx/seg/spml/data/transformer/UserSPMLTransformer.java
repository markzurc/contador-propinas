package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.data.transformer;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.hibernate.transform.ResultTransformer;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.data.dto.UserSPMLDto;

/**
 * <h1>UserSPMLTransformer</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 14/05/2015
 */
public class UserSPMLTransformer implements ResultTransformer {

	private static final long serialVersionUID = 1547454334923697746L;


	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List paramList) {
		return paramList;
	}

	@Override
	public Object transformTuple(Object[] rowData, String[] aliasNames) {
		String nombre = (String) rowData[0];
		String apellidoPaterno = (String) rowData[1];
		String apellidoMaterno = (String) rowData[2];
		String numeroEmpleado = (String) rowData[3];
		Integer idRol = ((BigDecimal) rowData[4]).intValue();
		
		String idRegion = (String) rowData[5];
		String jefe = (String) rowData[6];
		String codigoJefe = (String) rowData[7];
		String puesto = (String) rowData[8];
		
		String codigoPuesto = (String) rowData[9];
		String correo = (String) rowData[10];
		String usuarioCreacion = (String) rowData[11];
		Date fechaCreacion = (Date) rowData[12];
		
		String apellidos  = (String)rowData[13];
		String centCost   = (String)rowData[14];
		String clavDepto  = (String)rowData[15];
		String clavDire   = (String)rowData[16];
		
		String clavGere     = (String)rowData[17];
		String clavSubdir   = (String)rowData[18];
		String departamento = (String)rowData[19];
		String descanso1    = (String)rowData[20];
		
		String descanso2	= (String)rowData[21];    
		String direccion	= (String)rowData[22];
		String fechaIngreso	= (String)rowData[23];
		String fullname		= (String)rowData[24];
		
		String gerencia		= (String)rowData[25];
		String region		= (String)rowData[26];
		String subdireccion	= (String)rowData[27];
		String spmlTipo		= (String)rowData[28];
		String turno		= (String)rowData[29];

		String ubicacion	= (String)rowData[30];
		String universal	= (String)rowData[31];
		String empresa		= (String)rowData[32];
		String folioSua		= (String)rowData[33];
		
		String tipoUsuarioIdm	= (String)rowData[34];
		String estatusIdm		= (String)rowData[35];
		String estatusRh		= (String)rowData[36];
		String mov1Idm			= (String)rowData[37];
		
		String mov2Idm	= (String)rowData[38];
		String mov3Idm	= (String)rowData[39];
		String mov4Idm	= (String)rowData[40];
		String mov5Idm	= (String)rowData[41];
		
		
		return new UserSPMLDto(nombre, apellidoPaterno, apellidoMaterno, numeroEmpleado, 
				idRol, idRegion, jefe, codigoJefe, puesto, 
				codigoPuesto, correo, fechaCreacion, usuarioCreacion,	
				apellidos,  centCost,  clavDepto,  clavDire,
				clavGere,  clavSubdir,  departamento,  descanso1,
				descanso2,  direccion,  fechaIngreso,  fullname,
				gerencia,  region,  subdireccion,  spmlTipo,  turno,
				ubicacion,  universal,  empresa,  folioSua,
				tipoUsuarioIdm,  estatusIdm,  estatusRh,  mov1Idm,
				mov2Idm,  mov3Idm,  mov4Idm,  mov5Idm);
	}
}

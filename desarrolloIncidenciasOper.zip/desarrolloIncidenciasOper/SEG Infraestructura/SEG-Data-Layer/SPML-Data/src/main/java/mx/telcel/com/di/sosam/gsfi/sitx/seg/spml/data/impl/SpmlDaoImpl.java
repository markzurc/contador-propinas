package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.data.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoDatoUsuaInte;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoUsua;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.TsegcDatosinternoId;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.data.ISpmlDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.data.dto.UserSPMLDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.data.transformer.UserDetailsSpmlTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.data.transformer.UserSPMLTransformer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

/**
 * <h2> SpmlDaoImpl </h2>
 * 
 * <p>
 * 		The implementation class of {@link ISpmlDao} interface.
 * </p>
 * 
 * @author chcastro
 * @author hhernanm
 * @version 1.0
 * @since May 2015
 * @see {@link ISpmlDao} 
 *
 */

@Repository("spmlDao")
@Scope("prototype")
public class SpmlDaoImpl implements ISpmlDao {

	private Logger logger = LogManager.getLogger(SpmlDaoImpl.class);
	
	@PersistenceContext(unitName="entityManagerFactoryOVITSPML")
	protected EntityManager entityManager;
	private Session session = null;
	
	private static final String SELECT_INTERNAL_USER_BY_EMPLOYEE_NUMBRE = "TsegcUsuario.SELECT_INTERNAL_USER_BY_EMPLOYEE_NUMBRE";
	private static final String SELECT_INTERNAL_USERS_SPML = "TsegcUsuario.SELECT_INTERNAL_USERS_SPML";
	private static final String UPDATE_USER_ESTATUS =  "TsegcUsuario.UPDATE_USER_ESTATUS";
	private static final String SELECT_VALIDATE_USER = "TsegcUsuario.SELECT_VALIDATE_USER";
	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.data.ISpmlDao#createUserSPML(mx.com.telcel.inf.ds.sitx.ovit.common.data.entity.security.TsegcUsuario, mx.com.telcel.inf.ds.sitx.ovit.common.data.entity.security.TsegcDatosinterno)
	 */
	@Override
	public void createUserSPML(T7segoUsua tsegcUsuario, T7segoDatoUsuaInte tsegcDatosinterno) {
		logger.info("Ejecutando SpmlDaoImpl.createUserSPML");
		Session session = getSession();
		session.persist(tsegcUsuario);
		tsegcDatosinterno.setId(new TsegcDatosinternoId(tsegcUsuario.getIdUsuario()));
		session.persist(tsegcDatosinterno);
	}

	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.data.ISpmlDao#updateUserSPML(mx.com.telcel.inf.ds.sitx.ovit.common.data.entity.security.TsegcUsuario, mx.com.telcel.inf.ds.sitx.ovit.common.data.entity.security.TsegcDatosinterno)
	 */
	@Override
	public void updateUserSPML(T7segoUsua tsegcUsuario, T7segoDatoUsuaInte tsegcDatosinterno) {
		logger.info("Ejecutando SpmlDaoImpl.updateUserSPML");
		Session session = getSession();
		session.merge(tsegcUsuario);
		
		if(tsegcDatosinterno!=null){
			session.merge(tsegcDatosinterno);
		}
	}

	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.data.ISpmlDao#updateUserStatus(java.lang.Integer, java.lang.String)
	 */
	@Override
	public int updateUserStatus(Integer idEstatus, String numeroEmpleado) {
		logger.info("Ejecutando SpmlDaoImpl.updateUserStatus");
		Session session = getSession();
		
		Query query = session.
				getNamedQuery(UPDATE_USER_ESTATUS).
					setString("numeroEmpleado", numeroEmpleado).
					setInteger("idEstatus", idEstatus);
		return query.executeUpdate();
	}
	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.data.ISpmlDao#findUserSPMLbyEmplyeeNumber(java.lang.String)
	 */
	@Override
	public UserSPMLDto findUserSPMLbyEmplyeeNumber(String numeroEmpleado) {
		logger.info("Ejecutando SpmlDaoImpl.findUserSPMLbyEmplyeeNumbre");
		Session session = getSession();

		Query query = session
				.getNamedQuery(SpmlDaoImpl.SELECT_INTERNAL_USER_BY_EMPLOYEE_NUMBRE);
		query.setString("numeroEmpleado", numeroEmpleado).
			setResultTransformer(new UserSPMLTransformer());
		return (UserSPMLDto) query.uniqueResult();
	}

	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.data.ISpmlDao#findUsersSPML()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<UserSPMLDto> findUsersSPML() {
		logger.info("Ejecutando SpmlDaoImpl.findUserSPMLbyEmplyeeNumbre");
		Session session = getSession();

		Query query = session
				.getNamedQuery(SpmlDaoImpl.SELECT_INTERNAL_USERS_SPML);
		query.setResultTransformer(new UserSPMLTransformer());
		return query.list();
	}
	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.data.ISpmlDao#validateUser(java.lang.String)
	 */
	@Override
	public UserSPMLDto validateUser(String userName) {
		logger.info("Ejecutando UserDaoImpl.validateLogIn");
		Session session = getSession();
		Query query = session.
				getNamedQuery(SELECT_VALIDATE_USER).setString("numeroEmpleado", userName);
		query.setResultTransformer(new UserDetailsSpmlTransformer());
		
		UserSPMLDto userSPMLDto = (UserSPMLDto)query.uniqueResult();
			
		return userSPMLDto;
	}
	
	
	/**
	 * @return the session
	 */
	@Override
	public Session getSession() {
		if(session == null || !session.isOpen()){
			session = (Session) entityManager.getDelegate();
			logger.info("Nueva Sesion.");
		}
		return session;
	}

	/**
	 * @param session the session to set
	 */
	@Override
	public void setSession(Session session) {
		this.session = session;
	}

	

}

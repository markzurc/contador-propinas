package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.data;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoDatoUsuaInte;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoUsua;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.utils.session.ISession;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.data.dto.UserSPMLDto;

/**
 * <h2> ISpmlDao </h2>
 * 
 * <p>
 * 		ISpmlDao interface class DAO which contains the next methods.
 * </p>
 * 
 * @author chcastro
 * @author hhernanm
 * @version 1.0
 * @since May 2015
 */
public interface ISpmlDao extends ISession {

	/**
	 * <h3> createUserSPML </h3>
	 * <p>
	 * 		Method used for SPML in order to creates an internal user.
	 * </p>
	 * 
	 * @author chcastro
	 * @author hhernanm
	 * @param {@link T7segoUsua tsegcUsuario}
	 * @param {@link T7segoDatoUsuaInte tsegcDatosinterno}
	 */
	void createUserSPML(T7segoUsua tsegcUsuario, T7segoDatoUsuaInte tsegcDatosinterno);
	
	
	/**
	 * <h3> updateUserSPML </h3>
	 * <p>
	 * 		Method used for SPML in order to updates an internal user 
	 * 		information.
	 * </p> 
	 * 
	 * @author chcastro
	 * @author hhernanm
	 * @param {@link T7segoUsua tsegcUsuario} 
	 * @param {@link T7segoDatoUsuaInte tsegcDatosinterno} 
	 */
	void updateUserSPML(T7segoUsua tsegcUsuario, T7segoDatoUsuaInte tsegcDatosinterno);
	
	
	/**
	 * <h3> updateUserStatus </h3>
	 * <p>
	 * 		Method used for SPML in order to updates the status of 
	 * 		an internal user. Return the number of updated registers.
	 * </p> 
	 * 
	 * @author chcastro
	 * @author hhernanm
	 * @param {@link Integer idEstatus}  
	 * @param {@link String numeroEmpleado}
	 * @return {@link Integer}
	 */
	int updateUserStatus(Integer idEstatus, String numeroEmpleado);
	
	
	/**
	 * <h3> findUserSPMLbyEmplyeeNumber </h3>
	 * <p>
	 * 		Method used for SPML in order to find an internal user. 
	 * 		Return an {@link UserSPMLDto} object.
	 * </p> 
	 * 
	 * @author chcastro
	 * @author hhernanm
	 * @param {@link String numeroEmpleado}
	 * @return {@link UserSPMLDto}
	 */
	UserSPMLDto findUserSPMLbyEmplyeeNumber(String numeroEmpleado);
	
	
	
	/**
	 * <h3> findUsersSPML </h3>
	 * <p>
	 * 		Method used for SPML in order to find all the internal users. 
	 * 		Return a {@link List} of {@link UserSPMLDto} objects.
	 * </p>
	 * 
	 * @author chcastro
	 * @author hhernanm
	 * @return {@link List} <{@link UserSPMLDto}>
	 */
	List<UserSPMLDto> findUsersSPML();
	
	
	/**
	 * <h3> validateUser </h3>
	 * <p>
	 * 		Method used to validate an existing internal user.
	 * </p>
	 * 
	 * @author chcastro
	 * @author hhernanm
	 * @param userName
	 * @return {@link UserSPMLDto}
	 */
	UserSPMLDto validateUser(String userName);
	
}

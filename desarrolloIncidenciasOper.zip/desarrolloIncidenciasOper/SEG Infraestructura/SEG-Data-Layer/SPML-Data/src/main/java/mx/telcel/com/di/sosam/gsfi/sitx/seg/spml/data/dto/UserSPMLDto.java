package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.data.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * <h1>UserSPMLDto</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 14/05/2015
 */
public class UserSPMLDto implements Serializable {

	private static final long serialVersionUID = -774658724680568428L;
	
	private String nombre;
	private String apellidoPaterno;
	private String apellidoMaterno;
	private String numeroEmpleado;
	private Integer idRol;
	private String idRegion;
	private String jefe;
	private String codigoJefe;
	private String puesto;
	private String codigoPuesto;
	private String correo;
	private Date fechaCreacion;
	private String usuarioCreacion;
	private Integer idUsuario;
	private Integer idTipoUsuario;
	
	//nuevos campos spml
	private String apellidos;
	private String centCost;
	private String clavDepto;
	private String clavDire;
	private String clavGere;
	private String clavSubdir;
	private String departamento;
	private String descanso1;
	private String descanso2;
	private String direccion;
	private String fechaIngreso;
	private String fullname;
	private String gerencia;
	private String region;
	private String subdireccion;
	private String spmlTipo;
	private String turno;
	private String ubicacion;
	private String universal;
	private String empresa;
	private String folioSua;
	private String tipoUsuarioIdm;
	private String estatusIdm;
	private String estatusRh;
	private String mov1Idm;
	private String mov2Idm;
	private String mov3Idm;
	private String mov4Idm;
	private String mov5Idm;
	
	private String rfc;
	private Integer idEstatus;
	private Date fechaModificacion;
	private String usuarioModificacion;
	
	public UserSPMLDto() {
	}

		
	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the apellidoPaterno
	 */
	public String getApellidoPaterno() {
		return apellidoPaterno;
	}

	/**
	 * @param apellidoPaterno the apellidoPaterno to set
	 */
	public void setApellidoPaterno(String apellidoPaterno) {
		this.apellidoPaterno = apellidoPaterno;
	}

	/**
	 * @return the apellidoMaterno
	 */
	public String getApellidoMaterno() {
		return apellidoMaterno;
	}

	/**
	 * @param apellidoMaterno the apellidoMaterno to set
	 */
	public void setApellidoMaterno(String apellidoMaterno) {
		this.apellidoMaterno = apellidoMaterno;
	}

	/**
	 * @return the numeroEmpleado
	 */
	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}

	/**
	 * @param numeroEmpleado the numeroEmpleado to set
	 */
	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	/**
	 * @return the idRol
	 */
	public Integer getIdRol() {
		return idRol;
	}

	/**
	 * @param idRol the idRol to set
	 */
	public void setIdRol(Integer idRol) {
		this.idRol = idRol;
	}

	/**
	 * @return the idRegion
	 */
	public String getIdRegion() {
		return idRegion;
	}

	/**
	 * @param idRegion the idRegion to set
	 */
	public void setIdRegion(String idRegion) {
		this.idRegion = idRegion;
	}

	/**
	 * @return the jefe
	 */
	public String getJefe() {
		return jefe;
	}

	/**
	 * @param jefe the jefe to set
	 */
	public void setJefe(String jefe) {
		this.jefe = jefe;
	}

	/**
	 * @return the codigoJefe
	 */
	public String getCodigoJefe() {
		return codigoJefe;
	}

	/**
	 * @param codigoJefe the codigoJefe to set
	 */
	public void setCodigoJefe(String codigoJefe) {
		this.codigoJefe = codigoJefe;
	}

	/**
	 * @return the puesto
	 */
	public String getPuesto() {
		return puesto;
	}

	/**
	 * @param puesto the puesto to set
	 */
	public void setPuesto(String puesto) {
		this.puesto = puesto;
	}

	/**
	 * @return the codigoPuesto
	 */
	public String getCodigoPuesto() {
		return codigoPuesto;
	}

	/**
	 * @param codigoPuesto the codigoPuesto to set
	 */
	public void setCodigoPuesto(String codigoPuesto) {
		this.codigoPuesto = codigoPuesto;
	}

	/**
	 * @return the correo
	 */
	public String getCorreo() {
		return correo;
	}

	/**
	 * @param correo the correo to set
	 */
	public void setCorreo(String correo) {
		this.correo = correo;
	}

	/**
	 * @return the fechaCreacion
	 */
	public Date getFechaCreacion() {
		return fechaCreacion!=null?(Date)fechaCreacion.clone():null;
	}

	/**
	 * @param fechaCreacion the fechaCreacion to set
	 */
	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion!=null?(Date)fechaCreacion.clone():null;
	}

	/**
	 * @return the usuarioCreacion
	 */
	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	/**
	 * @param usuarioCreacion the usuarioCreacion to set
	 */
	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	/**
	 * @return the idUsuario
	 */
	public Integer getIdUsuario() {
		return idUsuario;
	}

	/**
	 * @param idUsuario the idUsuario to set
	 */
	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	/**
	 * @return the idTipoUsuario
	 */
	public Integer getIdTipoUsuario() {
		return idTipoUsuario;
	}

	/**
	 * @param idTipoUsuario the idTipoUsuario to set
	 */
	public void setIdTipoUsuario(Integer idTipoUsuario) {
		this.idTipoUsuario = idTipoUsuario;
	}

	/**
	 * @return the apellidos
	 */
	public String getApellidos() {
		return apellidos;
	}

	/**
	 * @param apellidos the apellidos to set
	 */
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	/**
	 * @return the centCost
	 */
	public String getCentCost() {
		return centCost;
	}

	/**
	 * @param centCost the centCost to set
	 */
	public void setCentCost(String centCost) {
		this.centCost = centCost;
	}

	/**
	 * @return the clavDepto
	 */
	public String getClavDepto() {
		return clavDepto;
	}

	/**
	 * @param clavDepto the clavDepto to set
	 */
	public void setClavDepto(String clavDepto) {
		this.clavDepto = clavDepto;
	}

	/**
	 * @return the clavDire
	 */
	public String getClavDire() {
		return clavDire;
	}

	/**
	 * @param clavDire the clavDire to set
	 */
	public void setClavDire(String clavDire) {
		this.clavDire = clavDire;
	}

	/**
	 * @return the clavGere
	 */
	public String getClavGere() {
		return clavGere;
	}

	/**
	 * @param clavGere the clavGere to set
	 */
	public void setClavGere(String clavGere) {
		this.clavGere = clavGere;
	}

	/**
	 * @return the clavSubdir
	 */
	public String getClavSubdir() {
		return clavSubdir;
	}

	/**
	 * @param clavSubdir the clavSubdir to set
	 */
	public void setClavSubdir(String clavSubdir) {
		this.clavSubdir = clavSubdir;
	}

	/**
	 * @return the departamento
	 */
	public String getDepartamento() {
		return departamento;
	}

	/**
	 * @param departamento the departamento to set
	 */
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	/**
	 * @return the descanso1
	 */
	public String getDescanso1() {
		return descanso1;
	}

	/**
	 * @param descanso1 the descanso1 to set
	 */
	public void setDescanso1(String descanso1) {
		this.descanso1 = descanso1;
	}

	/**
	 * @return the descanso2
	 */
	public String getDescanso2() {
		return descanso2;
	}

	/**
	 * @param descanso2 the descanso2 to set
	 */
	public void setDescanso2(String descanso2) {
		this.descanso2 = descanso2;
	}

	/**
	 * @return the direccion
	 */
	public String getDireccion() {
		return direccion;
	}

	/**
	 * @param direccion the direccion to set
	 */
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	/**
	 * @return the fechaIngreso
	 */
	public String getFechaIngreso() {
		return fechaIngreso;
	}

	/**
	 * @param fechaIngreso the fechaIngreso to set
	 */
	public void setFechaIngreso(String fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}

	/**
	 * @return the fullname
	 */
	public String getFullname() {
		return fullname;
	}

	/**
	 * @param fullname the fullname to set
	 */
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	/**
	 * @return the gerencia
	 */
	public String getGerencia() {
		return gerencia;
	}

	/**
	 * @param gerencia the gerencia to set
	 */
	public void setGerencia(String gerencia) {
		this.gerencia = gerencia;
	}

	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}

	/**
	 * @param region the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}

	/**
	 * @return the subdireccion
	 */
	public String getSubdireccion() {
		return subdireccion;
	}

	/**
	 * @param subdireccion the subdireccion to set
	 */
	public void setSubdireccion(String subdireccion) {
		this.subdireccion = subdireccion;
	}

	/**
	 * @return the spmlTipo
	 */
	public String getSpmlTipo() {
		return spmlTipo;
	}

	/**
	 * @param spmlTipo the spmlTipo to set
	 */
	public void setSpmlTipo(String spmlTipo) {
		this.spmlTipo = spmlTipo;
	}

	/**
	 * @return the turno
	 */
	public String getTurno() {
		return turno;
	}

	/**
	 * @param turno the turno to set
	 */
	public void setTurno(String turno) {
		this.turno = turno;
	}

	/**
	 * @return the ubicacion
	 */
	public String getUbicacion() {
		return ubicacion;
	}

	/**
	 * @param ubicacion the ubicacion to set
	 */
	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}

	/**
	 * @return the universal
	 */
	public String getUniversal() {
		return universal;
	}

	/**
	 * @param universal the universal to set
	 */
	public void setUniversal(String universal) {
		this.universal = universal;
	}

	/**
	 * @return the empresa
	 */
	public String getEmpresa() {
		return empresa;
	}

	/**
	 * @param empresa the empresa to set
	 */
	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	/**
	 * @return the folioSua
	 */
	public String getFolioSua() {
		return folioSua;
	}

	/**
	 * @param folioSua the folioSua to set
	 */
	public void setFolioSua(String folioSua) {
		this.folioSua = folioSua;
	}

	/**
	 * @return the tipoUsuarioIdm
	 */
	public String getTipoUsuarioIdm() {
		return tipoUsuarioIdm;
	}

	/**
	 * @param tipoUsuarioIdm the tipoUsuarioIdm to set
	 */
	public void setTipoUsuarioIdm(String tipoUsuarioIdm) {
		this.tipoUsuarioIdm = tipoUsuarioIdm;
	}

	/**
	 * @return the estatusIdm
	 */
	public String getEstatusIdm() {
		return estatusIdm;
	}

	/**
	 * @param estatusIdm the estatusIdm to set
	 */
	public void setEstatusIdm(String estatusIdm) {
		this.estatusIdm = estatusIdm;
	}

	/**
	 * @return the estatusRh
	 */
	public String getEstatusRh() {
		return estatusRh;
	}

	/**
	 * @param estatusRh the estatusRh to set
	 */
	public void setEstatusRh(String estatusRh) {
		this.estatusRh = estatusRh;
	}

	/**
	 * @return the mov1Idm
	 */
	public String getMov1Idm() {
		return mov1Idm;
	}

	/**
	 * @param mov1Idm the mov1Idm to set
	 */
	public void setMov1Idm(String mov1Idm) {
		this.mov1Idm = mov1Idm;
	}

	/**
	 * @return the mov2Idm
	 */
	public String getMov2Idm() {
		return mov2Idm;
	}

	/**
	 * @param mov2Idm the mov2Idm to set
	 */
	public void setMov2Idm(String mov2Idm) {
		this.mov2Idm = mov2Idm;
	}

	/**
	 * @return the mov3Idm
	 */
	public String getMov3Idm() {
		return mov3Idm;
	}

	/**
	 * @param mov3Idm the mov3Idm to set
	 */
	public void setMov3Idm(String mov3Idm) {
		this.mov3Idm = mov3Idm;
	}

	/**
	 * @return the mov4Idm
	 */
	public String getMov4Idm() {
		return mov4Idm;
	}

	/**
	 * @param mov4Idm the mov4Idm to set
	 */
	public void setMov4Idm(String mov4Idm) {
		this.mov4Idm = mov4Idm;
	}

	/**
	 * @return the mov5Idm
	 */
	public String getMov5Idm() {
		return mov5Idm;
	}

	/**
	 * @param mov5Idm the mov5Idm to set
	 */
	public void setMov5Idm(String mov5Idm) {
		this.mov5Idm = mov5Idm;
	}
	

	/**
	 * @return the rfc
	 */
	public String getRfc() {
		return rfc;
	}

	/**
	 * @param rfc the rfc to set
	 */
	public void setRfc(String rfc) {
		this.rfc = rfc;
	}

	/**
	 * @return the idEstatus
	 */
	public Integer getIdEstatus() {
		return idEstatus;
	}

	/**
	 * @param idEstatus the idEstatus to set
	 */
	public void setIdEstatus(Integer idEstatus) {
		this.idEstatus = idEstatus;
	}

	/**
	 * @return the fechaModificacion
	 */
	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	/**
	 * @param fechaModificacion the fechaModificacion to set
	 */
	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	/**
	 * @return the usuarioModificacion
	 */
	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}

	/**
	 * @param usuarioModificacion the usuarioModificacion to set
	 */
	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}

	/**
	 * @param nombre
	 * @param apellidoPaterno
	 * @param apellidoMaterno
	 * @param numeroEmpleado
	 * @param idRol
	 * @param idRegion
	 * @param jefe
	 * @param codigoJefe
	 * @param puesto
	 * @param codigoPuesto
	 * @param correo
	 * @param fechaCreacion
	 * @param usuarioCreacion
	 * @param idUsuario
	 * @param idTipoUsuario
	 * @param apellidos
	 * @param centCost
	 * @param clavDepto
	 * @param clavDire
	 * @param clavGere
	 * @param clavSubdir
	 * @param departamento
	 * @param descanso1
	 * @param descanso2
	 * @param direccion
	 * @param fechaIngreso
	 * @param fullname
	 * @param gerencia
	 * @param region
	 * @param subdireccion
	 * @param spmlTipo
	 * @param turno
	 * @param ubicacion
	 * @param universal
	 * @param empresa
	 * @param folioSua
	 * @param tipoUsuarioIdm
	 * @param estatusIdm
	 * @param estatusRh
	 * @param mov1Idm
	 * @param mov2Idm
	 * @param mov3Idm
	 * @param mov4Idm
	 * @param mov5Idm
	 * @param rfc
	 * @param idEstatus
	 * @param fechaLogueo
	 * @param fechaModificacion
	 * @param usuarioModificacion
	 */
	public UserSPMLDto(String nombre, String apellidoPaterno, String apellidoMaterno,
			String numeroEmpleado, Integer idRol, String idRegion, String jefe, String codigoJefe, String puesto, 
			String codigoPuesto, String correo, Date fechaCreacion, String usuarioCreacion, Integer idUsuario, Integer idTipoUsuario,
			String apellidos, String centCost, String clavDepto, String clavDire,
			String clavGere, String clavSubdir, String departamento, String descanso1,
			String descanso2, String direccion, String fechaIngreso, String fullname,
			String gerencia, String region, String subdireccion, String spmlTipo, String turno,
			String ubicacion, String universal, String empresa, String folioSua,
			String tipoUsuarioIdm, String estatusIdm, String estatusRh, String mov1Idm,
			String mov2Idm, String mov3Idm, String mov4Idm, String mov5Idm,
			String rfc, Integer idEstatus, Date fechaModificacion, String usuarioModificacion) {
		super();
		this.nombre = nombre;
		this.apellidoPaterno = apellidoPaterno;
		this.apellidoMaterno = apellidoMaterno;
		this.numeroEmpleado = numeroEmpleado;
		this.idRol = idRol;
		this.idRegion = idRegion;
		this.jefe = jefe;
		this.codigoJefe = codigoJefe;
		this.puesto = puesto;
		this.codigoPuesto = codigoPuesto;
		this.correo = correo;
		this.fechaCreacion = fechaCreacion;
		this.usuarioCreacion = usuarioCreacion;
		this.idUsuario = idUsuario;
		this.idTipoUsuario = idTipoUsuario;
		this.apellidos = apellidos;
		this.centCost = centCost;
		this.clavDepto = clavDepto;
		this.clavDire = clavDire;
		this.clavGere = clavGere;
		this.clavSubdir = clavSubdir;
		this.departamento = departamento;
		this.descanso1 = descanso1;
		this.descanso2 = descanso2;
		this.direccion = direccion;
		this.fechaIngreso = fechaIngreso;
		this.fullname = fullname;
		this.gerencia = gerencia;
		this.region = region;
		this.subdireccion = subdireccion;
		this.spmlTipo = spmlTipo;
		this.turno = turno;
		this.ubicacion = ubicacion;
		this.universal = universal;
		this.empresa = empresa;
		this.folioSua = folioSua;
		this.tipoUsuarioIdm = tipoUsuarioIdm;
		this.estatusIdm = estatusIdm;
		this.estatusRh = estatusRh;
		this.mov1Idm = mov1Idm;
		this.mov2Idm = mov2Idm;
		this.mov3Idm = mov3Idm;
		this.mov4Idm = mov4Idm;
		this.mov5Idm = mov5Idm;
		this.rfc = rfc;
		this.idEstatus = idEstatus;
		this.fechaModificacion = fechaModificacion;
		this.usuarioModificacion = usuarioModificacion;
	}

	
	
	/**
	 * @param nombre
	 * @param apellidoPaterno
	 * @param apellidoMaterno
	 * @param numeroEmpleado
	 * @param idRol
	 * @param idRegion
	 * @param jefe
	 * @param codigoJefe
	 * @param puesto
	 * @param codigoPuesto
	 * @param correo
	 * @param fechaCreacion
	 * @param usuarioCreacion
	 * @param idTipoUsuario
	 * @param apellidos
	 * @param centCost
	 * @param clavDepto
	 * @param clavDire
	 * @param clavGere
	 * @param clavSubdir
	 * @param departamento
	 * @param descanso1
	 * @param descanso2
	 * @param direccion
	 * @param fechaIngreso
	 * @param fullname
	 * @param gerencia
	 * @param region
	 * @param subdireccion
	 * @param spmlTipo
	 * @param turno
	 * @param ubicacion
	 * @param universal
	 * @param empresa
	 * @param folioSua
	 * @param tipoUsuarioIdm
	 * @param estatusIdm
	 * @param estatusRh
	 * @param mov1Idm
	 * @param mov2Idm
	 * @param mov3Idm
	 * @param mov4Idm
	 * @param mov5Idm
	 */
	public UserSPMLDto(
			String nombre, String apellidoPaterno, String apellidoMaterno, String numeroEmpleado,
			Integer idRol, String idRegion, String jefe, String codigoJefe, String puesto, 
			String codigoPuesto, String correo, Date fechaCreacion, String usuarioCreacion,
			String apellidos, String centCost, String clavDepto, String clavDire,
			String clavGere, String clavSubdir, String departamento, String descanso1,
			String descanso2, String direccion, String fechaIngreso, String fullname,
			String gerencia, String region, String subdireccion, String spmlTipo, String turno,
			String ubicacion, String universal, String empresa, String folioSua,
			String tipoUsuarioIdm, String estatusIdm, String estatusRh, String mov1Idm,
			String mov2Idm, String mov3Idm, String mov4Idm, String mov5Idm) {
		super();
		this.nombre = nombre;
		this.apellidoPaterno = apellidoPaterno;
		this.apellidoMaterno = apellidoMaterno;
		this.numeroEmpleado = numeroEmpleado;
		this.idRol = idRol;
		this.idRegion = idRegion;
		this.jefe = jefe;
		this.codigoJefe = codigoJefe;
		this.puesto = puesto;
		this.codigoPuesto = codigoPuesto;
		this.correo = correo;
		this.fechaCreacion = fechaCreacion;
		this.usuarioCreacion = usuarioCreacion;
		this.apellidos = apellidos;
		this.centCost = centCost;
		this.clavDepto = clavDepto;
		this.clavDire = clavDire;
		this.clavGere = clavGere;
		this.clavSubdir = clavSubdir;
		this.departamento = departamento;
		this.descanso1 = descanso1;
		this.descanso2 = descanso2;
		this.direccion = direccion;
		this.fechaIngreso = fechaIngreso;
		this.fullname = fullname;
		this.gerencia = gerencia;
		this.region = region;
		this.subdireccion = subdireccion;
		this.spmlTipo = spmlTipo;
		this.turno = turno;
		this.ubicacion = ubicacion;
		this.universal = universal;
		this.empresa = empresa;
		this.folioSua = folioSua;
		this.tipoUsuarioIdm = tipoUsuarioIdm;
		this.estatusIdm = estatusIdm;
		this.estatusRh = estatusRh;
		this.mov1Idm = mov1Idm;
		this.mov2Idm = mov2Idm;
		this.mov3Idm = mov3Idm;
		this.mov4Idm = mov4Idm;
		this.mov5Idm = mov5Idm;
	}
}

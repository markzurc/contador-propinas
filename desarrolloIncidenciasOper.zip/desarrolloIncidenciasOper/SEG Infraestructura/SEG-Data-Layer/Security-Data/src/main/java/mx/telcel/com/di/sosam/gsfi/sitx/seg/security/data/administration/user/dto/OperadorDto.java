package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @author VI7XXE0
 *
 */
public class OperadorDto implements Serializable {

	private static final long serialVersionUID = -988003283087250019L;

	private String grupoOperador;
	private String descripcion;

	
	public OperadorDto(String grupoOperador, String descripcion) {
		this.grupoOperador = grupoOperador;
		this.descripcion = descripcion;
	}

	public String getGrupoOperador() {
		return grupoOperador;
	}

	public void setGrupoOperador(String grupoOperador) {
		this.grupoOperador = grupoOperador;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.transfomer;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.hibernate.transform.ResultTransformer;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.ReportUserDto;

/**
 * 
 * <h1>ReporUserTransformer</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 21/04/2015
 *
 */
public class ReportUserTransformer implements ResultTransformer {

	private static final long serialVersionUID = -2716704721283262464L;

	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List paramList) {
		return paramList;
	}

	@Override
	public Object transformTuple(Object[] rowData, String[] aliasNames) {
		BigDecimal idUsuario = (BigDecimal) rowData[0];
		String nombre = (String) rowData[1];
		String apellidoPaterno = (String) rowData[2];
		String apellidoMaterno = (String) rowData[3];
		String correo = (String) rowData[4];
		String concesionario = (String) rowData[5]; 
		String tipoUsuario = (String) rowData[6];
		String estatus = (String) rowData[7];
		String pass = (String) rowData[8];
		String idOperador = (String) rowData[9];
		
		ReportUserDto reportUserDto = new ReportUserDto(idUsuario.intValue(), 
				nombre, apellidoPaterno, apellidoMaterno, correo, concesionario, tipoUsuario, 
				estatus, pass, idOperador);
		
		return reportUserDto;
	}

}

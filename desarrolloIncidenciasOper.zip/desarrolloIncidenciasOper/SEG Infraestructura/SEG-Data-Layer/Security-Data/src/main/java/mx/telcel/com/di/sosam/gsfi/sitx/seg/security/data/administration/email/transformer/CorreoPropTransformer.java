package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.email.transformer;

import java.util.List;

import org.hibernate.transform.ResultTransformer;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.email.dto.CorreoPropDto;

public class CorreoPropTransformer implements ResultTransformer {

	private static final long serialVersionUID = -840804576881746695L;

	@Override
	public Object transformTuple(Object[] tuple, String[] aliases) {
		CorreoPropDto correoProp = new CorreoPropDto();
		correoProp.setCve(this.checkStrNotNull(tuple[0]));
		correoProp.setValor(this.checkStrNotNull(tuple[1]));
		
		return correoProp;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List collection) {
		return collection;
	}
	
	private String checkStrNotNull(Object object) {
		return null != object ? object.toString() : "";
	}

}

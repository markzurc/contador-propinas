package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.email.dto;

import java.io.Serializable;

public class CorreoNotiDto implements Serializable{
	
	private static final long serialVersionUID = -9180434339747492299L;
	
	private Integer producto;
	private String productoDesc;
	private String correoDest;
	private String correoCc;
	private Integer estado;
	
	public CorreoNotiDto(Integer producto, String productoDesc, String correoDest, String correoCc, Integer estado) {
		super();
		this.producto = producto;
		this.productoDesc = productoDesc;
		this.correoDest = correoDest;
		this.correoCc = correoCc;
		this.estado = estado;
	}
	
	public CorreoNotiDto() {
		
	}

	public Integer getProducto() {
		return producto;
	}
	
	public void setProducto(Integer producto) {
		this.producto = producto;
	}
	
	public String getProductoDesc() {
		return productoDesc;
	}
	
	public void setProductoDesc(String productoDesc) {
		this.productoDesc = productoDesc;
	}
	
	public String getCorreoDest() {
		return correoDest;
	}
	
	public void setCorreoDest(String correoDest) {
		this.correoDest = correoDest;
	}
	
	public String getCorreoCc() {
		return correoCc;
	}
	
	public void setCorreoCc(String correoCc) {
		this.correoCc = correoCc;
	}
	
	public Integer getEstado() {
		return estado;
	}
	
	public void setEstado(Integer estado) {
		this.estado = estado;
	}
	
}

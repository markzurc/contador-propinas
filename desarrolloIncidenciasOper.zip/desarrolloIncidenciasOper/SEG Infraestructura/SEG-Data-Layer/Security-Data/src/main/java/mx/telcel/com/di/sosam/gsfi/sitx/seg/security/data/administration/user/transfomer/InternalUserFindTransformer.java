package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.transfomer;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcApli;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcRol;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoDatoUsuaInte;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoUsua;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segrCapliCrolRapti;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.InternalUserFindDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.SingleInternalUserDto;

import org.hibernate.transform.ResultTransformer;

public class InternalUserFindTransformer implements ResultTransformer {

	private static final long serialVersionUID = -8126727299760219838L;

	@SuppressWarnings("unchecked")
	@Override
	public List<InternalUserFindDto> transformList(@SuppressWarnings("rawtypes") List paramList) {
		if(paramList.size()>0){
			Set<T7segrCapliCrolRapti> tsegrRolAcls = new LinkedHashSet<T7segrCapliCrolRapti>();
			List<T7segrCapliCrolRapti> lstTsegrRolAcls;
			Set<T7segcApli> tsegcAplicacions = new LinkedHashSet<T7segcApli>();
			List<T7segcApli> lstTsegcAplicacions;
			for(Object tempObject : paramList){
				tsegrRolAcls.add(((SingleInternalUserDto) tempObject).getTsegrRolAcl());
				tsegcAplicacions.add(((SingleInternalUserDto) tempObject).getTsegcAplicacions());
			}
			SingleInternalUserDto singleInternalUserDto = (SingleInternalUserDto) paramList.get(0);
			lstTsegrRolAcls = new ArrayList<T7segrCapliCrolRapti>(tsegrRolAcls);
			lstTsegcAplicacions = new ArrayList<T7segcApli>(tsegcAplicacions);
			List<InternalUserFindDto> lstUserFindDtos = new ArrayList<InternalUserFindDto>(1);
			lstUserFindDtos.add(new InternalUserFindDto(singleInternalUserDto.getTsegcUsuario(), 
					singleInternalUserDto.getTsegcDatosinterno(), singleInternalUserDto.getTsegcRol(), 
					lstTsegrRolAcls, lstTsegcAplicacions));
			return lstUserFindDtos;
		}
		return paramList;
	}

	@Override
	public Object transformTuple(Object[] rowData, String[] aliasNames) {
		T7segoUsua tsegcUsuario = (T7segoUsua) rowData[0];
		T7segoDatoUsuaInte tsegcDatosinterno = (T7segoDatoUsuaInte) rowData[1];
		T7segcRol tsegcRol = (T7segcRol) rowData[2];
		T7segrCapliCrolRapti tsegrRolAcl = (T7segrCapliCrolRapti) rowData[3];
		T7segcApli tsegcAplicacion = (T7segcApli) rowData[4];
		SingleInternalUserDto singleInternalUserDto = new SingleInternalUserDto(tsegcUsuario, tsegcDatosinterno, 
				tsegcRol, tsegrRolAcl, tsegcAplicacion);
		
		return singleInternalUserDto;
	}

}

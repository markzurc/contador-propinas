package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto;

import java.io.Serializable;
import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcApli;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoDatoUsuaExte;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoDatoUsuaInte;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoUsua;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segrCapliCrolRapti;

/**
 * 
 * <h1>ExternalUserFindDto</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 23/04/2015
 *
 */
public class ExternalUserFindDto implements Serializable{

	private static final long serialVersionUID = -4781079157595126196L;
	
	private T7segoUsua tsegcUsuario;
	private T7segoDatoUsuaExte tsegcDatosexterno;
	private T7segoDatoUsuaInte tsegcDatosinterno;
	private T7segoUsua tsegcUsuarioResponsable;
	private List<T7segrCapliCrolRapti> tsegrRolAcl;
	private List<T7segcApli> tsegcAplicacions;
	
	public ExternalUserFindDto() {
	}

	/**
	 * @param tsegcUsuario
	 * @param tsegcDatosexterno
	 * @param tsegcDatosinterno
	 * @param tsegcUsuarioResponsable
	 * @param tsegrRolAcl
	 * @param tsegcAplicacions
	 */
	public ExternalUserFindDto(T7segoUsua tsegcUsuario,
			T7segoDatoUsuaExte tsegcDatosexterno,
			T7segoDatoUsuaInte tsegcDatosinterno,
			T7segoUsua tsegcUsuarioResponsable,
			List<T7segrCapliCrolRapti> tsegrRolAcl,
			List<T7segcApli> tsegcAplicacions) {
		super();
		this.tsegcUsuario = tsegcUsuario;
		this.tsegcDatosexterno = tsegcDatosexterno;
		this.tsegcDatosinterno = tsegcDatosinterno;
		this.tsegcUsuarioResponsable = tsegcUsuarioResponsable;
		this.tsegrRolAcl = tsegrRolAcl;
		this.tsegcAplicacions = tsegcAplicacions;
	}

	/**
	 * @return the tsegcUsuario
	 */
	public T7segoUsua getTsegcUsuario() {
		return tsegcUsuario;
	}

	/**
	 * @param tsegcUsuario the tsegcUsuario to set
	 */
	public void setTsegcUsuario(T7segoUsua tsegcUsuario) {
		this.tsegcUsuario = tsegcUsuario;
	}

	/**
	 * @return the tsegcDatosexterno
	 */
	public T7segoDatoUsuaExte getTsegcDatosexterno() {
		return tsegcDatosexterno;
	}

	/**
	 * @param tsegcDatosexterno the tsegcDatosexterno to set
	 */
	public void setTsegcDatosexterno(T7segoDatoUsuaExte tsegcDatosexterno) {
		this.tsegcDatosexterno = tsegcDatosexterno;
	}

	/**
	 * @return the tsegcDatosinterno
	 */
	public T7segoDatoUsuaInte getTsegcDatosinterno() {
		return tsegcDatosinterno;
	}

	/**
	 * @param tsegcDatosinterno the tsegcDatosinterno to set
	 */
	public void setTsegcDatosinterno(T7segoDatoUsuaInte tsegcDatosinterno) {
		this.tsegcDatosinterno = tsegcDatosinterno;
	}

	/**
	 * @return the tsegcUsuarioResponsable
	 */
	public T7segoUsua getTsegcUsuarioResponsable() {
		return tsegcUsuarioResponsable;
	}

	/**
	 * @param tsegcUsuarioResponsable the tsegcUsuarioResponsable to set
	 */
	public void setTsegcUsuarioResponsable(T7segoUsua tsegcUsuarioResponsable) {
		this.tsegcUsuarioResponsable = tsegcUsuarioResponsable;
	}

	/**
	 * @return the tsegrRolAcl
	 */
	public List<T7segrCapliCrolRapti> getTsegrRolAcl() {
		return tsegrRolAcl;
	}

	/**
	 * @param tsegrRolAcl the tsegrRolAcl to set
	 */
	public void setTsegrRolAcl(List<T7segrCapliCrolRapti> tsegrRolAcl) {
		this.tsegrRolAcl = tsegrRolAcl;
	}

	/**
	 * @return the tsegcAplicacions
	 */
	public List<T7segcApli> getTsegcAplicacions() {
		return tsegcAplicacions;
	}

	/**
	 * @param tsegcAplicacions the tsegcAplicacions to set
	 */
	public void setTsegcAplicacions(List<T7segcApli> tsegcAplicacions) {
		this.tsegcAplicacions = tsegcAplicacions;
	}
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.email.dto;

import java.io.Serializable;

public class CorreoPropDto implements Serializable{

	private static final long serialVersionUID = 3810356154056494903L;
	
	private String cve;
	private String valor;

	public CorreoPropDto(String clave, String valor) {
		super();
		this.cve = clave;
		this.valor = valor;
	}

	public CorreoPropDto() {

	}

	public String getCve() {
		return cve;
	}

	public void setCve(String cve) {
		this.cve = cve;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

}

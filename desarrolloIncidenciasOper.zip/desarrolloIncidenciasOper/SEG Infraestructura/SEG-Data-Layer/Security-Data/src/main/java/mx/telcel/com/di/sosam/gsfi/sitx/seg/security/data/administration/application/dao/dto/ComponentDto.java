/**
 * 
 */
package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.application.dao.dto;

import java.io.Serializable;

/**
 * @author VI7XXE0
 *
 */
public class ComponentDto implements Serializable {

	private static final long serialVersionUID = -988003283087250019L;

	private Integer idComponente;
	private String flujo;
	private Integer idPadre;
	private String nombre;
	private String descripcion;
	private Integer idTipoComponente;
	private Integer idAplicacion;
	private String valorComponente;
	
	public ComponentDto() {
	}

	/**
	 * @param idComponente
	 * @param flujo
	 * @param idPadre
	 * @param nombre
	 * @param descripcion
	 * @param idTipoComponente
	 * @param idAplicacion
	 * @param valorComponente
	 */
	public ComponentDto(Integer idComponente, String flujo, Integer idPadre,
			String nombre, String descripcion, Integer idTipoComponente,
			Integer idAplicacion, String valorComponente) {
		super();
		this.idComponente = idComponente;
		this.flujo = flujo;
		this.idPadre = idPadre;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.idTipoComponente = idTipoComponente;
		this.idAplicacion = idAplicacion;
		this.valorComponente = valorComponente;
	}

	/**
	 * @return the idComponente
	 */
	public Integer getIdComponente() {
		return idComponente;
	}

	/**
	 * @param idComponente the idComponente to set
	 */
	public void setIdComponente(Integer idComponente) {
		this.idComponente = idComponente;
	}

	/**
	 * @return the flujo
	 */
	public String getFlujo() {
		return flujo;
	}

	/**
	 * @param flujo the flujo to set
	 */
	public void setFlujo(String flujo) {
		this.flujo = flujo;
	}

	/**
	 * @return the idPadre
	 */
	public Integer getIdPadre() {
		return idPadre;
	}

	/**
	 * @param idPadre the idPadre to set
	 */
	public void setIdPadre(Integer idPadre) {
		this.idPadre = idPadre;
	}

	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}

	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	/**
	 * @return the idTipoComponente
	 */
	public Integer getIdTipoComponente() {
		return idTipoComponente;
	}

	/**
	 * @param idTipoComponente the idTipoComponente to set
	 */
	public void setIdTipoComponente(Integer idTipoComponente) {
		this.idTipoComponente = idTipoComponente;
	}

	/**
	 * @return the idAplicacion
	 */
	public Integer getIdAplicacion() {
		return idAplicacion;
	}

	/**
	 * @param idAplicacion the idAplicacion to set
	 */
	public void setIdAplicacion(Integer idAplicacion) {
		this.idAplicacion = idAplicacion;
	}

	/**
	 * @return the valorComponente
	 */
	public String getValorComponente() {
		return valorComponente;
	}

	/**
	 * @param valorComponente the valorComponente to set
	 */
	public void setValorComponente(String valorComponente) {
		this.valorComponente = valorComponente;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ComponentDto [idComponente=");
		builder.append(idComponente);
		builder.append(", flujo=");
		builder.append(flujo);
		builder.append(", idPadre=");
		builder.append(idPadre);
		builder.append(", nombre=");
		builder.append(nombre);
		builder.append(", descripcion=");
		builder.append(descripcion);
		builder.append(", idTipoComponente=");
		builder.append(idTipoComponente);
		builder.append(", idAplicacion=");
		builder.append(idAplicacion);
		builder.append(", valorComponente=");
		builder.append(valorComponente);
		builder.append("]");
		return builder.toString();
	}
	
	
	
	
	
}

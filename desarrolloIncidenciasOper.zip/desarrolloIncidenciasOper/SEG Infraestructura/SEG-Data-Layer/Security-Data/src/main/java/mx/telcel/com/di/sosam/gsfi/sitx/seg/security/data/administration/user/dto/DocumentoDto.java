package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @author VI7XXE0
 *
 */
public class DocumentoDto implements Serializable {

	private static final long serialVersionUID = -988003283087250019L;

	private Integer idUsuario;
	private Integer idDocumento;
	private Date fechaCarga;
	private String ruta;
	private String documento;
	
	public Integer getIdUsuario() {
		return idUsuario;
	}

	public Integer getIdDocumento() {
		return idDocumento;
	}

	public void setIdDocumento(Integer idDocumento) {
		this.idDocumento = idDocumento;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}
	public Date getFechaCarga() {
		return fechaCarga;
	}
	public void setFechaCarga(Date fechaCarga) {
		this.fechaCarga = fechaCarga;
	}
	public String getDocumento() {
		return documento;
	}
	public void setDocumento(String documento) {
		this.documento = documento;
	}
	
	public String getRuta() {
		return ruta;
	}

	public void setRuta(String ruta) {
		this.ruta = ruta;
	}

	public DocumentoDto(Integer idDocumento, Integer idUsuario, Date fechaCarga, String ruta, String documento) {
		this.idUsuario = idUsuario;
		this.idDocumento = idDocumento;
		this.fechaCarga = fechaCarga;
		this.ruta = ruta;
		this.documento = documento;
	}

	public DocumentoDto() {
	}
}

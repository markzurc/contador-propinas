package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto;

import java.io.Serializable;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcApli;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoDatoUsuaExte;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoDatoUsuaInte;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoUsua;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segrCapliCrolRapti;

/**
 * 
 * <h1>SingleExternalUserDto</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 23/04/2015
 *
 */
public class SingleExternalUserDto implements Serializable{
	
	private static final long serialVersionUID = -9184789734691169191L;
	
	private T7segoUsua tsegcUsuario;
	private T7segoDatoUsuaExte tsegcDatosexterno;
	private T7segoDatoUsuaInte tsegcDatosinterno;
	private T7segoUsua tsegcUsuarioResponsable;
	private T7segrCapliCrolRapti tsegrRolAcl;
	private T7segcApli tsegcAplicacion;
	
	public SingleExternalUserDto() {
	}

	/**
	 * @param tsegcUsuario
	 * @param tsegcDatosexterno
	 * @param tsegcDatosinterno
	 * @param tsegcUsuarioResponsable
	 * @param tsegrRolAcl
	 * @param tsegcAplicacion
	 */
	public SingleExternalUserDto(T7segoUsua tsegcUsuario,
			T7segoDatoUsuaExte tsegcDatosexterno,
			T7segoDatoUsuaInte tsegcDatosinterno,
			T7segoUsua tsegcUsuarioResponsable, T7segrCapliCrolRapti tsegrRolAcl,
			T7segcApli tsegcAplicacion) {
		super();
		this.tsegcUsuario = tsegcUsuario;
		this.tsegcDatosexterno = tsegcDatosexterno;
		this.tsegcDatosinterno = tsegcDatosinterno;
		this.tsegcUsuarioResponsable = tsegcUsuarioResponsable;
		this.tsegrRolAcl = tsegrRolAcl;
		this.tsegcAplicacion = tsegcAplicacion;
	}

	/**
	 * @return the tsegcUsuario
	 */
	public T7segoUsua getTsegcUsuario() {
		return tsegcUsuario;
	}

	/**
	 * @param tsegcUsuario the tsegcUsuario to set
	 */
	public void setTsegcUsuario(T7segoUsua tsegcUsuario) {
		this.tsegcUsuario = tsegcUsuario;
	}

	/**
	 * @return the tsegcDatosexterno
	 */
	public T7segoDatoUsuaExte getTsegcDatosexterno() {
		return tsegcDatosexterno;
	}

	/**
	 * @param tsegcDatosexterno the tsegcDatosexterno to set
	 */
	public void setTsegcDatosexterno(T7segoDatoUsuaExte tsegcDatosexterno) {
		this.tsegcDatosexterno = tsegcDatosexterno;
	}

	/**
	 * @return the tsegcDatosinterno
	 */
	public T7segoDatoUsuaInte getTsegcDatosinterno() {
		return tsegcDatosinterno;
	}

	/**
	 * @param tsegcDatosinterno the tsegcDatosinterno to set
	 */
	public void setTsegcDatosinterno(T7segoDatoUsuaInte tsegcDatosinterno) {
		this.tsegcDatosinterno = tsegcDatosinterno;
	}

	/**
	 * @return the tsegcUsuarioResponsable
	 */
	public T7segoUsua getTsegcUsuarioResponsable() {
		return tsegcUsuarioResponsable;
	}

	/**
	 * @param tsegcUsuarioResponsable the tsegcUsuarioResponsable to set
	 */
	public void setTsegcUsuarioResponsable(T7segoUsua tsegcUsuarioResponsable) {
		this.tsegcUsuarioResponsable = tsegcUsuarioResponsable;
	}

	/**
	 * @return the tsegrRolAcl
	 */
	public T7segrCapliCrolRapti getTsegrRolAcl() {
		return tsegrRolAcl;
	}

	/**
	 * @param tsegrRolAcl the tsegrRolAcl to set
	 */
	public void setTsegrRolAcl(T7segrCapliCrolRapti tsegrRolAcl) {
		this.tsegrRolAcl = tsegrRolAcl;
	}

	/**
	 * @return the tsegcAplicacion
	 */
	public T7segcApli getTsegcAplicacion() {
		return tsegcAplicacion;
	}

	/**
	 * @param tsegcAplicacion the tsegcAplicacion to set
	 */
	public void setTsegcAplicacion(T7segcApli tsegcAplicacion) {
		this.tsegcAplicacion = tsegcAplicacion;
	}
	
	
}

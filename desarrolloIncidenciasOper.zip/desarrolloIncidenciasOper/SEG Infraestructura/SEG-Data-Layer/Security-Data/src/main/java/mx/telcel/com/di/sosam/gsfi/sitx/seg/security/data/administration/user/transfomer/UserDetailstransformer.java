package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.transfomer;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.transform.ResultTransformer;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.UserDetailsDto;

/**
 * 
 * <h1>UserDetailstransformer</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 07/05/2015
 */
public class UserDetailstransformer implements ResultTransformer{
	
	private static final long serialVersionUID = -4648226524091925859L;

	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List paramList) {
		return paramList;
	}

	@Override
	public Object transformTuple(Object[] rowData, String[] aliasNames) {
		Integer idUsuario = ((BigDecimal) rowData[0]).intValue();
		String numeroEmpleado = (String) (rowData[1] == null?rowData[2]:rowData[1]);
		String nombre = (String) rowData[3];
		String apellidoPaterno = (String) rowData[4];
		String apellidoMaterno = (String) rowData[5];
		Integer idTipoUsuario = ((BigDecimal) rowData[6]).intValue();
		String tipoUsuarioNombre = (String) rowData[7];
		Integer idEstatus = ((BigDecimal) rowData[8]).intValue();
		String estatusNombre = (String) rowData[9];
		Integer idRol = ((BigDecimal) rowData[10]).intValue();
		String rolNombre = (String) rowData[11];
		String correo = (String)(rowData[12]!=null?rowData[12]:rowData[13]);
		Integer idRolInterno = rowData[14]!=null?((BigDecimal) rowData[14]).intValue():null;
		
		UserDetailsDto userDetailsDto = new UserDetailsDto(idUsuario, numeroEmpleado, 
				nombre, apellidoPaterno, apellidoMaterno, idTipoUsuario, tipoUsuarioNombre, 
				idEstatus, estatusNombre, idRol, rolNombre, correo,idRolInterno);
		return userDetailsDto;
	}
}

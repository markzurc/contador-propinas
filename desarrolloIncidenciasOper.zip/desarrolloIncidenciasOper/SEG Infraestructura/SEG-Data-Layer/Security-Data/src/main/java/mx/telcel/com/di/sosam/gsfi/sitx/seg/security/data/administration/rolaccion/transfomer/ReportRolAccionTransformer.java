package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.rolaccion.transfomer;

import java.util.List;

import org.hibernate.transform.ResultTransformer;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.rolaccion.dto.ReportRolAccionDto;

public class ReportRolAccionTransformer implements ResultTransformer{

	private static final long serialVersionUID = -8068094899492150786L;

	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List paramList) {
		return paramList;
	}

	@Override
	public Object transformTuple(Object[] rowData, String[] aliasNames) {
		int rol = (int) rowData[0];
		int accion = (int) rowData[1];
		int estatus = (int) rowData[2];
		
		ReportRolAccionDto reportRolAccionDto = new ReportRolAccionDto(rol, accion, estatus);
		
		return reportRolAccionDto;
	}

}

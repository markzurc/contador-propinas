package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.application.dao.transformer;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


import org.hibernate.transform.ResultTransformer;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.EstatusDto;

/**
 * 
 * <h1>ReporUserTransformer</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 21/04/2015
 *
 */
public class EstatusTransformer implements ResultTransformer {

	private static final long serialVersionUID = -2716704721283262464L;

	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List paramList) {
		return paramList;
	}

	@Override
	public Object transformTuple(Object[] rowData, String[] aliasNames) {
		Integer idEstatus= ((BigDecimal) rowData[0]).intValue();
		String valor= ((String) rowData[1]);
		
		EstatusDto estatusDto = new EstatusDto(idEstatus, valor);
		
		return estatusDto;
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.transfomer;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcApli;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoDatoUsuaExte;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoDatoUsuaInte;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoUsua;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segrCapliCrolRapti;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.ExternalUserFindDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.SingleExternalUserDto;

import org.hibernate.transform.ResultTransformer;

/**
 * 
 * <h1>ExternalUserTransformer</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 21/04/2015
 *
 */
public class ExternalUserFindTransformer implements ResultTransformer {

	private static final long serialVersionUID = 4145484155424543444L;

	@SuppressWarnings("unchecked")
	@Override
	public List<ExternalUserFindDto> transformList(@SuppressWarnings("rawtypes") List paramList) {
		if(paramList.size()>0){
			Set<T7segrCapliCrolRapti> tsegrRolAcls = new LinkedHashSet<T7segrCapliCrolRapti>();
			List<T7segrCapliCrolRapti> lstTsegrRolAcls;
			Set<T7segcApli> tsegcAplicacions = new LinkedHashSet<T7segcApli>();
			List<T7segcApli> lstTsegcAplicacions;
			for(Object tempObject : paramList){
				tsegrRolAcls.add(((SingleExternalUserDto) tempObject).getTsegrRolAcl());
				tsegcAplicacions.add(((SingleExternalUserDto) tempObject).getTsegcAplicacion());
			}
			SingleExternalUserDto singleExternalUserDto = (SingleExternalUserDto) paramList.get(0);
			lstTsegrRolAcls = new ArrayList<T7segrCapliCrolRapti>(tsegrRolAcls);
			lstTsegcAplicacions = new ArrayList<T7segcApli>(tsegcAplicacions);
			List<ExternalUserFindDto> lstUserFindDtos = new ArrayList<ExternalUserFindDto>(1);
			lstUserFindDtos.add(new ExternalUserFindDto(singleExternalUserDto.getTsegcUsuario(), singleExternalUserDto.getTsegcDatosexterno(),
					singleExternalUserDto.getTsegcDatosinterno(), singleExternalUserDto.getTsegcUsuarioResponsable(), lstTsegrRolAcls, lstTsegcAplicacions));
			return lstUserFindDtos;
		}
		return paramList;
	}

	@Override
	public Object transformTuple(Object[] rowData, String[] aliasNames) {
		T7segoUsua tsegcUsuario = (T7segoUsua) rowData[0];
		T7segoDatoUsuaExte tsegcDatosexterno = (T7segoDatoUsuaExte) rowData[1];
		T7segoDatoUsuaInte tsegcDatosinterno = (T7segoDatoUsuaInte) rowData[2];
		T7segoUsua tsegcUsuarioResponsable = (T7segoUsua) rowData[4];
		T7segrCapliCrolRapti tsegrRolAcl = (T7segrCapliCrolRapti) rowData[5];
		T7segcApli tsegcAplicacion = (T7segcApli) rowData[6];
		SingleExternalUserDto singleExternalUserDto = new SingleExternalUserDto(tsegcUsuario, tsegcDatosexterno, 
				tsegcDatosinterno, tsegcUsuarioResponsable, tsegrRolAcl, tsegcAplicacion);
		
		return singleExternalUserDto;
	}

}

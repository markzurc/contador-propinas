package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.rolaccion.dto;

import java.io.Serializable;

public class ReportRolAccionDto implements Serializable{

	private static final long serialVersionUID = -91114684233676053L;

	private Integer rol;
	private Integer accion;
	private Integer estatus;
	
	public ReportRolAccionDto(Integer rol, Integer accion, Integer estatus) {
		super();
		this.rol = rol;
		this.accion = accion;
		this.estatus = estatus;
	}

	public Integer getRol() {
		return rol;
	}

	public void setRol(Integer rol) {
		this.rol = rol;
	}

	public Integer getAccion() {
		return accion;
	}

	public void setAccion(Integer accion) {
		this.accion = accion;
	}

	public Integer getEstatus() {
		return estatus;
	}

	public void setEstatus(Integer estatus) {
		this.estatus = estatus;
	}
	
}

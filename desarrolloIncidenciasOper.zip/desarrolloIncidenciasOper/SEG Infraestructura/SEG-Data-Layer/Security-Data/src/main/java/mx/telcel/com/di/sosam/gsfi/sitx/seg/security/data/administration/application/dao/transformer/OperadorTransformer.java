package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.application.dao.transformer;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.hibernate.transform.ResultTransformer;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.OperadorDto;

/**
 * 
 * <h1>ReporUserTransformer</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 21/04/2015
 *
 */
public class OperadorTransformer implements ResultTransformer {

	private static final long serialVersionUID = -2716704721283262464L;

	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List paramList) {
		return paramList;
	}

	@Override
	public Object transformTuple(Object[] rowData, String[] aliasNames) {
		String grupoOperador= ((String) rowData[0]);
		String descripcion= ((String) rowData[1]);
		
		OperadorDto operadorDto = new OperadorDto(grupoOperador, descripcion);
		
		return operadorDto;
	}

}

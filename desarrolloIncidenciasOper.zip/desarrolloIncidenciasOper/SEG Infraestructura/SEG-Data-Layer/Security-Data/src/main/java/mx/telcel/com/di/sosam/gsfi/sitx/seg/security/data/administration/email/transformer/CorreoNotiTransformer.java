package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.email.transformer;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.transform.ResultTransformer;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.email.dto.CorreoNotiDto;

public class CorreoNotiTransformer implements ResultTransformer {

	private static final long serialVersionUID = -9096224012370991041L;

	@Override
	public Object transformTuple(Object[] tuple, String[] aliases) {
		CorreoNotiDto correoNoti = new CorreoNotiDto();
		correoNoti.setProducto(this.checkBigDecToInt(tuple[0]));
		correoNoti.setProductoDesc(this.checkStrNotNull(tuple[1]));
		correoNoti.setCorreoDest(this.checkStrNotNull(tuple[2]));
		correoNoti.setCorreoCc(this.checkStrNotNull(tuple[3]));
		correoNoti.setEstado(this.checkBigDecToInt(tuple[4]));
		
		return correoNoti;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List collection) {
		return collection;
	}
	
	private String checkStrNotNull(Object object) {
		return null != object ? object.toString() : "";
	}

	private Integer checkIntNotNull(Object object) {
		return (Integer) (null != object ? object : 0);
	}
	
	private Integer checkBigDecToInt(Object object) {
		BigDecimal bigDec = new BigDecimal(object.toString());
		return (null != object ? bigDec.intValue() : 0);
	}
	
}

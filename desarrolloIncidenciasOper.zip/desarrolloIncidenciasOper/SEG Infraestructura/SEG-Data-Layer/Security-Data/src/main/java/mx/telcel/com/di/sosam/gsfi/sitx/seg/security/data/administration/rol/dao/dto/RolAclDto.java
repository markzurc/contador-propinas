package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.rol.dao.dto;

import java.io.Serializable;

public class RolAclDto implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1926658129733912418L;
	
	private Integer idRol;
	private Integer idAplicacion;
	private Integer idComponente;
	private String flujo;
	private Integer idPadre;
	private String nombre;
	private Integer idTipoComponente;
	private Character permiso;
	private String valorComponente;
	private Integer nivel;

	public RolAclDto() {
	}

	/**
	 * @param idRol
	 * @param idAplicacion
	 * @param idComponente
	 * @param flujo
	 * @param idPadre
	 * @param nombre
	 * @param idTipoComponente
	 * @param permiso
	 * @param valorComponente
	 * @param nivel
	 */
	public RolAclDto(Integer idRol, Integer idAplicacion, Integer idComponente,
			String flujo, Integer idPadre, String nombre,
			Integer idTipoComponente, Character permiso,
			String valorComponente, Integer nivel) {
		super();
		this.idRol = idRol;
		this.idAplicacion = idAplicacion;
		this.idComponente = idComponente;
		this.flujo = flujo;
		this.idPadre = idPadre;
		this.nombre = nombre;
		this.idTipoComponente = idTipoComponente;
		this.permiso = permiso;
		this.valorComponente = valorComponente;
		this.nivel = nivel;
	}

	public Integer getIdRol() {
		return idRol;
	}

	public void setIdRol(Integer idRol) {
		this.idRol = idRol;
	}

	public Integer getIdAplicacion() {
		return idAplicacion;
	}

	public void setIdAplicacion(Integer idAplicacion) {
		this.idAplicacion = idAplicacion;
	}

	public Integer getIdComponente() {
		return idComponente;
	}

	public void setIdComponente(Integer idComponente) {
		this.idComponente = idComponente;
	}

	public String getFlujo() {
		return flujo;
	}

	public void setFlujo(String flujo) {
		this.flujo = flujo;
	}

	public Integer getIdPadre() {
		return idPadre;
	}

	public void setIdPadre(Integer idPadre) {
		this.idPadre = idPadre;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Integer getIdTipoComponente() {
		return idTipoComponente;
	}

	public void setIdTipoComponente(Integer idTipoComponente) {
		this.idTipoComponente = idTipoComponente;
	}

	public Character getPermiso() {
		return permiso;
	}

	public void setPermiso(Character permiso) {
		this.permiso = permiso;
	}
	
	/**
	 * @return the valorComponente
	 */
	public String getValorComponente() {
		return valorComponente;
	}

	/**
	 * @param valorComponente the valorComponente to set
	 */
	public void setValorComponente(String valorComponente) {
		this.valorComponente = valorComponente;
	}

	/**
	 * @return the nivel
	 */
	public Integer getNivel() {
		return nivel;
	}

	/**
	 * @param nivel the nivel to set
	 */
	public void setNivel(Integer nivel) {
		this.nivel = nivel;
	}

	
}

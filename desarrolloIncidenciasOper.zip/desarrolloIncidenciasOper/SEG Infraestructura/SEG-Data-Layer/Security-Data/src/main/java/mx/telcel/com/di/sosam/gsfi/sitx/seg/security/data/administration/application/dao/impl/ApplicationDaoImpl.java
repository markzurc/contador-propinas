package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.application.dao.impl;

import java.io.Serializable;
import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcApli;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.application.dao.IApplicationDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.application.dao.dto.ComponentDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.application.dao.transformer.ComponentTransformer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Order;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

/**
 * 
 * <h1>AplicacionDaoImpl</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 30/03/2015
 *
 */

@Repository(value="aplicacionDao")
@Scope("prototype")
public class ApplicationDaoImpl extends GenericFunctionDaoImpl implements
		IApplicationDao, Serializable {

	private static final long serialVersionUID = 3961585019400288399L;
	private static final Logger logger = LogManager.getLogger(ApplicationDaoImpl.class);
	
	private static final String SELECT_ACL_BY_ID_APP="TsegrAplicaionAcl.SELECT_ACL_BY_ID_APP";

	@SuppressWarnings("unchecked")
	@Override
	public List<T7segcApli> findBy(T7segcApli tsegcAplicacion) {
		logger.info("Ejecutando AplicacionDaoImpl.findBy");
		Session session = getSession();
		Example example = Example.create(tsegcAplicacion);
		return session.createCriteria(T7segcApli.class).add(example)
				.addOrder(Order.asc("idAplicacion")).list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ComponentDto> componentsForApplication(
			Integer idAplicacion) {
		logger.info("Ejecutando AplicacionDaoImpl.componentsForApplication");
		Session session = getSession();
		Query query = session.getNamedQuery(SELECT_ACL_BY_ID_APP).setInteger("APP", idAplicacion)
				.setResultTransformer(new ComponentTransformer());
		
		return query.list();
	
	}

}

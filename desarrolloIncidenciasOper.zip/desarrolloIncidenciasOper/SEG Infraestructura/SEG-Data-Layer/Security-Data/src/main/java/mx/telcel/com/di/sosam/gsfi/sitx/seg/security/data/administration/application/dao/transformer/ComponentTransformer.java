/**
 * 
 */
package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.application.dao.transformer;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.transform.ResultTransformer;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.application.dao.dto.ComponentDto;

/**
 * @author VI7XXE0
 *
 */
public class ComponentTransformer implements ResultTransformer {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4236500070905924140L;


	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List paramList) {
		return paramList;
	}

	@Override
	public Object transformTuple(Object[] rowData, String[] aliasNames) {
		Integer idComponente= (rowData[0]) == null?null:((BigDecimal)rowData[0]).intValue();
		Integer idAplicacion= (rowData[1]) == null?null:((BigDecimal)rowData[1]).intValue();
		String flujo = (String)rowData[2];
		Integer idPadre = (rowData[3]) == null?null:((BigDecimal)rowData[3]).intValue();
		String nombre= (String)rowData[4];
		String descripcion= (String)rowData[5];
		Integer idTipoComponente= (rowData[6]) == null?null:((BigDecimal)rowData[6]).intValue();
		String valorComponente = (String)rowData[7];
		
		return new ComponentDto(idComponente, flujo, idPadre, nombre,
				descripcion, idTipoComponente, idAplicacion, valorComponente);
	}

}

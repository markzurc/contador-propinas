package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.rol.dao;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcRol;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcTipoRol;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segrCapliCrolRapti;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.rol.dao.dto.RolAclDto;

/**
 * 
 * <h1>IRolDao</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 01/04/2015
 *
 */
public interface IRolDao {
	void createRol(T7segcRol tsegcRol);
	void updateRol(T7segcRol tsegcRol);
	List<T7segcRol> findBy(T7segcRol tsegcRol);
	List<T7segcRol> findByWithApplications(T7segcRol tsegcRol);
	void createRolRestriction(List<T7segrCapliCrolRapti> lstTsegrRolAcl);
	void deleteRolRestriction(T7segrCapliCrolRapti tsegrRolAcl);
	List<RolAclDto> findByRolAcl(Integer idRol, Integer idAplicacion);
	List<T7segcTipoRol> getRoltype();
	int isInUse(Integer idRol);
	List<T7segcRol> getRoles();
	String getRoltype(Integer idRol);
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dao;

import java.util.List;
import java.util.Map;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segbHistPass;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoDatoUsuaExte;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoPass;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoUsua;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.utils.session.ISession;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.email.dto.CorreoNotiDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.email.dto.CorreoPropDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.rolaccion.dto.ReportRolAccionDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.DocumentoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.EstatusDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.ExternalUserFindDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.InternalUserFindDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.OperadorDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.ReportUserDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.UserDetailsDto;

/**
 * 
 * <h1>IUserDao</h1>
 * <p>
 * </p>
 * 
 * @author chcastro
 * @version 1.0
 * @since 10/04/2015
 *
 */
public interface IUserDao extends ISession{
	void createUser(T7segoUsua tsegcUsuario, T7segoPass tsegcPassword,
			T7segoDatoUsuaExte tsegcDatosexterno);

	void updateUser(T7segoUsua tsegcUsuario,
			T7segoDatoUsuaExte tsegcDatosexterno);

	ExternalUserFindDto findExternalUserById(Integer idUsuario);

	InternalUserFindDto findInternalUserById(Integer idUsuario);
	
	void updatePassword(T7segoPass tsegcPassword, Integer motivo);
	
	T7segoPass findPassword(Integer userId);
	
	T7segoUsua validateLogIn(String userName);

	T7segoUsua findSimpleUserById(Integer idUsuario);
	
	UserDetailsDto findUserdetail(Integer idUsuario);
	
	T7segoDatoUsuaExte findExternalData(Integer userId);
	
	void updateStatus(Integer idUsuario, Integer idEstatus);
	
	List<T7segbHistPass> findLastPasswords(Integer userId, Integer notReusable);
	
	void updateLoginDate(Integer idUsuario);

	List<ReportRolAccionDto> findRolAccionByRol(Integer rol);

	List<CorreoNotiDto> findAllCorrNotiByProd(Long producto);

	List<CorreoPropDto> findAllCorrProp();
	
	List<String> findAllCorrAuto(Long rolAutorizador);

	UserDetailsDto findUserdetailByEmpleado(String idEmpleado);

	Map<String, String> findComponentesByRol(Integer idRol);

	List<String> getAllCorreoGrupoRol(List<Integer> grupoRol);
        
        public int consultaExistenciaUsuarioExterno(String usuario);
        
        public String consultaAccesoUsuarioExterno(String usuario);
        
        public int obtieneIntentosFallidos(String usuario);
        
        public int obtieneMaximoIntentosPermitidos();
        
        public String obtieneIdenUsuario(String usuario);
        
        public boolean actualizaNumeroDeIntentos(int numeroIntentos, String usuario);
        
        public boolean actualizaUsuarioABloqueo(String usuario);
	
        public String obtenerEnco(int numeral);

///////////////////////////////77

		public boolean actualizarUsuarioAdmin(ReportUserDto reportUserDto, String pass);

		public boolean altaUsuarioAdmin(ReportUserDto reportUserDto, String pass);
		
		boolean requiereCambioPass(String rol);

		public boolean altaPass(ReportUserDto reportUserDto);

		public boolean altaRolUsuario(ReportUserDto reportUserDto);

		public boolean guardarDocumento(String ruta, String name, Integer idUsuario);

		public boolean altaDocumento(String ruta, String name, Integer idUsuario);

		public List<DocumentoDto> obtenerDocumentos(Integer idUsuario);

		public List<OperadorDto> obtenerEmpresas();

		public String obtenerOperadorUsuario(Integer idUsuario);

		public List<EstatusDto> obtenerEstatus();

		public boolean eliminarDoc(Integer idDoc);
		
		List<ReportUserDto> findAllReportUsers();
		
		List<ReportUserDto> findReportUsersConcesionario();

		String idArchivosUsuario();
		
		List<ReportUserDto> getUsersConcesionarioByOp(String operadorUsuario);
		 
		int getCountUsersConcesionarioByOp(String seleccionadoConcesionario);
		
		String getPassUser(int idUsuario);
		
		String getEstadoUser(int idUsuario);
                
                
}

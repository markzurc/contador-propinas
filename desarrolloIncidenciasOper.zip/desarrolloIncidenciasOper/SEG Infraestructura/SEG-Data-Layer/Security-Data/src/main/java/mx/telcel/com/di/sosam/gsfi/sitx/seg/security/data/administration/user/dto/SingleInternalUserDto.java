package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto;

import java.io.Serializable;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcApli;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcRol;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoDatoUsuaInte;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoUsua;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segrCapliCrolRapti;

public class SingleInternalUserDto implements Serializable {

	private static final long serialVersionUID = 7446751725966095640L;
	private T7segoUsua tsegcUsuario;
	private T7segoDatoUsuaInte tsegcDatosinterno;
	private T7segcRol tsegcRol;
	private T7segrCapliCrolRapti tsegrRolAcl;
	private T7segcApli tsegcAplicacions;
	
	public SingleInternalUserDto() {
	}
	
	/**
	 * @param tsegcUsuario
	 * @param tsegcDatosinterno
	 * @param tsegcRol
	 * @param tsegrRolAcl
	 * @param tsegcAplicacions
	 */
	public SingleInternalUserDto(T7segoUsua tsegcUsuario,
			T7segoDatoUsuaInte tsegcDatosinterno, T7segcRol tsegcRol,
			T7segrCapliCrolRapti tsegrRolAcl, T7segcApli tsegcAplicacions) {
		super();
		this.tsegcUsuario = tsegcUsuario;
		this.tsegcDatosinterno = tsegcDatosinterno;
		this.tsegcRol = tsegcRol;
		this.tsegrRolAcl = tsegrRolAcl;
		this.tsegcAplicacions = tsegcAplicacions;
	}

	/**
	 * @return the tsegcUsuario
	 */
	public T7segoUsua getTsegcUsuario() {
		return tsegcUsuario;
	}

	/**
	 * @param tsegcUsuario the tsegcUsuario to set
	 */
	public void setTsegcUsuario(T7segoUsua tsegcUsuario) {
		this.tsegcUsuario = tsegcUsuario;
	}

	/**
	 * @return the tsegcDatosinterno
	 */
	public T7segoDatoUsuaInte getTsegcDatosinterno() {
		return tsegcDatosinterno;
	}

	/**
	 * @param tsegcDatosinterno the tsegcDatosinterno to set
	 */
	public void setTsegcDatosinterno(T7segoDatoUsuaInte tsegcDatosinterno) {
		this.tsegcDatosinterno = tsegcDatosinterno;
	}

	/**
	 * @return the tsegcRol
	 */
	public T7segcRol getTsegcRol() {
		return tsegcRol;
	}

	/**
	 * @param tsegcRol the tsegcRol to set
	 */
	public void setTsegcRol(T7segcRol tsegcRol) {
		this.tsegcRol = tsegcRol;
	}

	/**
	 * @return the tsegrRolAcl
	 */
	public T7segrCapliCrolRapti getTsegrRolAcl() {
		return tsegrRolAcl;
	}

	/**
	 * @param tsegrRolAcl the tsegrRolAcl to set
	 */
	public void setTsegrRolAcl(T7segrCapliCrolRapti tsegrRolAcl) {
		this.tsegrRolAcl = tsegrRolAcl;
	}

	/**
	 * @return the tsegcAplicacions
	 */
	public T7segcApli getTsegcAplicacions() {
		return tsegcAplicacions;
	}

	/**
	 * @param tsegcAplicacions the tsegcAplicacions to set
	 */
	public void setTsegcAplicacions(T7segcApli tsegcAplicacions) {
		this.tsegcAplicacions = tsegcAplicacions;
	}

	
}

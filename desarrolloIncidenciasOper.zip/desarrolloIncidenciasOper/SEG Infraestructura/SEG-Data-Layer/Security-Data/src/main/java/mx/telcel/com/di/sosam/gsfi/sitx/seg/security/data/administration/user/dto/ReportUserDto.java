package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * <h1>ReportUserVo</h1>
 * <p>
 * 
 * </p>
 * 
 * @author chcastro
 * @version 1.0
 * @since 20/04/2015
 *
 */
public class ReportUserDto implements Serializable {

	private static final long serialVersionUID = 2715639400231429243L;

	private Integer idUsuario;
	private String numeroEmpleado;
	private String nombre;
	private String apellidoPaterno;
	private String apellidoMaterno;
	private Integer idTipoUsuario;
	private String tipoUsuarioNombre;
	private Integer idEstatus;
	private String estatusNombre;
	private Integer idRol;
	private String rolNombre;
	private Date fechaLogueo;
	private String correo;
	private String empresa;
	private String pass;
	private String empresaId;

	public ReportUserDto() {
	}

	/**
	 * @param idUsuario
	 * @param numeroEmpleado
	 * @param nombre
	 * @param apellidoPaterno
	 * @param apellidoMaterno
	 * @param idTipoUsuario
	 * @param tipoUsuarioNombre
	 * @param idEstatus
	 * @param estatusNombre
	 * @param idRol
	 * @param rolNombre
	 * @param fechaLogueo
	 */
	public ReportUserDto(Integer idUsuario,
			String nombre, String apellidoPaterno, String apellidoMaterno,
			String correo, String empresa, String tipoUsuarioNombre, String estatusNombre, String pass, String empresaId) {
		super();
		this.idUsuario = idUsuario;
		this.nombre = nombre;
		this.apellidoPaterno = apellidoPaterno;
		this.apellidoMaterno = apellidoMaterno;
		this.correo = correo;
		this.empresa = empresa;
		this.tipoUsuarioNombre = tipoUsuarioNombre;
		this.estatusNombre = estatusNombre;
		this.pass = pass;
		this.empresaId = empresaId;
	}

	/**
	 * @return the idUsuario
	 */
	public Integer getIdUsuario() {
		return idUsuario;
	}

	/**
	 * @param idUsuario the idUsuario to set
	 */
	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	/**
	 * @return the numeroEmpleado
	 */
	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}

	/**
	 * @param numeroEmpleado the numeroEmpleado to set
	 */
	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the apellidoPaterno
	 */
	public String getApellidoPaterno() {
		return apellidoPaterno;
	}

	/**
	 * @param apellidoPaterno the apellidoPaterno to set
	 */
	public void setApellidoPaterno(String apellidoPaterno) {
		this.apellidoPaterno = apellidoPaterno;
	}

	/**
	 * @return the apellidoMaterno
	 */
	public String getApellidoMaterno() {
		return apellidoMaterno;
	}

	/**
	 * @param apellidoMaterno the apellidoMaterno to set
	 */
	public void setApellidoMaterno(String apellidoMaterno) {
		this.apellidoMaterno = apellidoMaterno;
	}

	/**
	 * @return the idTipoUsuario
	 */
	public Integer getIdTipoUsuario() {
		return idTipoUsuario;
	}

	/**
	 * @param idTipoUsuario the idTipoUsuario to set
	 */
	public void setIdTipoUsuario(Integer idTipoUsuario) {
		this.idTipoUsuario = idTipoUsuario;
	}

	/**
	 * @return the tipoUsuarioNombre
	 */
	public String getTipoUsuarioNombre() {
		return tipoUsuarioNombre;
	}

	/**
	 * @param tipoUsuarioNombre the tipoUsuarioNombre to set
	 */
	public void setTipoUsuarioNombre(String tipoUsuarioNombre) {
		this.tipoUsuarioNombre = tipoUsuarioNombre;
	}

	/**
	 * @return the idEstatus
	 */
	public Integer getIdEstatus() {
		return idEstatus;
	}

	/**
	 * @param idEstatus the idEstatus to set
	 */
	public void setIdEstatus(Integer idEstatus) {
		this.idEstatus = idEstatus;
	}

	/**
	 * @return the estatusNombre
	 */
	public String getEstatusNombre() {
		return estatusNombre;
	}

	/**
	 * @param estatusNombre the estatusNombre to set
	 */
	public void setEstatusNombre(String estatusNombre) {
		this.estatusNombre = estatusNombre;
	}

	/**
	 * @return the idRol
	 */
	public Integer getIdRol() {
		return idRol;
	}

	/**
	 * @param idRol the idRol to set
	 */
	public void setIdRol(Integer idRol) {
		this.idRol = idRol;
	}

	/**
	 * @return the rolNombre
	 */
	public String getRolNombre() {
		return rolNombre;
	}

	/**
	 * @param rolNombre the rolNombre to set
	 */
	public void setRolNombre(String rolNombre) {
		this.rolNombre = rolNombre;
	}

	/**
	 * @return the fechaLogueo
	 */
	public Date getFechaLogueo() {
		return fechaLogueo != null ? (Date) fechaLogueo.clone() : null;
	}

	/**
	 * @param fechaLogueo the fechaLogueo to set
	 */
	public void setFechaLogueo(Date fechaLogueo) {
		this.fechaLogueo = fechaLogueo != null ? (Date) fechaLogueo.clone() : null;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public String getEmpresaId() {
		return empresaId;
	}

	public void setEmpresaId(String empresaId) {
		this.empresaId = empresaId;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ReportUserDto [idUsuario=");
		builder.append(idUsuario);
		builder.append(", numeroEmpleado=");
		builder.append(numeroEmpleado);
		builder.append(", nombre=");
		builder.append(nombre);
		builder.append(", apellidoPaterno=");
		builder.append(apellidoPaterno);
		builder.append(", apellidoMaterno=");
		builder.append(apellidoMaterno);
		builder.append(", idTipoUsuario=");
		builder.append(idTipoUsuario);
		builder.append(", tipoUsuarioNombre=");
		builder.append(tipoUsuarioNombre);
		builder.append(", idEstatus=");
		builder.append(idEstatus);
		builder.append(", estatusNombre=");
		builder.append(estatusNombre);
		builder.append(", idRol=");
		builder.append(idRol);
		builder.append(", rolNombre=");
		builder.append(rolNombre);
		builder.append(", fechaLogueo=");
		builder.append(fechaLogueo);
		builder.append("]");
		return builder.toString();
	}
}

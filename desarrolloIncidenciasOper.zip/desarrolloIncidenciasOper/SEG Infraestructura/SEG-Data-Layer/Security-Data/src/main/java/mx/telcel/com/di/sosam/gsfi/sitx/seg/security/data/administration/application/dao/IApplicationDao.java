package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.application.dao;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcApli;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.application.dao.dto.ComponentDto;

/**
 * 
 * <h1>IAplicacionDao</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 30/03/2015
 *
 */
public interface IApplicationDao {
	List<T7segcApli> findBy(T7segcApli tsegcAplicacion);
	List<ComponentDto> componentsForApplication(Integer idAplicacion);
}

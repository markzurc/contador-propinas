package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.application.dao.transformer;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


import org.hibernate.transform.ResultTransformer;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.DocumentoDto;

/**
 * 
 * <h1>ReporUserTransformer</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 21/04/2015
 *
 */
public class DocumentoTransformer implements ResultTransformer {

	private static final long serialVersionUID = -2716704721283262464L;

	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List paramList) {
		return paramList;
	}

	@Override
	public Object transformTuple(Object[] rowData, String[] aliasNames) {
		Integer idDocumento= ((BigDecimal) rowData[0]).intValue();
		Integer idUsuario= ((BigDecimal) rowData[1]).intValue();
		Date fechaCarga = (Date)rowData[2];
		String ruta= ((String) rowData[3]);
		String documento= ((String) rowData[4]);
		
		DocumentoDto documentoDto = new DocumentoDto(idDocumento, idUsuario, fechaCarga, ruta, documento);
		
		
		return documentoDto;
	}

}

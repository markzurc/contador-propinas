package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.rol.dao.transformer;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.transform.ResultTransformer;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.rol.dao.dto.RolAclDto;


/**
 * 
 * @author chcastro
 * @author hhernanm
 * @version 1.0
 * 
 *
 */
public class RolAclTransformer implements ResultTransformer  {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 6312182004924604974L;

	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List paramList) {
		return paramList;
	}

	@Override
	public Object transformTuple(Object[] rowData, String[] aliasNames) {
		Integer idRol = ((BigDecimal)rowData[0]).intValue();
		Integer idAplicacion = ((BigDecimal)rowData[1]).intValue();
		Integer idComponente = (rowData[2]) == null?null:((BigDecimal)rowData[2]).intValue();
		Integer idPadre = (rowData[3]) == null?null:((BigDecimal)rowData[3]).intValue();
		String flujo = (String)rowData[4];
		String nombre = (String)rowData[5];
		Integer idTipoComponente = ((BigDecimal)rowData[6]).intValue();
		Character permiso = (Character)rowData[7];
		String valorComponente  = (String)rowData[8];
		Integer nivel = (rowData[9]) == null?null:((BigDecimal)rowData[9]).intValue();
		
		return new RolAclDto(idRol, idAplicacion, idComponente, flujo, idPadre, nombre, 
				idTipoComponente, permiso, valorComponente, nivel);
	}

}

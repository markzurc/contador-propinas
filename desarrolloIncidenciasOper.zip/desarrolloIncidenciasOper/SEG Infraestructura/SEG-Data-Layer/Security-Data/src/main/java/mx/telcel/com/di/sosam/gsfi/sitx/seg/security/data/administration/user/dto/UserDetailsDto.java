package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto;

import java.io.Serializable;
import java.util.Map;

/**
 * 
 * <h1>UserDetailsDto</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 07/05/2015
 */
public class UserDetailsDto implements Serializable{

	private static final long serialVersionUID = 5030750322840874204L;
	
	private Integer idUsuario;
	private String numeroEmpleado;
	private String nombre;
	private String apellidoPaterno;
	private String apellidoMaterno;
	private Integer idTipoUsuario;
	private String tipoUsuarioNombre;
	private Integer idEstatus;
	private String estatusNombre;
	private Integer idRol;
	private String rolNombre;
	private String correo;
	private Integer idRolInterno;
		
	public UserDetailsDto() {
	}

	public UserDetailsDto(Integer idUsuario, String numeroEmpleado, String nombre, String apellidoPaterno,
			String apellidoMaterno, Integer idTipoUsuario, String tipoUsuarioNombre, Integer idEstatus,
			String estatusNombre, Integer idRol, String rolNombre, String correo, Integer idRolInterno) {
		super();
		this.idUsuario = idUsuario;
		this.numeroEmpleado = numeroEmpleado;
		this.nombre = nombre;
		this.apellidoPaterno = apellidoPaterno;
		this.apellidoMaterno = apellidoMaterno;
		this.idTipoUsuario = idTipoUsuario;
		this.tipoUsuarioNombre = tipoUsuarioNombre;
		this.idEstatus = idEstatus;
		this.estatusNombre = estatusNombre;
		this.idRol = idRol;
		this.rolNombre = rolNombre;
		this.correo = correo;
		this.idRolInterno = idRolInterno;
	}


	public Integer getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}

	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidoPaterno() {
		return apellidoPaterno;
	}

	public void setApellidoPaterno(String apellidoPaterno) {
		this.apellidoPaterno = apellidoPaterno;
	}

	public String getApellidoMaterno() {
		return apellidoMaterno;
	}

	public void setApellidoMaterno(String apellidoMaterno) {
		this.apellidoMaterno = apellidoMaterno;
	}

	public Integer getIdTipoUsuario() {
		return idTipoUsuario;
	}

	public void setIdTipoUsuario(Integer idTipoUsuario) {
		this.idTipoUsuario = idTipoUsuario;
	}

	public String getTipoUsuarioNombre() {
		return tipoUsuarioNombre;
	}

	public void setTipoUsuarioNombre(String tipoUsuarioNombre) {
		this.tipoUsuarioNombre = tipoUsuarioNombre;
	}

	public Integer getIdEstatus() {
		return idEstatus;
	}

	public void setIdEstatus(Integer idEstatus) {
		this.idEstatus = idEstatus;
	}

	public String getEstatusNombre() {
		return estatusNombre;
	}

	public void setEstatusNombre(String estatusNombre) {
		this.estatusNombre = estatusNombre;
	}

	public Integer getIdRol() {
		return idRol;
	}

	public void setIdRol(Integer idRol) {
		this.idRol = idRol;
	}

	public String getRolNombre() {
		return rolNombre;
	}

	public void setRolNombre(String rolNombre) {
		this.rolNombre = rolNombre;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public Integer getIdRolInterno() {
		return idRolInterno;
	}

	public void setIdRolInterno(Integer idRolInterno) {
		this.idRolInterno = idRolInterno;
	}	
	
}

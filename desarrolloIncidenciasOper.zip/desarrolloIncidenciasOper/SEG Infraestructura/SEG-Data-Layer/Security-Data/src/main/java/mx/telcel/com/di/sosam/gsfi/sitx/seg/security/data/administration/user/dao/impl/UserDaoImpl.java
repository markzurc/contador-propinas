package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dao.impl;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segbHistPass;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoDatoUsuaExte;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoPass;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoUsua;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.TsegcDatosexternoId;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.TsegcPasswordId;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.PermisosCompDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.transformer.PermisosCompTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.application.dao.transformer.DocumentoTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.application.dao.transformer.EstatusTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.application.dao.transformer.OperadorTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.email.dto.CorreoNotiDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.email.dto.CorreoPropDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.email.transformer.CorreoNotiTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.email.transformer.CorreoPropTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.rolaccion.dto.ReportRolAccionDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.rolaccion.transfomer.ReportRolAccionTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dao.IUserDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.DocumentoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.EstatusDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.ExternalUserFindDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.InternalUserFindDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.OperadorDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.ReportUserDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.UserDetailsDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.transfomer.ExternalUserFindTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.transfomer.InternalUserFindTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.transfomer.ReportUserTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.transfomer.UserDetailstransformer;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

/**
 * 
 * <h1>UserDaoImpl</h1>
 * <p>
 * </p>
 * 
 * @author chcastro
 * @version 1.0
 * @since 10/04/2015
 *
 */

@Repository(value = "userDao")
@Scope("prototype")
public class UserDaoImpl extends GenericFunctionDaoImpl implements IUserDao,
		Serializable {

	private static final long serialVersionUID = -1118507398703362309L;

	private static final String SELECT_EXTERNAL_USER_BY_ID = "TsegcUsuario.SELECT_EXTERNAL_USER_BY_ID";
	private static final String SELECT_INTERNAL_USER_BY_ID = "TsegcUsuario.SELECT_INTERNAL_USER_BY_ID";
	private static final String SELECT_USER_LOGIN_BY_USER_NAME = "TsegcUsuario.SELECT_USER_LOGIN_BY_USER_NAME";
	private static final String SELECT_USER_LOGIN_BY_ID ="TsegcUsuario.SELECT_USER_LOGIN_BY_ID";
	private static final String SELECT_USERS_DETAILS = "TsegcUsuario.SELECT_USERS_DETAILS";
	private static final String SELECT_USERS_DETAILS_BY_EMPLEADO = "TsegcUsuario.SELECT_USERS_DETAILS_BY_EMPLEADO";
	private static final String UPDATE_USER_EXTERNAL_STATUS = "TsegcUsuario.UPDATE_USER_EXTERNAL_STATUS";
	private static final String UPDATE_USER_LOGIN_DATE = "TsegcUsuario.UPDATE_USER_LOGIN_DATE";
	private static final String INSERT_HISTORICO_CONTRA = "TsegcHistoricopassword.INSERT_HISTORICO_CONTRA";
	private static final String OBTENER_PERMISOS_COMPONENTES = "T7PFAC_PERM_COMP.obtenerPermisosComponentes";
	private static final String SELECT_CORREOS_BY_GRUPO_ROL = "TsegcUsuario.SELECT_CORREOS_BY_GRUPO_ROL";
	private static final String SELECT_CORREOS_BY_ROL_AUT ="T7segoDatoUsuaInte.SELECT_CORREOS_BY_ROL_AUT";
	private static final String SELECT_ACCESO_USUARIO_EXTERNO ="T7segoDatoUsuaExte.SELECT_ACCESO_USUARIO_EXTERNO";
	private static final String SELECT_EXISTENCIA_USUARIO_EXTERNO ="T7segoDatoUsuaExte.SELECT_EXISTENCIA_USUARIO_EXTERNO";
	private static final String SELECT_OBTIENE_INTENTOS_FALLIDOS ="T7segoDatoUsuaExte.SELECT_OBTIENE_INTENTOS_FALLIDOS";
	private static final String SELECT_OBTIENE_ID_USUARIO ="T7segoDatoUsuaExte.SELECT_OBTIENE_ID_USUARIO";
	private static final String UPDATE_T3SEGO_PASS_UPDATE_INTENTOS = "T3SEGO_PASS_UPDATE_INTENTOS";
	private static final String UPDATE_T3SEGO_USUA_UPDATE_ESTATUS = "T3SEGO_USUA_UPDATE_ESTATUS";
        private static final String SELECT_OBTIENE_MAXIMOS_INTENTOS_PERMITIDOS = "T3segcPara.OBTIENE_MAXIMOS_INTENTOS_PERMITIDOS";
	
	private static final String SELECT_USERS_CON_BY_OP = "TsegcUsuario.SELECT_USERS_CON_BY_OP";
	private static final String SELECT_COUNT_USERS_CON_BY_OP = "TsegcUsuario.SELECT_COUNT_USERS_CON_BY_OP";
	private static final String SELECT_USERS_ADMIN = "TsegcUsuario.SELECT_USERS_ADMIN";
	private static final String SELECT_USERS_CON = "TsegcUsuario.SELECT_USERS_CON";
	private static final String UPDATE_USER_ADMIN = "UPDATE_USER_ADMIN";
	private static final String UPDATE_USER_PASS = "UPDATE_USER_PASS";
	private static final String UPDATE_USER_ADMIN_DATO = "UPDATE_USER_ADMIN_DATO";
	private static final String INSERT_DOCU = "INSERT_DOCU";
	private static final String SELECT_DOCU = "SELECT_DOCU";
	private static final String SELECT_OPER = "SELECT_OPER";
	private static final String SELECT_ESTATUS = "SELECT_ESTATUS";
	private static final String SELECT_OPERADOR_USER = "SELECT_OPERADOR_USER";
	private static final String DELETE_DOCU = "DELETE_DOCU";
	private static final String INSERT_USER_ADMIN = "INSERT_USER_ADMIN";
	private static final String INSERT_DATO_USER_EXTE = "INSERT_DATO_USER_EXTE";
	private static final String INSERT_USER_PASS = "INSERT_USER_PASS";
	private static final String INSERT_ROL_USER = "INSERT_ROL_USER";
	private static final String REQUIERE_CAMBIO_PASS = "REQUIERE_CAMBIO_PASS";
	private static final String SELECT_PASS_USERS = "TsegcUsuario.SELECT_PASS_USERS";
	private static final String SELECT_ESTADO_USERS = "TsegcUsuario.SELECT_ESTADO_USERS";
	
	private static final int REASON_NEW = 0;

	private static final Logger logger = LogManager.getLogger(UserDaoImpl.class);

	@Override
	public void createUser(T7segoUsua tsegcUsuario, T7segoPass tsegcPassword,
			T7segoDatoUsuaExte tsegcDatosexterno) {
		logger.info("Ejecutando UserDaoImpl.createUser");
		create(tsegcUsuario);
		tsegcDatosexterno.setId(new TsegcDatosexternoId(tsegcUsuario.getIdUsuario()));
		tsegcPassword.setId(new TsegcPasswordId(tsegcUsuario.getIdUsuario()));
		create(tsegcDatosexterno);
		create(tsegcPassword);
		
	}
	
	@Override
	public void updateUser(T7segoUsua tsegcUsuario, T7segoDatoUsuaExte tsegcDatosexterno) {
		logger.info("Ejecutando UserDaoImpl.updateUser");
		
		update(tsegcUsuario);
		update(tsegcDatosexterno);
		
	}

	@Override
	public ExternalUserFindDto findExternalUserById(Integer idUsuario) {
		logger.info("Ejecutando UserDaoImpl.findExternalUserById");
		ExternalUserFindDto externalUserFindDto;
		Session session = getSession();
		
		Query query = session.
				getNamedQuery(SELECT_EXTERNAL_USER_BY_ID).setInteger("idUsuario", idUsuario);
		query.setResultTransformer(new ExternalUserFindTransformer());
		externalUserFindDto =  (ExternalUserFindDto) query.uniqueResult();
		return externalUserFindDto;
	}

	@Override
	public InternalUserFindDto findInternalUserById(Integer idUsuario) {
		logger.info("Ejecutando UserDaoImpl.findInternalUserById");
		InternalUserFindDto internalUserFindDto;
		Session session = getSession();
		
		Query query = session.
				getNamedQuery(SELECT_INTERNAL_USER_BY_ID).setInteger("idUsuario", idUsuario);
		query.setResultTransformer(new InternalUserFindTransformer());
		internalUserFindDto =  (InternalUserFindDto) query.uniqueResult();
		return internalUserFindDto;
	}
	
	@Override
	public void updatePassword(T7segoPass tsegcPassword, Integer motivo) {
		T7segoPass tsegcPasswordOld = findPassword(tsegcPassword.getId().getIdUsuario());
		Session session = getSession();
		Query query = session.
				getNamedQuery(INSERT_HISTORICO_CONTRA)
					.setTimestamp("fechaCambio", tsegcPasswordOld.getFechaCambioPassword())
					.setInteger("idMotivo", motivo)
					.setInteger("idUsuario", tsegcPasswordOld.getId().getIdUsuario())
					.setString("password", tsegcPasswordOld.getPassword());
		query.executeUpdate();
		tsegcPasswordOld.setFechaCambioPassword(tsegcPassword.getFechaCambioPassword());
		tsegcPasswordOld.setId(tsegcPassword.getId());
		tsegcPasswordOld.setIntentos(tsegcPassword.getIntentos());
		tsegcPasswordOld.setPassword(tsegcPassword.getPassword());
	}
	
	@Override
	public T7segoPass findPassword(Integer userId) {
		logger.info("Ejecutando UserDaoImpl.findPassword");
		Session session = getSession();
		Criteria criteria = session.createCriteria(T7segoPass.class);
		criteria.add(Restrictions.eq("id.idUsuario", userId));
		T7segoPass lstTsegcPasswords = (T7segoPass) criteria.uniqueResult();
		
		return lstTsegcPasswords;
	}
	
	@Override
	public T7segoUsua validateLogIn(String userName) {
		logger.info("Ejecutando UserDaoImpl.validateLogIn");
		T7segoUsua tsegcUsuario;
		Session session = getSession();
		
		Query query = session.
				getNamedQuery(SELECT_USER_LOGIN_BY_USER_NAME).setString("userName", userName);
		tsegcUsuario =  (T7segoUsua) query.uniqueResult();
		return tsegcUsuario;
	}
	
	@Override
	public T7segoUsua findSimpleUserById(Integer idUsuario) {
		logger.info("Ejecutando UserDaoImpl.validateLogIn");
		T7segoUsua tsegcUsuario;
		Session session = getSession();
		
		Query query = session.
				getNamedQuery(SELECT_USER_LOGIN_BY_ID).setInteger("idUsuario", idUsuario);
		tsegcUsuario =  (T7segoUsua) query.uniqueResult();
		return tsegcUsuario;
	}
	
	@Override
	public UserDetailsDto findUserdetail(Integer idUsuario) {
		logger.info("Ejecutando UserDaoImpl.findAllReportUsers");
		Session session = getSession();
		Query query = session
				.getNamedQuery(UserDaoImpl.SELECT_USERS_DETAILS);
		query.setInteger("idUsuario", idUsuario).
			setResultTransformer(new UserDetailstransformer());
		UserDetailsDto userDetailsDto = (UserDetailsDto) query.uniqueResult();
		return userDetailsDto;
	}
	
	private Map<String, String> toMap(List<PermisosCompDto> list) {
		Map<String, String> result = new HashMap<>();

		for (PermisosCompDto componente : list) {
			result.put(componente.getNombreComponente(), componente.getPermiso());
		}

		return result;
	}
	
	@Override
	public T7segoDatoUsuaExte findExternalData(Integer userId) {
		logger.info("Ejecutando UserDaoImpl.findPassword");
		Session session = getSession();
		Criteria criteria = session.createCriteria(T7segoDatoUsuaExte.class);
		criteria.add(Restrictions.eq("id.idUsuario", userId));
		T7segoDatoUsuaExte lstTsegcDatosexterno = (T7segoDatoUsuaExte) criteria.uniqueResult();
		
		return lstTsegcDatosexterno;
	}

	@Override
	public void updateStatus(Integer idUsuario, Integer idEstatus) {
		logger.info("Ejecutando UserDaoImpl.updateStatus");
		Session session = getSession();

		Query query = session
				.getNamedQuery(UPDATE_USER_EXTERNAL_STATUS);
		query.setInteger("idEstatus",idEstatus).setInteger("idUsuario", idUsuario);
		query.executeUpdate();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<T7segbHistPass> findLastPasswords(Integer userId, Integer notReusable) {
		logger.info("Ejecutando UserDaoImpl.findPassword");
		Session session = getSession();
		Criteria criteria = session.createCriteria(T7segbHistPass.class);
		criteria.add(Restrictions.eq("id.idUsuario", userId)).
				add(Restrictions.eq("id.idMotivo", REASON_NEW)).addOrder(Order.desc("id.fechaCambioPassword"));
		criteria.setMaxResults(notReusable);
		
		return criteria.list();
	}
	
	@Override
	public void updateLoginDate(Integer idUsuario) {
		logger.info("Ejecutando UserDaoImpl.updateLoginDate");
		Session session = getSession();
		Query query = session
				.getNamedQuery(UPDATE_USER_LOGIN_DATE);
		query.setDate("fecha",new Date()).setInteger("idUsuario", idUsuario);
		query.executeUpdate();
	}

	@Override
	public List<ReportRolAccionDto> findRolAccionByRol(Integer rol) {
		logger.info("Ejecutando UserDaoImpl.findRolAccionByRol");
		Session session = getSession();
		Query query = session.createQuery("SELECT rolAcci.rol, rolAcci.accion, rolAcci.estatus FROM T7segcRolAcci rolAcci WHERE rolAcci.rol ="+rol);
		query.setResultTransformer(new ReportRolAccionTransformer());
		@SuppressWarnings("unchecked")
		List<ReportRolAccionDto> aliasToValueMapList = query.list();
		return aliasToValueMapList;
	}

	@Override
	public List<CorreoNotiDto> findAllCorrNotiByProd(Long producto) {
		logger.info("Ejecutando UserDaoImpl.findAllCorrNotiByProdDesc");
		Session session = getSession();
		Query query =session.createSQLQuery("SELECT a.producto, a.producto_desc, dbms_lob.substr(a.correo_dest,4000,1), dbms_lob.substr(a.correo_cc,4000,1), a.estado" + 
				" FROM BDDSEG01.T3SEGC_ENVI_NOTI a WHERE a.producto ="+producto);
		query.setResultTransformer(new CorreoNotiTransformer());
		@SuppressWarnings("unchecked")
		List<CorreoNotiDto> aliasToValueMapList = query.list();
		return aliasToValueMapList;
	}

	@Override
	public List<CorreoPropDto> findAllCorrProp() {
		logger.info("Ejecutando UserDaoImpl.findAllCorrProp");
		Session session = getSession();
		Query query = session.createQuery("SELECT clave, valor FROM T7segcCorrProp WHERE clave LIKE 'mail.%' ORDER BY clave DESC");
		query.setResultTransformer(new CorreoPropTransformer());
		@SuppressWarnings("unchecked")
		List<CorreoPropDto> aliasToValueMapList = query.list();
		return aliasToValueMapList;
	}

	@Override
	public List<String> findAllCorrAuto(Long rolAutorizador) {
		logger.info("Ejecutando UserDaoImpl.findAllCorrAuto");
		Session session = getSession();
		//Query query = session.createQuery("SELECT correo FROM T7segoDatoUsuaInte WHERE rol ="+rolAutorizador);
		Query query = session.getNamedQuery(UserDaoImpl.SELECT_CORREOS_BY_ROL_AUT);
		query.setParameter("rolAutorizador", rolAutorizador);
		@SuppressWarnings("unchecked")
		List<String> lstCorrAuto = query.list();
		return lstCorrAuto;
	}
	
	@Override
	public UserDetailsDto findUserdetailByEmpleado(String idEmpleado) {
		logger.info("Ejecutando UserDaoImpl.findAllReportUsers");
		Session session = getSession();

		Query query = session
				.getNamedQuery(UserDaoImpl.SELECT_USERS_DETAILS_BY_EMPLEADO);
		query.setString("idEmpleado", idEmpleado).
			setResultTransformer(new UserDetailstransformer());
		UserDetailsDto userDetailsDto = (UserDetailsDto) query.uniqueResult();

		return userDetailsDto;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, String> findComponentesByRol(Integer idRol) {
		Session session = getSession();
		Query query = session.getNamedQuery(UserDaoImpl.OBTENER_PERMISOS_COMPONENTES);
		query.setParameter(0, idRol);
		query.setResultTransformer(new PermisosCompTransformer());
		Map<String, String> componentes;
		componentes = this.toMap(query.list());
		return componentes;
	}

	@Override
	public List<String> getAllCorreoGrupoRol(List<Integer> grupoRol) {
		Session session = getSession();
		Query query = session.getNamedQuery(UserDaoImpl.SELECT_CORREOS_BY_GRUPO_ROL);
		query.setParameterList("grupoRol", grupoRol);
		@SuppressWarnings("unchecked")
		List<String> listGrupoRol = query.list();
		return listGrupoRol;
	}
        
	@Override
	public String consultaAccesoUsuarioExterno(String usuario) {
		Session session = getSession();
		try {
			Query query = session.getNamedQuery(UserDaoImpl.SELECT_ACCESO_USUARIO_EXTERNO);
			query.setParameter("usuario", usuario);
			return query.uniqueResult().toString();
		} catch (HibernateException error) {
			return "";
		}

	}

    @Override
    public int consultaExistenciaUsuarioExterno(String usuario) {
        Session session = getSession();
        try{
        	Query query = session.getNamedQuery(UserDaoImpl.SELECT_EXISTENCIA_USUARIO_EXTERNO);
			query.setParameter("usuario", usuario);
            return Integer.parseInt(query.uniqueResult().toString());
        }catch(HibernateException error){
            System.err.println("UserDaoImpl:consultaExistenciaUsuarioExterno: Error al consultar existencia de usuario: "+error);
            return 0;
        }finally{
            session.close();
        }
    }
    
    @Override
    public int obtieneIntentosFallidos(String usuario){
        Session session = getSession();
        try{        
        	Query query = session.getNamedQuery(UserDaoImpl.SELECT_OBTIENE_INTENTOS_FALLIDOS);
        	query.setParameter("usuario", usuario);
            return Integer.parseInt(query.uniqueResult().toString());                
        }catch(HibernateException error){
            System.err.println("UserDaoImpl:obtieneIntentosFallidos: Error al obtener numero de intentos: "+error);
            return 3;
        }
//        finally{
//            session.close();
//        }        
    }
    
    @Override
    public int obtieneMaximoIntentosPermitidos() {
        Session session = getSession();
        try{        
            Query query = session.getNamedQuery(UserDaoImpl.SELECT_OBTIENE_MAXIMOS_INTENTOS_PERMITIDOS);
            return Integer.parseInt(query.uniqueResult().toString());                
        }catch(HibernateException error){
            System.err.println("UserDaoImpl:obtieneMaximoIntentosPermitidos: Error al obtener numero de intentos maximos: "+error);
            return 5;
        }
    }

    @Override
    public String obtieneIdenUsuario(String usuario) {
        Session session = getSession();
        try{
        	Query query = session.getNamedQuery(UserDaoImpl.SELECT_OBTIENE_ID_USUARIO);
        	query.setParameter("usuario", usuario);
            return query.uniqueResult().toString();                
        }catch(HibernateException error){
            System.err.println("UserDaoImpl:obtieneIdenUsuario Error al obtener identificador de usuario: "+error);
            return "";
        }
//        finally{
//            session.close();
//        }
    }

    @Override
    public boolean actualizaNumeroDeIntentos(int numeroIntentos, String usuario) {
        Session session = getSession();
        try{
            Query query = session.getNamedQuery(UserDaoImpl.UPDATE_T3SEGO_PASS_UPDATE_INTENTOS);
            query.setParameter("numeroIntentos", numeroIntentos);
        	query.setParameter("usuario", usuario);
            return query.executeUpdate()>0;
        }catch(HibernateException error){
            System.err.println("UserDaoImpl:actualizaNumeroDeIntentos Error al actualizar numero de intentos: "+error);
            return false;
        }finally{
            session.close();
        }
    }

    @Override
    public boolean actualizaUsuarioABloqueo(String usuario) {
        Session session = getSession();
        try{
        	Query query = session.getNamedQuery(UserDaoImpl.UPDATE_T3SEGO_USUA_UPDATE_ESTATUS);
        	query.setParameter("usuario", usuario);
            return query.executeUpdate()>0;
        }catch(HibernateException error){
            System.err.println("UserDaoImpl:actualizaUsuarioABloqueo Error al actualizar estado de usuario: "+error);
            return false;
        }
//        finally{
//            session.close();
//        }
    }
    
    @Override
    public String obtenerEnco(int numeral) {
        Session session = getSession();
        try {
            if (numeral == 1) {
                String en = "SELECT PARA.VALOR \n" +
                "FROM BDDSEG01.T3SEGC_PARA PARA \n" +
                "WHERE PARA.IDENTIFICADOR = 'CLAVE_1'";
                Query query = session.createSQLQuery(en);
                return String.valueOf(query.uniqueResult());
            } else if (numeral == 2) {
                String en = "SELECT PARA.VALOR \n" +
                    "FROM BDDSEG01.T3SEGC_PARA PARA \n" +
                    "WHERE PARA.IDENTIFICADOR = 'CLAVE_2'";
                Query query = session.createSQLQuery(en);
                return String.valueOf(query.uniqueResult());
            } else {
                return "";
            }
        } catch (HibernateException error) {
            System.err.println("UserDaoImpl:obtieneClavEnco Error al obtener dato: "+error);
            return "";
        }
    }
    
///////////////////////////////////////////////////////////////////////////////////////////////////

	@SuppressWarnings("unchecked")
	@Override
	public boolean actualizarUsuarioAdmin(ReportUserDto reportUserDto, String pass) {
		boolean indicador;
		try {
			Session session = getSession();
			Query query = session.getNamedQuery(UPDATE_USER_ADMIN).setString(0, reportUserDto.getNombre())
					.setString(1, reportUserDto.getApellidoPaterno()).setString(2, reportUserDto.getApellidoMaterno())
					.setInteger(3, reportUserDto.getIdEstatus()).setInteger(4, reportUserDto.getIdUsuario());
			query.executeUpdate();

			boolean andminD = actualizarUsuarioAdminDatos(reportUserDto);
			boolean passR = actualizarPass(reportUserDto.getIdUsuario(), pass);
			if (andminD) {
				indicador = true;
			} else {
				indicador = false;
			}
		} catch (Error error) {
			indicador = false;
			logger.info("SolicitudLlamada: se a producido un error al editar el usuario: " + error);
		}
		return indicador;
	}

	@SuppressWarnings("unchecked")
	public boolean actualizarUsuarioAdminDatos(ReportUserDto reportUserDto) {
		boolean indicador;
		try {
			Session session = getSession();
			Query query = session.getNamedQuery(UPDATE_USER_ADMIN_DATO).setInteger(0, 61)
					.setString(1, reportUserDto.getCorreo()).setInteger(2, reportUserDto.getIdUsuario());
			query.executeUpdate();
			indicador = true;
		} catch (Error error) {
			indicador = false;
			logger.info("SolicitudLlamada: se a producido un error al editar el usuario: " + error);
		}
		return indicador;
	}

	@SuppressWarnings("unchecked")
	public boolean actualizarPass(Integer idUsuario, String pass) {
		boolean indicador;
		try {
			Session session = getSession();
			Query query = session.getNamedQuery(UPDATE_USER_PASS).setString(0, pass).setInteger(1, idUsuario);
			query.executeUpdate();
			indicador = true;
		} catch (Error error) {
			indicador = false;
			logger.info("SolicitudLlamada: se a producido un error al editar el usuario: " + error);
		}
		return indicador;
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean altaUsuarioAdmin(ReportUserDto reportUserDto, String pass) {
		boolean indicador;
		Date fecha = new Date();
		try {
			Session session = getSession();
			Query query = session.getNamedQuery(INSERT_USER_ADMIN).setString(0, reportUserDto.getNombre())
					.setString(1, reportUserDto.getApellidoPaterno()).setString(2, reportUserDto.getApellidoMaterno())
					.setInteger(3, reportUserDto.getIdTipoUsuario()).setDate(4, fecha).setString(5, "SPML");
			query.executeUpdate();

			Integer usuario = Integer.parseInt(ultimoIdUsuario());
			Integer numeroEmpleado = usuario + 1;

			Query query2 = session.getNamedQuery(INSERT_DATO_USER_EXTE)
					.setInteger(0, usuario)
					.setInteger(1, 61)
					.setString(2, reportUserDto.getCorreo())
					.setInteger(3, reportUserDto.getIdRol())
					.setString(4, reportUserDto.getEmpresa());
			query2.executeUpdate();

			indicador = true;
		} catch (Error error) {
			indicador = false;
			logger.info("SolicitudLlamada: se a producido un error al editar el usuario: " + error);
		}
		return indicador;
	}
	
	@Override
	public boolean requiereCambioPass(String rol) {
		logger.info("Ejecutando UserDaoImpl.findExternalUserById");
		String valid = "";
		try {
			Session session = getSession();
			Query query = session.getNamedQuery(REQUIERE_CAMBIO_PASS).setString("rol", rol);
			valid = (query.uniqueResult() != null) ? query.uniqueResult().toString() : "0";
			if (valid.equals("1")) {
				return true;
			} else {
				return false;
			}
		} catch (Exception error) {
			logger.error("Error al consultar: " + error);
			return false;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean altaPass(ReportUserDto reportUserDto) {
		boolean indicador;
		Date fecha = new Date();
		try {
			Session session = getSession();
			Integer usuario = Integer.parseInt(ultimoIdUsuario());
			Query query3 = session.getNamedQuery(INSERT_USER_PASS).setInteger(0, usuario)
					.setString(1, reportUserDto.getPass()).setInteger(2, 0).setDate(3, fecha);
			query3.executeUpdate();

			indicador = true;
		} catch (Error error) {
			indicador = false;
			logger.info("SolicitudLlamada: se a producido un error al editar el usuario: " + error);
		}
		return indicador;
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean altaRolUsuario(ReportUserDto reportUserDto) {
		boolean indicador;
		try {
			Session session = getSession();
			Integer usuario = Integer.parseInt(ultimoIdUsuario());
			Query query3 = session.getNamedQuery(INSERT_ROL_USER).setInteger(0, reportUserDto.getIdRol()).setInteger(1,
					usuario);
			query3.executeUpdate();

			indicador = true;
		} catch (Error error) {
			indicador = false;
			logger.info("SolicitudLlamada: se a producido un error al editar los roles: " + error);
		}
		return indicador;
	}

	@SuppressWarnings("unchecked")
	public String ultimoIdUsuario() {
		Session session = getSession();
		String consulta = "select MAX(usuario) from BDDSEG01.T3SEGO_USUA";

		Query query = session.createSQLQuery(consulta);
		String variable = query.list().get(0).toString();
		return variable;
	}

	@SuppressWarnings("unchecked")
	public String idArchivosUsuario() {
		Session session = getSession();
		String consulta = "select MAX(usuario)+1 from BDDSEG01.T3SEGO_USUA";

		Query query = session.createSQLQuery(consulta);
		String variable = query.list().get(0).toString();
		return variable;
	}
	
	@Override
	public boolean guardarDocumento(String ruta, String name, Integer idUsuario) {
		boolean indicador;
		Date fecha = new Date();
		try {
			Session session = getSession();
			Query query = session.getNamedQuery(INSERT_DOCU).setInteger(0, idUsuario).setDate(1, fecha)
					.setString(2, ruta).setString(3, name);
			query.executeUpdate();
			indicador = true;
		} catch (Error error) {
			indicador = false;
			logger.info("SolicitudLlamada: se a producido un error al guardar el documento: " + error);
		}
		return indicador;
	}

	@Override
	public boolean altaDocumento(String ruta, String name, Integer idUsuario) {
		boolean indicador;
		Date fecha = new Date();
		try {
			Integer usuario = Integer.parseInt(ultimoIdUsuario());
			Session session = getSession();
			Query query = session.getNamedQuery(INSERT_DOCU).setInteger(0, usuario).setDate(1, fecha).setString(2, ruta)
					.setString(3, name);
			query.executeUpdate();
			indicador = true;
		} catch (Error error) {
			indicador = false;
			logger.info("SolicitudLlamada: se a producido un error al guardar el documento: " + error);
		}
		return indicador;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<DocumentoDto> obtenerDocumentos(Integer idUsuario) {
		Session session = getSession();

		Query query = session.getNamedQuery(SELECT_DOCU).setInteger("idUsuario", idUsuario);
		query.setResultTransformer(new DocumentoTransformer());
		@SuppressWarnings("unchecked")
		List<DocumentoDto> listDocu = query.list();
		return listDocu;

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OperadorDto> obtenerEmpresas() {
		Session session = getSession();

		Query query = session.getNamedQuery(SELECT_OPER);
		query.setResultTransformer(new OperadorTransformer());
		@SuppressWarnings("unchecked")
		List<OperadorDto> listOper = query.list();
		return listOper;

	}

	@Override
	public String obtenerOperadorUsuario(Integer idUsuario) {
		logger.info("Ejecutando UserDaoImpl.findExternalUserById");
		String operador = "";
		try {
			Session session = getSession();
			Query query = session.getNamedQuery(SELECT_OPERADOR_USER).setInteger("idUsuario", idUsuario);
			operador = query.uniqueResult().toString();
		} catch (Exception error) {
			operador = "0:No disponible";
			logger.error("Error al consultar obtenerOperadorUsuario: " + error);
		}
		return operador;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EstatusDto> obtenerEstatus() {
		Session session = getSession();

		Query query = session.getNamedQuery(SELECT_ESTATUS);
		query.setResultTransformer(new EstatusTransformer());
		@SuppressWarnings("unchecked")
		List<EstatusDto> listEstatus = query.list();
		return listEstatus;

	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean eliminarDoc(Integer idDoc) {
		boolean indicador;
		try {
			Session session = getSession();
			Query query = session.getNamedQuery(DELETE_DOCU).setInteger(0, idDoc);
			query.executeUpdate();
			indicador = true;
		} catch (Exception error) {
			indicador = false;
			logger.error("SolicitudLlamada: se a producido un error al eliminar el documento: " + error);
		}
		return indicador;
	}
	
	@Override
	public List<ReportUserDto> findAllReportUsers() {
		logger.info("Ejecutando UserDaoImpl.findAllReportUsers");
		Session session = getSession();

		Query query = session
				.getNamedQuery(UserDaoImpl.SELECT_USERS_ADMIN);
		query.setResultTransformer(new ReportUserTransformer());
		@SuppressWarnings("unchecked")
		List<ReportUserDto> aliasToValueMapList = query.list();

		return aliasToValueMapList;
	}
	
	@Override
	public List<ReportUserDto> findReportUsersConcesionario() {
		logger.info("Ejecutando UserDaoImpl.findAllReportUsers");
		Session session = getSession();

		Query query = session
				.getNamedQuery(UserDaoImpl.SELECT_USERS_CON);
		query.setResultTransformer(new ReportUserTransformer());
		@SuppressWarnings("unchecked")
		List<ReportUserDto> aliasToValueMapList = query.list();

		return aliasToValueMapList;
	}
	
	@Override
	public List<ReportUserDto> getUsersConcesionarioByOp(String operadorUsuario) {
		logger.info("Ejecutando UserDaoImpl.getUsersConcesionarioByOp");
		String[] operador = operadorUsuario.split("\\:");
		Session session = getSession();
		Query query = session
				.getNamedQuery(UserDaoImpl.SELECT_USERS_CON_BY_OP);
		query.setParameter("operador", operador[0]);
		query.setResultTransformer(new ReportUserTransformer());
		@SuppressWarnings("unchecked")
		List<ReportUserDto> aliasToValueMapList = query.list();
 
		return aliasToValueMapList;
	}
	@Override
    public int getCountUsersConcesionarioByOp(String operador){
        Session session = getSession();
        try{        
        	Query query = session.getNamedQuery(UserDaoImpl.SELECT_COUNT_USERS_CON_BY_OP);
        	query.setParameter("operador", operador);
            return Integer.parseInt(query.uniqueResult().toString());                
        }catch(Exception error){
        	logger.error("Error al consultar getCountUsersConcesionario: " + error);
            return 0;
        }  
    }
	
	@Override
    public String getPassUser(int idUsuario){
        Session session = getSession();
        try{        
        	Query query = session.getNamedQuery(UserDaoImpl.SELECT_PASS_USERS);
        	query.setParameter("idUsuario", idUsuario);
            return query.uniqueResult().toString();                
        }catch(Exception error){
        	logger.error("Error al consultar pass: " + error);
            return "";
        }  
    }
	
	@Override
    public String getEstadoUser(int idUsuario){
        Session session = getSession();
        try{        
        	Query query = session.getNamedQuery(UserDaoImpl.SELECT_ESTADO_USERS);
        	query.setParameter("idUsuario", idUsuario);
            return query.uniqueResult().toString();                
        }catch(Exception error){
        	logger.error("Error al consultar estado: " + error);
            return "";
        }  
    }
}

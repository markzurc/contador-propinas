package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @author VI7XXE0
 *
 */
public class EstatusDto implements Serializable {

	private static final long serialVersionUID = -988003283087250019L;

	private Integer idEstatus;
	private String valor;

	public Integer getIdEstatus() {
		return idEstatus;
	}

	public void setIdEstatus(Integer idEstatus) {
		this.idEstatus = idEstatus;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public EstatusDto(Integer idEstatus, String valor) {
		this.idEstatus = idEstatus;
		this.valor = valor;
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.rol.dao.impl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcRol;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcTipoRol;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segrCapliCrolRapti;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.rol.dao.IRolDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.rol.dao.dto.RolAclDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.rol.dao.transformer.RolAclTransformer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Order;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

/**
 * 
 * <h1>RolDaoImpl</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 01/04/2015
 *
 */
@Repository(value="rolDao")
@Scope("prototype")
public class RolDaoImpl extends GenericFunctionDaoImpl implements IRolDao, Serializable{

	private static final long serialVersionUID = -7503179887939062892L;
	
	private static final String DELETE_ROL_ACL_BY_ID_ROL = "TsegrRolAcl.DELETE_ROL_ACL_BY_ID_ROL";
	private static final String SELECT_ROL_ACL = "TsegrAplicaionAcl.SELECT_ROL_ACL";
	private static final String SELECT_COUNT_ROL_IS_IN_USE = "RolDaoImpl.SELECT_COUNT_ROL_IS_IN_USE";
	private static final String SELECT_ROL_TYPE_IS_IN_USE = "RolDaoImpl.SELECT_ROL_TYPE_IS_IN_USE";
	
	private static final Logger logger = LogManager.getLogger(RolDaoImpl.class);

	@Override
	public void createRol(T7segcRol tsegcRol){
		logger.info("Ejecutando RolDaoImpl.createRol");
		create(tsegcRol);
	}

	@Override
	public void updateRol(T7segcRol tsegcRol){
		logger.info("Ejecutando RolDaoImpl.updateRol");
		update(tsegcRol);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T7segcRol> findBy(T7segcRol tsegcRol){
		logger.info("Ejecutando RolDaoImpl.findBy");
		Session session = getSession();
		Example example = Example.create(tsegcRol);
		return session.createCriteria(T7segcRol.class).add(example)
				.addOrder(Order.asc("idRol")).list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T7segcRol> findByWithApplications(T7segcRol tsegcRol) {
		logger.info("Ejecutando RolDaoImpl.findByWithApplications");
		Session session = getSession();
		Example example = Example.create(tsegcRol).excludeProperty("aplicaciones");
	    return session.createCriteria(T7segcRol.class).add(example)
	    		.setFetchMode("aplicaciones", FetchMode.SELECT)
	    		.addOrder(Order.asc("idRol")).list();
	}

	@Override
	public void createRolRestriction(List<T7segrCapliCrolRapti> lstTsegrRolAcl) {
		logger.info("Ejecutando RolDaoImpl.createRolRestriction");
		Session session = getSession();
		for (int i = 0; i < lstTsegrRolAcl.size(); i++) {
			if (i % 20 == 0) { // 20, same as the JDBC batch size
				// flush a batch of inserts and release memory:
				session.flush();
				session.clear();
			}
			session.save(lstTsegrRolAcl.get(i));
		}

	}

	@Override
	public void deleteRolRestriction(T7segrCapliCrolRapti tsegrRolAcl) {
		logger.info("Ejecutando RolDaoImpl.deleteRolRestriction");
		Session session = getSession();
		session.getNamedQuery(DELETE_ROL_ACL_BY_ID_ROL).setInteger("idRol", tsegrRolAcl.getIdRol()).executeUpdate();
	}

	@Override
	public List<RolAclDto> findByRolAcl(Integer idRol, Integer idAplicacion) {
		logger.info("Ejecutando RolDaoImpl.findByWithApplications");
		Session session = getSession();
		Query query = session.getNamedQuery(SELECT_ROL_ACL).setInteger("idAplicacion", idAplicacion).
												setInteger("idRol", idRol);
		query.setResultTransformer(new RolAclTransformer());
		@SuppressWarnings("unchecked")
		List<RolAclDto> lstRolAclDtos = query.list();
		return lstRolAclDtos;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T7segcTipoRol> getRoltype() {
		Session session = getSession();
		Criteria criteria = session.createCriteria(T7segcTipoRol.class);
		return criteria.list();
	}

	@Override
	public int isInUse(Integer idRol) {
		logger.info("Ejecutando RolDaoImpl.isInUse");
		Session session = getSession();
		Query query = session.getNamedQuery(SELECT_COUNT_ROL_IS_IN_USE).setInteger("idRol", idRol);
		return ((BigDecimal) query.uniqueResult()).intValue();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<T7segcRol> getRoles() {
		Session session = getSession();
		Criteria criteria = session.createCriteria(T7segcRol.class);
		return criteria.list();
	}

	@Override
	public String getRoltype(Integer idRol) {
		Session session = getSession();
		Query query = session.getNamedQuery(SELECT_ROL_TYPE_IS_IN_USE).setInteger("idRol", idRol);
		
		return (String) query.uniqueResult();
	}
}

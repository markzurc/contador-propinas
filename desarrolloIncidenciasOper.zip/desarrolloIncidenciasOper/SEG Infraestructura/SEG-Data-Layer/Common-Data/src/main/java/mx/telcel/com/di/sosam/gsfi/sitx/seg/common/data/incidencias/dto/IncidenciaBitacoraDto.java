package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto;

import java.io.Serializable;
import java.util.Date;

public class IncidenciaBitacoraDto implements Serializable {
	private Long id;
	private Long idIncidencia;
	private String estatusNuevo;
	private String responsabilidad;
	private String usuarioMovimiento;
	private Date fechaEvento;
	private String comentario;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getIdIncidencia() {
		return idIncidencia;
	}

	public void setIdIncidencia(Long idIncidencia) {
		this.idIncidencia = idIncidencia;
	}

	public String getEstatusNuevo() {
		return estatusNuevo;
	}

	public void setEstatusNuevo(String estatusNuevo) {
		this.estatusNuevo = estatusNuevo;
	}

	public String getResponsabilidad() {
		return responsabilidad;
	}

	public void setResponsabilidad(String responsabilidad) {
		this.responsabilidad = responsabilidad;
	}

	public String getUsuarioMovimiento() {
		return usuarioMovimiento;
	}

	public void setUsuarioMovimiento(String usuarioMovimiento) {
		this.usuarioMovimiento = usuarioMovimiento;
	}

	public Date getFechaEvento() {
		return fechaEvento;
	}

	public void setFechaEvento(Date fechaEvento) {
		this.fechaEvento = fechaEvento;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
}
package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto;

import java.util.List;

public class ConsultaSolicitudesDTO {
	
	public List<SolicitudDto> listSolicitudes;
	private String mensajeError;
	public String getMensajeError() {
		return mensajeError;
	}
	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}
	public List<SolicitudDto> getListSolicitudes() {
		return listSolicitudes;
	}
	public void setListSolicitudes(List<SolicitudDto> listSolicitudes) {
		this.listSolicitudes = listSolicitudes;
	}
	
	
	
	

}

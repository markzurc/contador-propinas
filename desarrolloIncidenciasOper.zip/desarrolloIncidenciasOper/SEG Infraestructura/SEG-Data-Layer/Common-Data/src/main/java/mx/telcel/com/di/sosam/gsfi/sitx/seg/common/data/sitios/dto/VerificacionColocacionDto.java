package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto;

import java.io.Serializable;

public class VerificacionColocacionDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5781251029872919469L;
	private String idVerificacionColocacion;
	private String observacionesVerificacion;
	private String areaPiso;
	private String espacioLineal;
	private String revisionPiso;
	private String revisionTorre;
	private String fechaCreacion;
	private String idFolio;
	
	public String getIdVerificacionColocacion() {
		return idVerificacionColocacion;
	}
	
	public void setIdVerificacionColocacion(String idVerificacionColocacion) {
		this.idVerificacionColocacion = idVerificacionColocacion;
	}
	
	public String getObservacionesVerificacion() {
		return observacionesVerificacion;
	}
	
	public void setObservacionesVerificacion(String observacionesVerificacion) {
		this.observacionesVerificacion = observacionesVerificacion;
	}
	
	public String getAreaPiso() {
		return areaPiso;
	}
	
	public void setAreaPiso(String areaPiso) {
		this.areaPiso = areaPiso;
	}
	
	public String getEspacioLineal() {
		return espacioLineal;
	}
	
	public void setEspacioLineal(String espacioLineal) {
		this.espacioLineal = espacioLineal;
	}
	
	public String getRevisionPiso() {
		return revisionPiso;
	}
	
	public void setRevisionPiso(String revisionPiso) {
		this.revisionPiso = revisionPiso;
	}
	
	public String getRevisionTorre() {
		return revisionTorre;
	}
	
	public void setRevisionTorre(String revisionTorre) {
		this.revisionTorre = revisionTorre;
	}
	
	public String getFechaCreacion() {
		return fechaCreacion;
	}
	
	public void setFechaCreacion(String fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	
	public String getIdFolio() {
		return idFolio;
	}
	
	public void setIdFolio(String idFolio) {
		this.idFolio = idFolio;
	}
	
	public VerificacionColocacionDto(String idVerificacionColocacion, String observacionesVerificacion, String areaPiso,
			String espacioLineal, String revisionPiso, String revisionTorre, String fechaCreacion, String idFolio) {
		super();
		this.idVerificacionColocacion = idVerificacionColocacion;
		this.observacionesVerificacion = observacionesVerificacion;
		this.areaPiso = areaPiso;
		this.espacioLineal = espacioLineal;
		this.revisionPiso = revisionPiso;
		this.revisionTorre = revisionTorre;
		this.fechaCreacion = fechaCreacion;
		this.idFolio = idFolio;
	}
	
	public VerificacionColocacionDto() {
		
	}
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.transformer;

import java.math.BigDecimal;
import java.util.List;
import org.hibernate.transform.ResultTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ServicioDto;;

public class ServicioTransformer implements ResultTransformer {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4569880860719168302L;

	@Override
	public Object transformTuple(Object[] tuple, String[] aliases) {
		Integer idServicio = ((BigDecimal) tuple[0]).intValue();
		String descripcion = checkStrNotNull(tuple[1]);
		
		ServicioDto detalleSevicio = new ServicioDto(idServicio, descripcion);
		return detalleSevicio;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List collection) {
		return collection;
	}
	
	private String checkStrNotNull(Object object) {
		return null != object ? object.toString() : " ";
	}
}

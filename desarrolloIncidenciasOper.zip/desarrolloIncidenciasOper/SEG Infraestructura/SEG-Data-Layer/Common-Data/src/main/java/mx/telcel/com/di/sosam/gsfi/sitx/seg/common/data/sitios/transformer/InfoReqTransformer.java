package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.transformer;

import java.math.BigDecimal;
import java.util.List;
import org.hibernate.transform.ResultTransformer;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.CInfoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ServicioDto;;

public class InfoReqTransformer implements ResultTransformer {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4569880860719168302L;

	@Override
	public Object transformTuple(Object[] tuple, String[] aliases) {
		String idTipoInfo  = checkStrNotNull(tuple[0]);
		String descripcion = checkStrNotNull(tuple[1]);
		String estatus = checkStrNotNull(tuple[2]);

		
		CInfoDto infoReq = new CInfoDto(idTipoInfo, descripcion, estatus);
		return infoReq;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List collection) {
		return collection;
	}
	
	private String checkStrNotNull(Object object) {
		return null != object ? object.toString() : " ";
	}
}

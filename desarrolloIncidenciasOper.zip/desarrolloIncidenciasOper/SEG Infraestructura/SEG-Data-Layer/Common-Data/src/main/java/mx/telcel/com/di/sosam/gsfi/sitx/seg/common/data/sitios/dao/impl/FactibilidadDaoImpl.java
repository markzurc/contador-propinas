package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.impl;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.IConsultaSitiosDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.IFactibilidadDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.AntenaDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.FactibilidadDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.FiltroSitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ServicioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.transformer.AntenasTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.transformer.ConsultaSitiosTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.transformer.FiltroSitioTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dto.GraficaDto;

@Repository(value = "factibilidadDao")
@Scope("prototype")
public class FactibilidadDaoImpl extends GenericFunctionDaoImpl
implements IFactibilidadDao, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5927713844014847278L;
	private Logger LOGGER = LogManager.getLogger(FactibilidadDaoImpl.class);
	private static final String SELECT_SERVICIOS = "T3Segcserv.SELECT_SERVICIOS";
	private static final String SELECT_ANTENAS = "T3SEGC_ANTE.SELECT_ANTENAS";
	private static final String INSERT_FACTI = "T3SEGO_FACTI.INSERT";
	private static final String T3SEGO_FACTI_RESU_UPDATE = "T3SEGO_FACTI_RESU.UPDATE";
	private static final String T3SEGO_FACTI_RESU_UPDATE_MR = "T3SEGO_FACTI_RESU.UPDATE_MR";
	private static final String SELECT_ID_FACTI = "T3SEGO_FACTI.SELECT_ID";
	private static final String SELECT_TORRE_POR_ID = "T3SEGO_TORRE.POR_ID";
	private static final String SELECT_FACTI_POR_FOLIO = "T3SEGO_FACTI.POR_FOLIO";
	private static final String INSERT_ANTENA = "T3SEGC_ANTE.INSERT";
	private static final String SELECT_TORRE = "T3Segcserv.SELECT_TORRES";
	private static final String SELECT_TIPO_ANTENAS = "T3Segcserv.SELECT_TIPO_ANTENAS";
	private static final String T3SEGO_SOLI_UPDATE_ESTADO = "T3SEGO_SOLI_UPDATE_ESTADO";
	

	@SuppressWarnings("unchecked")
	@Override
	public List<FactibilidadDto> getFactibilidad() {
		Session session = getSession();
		try {
			Query query = session.getNamedQuery(SELECT_SERVICIOS);
			LOGGER.info(query.toString());
			query.setResultTransformer(new ConsultaSitiosTransformer());
			return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar los Servicios");
			return Collections.<FactibilidadDto>emptyList();
		}
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<AntenaDto> getAntenas(String idFacti) {
		Session session = getSession();
		try {
			Query query = session.getNamedQuery(SELECT_ANTENAS)
					.setInteger(0, Integer.parseInt(idFacti));
			LOGGER.info(query.toString());
			query.setResultTransformer(new AntenasTransformer());
			return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar las antenas");
			return Collections.<AntenaDto>emptyList();
		}
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<String> getTorres() {
		Session session = getSession();
		try {
			Query query = session.getNamedQuery(SELECT_TORRE);
			return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar los Torres");
			return Collections.<String>emptyList();
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<String> getTipoAntenas() {
		Session session = getSession();
		try {
			Query query = session.getNamedQuery(SELECT_TIPO_ANTENAS);
			return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar los tipos de antenas");
			return Collections.<String>emptyList();
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public boolean crearSolicitud(FactibilidadDto factibilidadDto) {
		boolean indicador;
		try {
			Session session = getSession();
			Query query3 = session.getNamedQuery(INSERT_FACTI)
					.setString(0, factibilidadDto.getNivelCentroRadiacion())
					.setString(1, factibilidadDto.getAreaRequerida())
					.setString(2, factibilidadDto.getFolio())
					.setString(3, factibilidadDto.getFecha());
			query3.executeUpdate();

			indicador = true;
		} catch (Error error) {
			indicador = false;
			LOGGER.error("SolicitudLlamada: se a producido un error al insertar la factibilidad: " + error);
		}
		return indicador;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public boolean crearResultado(FactibilidadDto factibilidadDto) {
		boolean indicador;
		try {
			Session session = getSession();
			Query query3 = session.getNamedQuery(T3SEGO_FACTI_RESU_UPDATE)
					.setString(0, factibilidadDto.getIdTipoTorre())
					.setString(1, factibilidadDto.getAlturaTotal())
					.setString(2, factibilidadDto.getNivelCentroRadiacionDisponible())
					.setString(3, factibilidadDto.getAreaDisponiblePiso())
					.setString(4, factibilidadDto.getRecuperacionEspacio())
					.setString(5, factibilidadDto.getAdecuacion())
					.setString(6, factibilidadDto.getFactibilidadIncrementoTorre())
					.setString(7, factibilidadDto.getEspacioAdicionalPiso())
					.setString(8, factibilidadDto.getObservacionesInfraestructura())
					.setString(9, factibilidadDto.getLicencias())
					.setString(10, factibilidadDto.getDetalleLicencias())
					.setDate(11, factibilidadDto.getFechaInicio())
					.setDate(12, factibilidadDto.getFechaTermino())
					.setString(13, factibilidadDto.getRentaPisoActualizada())
					.setString(14, factibilidadDto.getRentaPisoConcesionario())
					.setString(15, factibilidadDto.getRentaTorre())
					.setString(16, factibilidadDto.getAcceso())
					.setString(17, factibilidadDto.getObservacionesOcupacion())
					.setString(18, factibilidadDto.getFactiLineaSuministro())
					.setString(19, factibilidadDto.getFactiLineaSuministroElectrica())
					.setString(20, factibilidadDto.getObservacionesEnergiaElectrica())
					.setString(21, factibilidadDto.getFactiAire())
					.setString(22, factibilidadDto.getFactiElementosAuxiliares())
					.setString(23, factibilidadDto.getObservacionesOtrosElementos())
					.setInteger(24, factibilidadDto.getIdFactibilidad());
			query3.executeUpdate();

			indicador = true;
		} catch (Error error) {
			indicador = false;
			LOGGER.error("SolicitudLlamada: se a producido un error al insertar la factibilidad: " + error);
		}
		return indicador;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public boolean actualizarMotivoRechazo(FactibilidadDto factibilidadDto) {
		boolean indicador;
		try {
			Session session = getSession();
			Query query3 = session.getNamedQuery(T3SEGO_FACTI_RESU_UPDATE_MR)
					.setString(0, factibilidadDto.getMotivoRechazo())
					.setInteger(1, factibilidadDto.getIdFactibilidad());
			query3.executeUpdate();

			indicador = true;
		} catch (Error error) {
			indicador = false;
			LOGGER.error("SolicitudLlamada: se a producido un error al actualizar la factibilidad: " + error);
		}
		return indicador;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public boolean crearAntena(List<AntenaDto> antenaDto) {
		boolean indicador;
		try {
			Session session = getSession();
			Integer idFacti = Integer.parseInt(idFacti());
			for (AntenaDto antenaDto2 : antenaDto) {
				Query query3 = session.getNamedQuery(INSERT_ANTENA)
						.setString(0, antenaDto2.getTipo())
						.setString(1, antenaDto2.getDimenciones())
						.setString(2, antenaDto2.getPeso())
						.setInteger(3, idFacti);
				query3.executeUpdate();
			}
			indicador = true;
		} catch (Error error) {
			indicador = false;
			LOGGER.error("SolicitudLlamada: se a producido un error al insertar la antena: " + error);
		}
		return indicador;
	}
	
	@SuppressWarnings("unchecked")
	public String idFacti() {
		Session session = getSession();
		Query query = session.getNamedQuery(SELECT_ID_FACTI);
		String variable = query.list().get(0).toString();
		return variable;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public String getTorrePorId(String idTorre) {
		Session session = getSession();
		Query query = session.getNamedQuery(SELECT_TORRE_POR_ID)
				.setInteger(0, Integer.parseInt(idTorre));
		String variable = query.list().get(0).toString();
		return variable;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public boolean modificarSitioEstado(String idFolio, String estado) {
		boolean indicador;
		try {
			Session session = getSession();
			Query query3 = session.getNamedQuery(T3SEGO_SOLI_UPDATE_ESTADO)
					.setString(0, estado)
					.setString(1, idFolio);
			query3.executeUpdate();
			indicador = true;
		} catch (Error error) {
			indicador = false;
			LOGGER.error("SolicitudLlamada: se a producido un error al editar la solicitud: " + error);
		}
		return indicador;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FactibilidadDto> getFacti(String idFacti) {
		try {
			Session session = getSession();
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT ID_FACTIBILIDAD AS \"idFactibilidad\", ");
			sql.append("NIVEL_CENTRO_RADIACION AS \"nivelCentroRadiacion\", ");
			sql.append("AREA_REQUERIDA AS \"areaRequerida\", ");
			sql.append("MOTIVO_RECHAZO AS \"motivoRechazo\", ");
			sql.append("ID_TIPO_TORRE AS \"idTipoTorre\", ");
			sql.append("ALTURA_TOTAL AS \"alturaTotal\", ");
			sql.append("NIVEL_CENTRO_RAD_DISPO AS \"nivelCentroRadiacionDisponible\", ");
			sql.append("AREA_DISPONIBLE_PISO AS \"areaDisponiblePiso\", ");
			sql.append("RECUPERACION_ESPACIO AS \"recuperacionEspacio\", ");
			sql.append("ADECUACION AS \"adecuacion\", ");
			sql.append("FACTI_INCREMENTO_TORRE AS \"factibilidadIncrementoTorre\", ");
			sql.append("ESPACIO_ADICIONAL_PISO AS \"espacioAdicionalPiso\", ");
			sql.append("OBSERVACIONES_INFRA AS \"observacionesInfraestructura\", ");
			sql.append("LICENCIAS AS \"licencias\", ");
			sql.append("DETALLE_LICENCIAS AS \"detalleLicencias\", ");
			sql.append("FECHA_INICIO AS \"fechaInicio\", ");
			sql.append("FECHA_TERMINO AS \"fechaTermino\", ");
			sql.append("RENTA_PISO_ATUALIZADA AS \"rentaPisoActualizada\", ");
			sql.append("RENTA_PISO_CONCESIONARIO AS \"rentaPisoConcesionario\", ");
			sql.append("RENTA_TORRE AS \"rentaTorre\", ");
			sql.append("ACCESO AS \"acceso\", ");
			sql.append("OBSERVACIONES_OCUPACION AS \"observacionesOcupacion\", ");
			sql.append("FACTI_SUMINISTRO AS \"factiLineaSuministro\", ");
			sql.append("FACTI_LINEA_SUMINISTRO_ELEC AS \"factiLineaSuministroElectrica\", ");
			sql.append("OBS_ENERGIA_ELCTRICA AS \"observacionesEnergiaElectrica\", ");
			sql.append("FACTI_AIRE AS \"factiAire\", ");
			sql.append("FACTI_ELEMENTOS_AUXILIARES AS \"factiElementosAuxiliares\", ");
			sql.append("OBS_OTROS_ELEMENTOS AS \"observacionesOtrosElementos\", ");
			sql.append("FECHA AS \"fecha\" ");
			sql.append("FROM BDDSEG01.T3SEGO_FACTI ");
			sql.append("WHERE ID_FACTIBILIDAD = :idFactibilidad");

			Query query = session.createSQLQuery(sql.toString())
					.addScalar("idFactibilidad", StandardBasicTypes.INTEGER)
					.addScalar("nivelCentroRadiacion", StandardBasicTypes.STRING)
					.addScalar("areaRequerida", StandardBasicTypes.STRING)
					.addScalar("motivoRechazo", StandardBasicTypes.STRING)
					.addScalar("idTipoTorre", StandardBasicTypes.STRING)
					.addScalar("alturaTotal", StandardBasicTypes.STRING)
					.addScalar("nivelCentroRadiacionDisponible", StandardBasicTypes.STRING)
					.addScalar("areaDisponiblePiso", StandardBasicTypes.STRING)
					.addScalar("recuperacionEspacio", StandardBasicTypes.STRING)
					.addScalar("adecuacion", StandardBasicTypes.STRING)
					.addScalar("factibilidadIncrementoTorre", StandardBasicTypes.STRING)
					.addScalar("espacioAdicionalPiso", StandardBasicTypes.STRING)
					.addScalar("observacionesInfraestructura", StandardBasicTypes.STRING)
					.addScalar("licencias", StandardBasicTypes.STRING)
					.addScalar("detalleLicencias", StandardBasicTypes.STRING)
					.addScalar("fechaInicio", StandardBasicTypes.DATE)
					.addScalar("fechaTermino", StandardBasicTypes.DATE)
					.addScalar("rentaPisoActualizada", StandardBasicTypes.STRING)
					.addScalar("rentaPisoConcesionario", StandardBasicTypes.STRING)
					.addScalar("rentaTorre", StandardBasicTypes.STRING)
					.addScalar("acceso", StandardBasicTypes.STRING)
					.addScalar("observacionesOcupacion", StandardBasicTypes.STRING)
					.addScalar("factiLineaSuministro", StandardBasicTypes.STRING)
					.addScalar("factiLineaSuministroElectrica", StandardBasicTypes.STRING)
					.addScalar("observacionesEnergiaElectrica", StandardBasicTypes.STRING)
					.addScalar("factiAire", StandardBasicTypes.STRING)
					.addScalar("factiElementosAuxiliares", StandardBasicTypes.STRING)
					.addScalar("observacionesOtrosElementos", StandardBasicTypes.STRING)
					.addScalar("fecha", StandardBasicTypes.STRING)
					.setResultTransformer(Transformers.aliasToBean(FactibilidadDto.class));
			query.setParameter("idFactibilidad", idFacti);
			return query.list();

		} catch (Exception e) {
			LOGGER.error("Error al consultar datos de la factibilidad: " + e);
			return Collections.<FactibilidadDto>emptyList();
		}
	}
	
	@Override
	public String getFactiPorFolio(String idFolio) {
		Session session = getSession();
		Query query = session.getNamedQuery(SELECT_FACTI_POR_FOLIO)
				.setInteger(0, Integer.parseInt(idFolio));
		if (query.list().size()>0) {
			String variable = query.list().get(0).toString();
			return variable;
		} else {
			return null;
		}
	}

}

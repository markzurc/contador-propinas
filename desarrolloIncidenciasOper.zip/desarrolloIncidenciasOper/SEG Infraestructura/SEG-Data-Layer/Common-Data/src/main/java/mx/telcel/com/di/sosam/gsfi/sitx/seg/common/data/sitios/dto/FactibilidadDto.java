package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto;

import java.io.Serializable;
import java.util.Date;

public class FactibilidadDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7776453995074889145L;
	private Integer idFactibilidad;
	private String nivelCentroRadiacion;
	private String areaRequerida;
	private String motivoRechazo;
	private String idTipoTorre;
	private String alturaTotal;
	private String nivelCentroRadiacionDisponible;
	private String areaDisponiblePiso;
	private String recuperacionEspacio;
	private String adecuacion;
	private String factibilidadIncrementoTorre;
	private String espacioAdicionalPiso;
	private String observacionesInfraestructura;
	private String licencias;
	private String detalleLicencias;
	private Date fechaInicio;
	private Date fechaTermino;
	private String rentaPisoActualizada;
	private String rentaPisoConcesionario;
	private String rentaTorre;
	private String acceso;
	private String observacionesOcupacion;
	private String factiLineaSuministro;
	private String factiLineaSuministroElectrica;
	private String observacionesEnergiaElectrica;
	private String factiAire;
	private String factiElementosAuxiliares;
	private String observacionesOtrosElementos;
	private String folio;
	private String fecha;

	public FactibilidadDto(Integer idFactibilidad, String nivelCentroRadiacion, String areaRequerida,
			String motivoRechazo, String idTipoTorre, String alturaTotal, String nivelCentroRadiacionDisponible,
			String areaDisponiblePiso, String recuperacionEspacio, String adecuacion,
			String factibilidadIncrementoTorre, String espacioAdicionalPiso, String observacionesInfraestructura,
			String licencias, String detalleLicencias, Date fechaInicio, Date fechaTermino, String rentaPisoActualizada,
			String rentaPisoConcesionario, String rentaTorre, String acceso, String observacionesOcupacion,
			String factiLineaSuministro, String factiLineaSuministroElectrica, String observacionesEnergiaElectrica,
			String factiAire, String factiElementosAuxiliares, String observacionesOtrosElementos, String fecha) {
		super();
		this.idFactibilidad = idFactibilidad;
		this.nivelCentroRadiacion = nivelCentroRadiacion;
		this.areaRequerida = areaRequerida;
		this.motivoRechazo = motivoRechazo;
		this.idTipoTorre = idTipoTorre;
		this.alturaTotal = alturaTotal;
		this.nivelCentroRadiacionDisponible = nivelCentroRadiacionDisponible;
		this.areaDisponiblePiso = areaDisponiblePiso;
		this.recuperacionEspacio = recuperacionEspacio;
		this.adecuacion = adecuacion;
		this.factibilidadIncrementoTorre = factibilidadIncrementoTorre;
		this.espacioAdicionalPiso = espacioAdicionalPiso;
		this.observacionesInfraestructura = observacionesInfraestructura;
		this.licencias = licencias;
		this.detalleLicencias = detalleLicencias;
		this.fechaInicio = fechaInicio;
		this.fechaTermino = fechaTermino;
		this.rentaPisoActualizada = rentaPisoActualizada;
		this.rentaPisoConcesionario = rentaPisoConcesionario;
		this.rentaTorre = rentaTorre;
		this.acceso = acceso;
		this.observacionesOcupacion = observacionesOcupacion;
		this.factiLineaSuministro = factiLineaSuministro;
		this.factiLineaSuministroElectrica = factiLineaSuministroElectrica;
		this.observacionesEnergiaElectrica = observacionesEnergiaElectrica;
		this.factiAire = factiAire;
		this.factiElementosAuxiliares = factiElementosAuxiliares;
		this.observacionesOtrosElementos = observacionesOtrosElementos;
		this.fecha = fecha;
	}

	public FactibilidadDto() {

	}

	/**
	 * @return the idFactibilidad
	 */
	public Integer getIdFactibilidad() {
		return idFactibilidad;
	}

	/**
	 * @param idFactibilidad the idFactibilidad to set
	 */
	public void setIdFactibilidad(Integer idFactibilidad) {
		this.idFactibilidad = idFactibilidad;
	}

	/**
	 * @param areaRequerida the areaRequerida to set
	 */
	public void setAreaRequerida(String areaRequerida) {
		this.areaRequerida = areaRequerida;
	}

	/**
	 * @return the nivelCentroRadiacion
	 */
	public String getNivelCentroRadiacion() {
		return nivelCentroRadiacion;
	}

	/**
	 * @param nivelCentroRadiacion the nivelCentroRadiacion to set
	 */
	public void setNivelCentroRadiacion(String nivelCentroRadiacion) {
		this.nivelCentroRadiacion = nivelCentroRadiacion;
	}

	/**
	 * @return the motivoRechazo
	 */
	public String getMotivoRechazo() {
		return motivoRechazo;
	}

	/**
	 * @param motivoRechazo the motivoRechazo to set
	 */
	public void setMotivoRechazo(String motivoRechazo) {
		this.motivoRechazo = motivoRechazo;
	}

	/**
	 * @return the idTipoTorre
	 */
	public String getIdTipoTorre() {
		return idTipoTorre;
	}

	/**
	 * @param idTipoTorre the idTipoTorre to set
	 */
	public void setIdTipoTorre(String idTipoTorre) {
		this.idTipoTorre = idTipoTorre;
	}

	/**
	 * @return the nivelCentroRadiacionDisponible
	 */
	public String getNivelCentroRadiacionDisponible() {
		return nivelCentroRadiacionDisponible;
	}

	/**
	 * @param nivelCentroRadiacionDisponible the nivelCentroRadiacionDisponible to
	 *                                       set
	 */
	public void setNivelCentroRadiacionDisponible(String nivelCentroRadiacionDisponible) {
		this.nivelCentroRadiacionDisponible = nivelCentroRadiacionDisponible;
	}

	/**
	 * @return the alturaTotal
	 */
	public String getAlturaTotal() {
		return alturaTotal;
	}

	/**
	 * @param alturaTotal the alturaTotal to set
	 */
	public void setAlturaTotal(String alturaTotal) {
		this.alturaTotal = alturaTotal;
	}

	/**
	 * @return the areaDisponiblePiso
	 */
	public String getAreaDisponiblePiso() {
		return areaDisponiblePiso;
	}

	/**
	 * @param areaDisponiblePiso the areaDisponiblePiso to set
	 */
	public void setAreaDisponiblePiso(String areaDisponiblePiso) {
		this.areaDisponiblePiso = areaDisponiblePiso;
	}

	/**
	 * @return the recuperacionEspacio
	 */
	public String getRecuperacionEspacio() {
		return recuperacionEspacio;
	}

	/**
	 * @param recuperacionEspacio the recuperacionEspacio to set
	 */
	public void setRecuperacionEspacio(String recuperacionEspacio) {
		this.recuperacionEspacio = recuperacionEspacio;
	}

	/**
	 * @return the adecuacion
	 */
	public String getAdecuacion() {
		return adecuacion;
	}

	/**
	 * @param adecuacion the adecuacion to set
	 */
	public void setAdecuacion(String adecuacion) {
		this.adecuacion = adecuacion;
	}

	/**
	 * @return the factibilidadIncrementoTorre
	 */
	public String getFactibilidadIncrementoTorre() {
		return factibilidadIncrementoTorre;
	}

	/**
	 * @param factibilidadIncrementoTorre the factibilidadIncrementoTorre to set
	 */
	public void setFactibilidadIncrementoTorre(String factibilidadIncrementoTorre) {
		this.factibilidadIncrementoTorre = factibilidadIncrementoTorre;
	}

	/**
	 * @return the espacioAdicionalPiso
	 */
	public String getEspacioAdicionalPiso() {
		return espacioAdicionalPiso;
	}

	/**
	 * @param espacioAdicionalPiso the espacioAdicionalPiso to set
	 */
	public void setEspacioAdicionalPiso(String espacioAdicionalPiso) {
		this.espacioAdicionalPiso = espacioAdicionalPiso;
	}

	/**
	 * @return the observacionesInfraestructura
	 */
	public String getObservacionesInfraestructura() {
		return observacionesInfraestructura;
	}

	/**
	 * @param observacionesInfraestructura the observacionesInfraestructura to set
	 */
	public void setObservacionesInfraestructura(String observacionesInfraestructura) {
		this.observacionesInfraestructura = observacionesInfraestructura;
	}

	/**
	 * @return the licencias
	 */
	public String getLicencias() {
		return licencias;
	}

	/**
	 * @param licencias the licencias to set
	 */
	public void setLicencias(String licencias) {
		this.licencias = licencias;
	}

	/**
	 * @return the detalleLicencias
	 */
	public String getDetalleLicencias() {
		return detalleLicencias;
	}

	/**
	 * @param detalleLicencias the detalleLicencias to set
	 */
	public void setDetalleLicencias(String detalleLicencias) {
		this.detalleLicencias = detalleLicencias;
	}

	/**
	 * @return the fechaInicio
	 */
	public Date getFechaInicio() {
		return fechaInicio;
	}

	/**
	 * @param fechaInicio the fechaInicio to set
	 */
	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	/**
	 * @return the fechaTermino
	 */
	public Date getFechaTermino() {
		return fechaTermino;
	}

	/**
	 * @param fechaTermino the fechaTermino to set
	 */
	public void setFechaTermino(Date fechaTermino) {
		this.fechaTermino = fechaTermino;
	}

	/**
	 * @return the rentaPisoActualizada
	 */
	public String getRentaPisoActualizada() {
		return rentaPisoActualizada;
	}

	/**
	 * @param rentaPisoActualizada the rentaPisoActualizada to set
	 */
	public void setRentaPisoActualizada(String rentaPisoActualizada) {
		this.rentaPisoActualizada = rentaPisoActualizada;
	}

	/**
	 * @return the rentaPisoConcesionario
	 */
	public String getRentaPisoConcesionario() {
		return rentaPisoConcesionario;
	}

	/**
	 * @param rentaPisoConcesionario the rentaPisoConcesionario to set
	 */
	public void setRentaPisoConcesionario(String rentaPisoConcesionario) {
		this.rentaPisoConcesionario = rentaPisoConcesionario;
	}

	/**
	 * @return the rentaTorre
	 */
	public String getRentaTorre() {
		return rentaTorre;
	}

	/**
	 * @param rentaTorre the rentaTorre to set
	 */
	public void setRentaTorre(String rentaTorre) {
		this.rentaTorre = rentaTorre;
	}

	/**
	 * @return the acceso
	 */
	public String getAcceso() {
		return acceso;
	}

	/**
	 * @param acceso the acceso to set
	 */
	public void setAcceso(String acceso) {
		this.acceso = acceso;
	}

	/**
	 * @return the observacionesOcupacion
	 */
	public String getObservacionesOcupacion() {
		return observacionesOcupacion;
	}

	/**
	 * @param observacionesOcupacion the observacionesOcupacion to set
	 */
	public void setObservacionesOcupacion(String observacionesOcupacion) {
		this.observacionesOcupacion = observacionesOcupacion;
	}

	/**
	 * @return the factiLineaSuministro
	 */
	public String getFactiLineaSuministro() {
		return factiLineaSuministro;
	}

	/**
	 * @param factiLineaSuministro the factiLineaSuministro to set
	 */
	public void setFactiLineaSuministro(String factiLineaSuministro) {
		this.factiLineaSuministro = factiLineaSuministro;
	}

	/**
	 * @return the factiLineaSuministroElectrica
	 */
	public String getFactiLineaSuministroElectrica() {
		return factiLineaSuministroElectrica;
	}

	/**
	 * @param factiLineaSuministroElectrica the factiLineaSuministroElectrica to set
	 */
	public void setFactiLineaSuministroElectrica(String factiLineaSuministroElectrica) {
		this.factiLineaSuministroElectrica = factiLineaSuministroElectrica;
	}

	/**
	 * @return the observacionesEnergiaElectrica
	 */
	public String getObservacionesEnergiaElectrica() {
		return observacionesEnergiaElectrica;
	}

	/**
	 * @param observacionesEnergiaElectrica the observacionesEnergiaElectrica to set
	 */
	public void setObservacionesEnergiaElectrica(String observacionesEnergiaElectrica) {
		this.observacionesEnergiaElectrica = observacionesEnergiaElectrica;
	}

	/**
	 * @return the factiAire
	 */
	public String getFactiAire() {
		return factiAire;
	}

	/**
	 * @param factiAire the factiAire to set
	 */
	public void setFactiAire(String factiAire) {
		this.factiAire = factiAire;
	}

	/**
	 * @return the factiElementosAuxiliares
	 */
	public String getFactiElementosAuxiliares() {
		return factiElementosAuxiliares;
	}

	/**
	 * @param factiElementosAuxiliares the factiElementosAuxiliares to set
	 */
	public void setFactiElementosAuxiliares(String factiElementosAuxiliares) {
		this.factiElementosAuxiliares = factiElementosAuxiliares;
	}

	/**
	 * @return the observacionesOtrosElementos
	 */
	public String getObservacionesOtrosElementos() {
		return observacionesOtrosElementos;
	}

	/**
	 * @param observacionesOtrosElementos the observacionesOtrosElementos to set
	 */
	public void setObservacionesOtrosElementos(String observacionesOtrosElementos) {
		this.observacionesOtrosElementos = observacionesOtrosElementos;
	}

	/**
	 * @return the folio
	 */
	public String getFolio() {
		return folio;
	}

	/**
	 * @param folio the folio to set
	 */
	public void setFolio(String folio) {
		this.folio = folio;
	}

	/**
	 * @return the areaRequerida
	 */
	public String getAreaRequerida() {
		return areaRequerida;
	}
	
	/**
	 * @return the fecha
	 */
	public String getFecha() {
		return fecha;
	}

	/**
	 * @param fecha the fecha to set
	 */
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

}

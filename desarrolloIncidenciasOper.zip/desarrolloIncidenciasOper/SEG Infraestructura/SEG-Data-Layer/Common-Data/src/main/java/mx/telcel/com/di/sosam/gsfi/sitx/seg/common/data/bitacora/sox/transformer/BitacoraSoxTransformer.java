package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.transformer;

import java.util.Date;
import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dto.BitacoraSoxDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segbBita;

import org.hibernate.transform.ResultTransformer;

/**
 * 
 * 
 * <h1>BitacoraSoxTransformer</h1>
 * <p>
 * </p>
 * 
 * @author chcastro
 * @version 1.0
 * @since 30/06/2015
 */
public class BitacoraSoxTransformer implements ResultTransformer {

	private static final long serialVersionUID = -6453138604822687586L;

	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List paramList) {
		return paramList;
	}

	@Override
	public Object transformTuple(Object[] rowData, String[] aliasNames) {
		T7segbBita tsegcBitacoraSox = (T7segbBita) rowData[0];
		Integer idBitacora = tsegcBitacoraSox.getIdBitacora();
		String objetoFinal = tsegcBitacoraSox.getDatoFinal();
		String objetoInicial = tsegcBitacoraSox.getDatoInicial();
		Date fechaOperacion = tsegcBitacoraSox.getFechaOperacion();
		String folioSua = tsegcBitacoraSox.getFolioSua();
		Integer idAccion = tsegcBitacoraSox.getIdAccion();
		Integer idUsuario = tsegcBitacoraSox.getIdUsuario();
		String numeroEmpleado = tsegcBitacoraSox.getNumeroEmpleado();
		String accionDescripcion = (String) rowData[1];
		return new BitacoraSoxDto(idBitacora, idUsuario, numeroEmpleado,
				folioSua, fechaOperacion, objetoInicial, objetoFinal, idAccion,
				accionDescripcion);
	}

}

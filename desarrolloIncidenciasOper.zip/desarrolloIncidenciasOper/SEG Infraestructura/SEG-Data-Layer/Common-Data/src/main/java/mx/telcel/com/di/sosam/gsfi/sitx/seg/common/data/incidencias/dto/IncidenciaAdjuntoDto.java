package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto;

import java.io.Serializable;

public class IncidenciaAdjuntoDto implements Serializable {
	private Long idAdjunto;
	private String nombreArchivo;
	private Long tamanioBytes;
	private String rutaArchivo;

	public Long getIdAdjunto() {
		return idAdjunto;
	}

	public void setIdAdjunto(Long idAdjunto) {
		this.idAdjunto = idAdjunto;
	}

	public String getNombreArchivo() {
		return nombreArchivo;
	}

	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}

	public Long getTamanioBytes() {
		return tamanioBytes;
	}

	public void setTamanioBytes(Long tamanioBytes) {
		this.tamanioBytes = tamanioBytes;
	}

	public String getRutaArchivo() {
		return rutaArchivo;
	}

	public void setRutaArchivo(String rutaArchivo) {
		this.rutaArchivo = rutaArchivo;
	}
}
package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.application.thirdparty;

import org.hibernate.Session;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.application.thirdparty.response.ApplicationGenericResponse;



/**
 * 
 * <h1>IApplicationMethods</h1>
 * <p>
 * Interface contains methods for the applications party
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 12/03/2015
 *
 */
public interface IApplicationMethods {
	
	/**
	 * <p>Example method to execute the insert</p>
	 * @param request {@link T} 
	 * @return {@link ApplicationGenericResponse}
	 */
	<T> ApplicationGenericResponse executeInsert(T request);
	
	/**
	 * <p>Example method to execute the Update</p>
	 * @param request {@link T} 
	 * @return {@link ApplicationGenericResponse}
	 */
	<T> ApplicationGenericResponse executeUpdate(T request);
	
	void setSession(Session session);
}

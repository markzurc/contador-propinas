package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto;

import java.io.Serializable;

public class InfoSoliDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4696068639029540302L;
	private Number idInfo;
	private String idFolioSoli;
	private String informacionEntregada;
	
	
	
	public InfoSoliDto() {
		super();
		this.idInfo = idInfo;
		this.idFolioSoli = idFolioSoli;
		this.informacionEntregada = informacionEntregada;
	}
	
	public Number getIdInfo() {
		return idInfo;
	}
	public void setIdInfo(Number idInfo) {
		this.idInfo = idInfo;
	}
	public String getIdFolioSoli() {
		return idFolioSoli;
	}
	public void setIdFolioSoli(String idFolioSoli) {
		this.idFolioSoli = idFolioSoli;
	}

	public String getInformacionEntregada() {
		return informacionEntregada;
	}

	public void setInformacionEntregada(String informacionEntregada) {
		this.informacionEntregada = informacionEntregada;
	}
	
	
}

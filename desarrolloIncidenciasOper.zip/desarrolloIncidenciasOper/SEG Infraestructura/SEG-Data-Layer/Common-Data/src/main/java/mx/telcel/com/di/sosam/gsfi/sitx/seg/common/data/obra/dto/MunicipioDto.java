package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class MunicipioDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5800061787186045591L;
	private BigDecimal idMunicipio;
	private String nombre;
	private BigDecimal idEstado;
	private String nombreEstado;
	private String idRegion;
	private BigDecimal estatus;
	
	public MunicipioDto(BigDecimal idMunicipio, String nombre, BigDecimal idEstado, String nombreEstado, String idRegion,
			BigDecimal estatus) {
		super();
		this.idMunicipio = idMunicipio;
		this.nombre = nombre;
		this.idEstado = idEstado;
		this.nombreEstado = nombreEstado;
		this.idRegion = idRegion;
		this.estatus = estatus;
	}
		
	public MunicipioDto() {

	}

	/**
	 * @return the idMunicipio
	 */
	public BigDecimal getIdMunicipio() {
		return idMunicipio;
	}
	/**
	 * @param idMunicipio the idMunicipio to set
	 */
	public void setIdMunicipio(BigDecimal idMunicipio) {
		this.idMunicipio = idMunicipio;
	}
	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @return the idEstado
	 */
	public BigDecimal getIdEstado() {
		return idEstado;
	}
	/**
	 * @param idEstado the idEstado to set
	 */
	public void setIdEstado(BigDecimal idEstado) {
		this.idEstado = idEstado;
	}
	/**
	 * @return the nombreEstado
	 */
	public String getNombreEstado() {
		return nombreEstado;
	}
	/**
	 * @param nombreEstado the nombreEstado to set
	 */
	public void setNombreEstado(String nombreEstado) {
		this.nombreEstado = nombreEstado;
	}
	/**
	 * @return the idRegion
	 */
	public String getIdRegion() {
		return idRegion;
	}
	/**
	 * @param idRegion the idRegion to set
	 */
	public void setIdRegion(String idRegion) {
		this.idRegion = idRegion;
	}
	/**
	 * @return the estatus
	 */
	public BigDecimal getEstatus() {
		return estatus;
	}
	/**
	 * @param estatus the estatus to set
	 */
	public void setEstatus(BigDecimal estatus) {
		this.estatus = estatus;
	}
	
}

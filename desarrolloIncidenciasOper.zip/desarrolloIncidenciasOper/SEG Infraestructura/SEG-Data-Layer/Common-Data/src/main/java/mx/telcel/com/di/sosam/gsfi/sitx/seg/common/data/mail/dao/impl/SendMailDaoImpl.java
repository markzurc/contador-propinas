package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.mail.dao.impl;

import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T7allcNoti;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.mail.dao.ISendMailDao;
import oracle.jdbc.OracleTypes;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.engine.jdbc.spi.JdbcConnectionAccess;
import org.hibernate.engine.spi.SessionImplementor;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

/**
 * 
 * <h1>SendMailDaoImpl</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 04/05/2015
 *
 */
@Repository(value="sendMailDao")
@Scope("prototype")
public class SendMailDaoImpl extends GenericFunctionDaoImpl implements
		ISendMailDao, Serializable {
	
	private static final long serialVersionUID = -3747501497758084027L;
	
	private static final Logger logger = LogManager.getLogger(SendMailDaoImpl.class);
	
	private static final String SP7SEG_NOTI_NUEV_USUA = "CALL BDDOVI01.SP7SEG_NOTI_NUEV_USUA(?,?,?)";
	private static final int MESSAGE_ID_NEW_USER = 1;
	private static final int MESSAGE_ID_RESET_PASSWORD = 2;
	
	private Connection conn = null;

	@Override
	public T7allcNoti getMessage(String identifier) {
		logger.info("Ejecutando SendMailDaoImpl.getMessage");
		Session session = getSession();
		Criteria criteria = session.createCriteria(T7allcNoti.class);
		criteria.add(Restrictions.like("nombreCorreo", identifier));
		return (T7allcNoti) criteria.uniqueResult();
	}

	@Override
	public T7allcNoti getNewUserMessage() throws SQLException {
		logger.info("Ejecutando SendMailDaoImpl.getResetPasswordMessage");
		CallableStatement callableStatement = null;
		ResultSet rs = null;
		
		try {
			T7allcNoti tcomcMensajes = null;

			conn = getJDBCConnection();
			callableStatement = getCallable();
			
			if (callableStatement != null && !callableStatement.isClosed()) {
				callableStatement.registerOutParameter(1, OracleTypes.VARCHAR);
				callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
				callableStatement.setInt(3, MESSAGE_ID_NEW_USER);
				callableStatement.execute();
				
				tcomcMensajes = new T7allcNoti();
				
				tcomcMensajes.setAsunto((String) callableStatement.getObject(1));
				tcomcMensajes.setValor((String) callableStatement.getObject(2));
				
			}
				
			return tcomcMensajes;
		}catch (SQLException e) {
			logger.error("Error al ejecutar SendMailDaoImpl.getResetPasswordMessage: " + e);
			throw e;
		}finally{
			if(rs != null && !rs.isClosed()){
				rs.close();
			}
			if(callableStatement != null && !callableStatement.isClosed()){
				callableStatement.close();
			}
			if(conn != null && !conn.isClosed()){
				conn.close();
			}
		}
	}
	
	@Override
	public T7allcNoti getResetPasswordMessage() throws SQLException {
		logger.info("Ejecutando SendMailDaoImpl.getResetPasswordMessage");
		CallableStatement callableStatement = null;
		ResultSet rs = null;
		
		try {
			T7allcNoti tcomcMensajes = null;

			conn = getJDBCConnection();
			callableStatement = getCallable();
			
			if (callableStatement != null && !callableStatement.isClosed()) {
				callableStatement.registerOutParameter(1, OracleTypes.VARCHAR);
				callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
				callableStatement.setInt(3, MESSAGE_ID_RESET_PASSWORD);
				callableStatement.execute();
				
				tcomcMensajes = new T7allcNoti();
				
				tcomcMensajes.setAsunto((String) callableStatement.getObject(1));
				tcomcMensajes.setValor((String) callableStatement.getObject(2));
				
			}
				
			return tcomcMensajes;
		}catch (SQLException e) {
			logger.error("Error al ejecutar SendMailDaoImpl.getResetPasswordMessage: " + e);
			throw e;
		}finally{
			if(rs != null && !rs.isClosed()){
				rs.close();
			}
			if(callableStatement != null && !callableStatement.isClosed()){
				callableStatement.close();
			}
			if(conn != null && !conn.isClosed()){
				conn.close();
			}
		}
	}
	
	private Connection  getJDBCConnection() throws SQLException{
		JdbcConnectionAccess access = getAccess();
		if(access!=null){
			return access.obtainConnection();
		}
		return null;
	}
	
	private JdbcConnectionAccess getAccess(){
		Session session = getSession();
		SessionImplementor sfi = (SessionImplementor) session;
		return sfi.getJdbcConnectionAccess();
	}
	
	private CallableStatement getCallable() throws SQLException{
		conn = getJDBCConnection();
		if (conn != null && !conn.isClosed()) {
			return conn.prepareCall(SP7SEG_NOTI_NUEV_USUA);
		}else{
			return null;
		}
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
/**
 * 
 * @author cavilezg
 *Entidad de tabla T7PFAC_GRUP_ROL
 */
@Entity
@Table(name = "T3PFAC_GRUP_ROL",  schema="BDDSEG01")
public class T7pfAcGrupRol {
	

	
	private Integer idGrupo;//	ID_GRUPO	NUMBER(3,0)
	private String nombre;//	NOMBRE	VARCHAR2(50 BYTE)
	private Integer estatus;//	ESTATUS	NUMBER(1,0)
	private String usuarioModificacion;//	USUARIO_MODIFICACION	NUMBER(9,0)
	private Date fechaModificacion;//	FECHA_MODIFICACION	DATE
	
	public T7pfAcGrupRol() {
		super();
	}

	public T7pfAcGrupRol(Integer idGrupo, String nombre, Integer estatus, String usuarioModificacion,
			Date fechaModificacion) {
		super();
		this.idGrupo = idGrupo;
		this.nombre = nombre;
		this.estatus = estatus;
		this.usuarioModificacion = usuarioModificacion;
		this.fechaModificacion = fechaModificacion;
	}

	@Id
	@Column(name = "ID_GRUPO", unique = true, nullable = false, precision = 22, scale = 0)
	//@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "")//validar si hay sequencia ligada
	//@SequenceGenerator(name = "SQ7SEGC_ROL", sequenceName = "BDDSEG01.SQ7SEGC_ROL",schema="BDDSEG01", allocationSize = 1)
	public Integer getIdGrupo() {
		return idGrupo;
	}
	
	public void setIdGrupo(Integer idGrupo) {
		this.idGrupo = idGrupo;
	}

	@Column(name = "NOMBRE", length = 270)
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "TIPO_ROL", nullable = false, precision = 22, scale = 0)
	public Integer getEstatus() {
		return estatus;
	}

	public void setEstatus(Integer estatus) {
		this.estatus = estatus;
	}

	@Column(name = "USUARIO_MODIFICACION", length = 70)
	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}

	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}

	@Column(name = "FECHA_MODIFICACION")
	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

}

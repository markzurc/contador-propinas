package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.proyecto.dao.impl;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegdSoliArch;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.impl.GestionObraCivilDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.proyecto.dao.IProyectoPresupuestoDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.proyecto.dto.ProyectoPresupuestoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.proyecto.dto.TipoSolicitudDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SoliArchDto;

@Repository(value = "proyectoPresupuestoDao")
@Scope("prototype")
public class ProyectoPresupuestoDaoImpl extends GenericFunctionDaoImpl implements IProyectoPresupuestoDao, Serializable {

	private static final long serialVersionUID = -4876881959773278951L;
	private Logger LOGGER = LogManager.getLogger(GestionObraCivilDaoImpl.class);
	private static final String INSERT_T3SEGO_ELAB_PROY_PREP = "T3SEGO_ELAB_PROY_PREP.INSERT";
	private static final String UPDATE_T3SEGO_SOLI = "T3SEGO_SOLI.UPDATE";
	private static final String ATENCION_T3SEGO_ELAB_PROY_PREP = "T3SEGO_ELAB_PROY_PREP.ATENCION";
	private static final String RECHAZO_T3SEGO_ELAB_PROY_PREP = "T3SEGO_ELAB_PROY_PREP.RECHAZO";
	private static final String CORRECCION_T3SEGO_ELAB_PROY_PREP = "T3SEGO_ELAB_PROY_PREP.CORRECCION";
	private static final String ADECUACION_RECUPERACION_T3SEGO_ELAB_PROY_PREP = "T3SEGO_ELAB_PROY_PREP.ADECUACION_RECUPERACION";
	private static final String ELIMINAR_T3SEGD_SOLI_ARCH = "T3SEGD_SOLI_ARCH.ELIMINAR";

	@SuppressWarnings("unchecked")
	@Override
	public List<SoliArchDto> getArchivos(String folio, String tipoArchivo) {
		try {
			 Session session = getSession();
			 StringBuilder sql= new StringBuilder();
			 sql.append("SELECT id_archivo AS \"idArchivo\", ruta AS \"ruta\", ")
			 .append("descripcion AS \"descripcion\", nombre_archivo AS \"nombreArch\",")
			 .append("tamanio AS \"tamanio\",to_char(FECHA_CARGA,'dd/MM/yyyy hh:mi:ss a.m.') AS \"fechaCarga\",")
			 .append("revision AS \"revision\", id_seccion AS \"idSeccion\",")
		     .append("id_folio AS \"folio\",")
		     .append("USUARIO.NOMBRE || ' ' || USUARIO.APELLIDO_PATERNO || ' ' || USUARIO.APELLIDO_MATERNO AS \"usuario\", ")
		     .append("'true' AS \"botonEliminar\" ")
		     .append("FROM BDDSEG01.T3SEGD_SOLI_ARCH SOLICITUD_ARCHIVO " )
		     .append("INNER JOIN  BDDSEG01.T3SEGO_USUA USUARIO ON SOLICITUD_ARCHIVO.USUARIO = USUARIO.USUARIO ")
		     .append("WHERE id_folio=:folio ")
			 .append("AND LOWER(descripcion) = LOWER(:tipoArchivo)");
		     Query query= session.createSQLQuery(sql.toString())
		        		.addScalar("idArchivo",StandardBasicTypes.INTEGER)
		        		.addScalar("ruta",StandardBasicTypes.STRING)
		        		.addScalar("descripcion",StandardBasicTypes.STRING)
		        		.addScalar("nombreArch",StandardBasicTypes.STRING)
		        		.addScalar("tamanio",StandardBasicTypes.STRING)
		        		.addScalar("fechaCarga",StandardBasicTypes.STRING)
		        		.addScalar("revision",StandardBasicTypes.STRING)
		        		.addScalar("usuario",StandardBasicTypes.STRING)
		        		.addScalar("idSeccion",StandardBasicTypes.INTEGER)
		        		.addScalar("folio",StandardBasicTypes.STRING)
		        		.addScalar("botonEliminar",StandardBasicTypes.STRING)
		        		.setResultTransformer(Transformers.aliasToBean(SoliArchDto.class));
			 query.setParameter("folio", folio);
			 query.setParameter("tipoArchivo", tipoArchivo);
			 
			 return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar el archivo: "+ tipoArchivo + " de Proyecto y Presupuestp: " + e);
			return Collections.<SoliArchDto>emptyList();
		}
	}
	

	@SuppressWarnings("unchecked")
	@Override
	public List<ProyectoPresupuestoDto> getDatosProyectoPorFolio(String folio) {
		try {
			 Session session = getSession();
			 StringBuilder sql= new StringBuilder();
			 sql.append("SELECT \"ID_PROYECTO\" AS idProyecto, ")
			 .append("\"OBSERVACIONES_SOLICITUD\" AS observacionesSolicitud, ")
			 .append("\"OBSERVACIONES_ATENCION\" AS observacionesAtencion, ")
			 .append("\"MOTIVO_RECHAZO\" AS motivoRechazo, ")
			 .append("\"OBSERVACIONES_ADECUACION\" AS observacionesAdecuacion, ")
			 .append("\"OBSERVACIONES_RECUPERACION\" AS observacionesRecuperacion, ")
			 .append("\"FECHA_CREACION\" AS fechaCreacion, ")
			 .append("\"ID_FOLIO\" AS idFolio, ")
			 .append("\"ID_TIPO_SOLICITUD\" AS idTipoSolicitud ")
		     .append("FROM BDDSEG01.T3SEGO_ELAB_PROY_PREP ")
		     .append("WHERE ID_FOLIO = :folio");
		     Query query= session.createSQLQuery(sql.toString())
		        		.addScalar("idProyecto",StandardBasicTypes.STRING)
		        		.addScalar("observacionesSolicitud",StandardBasicTypes.STRING)
		        		.addScalar("observacionesAtencion",StandardBasicTypes.STRING)
		        		.addScalar("motivoRechazo",StandardBasicTypes.STRING)
		        		.addScalar("observacionesAdecuacion",StandardBasicTypes.STRING)
		        		.addScalar("observacionesRecuperacion",StandardBasicTypes.STRING)
		        		.addScalar("fechaCreacion",StandardBasicTypes.STRING)
		        		.addScalar("idFolio",StandardBasicTypes.STRING)
		        		.addScalar("idTipoSolicitud",StandardBasicTypes.STRING)
		        		.setResultTransformer(Transformers.aliasToBean(ProyectoPresupuestoDto.class));
			 query.setParameter("folio", folio);
			 return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar los datos del Proyecto y Presupuesto " + e);
			return Collections.<ProyectoPresupuestoDto>emptyList();
		}
	}


	@Override
	public boolean crearProyectoPresupuesto(ProyectoPresupuestoDto proyecto) {
		boolean indicador;
		try {
			Session session = getSession();
			Query query = session.getNamedQuery(INSERT_T3SEGO_ELAB_PROY_PREP)
					.setString(0, proyecto.getObservacionesSolicitud())
					.setString(1, proyecto.getIdFolio());
			query.executeUpdate();

			indicador = true;
		} catch (Exception e) {
			indicador = false;
			LOGGER.error("Ocurrio un error al registrar la Solicitud de Proyecto y Presupuesto: " + e);
		}
		return indicador;
	}

	@Override
	public boolean updateEstadoSolicitud(String folio, String estatus) {
		boolean indicador;
		try {
			Session session = getSession();
			Query query = session.getNamedQuery(UPDATE_T3SEGO_SOLI)
					.setString(0, estatus)
					.setString(1, folio);
			query.executeUpdate();
			indicador = true;
		} catch (Exception e) {
			indicador = false;
			LOGGER.error("Se ha producido un error al actualizar el estatus de la Solicitud: " + e);
		}
		return indicador;
	}

	@Override
	public boolean guardarArchivo(T3SegdSoliArch archivo) {
		try {
			 Session session = getSession();
			 session.save(archivo);
			return true;
		} catch (Exception e) {
			LOGGER.error("Se ha producido un error al guardar el archivo en la tabla T3SEGD_SOLI_ARCH: " + e);
			return false;
		}
	}

	@Override
	public boolean atenderProyectoPresupuesto(ProyectoPresupuestoDto proyecto) {
		boolean indicador;
		try {
			Session session = getSession();
			Query query = session.getNamedQuery(ATENCION_T3SEGO_ELAB_PROY_PREP)
					.setString(0, proyecto.getObservacionesAtencion())
					.setString(1, proyecto.getIdProyecto());
			query.executeUpdate();
			indicador = true;
		} catch (Exception e) {
			indicador = false;
			LOGGER.error("Se ha producido un error al atender la Solicitud: " + e);
		}
		return indicador;
	}


	@Override
	public boolean rechazarProyectoPresupuesto(ProyectoPresupuestoDto proyecto) {
		boolean indicador;
		try {
			Session session = getSession();
			Query query = session.getNamedQuery(RECHAZO_T3SEGO_ELAB_PROY_PREP)
					.setString(0, proyecto.getMotivoRechazo())
					.setString(1, proyecto.getIdProyecto());
			query.executeUpdate();
			indicador = true;
		} catch (Exception e) {
			indicador = false;
			LOGGER.error("Se ha producido un error al rechazar la Solicitud: " + e);
		}
		return indicador;
	}


	@Override
	public boolean corregirProyectoPresupuesto(ProyectoPresupuestoDto proyecto) {
		boolean indicador;
		try {
			Session session = getSession();
			Query query = session.getNamedQuery(CORRECCION_T3SEGO_ELAB_PROY_PREP)
					.setString(0, proyecto.getObservacionesSolicitud())
					.setString(1, proyecto.getIdProyecto());
			query.executeUpdate();
			indicador = true;
		} catch (Exception e) {
			indicador = false;
			LOGGER.error("Se ha producido un error al corregir la Solicitud: " + e);
		}
		return indicador;
	}


	@Override
	public boolean eliminarArchivo(SoliArchDto archivo) {
		boolean indicador;
		try {
			Session session = getSession();
			Query query = session.getNamedQuery(ELIMINAR_T3SEGD_SOLI_ARCH)
					.setInteger(0, archivo.getIdArchivo());
			query.executeUpdate();
			indicador = true;
		} catch (Exception e) {
			indicador = false;
			LOGGER.error("Se ha producido un error al corregir la Solicitud: " + e);
		}
		return indicador;
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<TipoSolicitudDto> getDatosTipoSolicitud() {
		Session session = getSession();
		StringBuilder sql= new StringBuilder();
		try {
			sql.append("SELECT ID_TIPO_SOLICITUD AS \"idTipoSolicitud\", DESCRIPCION AS \"descripcion\" FROM BDDSEG01.T3SEGC_TIPO_SOLICITUD ORDER BY 1");

			Query query = session.createSQLQuery(sql.toString())
					.addScalar("idTipoSolicitud",StandardBasicTypes.STRING)
	        		.addScalar("descripcion",StandardBasicTypes.STRING)
			.setResultTransformer(Transformers.aliasToBean(TipoSolicitudDto.class));		
			return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar los tipos de solicitud: " + e.getMessage());
			return Collections.<TipoSolicitudDto>emptyList();
		}
	}

	@Override
	public boolean solicitarAdecuacionRecuperacion(ProyectoPresupuestoDto proyecto) {
		boolean indicador;
		try {
			Session session = getSession();
			Query query = session.getNamedQuery(ADECUACION_RECUPERACION_T3SEGO_ELAB_PROY_PREP)
					.setString(0, proyecto.getIdTipoSolicitud())
					.setString(1, proyecto.getObservacionesRecuperacion())
					.setString(2, proyecto.getObservacionesAdecuacion())
					.setString(3, proyecto.getIdProyecto());
			query.executeUpdate();
			indicador = true;
		} catch (Exception e) {
			indicador = false;
			LOGGER.error("Se ha producido un error al solicitar Adecuaci�n / Recuperaci�n: " + e);
		}
		return indicador;
	}


	@Override
	public String consultaIdEstadoBitacora(String estatus) {
		Session session = getSession();
        try{
            String sentencia = "SELECT ID_ESTADO_SOLI FROM BDDSEG01.T3SEGC_ESTA_SOLI WHERE UPPER(DESCRIPCION) = :estatus";
            Query query = session.createSQLQuery(sentencia);
            query.setParameter("estatus", estatus);
            String variable = query.list().get(0).toString() != null ? query.list().get(0).toString() : "0";
    		return variable;
        }catch(Exception e){
            return "0";
        }
	}
	
}

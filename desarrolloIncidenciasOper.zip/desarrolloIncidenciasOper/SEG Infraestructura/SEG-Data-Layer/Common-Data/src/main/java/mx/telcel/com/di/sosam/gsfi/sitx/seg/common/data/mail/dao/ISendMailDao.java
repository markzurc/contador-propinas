package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.mail.dao;

import java.sql.SQLException;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T7allcNoti;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.utils.session.ISession;

/**
 * 
 * <h1>ISendMailDao</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 04/05/2015
 *
 */
public interface ISendMailDao extends ISession{
	T7allcNoti getMessage(String identifier);
	T7allcNoti getNewUserMessage() throws SQLException;
	T7allcNoti getResetPasswordMessage() throws SQLException;
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * <h1>T7segcTipoUsua</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 20/04/2015
 *
 */
@Entity
@Table(name = "T3SEGC_TIPO_USUA",  schema="BDDSEG01")
public class T7segcTipoUsua implements java.io.Serializable {
	
	private static final long serialVersionUID = -6359035770357058726L;
	private Integer tipoUsuario;
	private String descripcion;

	public T7segcTipoUsua() {
	}

	public T7segcTipoUsua(Integer tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}

	public T7segcTipoUsua(Integer tipoUsuario, String descripcion) {
		this.tipoUsuario = tipoUsuario;
		this.descripcion = descripcion;
	}

	@Id
	@Column(name = "TIPO_USUARIO", unique = true, nullable = false, precision = 22, scale = 0)
	public Integer getIdTipoUsuario() {
		return this.tipoUsuario;
	}

	public void setIdTipoUsuario(Integer tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}

	@Column(name = "DESCRIPCION", length = 45)
	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * 
 * <h1>T7segoDatoUsuaInte</h1>
 * <p>
 * 
 * @author chcastro
 *
 */
@Entity
@Table(name = "T3SEGO_DATO_USUA_INTE",   schema="BDDSEG01",
		uniqueConstraints = 
			{@UniqueConstraint(columnNames = {"NUMERO_EMPLEADO"})})
public class T7segoDatoUsuaInte implements java.io.Serializable {

	private static final long serialVersionUID = -8467563185277546728L;

	private TsegcDatosinternoId id;
	private String claveRegion;
	private String jefe;
	private String codigoJefe;
	private String puesto;
	private String codigoPuesto;
	private String correo;
	private String numeroEmpleado;
	private Integer rol;
	
	//nuevos campos spml
	private String apellidos;
	private String centCost;
	private String clavDepto;
	private String clavDire;
	private String clavGere;
	private String clavSubdir;
	private String departamento;
	private String descanso1;
	private String descanso2;
	private String direccion;
	private String fechaIngreso;
	private String fullname;
	private String gerencia;
	private String region;
	private String subdireccion;
	private String spmlTipo;
	private String turno;
	private String ubicacion;
	private String universal;
	private String empresa;
	private String folioSua;
	private String tipoUsuarioIdm;
	private String estatusIdm;
	private String estatusRh;
	private String mov1Idm;
	private String mov2Idm;
	private String mov3Idm;
	private String mov4Idm;
	private String mov5Idm;
		
	public T7segoDatoUsuaInte() {
	}
	
	
	
	/**
	 * @param id
	 * @param claveRegion
	 * @param jefe
	 * @param codigoJefe
	 * @param puesto
	 * @param codigoPuesto
	 * @param correo
	 * @param numeroEmpleado
	 * @param rol
	 * @param apellidos
	 * @param centCost
	 * @param clavDepto
	 * @param clavDire
	 * @param clavGere
	 * @param clavSubdir
	 * @param departamento
	 * @param descanso1
	 * @param descanso2
	 * @param direccion
	 * @param fechaIngreso
	 * @param fullname
	 * @param gerencia
	 * @param region
	 * @param subdireccion
	 * @param spmlTipo
	 * @param turno
	 * @param ubicacion
	 * @param universal
	 * @param empresa
	 * @param folioSua
	 * @param tipoUsuarioIdm
	 * @param estatusIdm
	 * @param estatusRh
	 * @param mov1Idm
	 * @param mov2Idm
	 * @param mov3Idm
	 * @param mov4Idm
	 * @param mov5Idm
	 */
	public T7segoDatoUsuaInte(TsegcDatosinternoId id, String claveRegion,
			String jefe, String codigoJefe, String puesto, String codigoPuesto,
			String correo, String numeroEmpleado, Integer rol,
			String apellidos, String centCost, String clavDepto,
			String clavDire, String clavGere, String clavSubdir,
			String departamento, String descanso1, String descanso2,
			String direccion, String fechaIngreso, String fullname,
			String gerencia, String region, String subdireccion,
			String spmlTipo, String turno, String ubicacion, String universal,
			String empresa, String folioSua, String tipoUsuarioIdm,
			String estatusIdm, String estatusRh, String mov1Idm,
			String mov2Idm, String mov3Idm, String mov4Idm, String mov5Idm) {
		super();
		this.id = id;
		this.claveRegion = claveRegion;
		this.jefe = jefe;
		this.codigoJefe = codigoJefe;
		this.puesto = puesto;
		this.codigoPuesto = codigoPuesto;
		this.correo = correo;
		this.numeroEmpleado = numeroEmpleado;
		this.rol = rol;
		this.apellidos = apellidos;
		this.centCost = centCost;
		this.clavDepto = clavDepto;
		this.clavDire = clavDire;
		this.clavGere = clavGere;
		this.clavSubdir = clavSubdir;
		this.departamento = departamento;
		this.descanso1 = descanso1;
		this.descanso2 = descanso2;
		this.direccion = direccion;
		this.fechaIngreso = fechaIngreso;
		this.fullname = fullname;
		this.gerencia = gerencia;
		this.region = region;
		this.subdireccion = subdireccion;
		this.spmlTipo = spmlTipo;
		this.turno = turno;
		this.ubicacion = ubicacion;
		this.universal = universal;
		this.empresa = empresa;
		this.folioSua = folioSua;
		this.tipoUsuarioIdm = tipoUsuarioIdm;
		this.estatusIdm = estatusIdm;
		this.estatusRh = estatusRh;
		this.mov1Idm = mov1Idm;
		this.mov2Idm = mov2Idm;
		this.mov3Idm = mov3Idm;
		this.mov4Idm = mov4Idm;
		this.mov5Idm = mov5Idm;
	}

	
	
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "idUsuario", column = @Column(name = "USUARIO", nullable = false, precision = 22, scale = 0))})
	public TsegcDatosinternoId getId() {
		return this.id;
	}

	public void setId(TsegcDatosinternoId id) {
		this.id = id;
	}

	@Column(name = "CLAVE_REGION", length = 250)
	public String getIdRegion() {
		return this.claveRegion;
	}

	public void setIdRegion(String claveRegion) {
		this.claveRegion = claveRegion;
	}

	@Column(name = "JEFE", length = 250)
	public String getJefe() {
		return this.jefe;
	}

	public void setJefe(String jefe) {
		this.jefe = jefe;
	}

	@Column(name = "CODIGO_JEFE", length = 250)
	public String getCodigoJefe() {
		return this.codigoJefe;
	}

	public void setCodigoJefe(String codigoJefe) {
		this.codigoJefe = codigoJefe;
	}

	@Column(name = "PUESTO", length = 250)
	public String getPuesto() {
		return this.puesto;
	}

	public void setPuesto(String puesto) {
		this.puesto = puesto;
	}

	@Column(name = "CODIGO_PUESTO", length = 250)
	public String getCodigoPuesto() {
		return this.codigoPuesto;
	}

	public void setCodigoPuesto(String codigoPuesto) {
		this.codigoPuesto = codigoPuesto;
	}

	@Column(name = "CORREO", length = 250)
	public String getCorreo() {
		return this.correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}
	
	@Column(name = "NUMERO_EMPLEADO", nullable = false, unique = true, length = 250)
	public String getNumeroEmpleado() {
		return this.numeroEmpleado;
	}

	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	@Column(name = "ROL", nullable = false, precision = 22, scale = 0)
	public Integer getIdRol() {
		return rol;
	}

	public void setIdRol(Integer rol) {
		this.rol = rol;
	}
	
	@Column(name = "APELLIDOS", length = 250)
	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	@Column(name = "CENT_COST", length = 250)
	public String getCentCost() {
		return centCost;
	}

	public void setCentCost(String centCost) {
		this.centCost = centCost;
	}

	@Column(name = "CLAV_DEPTO", length = 250)
	public String getClavDepto() {
		return clavDepto;
	}

	public void setClavDepto(String clavDepto) {
		this.clavDepto = clavDepto;
	}

	@Column(name = "CLAV_DIRE", length = 250)
	public String getClavDire() {
		return clavDire;
	}

	public void setClavDire(String clavDire) {
		this.clavDire = clavDire;
	}

	@Column(name = "CLAV_GERE", length = 250)
	public String getClavGere() {
		return clavGere;
	}

	public void setClavGere(String clavGere) {
		this.clavGere = clavGere;
	}

	@Column(name = "CLAV_SUBDIR", length = 250)
	public String getClavSubdir() {
		return clavSubdir;
	}

	public void setClavSubdir(String clavSubdir) {
		this.clavSubdir = clavSubdir;
	}

	@Column(name = "DEPARTAMENTO", length = 250)
	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	@Column(name = "DESCANSO_1", length = 250)
	public String getDescanso1() {
		return descanso1;
	}

	public void setDescanso1(String descanso1) {
		this.descanso1 = descanso1;
	}

	@Column(name = "DESCANSO_2", length = 250)
	public String getDescanso2() {
		return descanso2;
	}

	public void setDescanso2(String descanso2) {
		this.descanso2 = descanso2;
	}

	@Column(name = "DIRECCION", length = 250)
	public String getDireccion() {
		return direccion;
	}
	
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	@Column(name = "FECHA_INGRESO", length = 250)
	public String getFechaIngreso() {
		return fechaIngreso;
	}

	public void setFechaIngreso(String fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}

	@Column(name = "EMPRESA", length = 250)
	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	@Column(name = "FOLIO_SUA", length = 250)
	public String getFolioSua() {
		return folioSua;
	}

	public void setFolioSua(String folioSua) {
		this.folioSua = folioSua;
	}

	@Column(name = "ESTATUS_IDM", length = 250)
	public String getEstatusIdm() {
		return estatusIdm;
	}

	public void setEstatusIdm(String estatusIdm) {
		this.estatusIdm = estatusIdm;
	}

	@Column(name = "ESTATUS_RH", length = 250)
	public String getEstatusRh() {
		return estatusRh;
	}

	public void setEstatusRh(String estatusRh) {
		this.estatusRh = estatusRh;
	}

	@Column(name = "FULLNAME", length = 250)
	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	@Column(name = "GERENCIA", length = 250)
	public String getGerencia() {
		return gerencia;
	}

	public void setGerencia(String gerencia) {
		this.gerencia = gerencia;
	}

	@Column(name = "MOV1_IDM", length = 250)
	public String getMov1Idm() {
		return mov1Idm;
	}

	public void setMov1Idm(String mov1Idm) {
		this.mov1Idm = mov1Idm;
	}

	@Column(name = "MOV2_IDM", length = 250)
	public String getMov2Idm() {
		return mov2Idm;
	}

	public void setMov2Idm(String mov2Idm) {
		this.mov2Idm = mov2Idm;
	}

	@Column(name = "MOV3_IDM", length = 250)
	public String getMov3Idm() {
		return mov3Idm;
	}

	public void setMov3Idm(String mov3Idm) {
		this.mov3Idm = mov3Idm;
	}

	@Column(name = "MOV4_IDM", length = 250)
	public String getMov4Idm() {
		return mov4Idm;
	}

	public void setMov4Idm(String mov4Idm) {
		this.mov4Idm = mov4Idm;
	}

	@Column(name = "MOV5_IDM", length = 250)
	public String getMov5Idm() {
		return mov5Idm;
	}

	public void setMov5Idm(String mov5Idm) {
		this.mov5Idm = mov5Idm;
	}

	@Column(name = "REGION", length = 250)
	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	@Column(name = "SUBDIRECCION", length = 250)
	public String getSubdireccion() {
		return subdireccion;
	}

	public void setSubdireccion(String subdireccion) {
		this.subdireccion = subdireccion;
	}

	@Column(name = "SPML_TIPO", length = 250)
	public String getSpmlTipo() {
		return spmlTipo;
	}

	public void setSpmlTipo(String spmlTipo) {
		this.spmlTipo = spmlTipo;
	}

	@Column(name = "TIPO_USUARIO_IDM", length = 250)
	public String getTipoUsuarioIdm() {
		return tipoUsuarioIdm;
	}

	public void setTipoUsuarioIdm(String tipoUsuarioIdm) {
		this.tipoUsuarioIdm = tipoUsuarioIdm;
	}

	@Column(name = "TURNO", length = 250)
	public String getTurno() {
		return turno;
	}

	public void setTurno(String turno) {
		this.turno = turno;
	}

	@Column(name = "UBICACION", length = 250)
	public String getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}

	@Column(name = "UNIVERSAL", length = 250)
	public String getUniversal() {
		return universal;
	}

	public void setUniversal(String universal) {
		this.universal = universal;
	}

}

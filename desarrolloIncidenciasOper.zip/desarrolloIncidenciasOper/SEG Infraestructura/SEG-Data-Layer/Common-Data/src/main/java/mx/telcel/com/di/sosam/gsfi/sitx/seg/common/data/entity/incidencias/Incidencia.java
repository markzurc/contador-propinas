package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date; // Usamos solo Date

@Entity
@Table(name = "T3SINO_INCI", schema = "BDDSEG01")
public class Incidencia implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID_INCI", nullable = false)
    private Long id;

    @Column(name = "FOLI_INCI", nullable = false, length = 30)
    private String folio;

    @Column(name = "ID_SITIO", nullable = false, length = 30)
    private String idSitio;

    @Column(name = "CONC_ID", nullable = false, length = 50)
    private String idConcesionario;

    @Column(name = "ID_TIPO_INCI", nullable = false)
    private Long idTipoIncidencia;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_TIPO_INCI", referencedColumnName = "ID_TIPO_INCI", insertable = false, updatable = false)
    private IncidenciaTipoCatalogo tipoCatalogo;

    @Column(name = "ID_ESTA_INCI", nullable = false)
    private Long idEstatusIncidencia;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_ESTA_INCI", referencedColumnName = "ID_ESTA_INCI", insertable = false, updatable = false)
    private IncidenciaEstatusCatalogo estatusCatalogo;

    @Column(name = "ID_RESP_INCI", nullable = false)
    private Long idResponsabilidad;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_RESP_INCI", referencedColumnName = "ID_RESP_INCI", insertable = false, updatable = false)
    private IncidenciaResponsabilidadCatalogo responsabilidadCatalogo;

    @Lob
    @Column(name = "DESC_INCI", nullable = false)
    private String descripcion;

    @Column(name = "ORIG_ALTA", nullable = false, length = 1)
    private String origenAlta = "I";

    @Column(name = "NOMB_REPO", length = 120)
    private String nombreReporta;

    @Column(name = "CORR_REPO", length = 200)
    private String correoReporta;

    @Column(name = "USU_ALTA", nullable = false, length = 60)
    private String usuarioAlta;
    
    // --- CORRECCI�N 1: Todas las fechas son java.util.Date ---

    @Column(name = "FEC_ALTA")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaAlta;

    @Column(name = "FEC_ULT_MOV")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaUltimoMovimiento;

    @Column(name = "ACTIVO", nullable = false, length = 1)
    private String activo = "S";

    @Column(name = "USU_ULT_MOD", length = 60)
    private String usuarioUltimaModificacion;

    // AQUI FALLABA: Tambi�n debe ser Date
    @Column(name = "FEC_ULT_MOD")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaUltimaModificacion;

    // --- CORRECCI�N 2: El PrePersist debe usar Date ---
    @PrePersist
    private void prePersist() {
        Date now = new Date(); // Usamos Date, no LocalDateTime
        
        if (fechaAlta == null) fechaAlta = now;
        if (fechaUltimoMovimiento == null) fechaUltimoMovimiento = now;
        if (fechaUltimaModificacion == null) fechaUltimaModificacion = now;
        
        if (activo == null) activo = "S";
        if (origenAlta == null) origenAlta = "I";
    }

    // Getters/Setters (Ajustados para recibir Date)
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getFolio() { return folio; }
    public void setFolio(String folio) { this.folio = folio; }

    public String getIdSitio() { return idSitio; }
    public void setIdSitio(String idSitio) { this.idSitio = idSitio; }

    public String getIdConcesionario() { return idConcesionario; }
    public void setIdConcesionario(String idConcesionario) { this.idConcesionario = idConcesionario; }

    public Long getIdTipoIncidencia() { return idTipoIncidencia; }
    public void setIdTipoIncidencia(Long idTipoIncidencia) { this.idTipoIncidencia = idTipoIncidencia; }

    public Long getIdEstatusIncidencia() { return idEstatusIncidencia; }
    public void setIdEstatusIncidencia(Long idEstatusIncidencia) { this.idEstatusIncidencia = idEstatusIncidencia; }

    public Long getIdResponsabilidad() { return idResponsabilidad; }
    public void setIdResponsabilidad(Long idResponsabilidad) { this.idResponsabilidad = idResponsabilidad; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getOrigenAlta() { return origenAlta; }
    public void setOrigenAlta(String origenAlta) { this.origenAlta = origenAlta; }

    public String getNombreReporta() { return nombreReporta; }
    public void setNombreReporta(String nombreReporta) { this.nombreReporta = nombreReporta; }

    public String getCorreoReporta() { return correoReporta; }
    public void setCorreoReporta(String correoReporta) { this.correoReporta = correoReporta; }

    public String getUsuarioAlta() { return usuarioAlta; }
    public void setUsuarioAlta(String usuarioAlta) { this.usuarioAlta = usuarioAlta; }

    public Date getFechaAlta() { return fechaAlta; }
    public void setFechaAlta(Date fechaAlta) { this.fechaAlta = fechaAlta; }

    public Date getFechaUltimoMovimiento() { return fechaUltimoMovimiento; }
    public void setFechaUltimoMovimiento(Date fechaUltimoMovimiento) { this.fechaUltimoMovimiento = fechaUltimoMovimiento; }

    public String getActivo() { return activo; }
    public void setActivo(String activo) { this.activo = activo; }

    public String getUsuarioUltimaModificacion() { return usuarioUltimaModificacion; }
    public void setUsuarioUltimaModificacion(String usuarioUltimaModificacion) { this.usuarioUltimaModificacion = usuarioUltimaModificacion; }

    public Date getFechaUltimaModificacion() { return fechaUltimaModificacion; }
    public void setFechaUltimaModificacion(Date fechaUltimaModificacion) { this.fechaUltimaModificacion = fechaUltimaModificacion; }
}
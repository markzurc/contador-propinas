package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.impl;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;
import java.time.LocalDateTime;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.Incidencia;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaDao;

@Repository
@Transactional
public class IncidenciaDaoImpl implements IIncidenciaDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Long obtenerSiguienteId() {
        Number siguiente = (Number) entityManager
                .createNativeQuery("SELECT NVL(MAX(ID_INCI), 0) + 1 FROM BDDSEG01.T3SINO_INCI")
                .getSingleResult();
        return siguiente.longValue();
    }

    @Override
    public void persist(Incidencia incidencia) {
        if (incidencia == null) {
            return;
        }

        if (incidencia.getId() == null) {
            incidencia.setId(obtenerSiguienteId());
        }

        prepararDefaultsAntesDePersistir(incidencia);
        entityManager.persist(incidencia);
    }

    @Override
    public Incidencia merge(Incidencia incidencia) {
        if (incidencia == null) {
            return null;
        }

        prepararDefaultsAntesDePersistir(incidencia);
        return entityManager.merge(incidencia);
    }

    @Override
    public Incidencia findById(Long idIncidencia) {
        if (idIncidencia == null) {
            return null;
        }

        TypedQuery<Incidencia> query = entityManager.createQuery(
                "SELECT i FROM Incidencia i WHERE i.id = :id AND i.activo = 'S'",
                Incidencia.class);
        query.setParameter("id", idIncidencia);

        List<Incidencia> resultados = query.getResultList();
        return resultados.isEmpty() ? null : resultados.get(0);
    }

    @Override
    public Incidencia findByFolio(String folioIncidencia) {
        if (folioIncidencia == null || folioIncidencia.trim().isEmpty()) {
            return null;
        }

        TypedQuery<Incidencia> query = entityManager.createQuery(
                "SELECT i FROM Incidencia i WHERE i.folio = :folio AND i.activo = 'S'",
                Incidencia.class);
        query.setParameter("folio", folioIncidencia.trim());

        List<Incidencia> resultados = query.getResultList();
        return resultados.isEmpty() ? null : resultados.get(0);
    }

    @Override
    public List<Incidencia> findAll() {
        TypedQuery<Incidencia> query = entityManager.createQuery(
                "SELECT i FROM Incidencia i WHERE i.activo = 'S' ORDER BY i.fechaUltimoMovimiento DESC",
                Incidencia.class);
        return query.getResultList();
    }

    @Override
    public List<Incidencia> findAllByConcesionario(String idConcesionario) {
        if (idConcesionario == null || idConcesionario.trim().isEmpty()) {
            return Collections.emptyList();
        }

        TypedQuery<Incidencia> query = entityManager.createQuery(
                "SELECT i FROM Incidencia i " +
                "WHERE i.idConcesionario = :idConcesionario AND i.activo = 'S' " +
                "ORDER BY i.fechaUltimoMovimiento DESC",
                Incidencia.class);
        query.setParameter("idConcesionario", idConcesionario.trim());

        return query.getResultList();
    }

    @Override
    public List<Incidencia> findBySitioAndEstatus(String idSitio, String estatus) {
        if (idSitio == null || idSitio.trim().isEmpty() || estatus == null || estatus.trim().isEmpty()) {
            return Collections.emptyList();
        }

        // Soporta filtrar por CVE (EN_ATENCION) o por DSC (EN ATENCI�N/EN ATENCION)
        TypedQuery<Incidencia> query = entityManager.createQuery(
                "SELECT i FROM Incidencia i " +
                "JOIN i.estatusCatalogo e " +
                "WHERE i.idSitio = :idSitio AND i.activo = 'S' AND (" +
                "  UPPER(e.clave) = UPPER(:estatus) OR " +
                "  FUNCTION('TRANSLATE', UPPER(e.descripcion), '�����', 'AEIOU') = FUNCTION('TRANSLATE', UPPER(:estatus), '�����', 'AEIOU')" +
                ") " +
                "ORDER BY i.fechaUltimoMovimiento DESC",
                Incidencia.class);

        query.setParameter("idSitio", idSitio.trim());
        query.setParameter("estatus", estatus.trim());

        return query.getResultList();
    }

    @Override
    public Incidencia findBySitioAndConcesionario(String idSitio, String idConcesionario) {
        if (idSitio == null || idSitio.trim().isEmpty() || idConcesionario == null || idConcesionario.trim().isEmpty()) {
            return null;
        }

        TypedQuery<Incidencia> query = entityManager.createQuery(
                "SELECT i FROM Incidencia i " +
                "WHERE i.idSitio = :idSitio AND i.idConcesionario = :idConcesionario AND i.activo = 'S'",
                Incidencia.class);

        query.setParameter("idSitio", idSitio.trim());
        query.setParameter("idConcesionario", idConcesionario.trim());

        List<Incidencia> resultados = query.getResultList();
        return resultados.isEmpty() ? null : resultados.get(0);
    }

  

    private void prepararDefaultsAntesDePersistir(Incidencia incidencia) {
        LocalDateTime ahora = LocalDateTime.now();

        if (incidencia.getFechaAlta() == null) {
            incidencia.setFechaAlta(ahora);
        }

        if (incidencia.getFechaUltimoMovimiento() == null) {
            incidencia.setFechaUltimoMovimiento(ahora);
        }

        if (incidencia.getActivo() == null || incidencia.getActivo().trim().isEmpty()) {
            incidencia.setActivo("S");
        }

        if (incidencia.getOrigenAlta() == null || incidencia.getOrigenAlta().trim().isEmpty()) {
            incidencia.setOrigenAlta("I");
        }
    }

}

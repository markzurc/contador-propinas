package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.impl;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.T3SINO_INCI;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaDao;

@Repository
@Transactional
public class IncidenciaDaoImpl implements IIncidenciaDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(IncidenciaDaoImpl.class);

    private static final String SQL_NEXT_ID =
            "SELECT NVL(MAX(ID_INCI), 0) + 1 FROM BDDSEG01.T3SINO_INCI";

    private static final String JPQL_FIND_BY_FOLIO =
            "SELECT i FROM T3SINO_INCI i WHERE i.folio = :folio AND i.activo = 'S'";

    private static final String JPQL_FIND_ALL =
            "SELECT i FROM T3SINO_INCI i WHERE i.activo = 'S' ORDER BY i.fechaUltimoMovimiento DESC";

    private static final String JPQL_FIND_ALL_BY_CONCESIONARIO =
            "SELECT i FROM T3SINO_INCI i WHERE i.idConcesionario = :concId AND i.activo = 'S' " +
            "ORDER BY i.fechaUltimoMovimiento DESC";

    private static final String JPQL_FIND_BY_SITIO_AND_CONCESIONARIO =
            "SELECT i FROM T3SINO_INCI i WHERE i.idSitio = :idSitio AND i.idConcesionario = :idConcesionario " +
            "AND i.activo = 'S'";

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Long obtenerSiguienteId() {
        Number siguiente = (Number) entityManager.createNativeQuery(SQL_NEXT_ID).getSingleResult();
        return siguiente.longValue();
    }

    @Override
    public void persist(T3SINO_INCI incidencia) {
        if (incidencia == null) {
            return;
        }

        if (incidencia.getId() == null) {
            incidencia.setId(obtenerSiguienteId());
        }

        prepararDefaultsAntesDePersistir(incidencia);
        entityManager.persist(incidencia);
    }

    @Override
    public T3SINO_INCI merge(T3SINO_INCI incidencia) {
        if (incidencia == null) {
            return null;
        }

        prepararDefaultsAntesDePersistir(incidencia);
        return entityManager.merge(incidencia);
    }

    @Override
    public T3SINO_INCI findById(Long idIncidencia) {
        if (idIncidencia == null) {
            return null;
        }
        return entityManager.find(T3SINO_INCI.class, idIncidencia);
    }

    @Override
    public T3SINO_INCI findByFolio(String folioIncidencia) {
        if (isBlank(folioIncidencia)) {
            return null;
        }

        TypedQuery<T3SINO_INCI> query = entityManager.createQuery(JPQL_FIND_BY_FOLIO, T3SINO_INCI.class);
        query.setParameter("folio", folioIncidencia.trim());

        List<T3SINO_INCI> resultados = query.setMaxResults(1).getResultList();
        return resultados.isEmpty() ? null : resultados.get(0);
    }

    @Override
    public List<T3SINO_INCI> findAll() {
        TypedQuery<T3SINO_INCI> query = entityManager.createQuery(JPQL_FIND_ALL, T3SINO_INCI.class);
        return query.getResultList();
    }

    @Override
    public List<T3SINO_INCI> findAllByConcesionario(String idConcesionario) {
        if (isBlank(idConcesionario)) {
            return Collections.emptyList();
        }

        TypedQuery<T3SINO_INCI> query = entityManager.createQuery(JPQL_FIND_ALL_BY_CONCESIONARIO, T3SINO_INCI.class);
        query.setParameter("concId", idConcesionario.trim());

        return query.getResultList();
    }

    @Override
    public List<T3SINO_INCI> findBySitioAndEstatus(String idSitio, String estatus) {
        if (idSitio == null) {
            return Collections.emptyList();
        }

        Long estatusNumerico = null;
        if (!isBlank(estatus)) {
            try {
                estatusNumerico = Long.valueOf(estatus);
            } catch (NumberFormatException ex) {
                // Mantener el efecto en UI (sin tronar): si llega basura, no hay resultados.
                LOGGER.warn("Estatus inv�lido (no num�rico) en findBySitioAndEstatus: [{}]", estatus);
                return Collections.emptyList();
            }
        }

        StringBuilder jpql = new StringBuilder();
        jpql.append("SELECT i FROM T3SINO_INCI i ");
        jpql.append("WHERE i.idSitio = :idSitio AND i.activo = 'S' ");

        if (estatusNumerico != null) {
            jpql.append("AND i.idEstatusIncidencia = :estatus ");
        }

        jpql.append("ORDER BY i.fechaUltimoMovimiento DESC");

        TypedQuery<T3SINO_INCI> query = entityManager.createQuery(jpql.toString(), T3SINO_INCI.class);
        query.setParameter("idSitio", idSitio);

        if (estatusNumerico != null) {
            query.setParameter("estatus", estatusNumerico);
        }

        return query.getResultList();
    }

    @Override
    public T3SINO_INCI findBySitioAndConcesionario(String idSitio, String idConcesionario) {
        if (idSitio == null || idConcesionario == null) {
            return null;
        }

        TypedQuery<T3SINO_INCI> query = entityManager.createQuery(
                JPQL_FIND_BY_SITIO_AND_CONCESIONARIO,
                T3SINO_INCI.class);

        query.setParameter("idSitio", idSitio.trim());
        query.setParameter("idConcesionario", idConcesionario.trim());

        List<T3SINO_INCI> resultados = query.setMaxResults(1).getResultList();
        return resultados.isEmpty() ? null : resultados.get(0);
    }

    private void prepararDefaultsAntesDePersistir(T3SINO_INCI incidencia) {
        Date ahora = new Date();

        if (incidencia.getFechaAlta() == null) {
            incidencia.setFechaAlta(ahora);
        }
        if (incidencia.getFechaUltimoMovimiento() == null) {
            incidencia.setFechaUltimoMovimiento(ahora);
        }
        if (isBlank(incidencia.getActivo())) {
            incidencia.setActivo("S");
        }
        if (isBlank(incidencia.getOrigenAlta())) {
            incidencia.setOrigenAlta("I");
        }
    }

    @Override
    @Transactional(readOnly = true)
    public String obtenerCorreoExternoPorUsuario(Integer idUsuario, Integer idRol) {
        if (idUsuario == null) {
            return null;
        }

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT CORREO ");
        sql.append("  FROM BDDSEG01.T3SEGO_DATO_USUA_EXTE ");
        sql.append(" WHERE USUARIO = :idUsuario ");

        if (idRol != null) {
            sql.append("   AND ID_ROL = :idRol ");
        }

        sql.append("   AND ROWNUM = 1 ");

        Query query = entityManager.createNativeQuery(sql.toString());
        query.setParameter("idUsuario", idUsuario);

        if (idRol != null) {
            query.setParameter("idRol", idRol);
        }

        @SuppressWarnings("unchecked")
        List<Object> resultados = query.getResultList();

        return firstStringOrNull(resultados);
    }

    @Override
    @Transactional(readOnly = true)
    public String obtenerNombreCompletoUsuarioPorId(Integer idUsuario) {
        if (idUsuario == null) {
            return null;
        }

        final String sql =
                "SELECT TRIM(NOMBRE || ' ' || APELLIDO_PATERNO || ' ' || APELLIDO_MATERNO) " +
                "  FROM BDDSEG01.T3SEGO_USUA " +
                " WHERE USUARIO = :idUsuario";

        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("idUsuario", idUsuario);

        @SuppressWarnings("unchecked")
        List<Object> resultados = query.getResultList();

        return firstStringOrNull(resultados);
    }

    private String firstStringOrNull(List<Object> resultados) {
        if (resultados == null || resultados.isEmpty()) {
            return null;
        }

        Object valor = resultados.get(0);
        String texto = (valor != null) ? valor.toString().trim() : null;

        return isBlank(texto) ? null : texto;
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}

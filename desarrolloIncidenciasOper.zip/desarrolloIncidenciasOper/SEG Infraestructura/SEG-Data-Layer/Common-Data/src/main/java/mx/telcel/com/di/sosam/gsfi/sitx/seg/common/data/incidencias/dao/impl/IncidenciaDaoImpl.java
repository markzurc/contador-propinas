package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.impl;

import java.util.Collections;
import javax.persistence.Query;

import java.util.Date; // <--- USAR DATE
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.Incidencia;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaDao;
import java.util.List;
@Repository
@Transactional
public class IncidenciaDaoImpl implements IIncidenciaDao {

    @PersistenceContext
    private EntityManager entityManager;

    // --------------------------------------------------------
    // M�TODOS OBLIGATORIOS DE LA INTERFACE
    // --------------------------------------------------------

    @Override
    public Long obtenerSiguienteId() {
        Number siguiente = (Number) entityManager
                .createNativeQuery("SELECT NVL(MAX(ID_INCI), 0) + 1 FROM BDDSEG01.T3SINO_INCI")
                .getSingleResult();
        return siguiente.longValue();
    }

    @Override
    public void persist(Incidencia incidencia) {
        if (incidencia == null) return;
        
        if (incidencia.getId() == null) {
            incidencia.setId(obtenerSiguienteId());
        }

        prepararDefaultsAntesDePersistir(incidencia);
        entityManager.persist(incidencia);
    }

    @Override
    public Incidencia merge(Incidencia incidencia) {
        if (incidencia == null) return null;
        prepararDefaultsAntesDePersistir(incidencia);
        return entityManager.merge(incidencia);
    }

    @Override
    public Incidencia findById(Long id) {
        if (id == null) return null;
        return entityManager.find(Incidencia.class, id);
    }

    // --- ESTE FALTABA Y ES REQUERIDO POR LA INTERFACE ---
    @Override
    public Incidencia findByFolio(String folioIncidencia) {
        if (folioIncidencia == null || folioIncidencia.trim().isEmpty()) return null;
        
        TypedQuery<Incidencia> query = entityManager.createQuery(
                "SELECT i FROM Incidencia i WHERE i.folio = :folio AND i.activo = 'S'", 
                Incidencia.class);
        query.setParameter("folio", folioIncidencia.trim());
        
        List<Incidencia> lista = query.getResultList();
        return lista.isEmpty() ? null : lista.get(0);
    }

    @Override
    public List<Incidencia> findAll() {
        TypedQuery<Incidencia> query = entityManager.createQuery(
                "SELECT i FROM Incidencia i WHERE i.activo = 'S' ORDER BY i.fechaUltimoMovimiento DESC",
                Incidencia.class);
        return query.getResultList();
    }

    @Override
    public List<Incidencia> findAllByConcesionario(String concesionario) {
        if (concesionario == null || concesionario.trim().isEmpty()) {
            return Collections.emptyList();
        }
        TypedQuery<Incidencia> query = entityManager.createQuery(
                "SELECT i FROM Incidencia i WHERE i.idConcesionario = :concId AND i.activo = 'S' ORDER BY i.fechaUltimoMovimiento DESC",
                Incidencia.class);
        query.setParameter("concId", concesionario.trim());
        return query.getResultList();
    }

    // --- ESTE FALTABA Y ES REQUERIDO POR LA INTERFACE ---
    @Override
    public List<Incidencia> findBySitioAndEstatus(String idSitio, String estatus) {
        if (idSitio == null) return Collections.emptyList();
        
        StringBuilder jpql = new StringBuilder("SELECT i FROM Incidencia i WHERE i.idSitio = :idSitio AND i.activo = 'S' ");
        if (estatus != null && !estatus.isEmpty()) {
            // Asumiendo que estatus llega como ID o Clave, ajusta seg�n tu l�gica si es necesario
            // Aqu� hago un join impl�cito simple si estatus es el ID
            jpql.append("AND i.idEstatusIncidencia = :estatus ");
        }
        jpql.append("ORDER BY i.fechaUltimoMovimiento DESC");

        TypedQuery<Incidencia> query = entityManager.createQuery(jpql.toString(), Incidencia.class);
        query.setParameter("idSitio", idSitio);
        
        if (estatus != null && !estatus.isEmpty()) {
            try {
                query.setParameter("estatus", Long.valueOf(estatus));
            } catch (NumberFormatException e) {
                // Si no es n�mero, ignoramos o manejamos l�gica extra
            }
        }
        
        return query.getResultList();
    }

    @Override
    public Incidencia findBySitioAndConcesionario(String idSitio, String idConcesionario) {
        if (idSitio == null || idConcesionario == null) return null;
        
        TypedQuery<Incidencia> query = entityManager.createQuery(
                "SELECT i FROM Incidencia i WHERE i.idSitio = :idSitio AND i.idConcesionario = :idConcesionario AND i.activo = 'S'",
                Incidencia.class);
        
        query.setParameter("idSitio", idSitio.trim());
        query.setParameter("idConcesionario", idConcesionario.trim());
        
        List<Incidencia> resultados = query.getResultList();
        return resultados.isEmpty() ? null : resultados.get(0);
    }

    // --------------------------------------------------------
    // M�TODO PRIVADO CR�TICO (Con correcci�n de Date)
    // --------------------------------------------------------
    private void prepararDefaultsAntesDePersistir(Incidencia incidencia) {
        Date ahora = new Date(); // <--- CORRECCI�N CR�TICA: java.util.Date

        if (incidencia.getFechaAlta() == null) {
            incidencia.setFechaAlta(ahora);
        }
        if (incidencia.getFechaUltimoMovimiento() == null) {
            incidencia.setFechaUltimoMovimiento(ahora);
        }
        if (incidencia.getActivo() == null || incidencia.getActivo().trim().isEmpty()) {
            incidencia.setActivo("S");
        }
        if (incidencia.getOrigenAlta() == null || incidencia.getOrigenAlta().trim().isEmpty()) {
            incidencia.setOrigenAlta("I");
        }
    }
    
    
    @Override
    @Transactional(readOnly = true)
    public String obtenerCorreoExternoPorUsuario(Integer idUsuario, Integer idRol) {
        if (idUsuario == null) {
            return null;
        }

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT CORREO ");
        sql.append("  FROM BDDSEG01.T3SEGO_DATO_USUA_EXTE ");
        sql.append(" WHERE USUARIO = :idUsuario ");

        if (idRol != null) {
            sql.append("   AND ID_ROL = :idRol ");
        }

        // Seguridad: 1 solo registro
        sql.append("   AND ROWNUM = 1 ");

        Query query = entityManager.createNativeQuery(sql.toString());
        query.setParameter("idUsuario", idUsuario);

        if (idRol != null) {
            query.setParameter("idRol", idRol);
        }

        @SuppressWarnings("unchecked")
        List<Object> resultados = query.getResultList();

        if (resultados == null || resultados.isEmpty()) {
            return null;
        }

        Object raw = resultados.get(0);
        String correo = (raw != null) ? raw.toString().trim() : null;

        if (correo == null || correo.isEmpty()) {
            return null;
        }
        return correo;
    }
    @Override
    @Transactional(readOnly = true)
    public String obtenerNombreCompletoUsuarioPorId(Integer idUsuario) {
        if (idUsuario == null) {
            return null;
        }

        final String sql =
                "SELECT TRIM(NOMBRE || ' ' || APELLIDO_PATERNO || ' ' || APELLIDO_MATERNO) " +
                "  FROM BDDSEG01.T3SEGO_USUA " +
                " WHERE USUARIO = :idUsuario";

        javax.persistence.Query query = entityManager.createNativeQuery(sql);
        query.setParameter("idUsuario", idUsuario);

        @SuppressWarnings("unchecked")
        List<Object> resultados = query.getResultList();

        if (resultados == null || resultados.isEmpty()) {
            return null;
        }

        Object raw = resultados.get(0);
        String nombreCompleto = (raw == null) ? null : raw.toString().trim();
        return (nombreCompleto == null || nombreCompleto.isEmpty()) ? null : nombreCompleto;
    }


}
package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto;

import java.io.Serializable;
import java.util.Date;

public class ProgramaColocacionDto implements Serializable {

	private static final long serialVersionUID = 7776453995074889145L;
	private Integer idProgramaColocacion;
	private String semana;
	private String actividad;
	private String fechaInicioProgramada;
	private String fechaFinalProgramada;
	private String idFolio;
	
	public ProgramaColocacionDto() {

	}

	public Integer getIdProgramaColocacion() {
		return idProgramaColocacion;
	}

	public void setIdProgramaColocacion(Integer idProgramaColocacion) {
		this.idProgramaColocacion = idProgramaColocacion;
	}

	public String getSemana() {
		return semana;
	}

	public void setSemana(String semana) {
		this.semana = semana;
	}

	public String getActividad() {
		return actividad;
	}

	public void setActividad(String actividad) {
		this.actividad = actividad;
	}

	public String getFechaInicioProgramada() {
		return fechaInicioProgramada;
	}

	public void setFechaInicioProgramada(String fechaInicioProgramada) {
		this.fechaInicioProgramada = fechaInicioProgramada;
	}

	public String getFechaFinalProgramada() {
		return fechaFinalProgramada;
	}

	public void setFechaFinalProgramada(String fechaFinalProgramada) {
		this.fechaFinalProgramada = fechaFinalProgramada;
	}

	public String getIdFolio() {
		return idFolio;
	}

	public void setIdFolio(String idFolio) {
		this.idFolio = idFolio;
	}

}

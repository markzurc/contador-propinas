package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * <h1>T7segcAcci</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 11/05/2015
 */
@Entity
@Table(name = "T3SEGC_ACCI",  schema="BDDSEG01")
public class T7segcAcci implements java.io.Serializable {

	private static final long serialVersionUID = -4429046716310852082L;
	private Integer accion;
	private String descripcion;

	public T7segcAcci() {
	}

	public T7segcAcci(Integer accion) {
		this.accion = accion;
	}

	public T7segcAcci(Integer accion, String descripcion) {
		this.accion = accion;
		this.descripcion = descripcion;
	}

	@Id
	@Column(name = "ACCION", unique = true, nullable = false, precision = 22, scale = 0)
	public Integer getIdAccion() {
		return this.accion;
	}

	public void setIdAccion(Integer accion) {
		this.accion = accion;
	}

	@Column(name = "DESCRIPCION", length = 20)
	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

}

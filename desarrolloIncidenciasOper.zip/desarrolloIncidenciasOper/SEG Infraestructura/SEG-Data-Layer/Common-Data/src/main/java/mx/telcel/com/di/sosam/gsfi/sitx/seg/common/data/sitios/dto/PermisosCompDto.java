package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto;

import java.io.Serializable;

public class PermisosCompDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5419678494509670638L;
	
	private Integer idPermisoComponente;
	private Integer idRol;
	private Integer idComponente;
	private String nombreComponente;
	private String permiso;
	private String propiedad;
	
	public Integer getIdPermisoComponente() {
		return idPermisoComponente;
	}
	
	public void setIdPermisoComponente(Integer idPermisoComponente) {
		this.idPermisoComponente = idPermisoComponente;
	}
	
	public Integer getIdRol() {
		return idRol;
	}
	
	public void setIdRol(Integer idRol) {
		this.idRol = idRol;
	}
	
	public Integer getIdComponente() {
		return idComponente;
	}
	
	public void setIdComponente(Integer idComponente) {
		this.idComponente = idComponente;
	}
	
	public String getNombreComponente() {
		return nombreComponente;
	}
	
	public void setNombreComponente(String nombreComponente) {
		this.nombreComponente = nombreComponente;
	}
	
	public String getPermiso() {
		return permiso;
	}
	
	public void setPermiso(String permiso) {
		this.permiso = permiso;
	}
	
	public String getPropiedad() {
		return propiedad;
	}
	
	public void setPropiedad(String propiedad) {
		this.propiedad = propiedad;
	}

	public PermisosCompDto() {
		super();
	}

	public PermisosCompDto(Integer idPermisoComponente, Integer idRol, Integer idComponente, String nombreComponente,
			String permiso, String propiedad) {
		super();
		this.idPermisoComponente = idPermisoComponente;
		this.idRol = idRol;
		this.idComponente = idComponente;
		this.nombreComponente = nombreComponente;
		this.permiso = permiso;
		this.propiedad = propiedad;
	}
		
}

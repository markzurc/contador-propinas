/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao;

import java.util.List;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ColocacionTablaEspacioPisoDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ColocacionTablaEspacioTorreDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ProgramaColocacionDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SoliArchDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.VerificacionColocacionDto;

/**
 *
 * @author Jair Javier
 */
public interface IColocacion {
    public boolean insertaPrincipalSolicitudColocacion(String folio, String calibreRF, String calibreMW, String superficie, String transformador, String observaciones, String observacionesTelcel);
    
    public boolean actualizaPrincipalSolicitudColocacion(String folio, String calibreRF, String calibreMW, String superficie, String transformador, String observaciones, String observacionesTelcel);
    
    public boolean insertaSolicitudColocacionEspacioTorre(String folio, List<ColocacionTablaEspacioTorreDTO> listaEspacioTorre);
    
    public boolean actualizaSolicitudColocacionEspacioTorre(String folio, List<ColocacionTablaEspacioTorreDTO> listaEspacioTorre);
    
    public boolean eliminaSolicitudColocacionEspacioTorre(String folio, List<ColocacionTablaEspacioTorreDTO> listaEspacioTorre);
    
    public boolean insertaSolicitudColocacionEspacioPiso(String folio, List<ColocacionTablaEspacioPisoDTO> listaEspacioPiso);
    
    public boolean actualizaSolicitudColocacionEspacioPiso(String folio, List<ColocacionTablaEspacioPisoDTO> listaEspacioPiso);
    
    public boolean eliminarSolicitudColocacionEspacioPiso(String folio, List<ColocacionTablaEspacioPisoDTO> listaEspacioPiso);
    
    public boolean insertaArchivoEnTabla(String folio, List<SoliArchDto> listaArchivo);
    
    public boolean actualizaArchivoEnTabla(String folio, String ruta, List<SoliArchDto> listaArchivo);
    
    public boolean eliminaArchivoEnTabla(String folio, List<SoliArchDto> listaArchivo);
    
    public List<SoliArchDto> obtenerArchivoEnTabla(String folio, String Ruta);
    
    public List<ColocacionTablaEspacioTorreDTO> obtenerEspacioTorre(String folio);
    
    public List<ColocacionTablaEspacioPisoDTO> obtenerEspacioPiso(String folio);
    
    public String obtenerDatosSolicitudColocacion(String folio);
    
    public String consultaExistenciaSolicitudColocacion(String folio);
    
    public boolean insertaProgramaColocacion(List<ProgramaColocacionDto> list);
    
    public List<ProgramaColocacionDto> obtenerProgramaColocacion(String folio);
    
    public boolean insertaVerificacionColocacion(VerificacionColocacionDto colocacion);

	public List<VerificacionColocacionDto> consultaListaVerificacion(String folio);

	public boolean updateVerificacionColocacion(VerificacionColocacionDto colocacion);

	public boolean corregirVerificacionColocacion(VerificacionColocacionDto colocacion);

	public int consultaEstadoBitacora(String folio, String estatus);
}

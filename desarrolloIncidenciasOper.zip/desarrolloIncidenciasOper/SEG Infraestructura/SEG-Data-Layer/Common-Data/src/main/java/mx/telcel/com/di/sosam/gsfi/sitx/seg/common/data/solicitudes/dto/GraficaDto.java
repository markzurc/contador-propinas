package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dto;

import java.io.Serializable;

public class GraficaDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6262496252489067492L;
	private Integer idEstatusGrafica;
	private Integer idEstadoSoli;
	private String descripcion;
	private Integer valorGrafica;
	private Integer valorTab;
	private String color;
	private Integer estatus;
		
	public GraficaDto(Integer idEstatusGrafica, Integer idEstadoSoli, String descripcion, Integer valorGrafica,
			Integer valorTab, String color, Integer estatus) {
		super();
		this.idEstatusGrafica = idEstatusGrafica;
		this.idEstadoSoli = idEstadoSoli;
		this.descripcion = descripcion;
		this.valorGrafica = valorGrafica;
		this.valorTab = valorTab;
		this.color = color;
		this.estatus = estatus;
	}

	public GraficaDto() {

	}

	/**
	 * @return the idEstatusGrafica
	 */
	public Integer getIdEstatusGrafica() {
		return idEstatusGrafica;
	}
	
	/**
	 * @param idEstatusGrafica the idEstatusGrafica to set
	 */
	public void setIdEstatusGrafica(Integer idEstatusGrafica) {
		this.idEstatusGrafica = idEstatusGrafica;
	}
	
	/**
	 * @return the idEstadoSoli
	 */
	public Integer getIdEstadoSoli() {
		return idEstadoSoli;
	}
	
	/**
	 * @param idEstadoSoli the idEstadoSoli to set
	 */
	public void setIdEstadoSoli(Integer idEstadoSoli) {
		this.idEstadoSoli = idEstadoSoli;
	}
	
	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}
	
	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	/**
	 * @return the valorGrafica
	 */
	public Integer getValorGrafica() {
		return valorGrafica;
	}
	
	/**
	 * @param valorGrafica the valorGrafica to set
	 */
	public void setValorGrafica(Integer valorGrafica) {
		this.valorGrafica = valorGrafica;
	}
	
	/**
	 * @return the valorTab
	 */
	public Integer getValorTab() {
		return valorTab;
	}

	/**
	 * @param valorTab the valorTab to set
	 */
	public void setValorTab(Integer valorTab) {
		this.valorTab = valorTab;
	}

	/**
	 * @return the color
	 */
	public String getColor() {
		return color;
	}
	
	/**
	 * @param color the color to set
	 */
	public void setColor(String color) {
		this.color = color;
	}

	/**
	 * @return the estatus
	 */
	public Integer getEstatus() {
		return estatus;
	}
	
	/**
	 * @param estatus the estatus to set
	 */
	public void setEstatus(Integer estatus) {
		this.estatus = estatus;
	}
	
}

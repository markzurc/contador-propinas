package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dao.impl;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dao.IBitacoraDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dto.BitacoraDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;

@Repository(value = "bitacoraDao")
@Scope("prototype")
public class BitacoraDaoImpl extends GenericFunctionDaoImpl
implements IBitacoraDao, Serializable{
	
	private static final long serialVersionUID = 5927713844014847278L;
	private static final Logger LOGGER = LogManager.getLogger(BitacoraDaoImpl.class);
	
	private static final String INSERT_BITACORA = "T3SEGO_BITA.INSERT";
	
	@Override
	@Transactional
	public boolean insertaBitacora(BitacoraDto bitacoraDto) {
		Session session = getSession();
		try {
			Query query = session.
					getNamedQuery(INSERT_BITACORA)
						.setString(0, bitacoraDto.getIdSolicitud())
						.setString(1, bitacoraDto.getIdUsuario())
						.setString(2, bitacoraDto.getIdEmpresa())
						.setString(3, bitacoraDto.getIdEstatusFlujo())
						.setString(4, bitacoraDto.getFechaMovimiento())
						.setString(5, bitacoraDto.getIdAccion())
						.setString(6, bitacoraDto.getMotivoRechazo());
			query.executeUpdate();
			return true;
		} catch (Exception e) {
			LOGGER.error("Error en el guardado de la informacion de la bitacora, causa: " + e);
			return false;
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BitacoraDto> obtenerAcciones(String idSoli) {
		try {
			Session session = getSession();
			StringBuilder sql = new StringBuilder();
			sql.append("select usua.nombre||' '||usua.APELLIDO_PATERNO||' '||usua.APELLIDO_MATERNO AS \"idUsuario\", ");
			sql.append("CASE WHEN rolU.ROL != 13 THEN 'Telcel' ELSE BDDOVI01.FNOBT_CAMP_OPER('DESCRIPCION_CORTA',oper.GRUPO_OPERADOR,gr.grupo_Producto,1) END AS \"idEmpresa\", ");
			sql.append("estado.DESCRIPCION AS \"idEstatusFlujo\", ");
			sql.append("bita.FECHA_MOVIMIENTO AS \"fechaMovimiento\", ");
			sql.append("accion.DESCRIPCION AS \"idAccion\", ");
			sql.append("bita.MOTIVO_RECHAZO AS \"motivoRechazo\", ");
			sql.append("rolU.ROL AS \"rol\" ");
			sql.append("FROM BDDSEG01.T3SEGO_BITA bita, BDDSEG01.T3SEGO_USUA usua, BDDOVI01.T1ALLC_GRUP_OPER oper, BDDSEG01.T3SEGC_ESTA_SOLI estado, BDDSEG01.T3SEGC_ACCI_FLUJ_INFR accion, BDDSEG01.T3SEGR_CROL_CUSUA rolU, BDDOVI01.T1ALLR_CGROP_CGRPR gr ");
			sql.append("WHERE bita.id_usuario = usua.usuario(+) and bita.id_empresa = oper.grupo_operador(+) and bita.id_estatus_flujo = estado.ID_ESTADO_SOLI(+) and bita.id_accion = accion.ID_ACCION(+) and usua.USUARIO = rolU.USUARIO(+) and oper.grupo_operador = gr.grupo_operador(+) and gr.grupo_producto = 32 and bita.id_solicitud = :idSolicitud ");
			sql.append("order by bita.ID_BITACORA desc ");
			

			Query query = session.createSQLQuery(sql.toString())
					.addScalar("idUsuario", StandardBasicTypes.STRING)
					.addScalar("idEmpresa", StandardBasicTypes.STRING)
					.addScalar("idEstatusFlujo", StandardBasicTypes.STRING)
					.addScalar("fechaMovimiento", StandardBasicTypes.STRING)
					.addScalar("idAccion", StandardBasicTypes.STRING)
					.addScalar("motivoRechazo", StandardBasicTypes.STRING)
					.addScalar("rol", StandardBasicTypes.STRING)
					.setResultTransformer(Transformers.aliasToBean(BitacoraDto.class));
			query.setParameter("idSolicitud", idSoli);
			return query.list();

		} catch (Exception e) {
			LOGGER.error("Error al consultar datos de la bitacora: " + e);
			return Collections.<BitacoraDto>emptyList();
		}
	}
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.Hibernate;

@Entity
@Table(name = "T3SINB_INCI_MOVI", schema = "BDDSEG01")
public class T3SINB_INCI_MOVI implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID_MOVI", nullable = false)
    private Long id;

    @Column(name = "ID_INCI", nullable = false)
    private Long idIncidencia;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_INCI", referencedColumnName = "ID_INCI", insertable = false, updatable = false)
    private T3SINO_INCI incidencia;

    @Column(name = "ID_ESTA_INCI", nullable = false)
    private Long idEstatusIncidencia;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_ESTA_INCI", referencedColumnName = "ID_ESTA_INCI", insertable = false, updatable = false)
    private T3SINC_INCI_ESTA estatusCatalogo;

    @Column(name = "ID_RESP_INCI", nullable = false)
    private Long idResponsabilidad;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_RESP_INCI", referencedColumnName = "ID_RESP_INCI", insertable = false, updatable = false)
    private T3SINC_INCI_RESP responsabilidadCatalogo;

    @Column(name = "PERF_MOVI", nullable = false, length = 1)
    private String perfilMovimiento;

    @Column(name = "USU_MOVI", nullable = false, length = 60)
    private String usuarioMovimiento;

    @Column(name = "FEC_MOVI", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaEvento;

    @Lob
    @Column(name = "COMENTARIO")
    private String comentario;

    @Column(name = "ACTIVO", nullable = false, length = 1)
    private String activo = "S";

    @Transient
    private String evento;

    @Transient
    private String estatusAnterior;

    @Transient
    private String estatusNuevo;

    @PrePersist
    private void prePersist() {
        if (activo == null) {
            activo = "S";
        }
        if (fechaEvento == null) {
            fechaEvento = new Date();
        }
    }

 

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getIdIncidencia() {
        return idIncidencia;
    }

    public void setIdIncidencia(Long idIncidencia) {
        this.idIncidencia = idIncidencia;
    }

    public Long getIdEstatusIncidencia() {
        return idEstatusIncidencia;
    }

    public void setIdEstatusIncidencia(Long idEstatusIncidencia) {
        this.idEstatusIncidencia = idEstatusIncidencia;
    }

    public Long getIdResponsabilidad() {
        return idResponsabilidad;
    }

    public void setIdResponsabilidad(Long idResponsabilidad) {
        this.idResponsabilidad = idResponsabilidad;
    }

    public String getPerfilMovimiento() {
        return perfilMovimiento;
    }

    public void setPerfilMovimiento(String perfilMovimiento) {
        this.perfilMovimiento = perfilMovimiento;
    }

    public String getUsuarioMovimiento() {
        return usuarioMovimiento;
    }

    public void setUsuarioMovimiento(String usuarioMovimiento) {
        this.usuarioMovimiento = usuarioMovimiento;
    }

    public Date getFechaEvento() {
        return fechaEvento;
    }

    public void setFechaEvento(Date fechaEvento) {
        this.fechaEvento = fechaEvento;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public String getActivo() {
        return activo;
    }

    public void setActivo(String activo) {
        this.activo = activo;
    }

    public String getEvento() {
        return evento;
    }

    public void setEvento(String evento) {
        this.evento = evento;
    }

    public String getEstatusAnterior() {
        return estatusAnterior;
    }

    public void setEstatusAnterior(String estatusAnterior) {
        this.estatusAnterior = estatusAnterior;
    }

    
    public String getEstatusNuevo() {
        if (estatusNuevo != null && !estatusNuevo.trim().isEmpty()) {
            return estatusNuevo;
        }

        if (estatusCatalogo != null && Hibernate.isInitialized(estatusCatalogo)) {
            String clave = estatusCatalogo.getClave();
            if (clave != null && !clave.trim().isEmpty()) {
                return clave;
            }
        }

        return estatusNuevo;
    }

    public void setEstatusNuevo(String estatusNuevo) {
        this.estatusNuevo = estatusNuevo;
    }

   
    public String getEstatusAnt() {
        return getEstatusAnterior();
    }

    public void setEstatusAnt(String estatusAnt) {
        setEstatusAnterior(estatusAnt);
    }

   
    public String getUsuarioId() {
        return getUsuarioMovimiento();
    }

    public void setUsuarioId(String usuarioId) {
        setUsuarioMovimiento(usuarioId);
    }

    public String getDescripcion() {
        return getComentario();
    }

    public void setDescripcion(String descripcion) {
        setComentario(descripcion);
    }
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.port.impl;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.port.ISitiosQueryPort;

/**
 * Implementaci�n del puerto de Sitios sin dependencia fuerte al servicio de Sitios.
 * Inyecta el bean real por nombre (p.ej. "consultaSitiosServiceImpl") y usa reflexi�n
 * para invocar getListaSitios() y leer getters de cada DTO (getSitio, getDisponible).
 */
@Repository // id por defecto: "sitiosQueryPortImpl"
public class SitiosQueryPortImpl implements ISitiosQueryPort {

    private static final Logger log = LoggerFactory.getLogger(SitiosQueryPortImpl.class);

    /**
     * Ajusta el name si tu bean de servicio de sitios se llama distinto.
     * Ejemplos comunes en el proyecto: "consultaSitiosServiceImpl", "consultaSitiosService".
     */
    @Resource(name = "consultaSitiosServiceImpl")
    private Object consultaSitiosService;

    @Override
    public boolean existeYActivo(String sitioId) {
        if (sitioId == null || sitioId.trim().isEmpty()) return false;
        try {
            List<?> sitios = obtenerListaSitios();
            for (Object dto : sitios) {
                String id  = getString(dto, "getSitio");        // ajusta el getter si tu DTO usa otro nombre
                if (id != null && sitioId.equalsIgnoreCase(id)) {
                    String disp = getString(dto, "getDisponible"); // "SI"/"S"/"1"/"ACTIVO", etc.
                    if (disp == null || disp.trim().isEmpty()) return true;
                    return "SI".equalsIgnoreCase(disp) || "S".equalsIgnoreCase(disp)
                        || "1".equals(disp) || "ACTIVO".equalsIgnoreCase(disp);
                }
            }
        } catch (Exception e) {
            log.warn("SitiosQueryPortImpl.existeYActivo error: {}", e.toString());
        }
        return false;
    }

    @Override
    public List<?> listarSitiosVisiblesParaUsuario() {
        try {
            return obtenerListaSitios();
        } catch (Exception e) {
            log.warn("SitiosQueryPortImpl.listarSitiosVisiblesParaUsuario error: {}", e.toString());
            return Collections.emptyList();
        }
    }

    // ================== Helpers por reflexi�n ==================

    @SuppressWarnings("unchecked")
    private List<?> obtenerListaSitios() throws Exception {
        if (consultaSitiosService == null) {
            log.warn("SitiosQueryPortImpl: Bean de servicio de sitios es NULL (revisa el nombre del @Resource).");
            return Collections.emptyList();
        }
        Method m = consultaSitiosService.getClass().getMethod("getListaSitios");
        Object result = m.invoke(consultaSitiosService);
        if (result == null) return Collections.emptyList();
        if (result instanceof List<?>) return (List<?>) result;
        // Si no regres� una lista, intenta envolver en una
        List<Object> l = new ArrayList<Object>(1);
        l.add(result);
        return l;
    }

    private String getString(Object target, String getter) {
        if (target == null) return null;
        try {
            Method m = target.getClass().getMethod(getter);
            Object v = m.invoke(target);
            return (v == null) ? null : String.valueOf(v);
        } catch (Exception e) {
            // Si el getter no existe con ese nombre, intenta alternativas comunes
            if ("getSitio".equals(getter)) {
                // Alternativas habituales de naming
                String alt = tryMany(target, "getIdSitio", "getClave", "getCodigo", "getFolio", "getNoSitio");
                if (alt != null) return alt;
            } else if ("getDisponible".equals(getter)) {
                String alt = tryMany(target, "getActivo", "getEstatus", "getStatus", "isActivo");
                if (alt != null) return alt;
            }
            return null;
        }
    }

    private String tryMany(Object target, String... getters) {
        for (String g : getters) {
            try {
                Method m = target.getClass().getMethod(g);
                Object v = m.invoke(target);
                if (v != null) return String.valueOf(v);
            } catch (Exception ignore) {}
        }
        return null;
    }
}

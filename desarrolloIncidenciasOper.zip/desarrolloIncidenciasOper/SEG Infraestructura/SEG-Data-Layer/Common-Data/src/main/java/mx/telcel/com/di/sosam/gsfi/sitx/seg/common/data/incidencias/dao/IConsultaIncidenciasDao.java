package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao;

import java.util.List;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaGestionDto;

public interface IConsultaIncidenciasDao {
	
	    List<IncidenciaGestionDto> buscarGestion(String folio, String sitioId, String estatus);
	
}

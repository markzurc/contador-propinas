package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * 
 * <h1>TsegcRol</h1>
 * <p>
 * Class for mapping the table "TsegcRol" of database.
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 24/03/2015
 *
 */
@Entity
@Table(name = "T3SEGC_ROL",  schema="BDDSEG01")
public class T7segcRol implements java.io.Serializable {

	private static final long serialVersionUID = -6920280892218707563L;
	
	private Integer rol;
	private String nombre;
	private String descripcion;
	private Integer tipoRol;
	private List<T7segcApli> tsegcAplicacions = new ArrayList<T7segcApli>(0);
	private Integer estatus;

	public T7segcRol() {
	}

	public T7segcRol(Integer rol) {
		this.rol = rol;
	}

	public T7segcRol(Integer rol, String nombre, String descripcion,
			Integer tipoRol, List<T7segcApli> tsegcAplicacions) {
		this.rol = rol;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.tipoRol = tipoRol;
		this.tsegcAplicacions = tsegcAplicacions;
	}

	@Id
	@Column(name = "ROL", unique = true, nullable = false, precision = 22, scale = 0)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQ7SEGC_ROL")
	@SequenceGenerator(name = "SQ7SEGC_ROL", sequenceName = "BDDSEG01.SQ7SEGC_ROL",schema="BDDSEG01", allocationSize = 1)
	public Integer getIdRol() {
		return this.rol;
	}

	public void setIdRol(Integer rol) {
		this.rol = rol;
	}

	@Column(name = "NOMBRE", length = 70)
	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "DESCRIPCION", length = 100)
	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Column(name = "TIPO_ROL", nullable = false, precision = 22, scale = 0)
	public Integer getIdTipoRol() {
		return this.tipoRol;
	}

	public void setIdTipoRol(Integer tipoRol) {
		this.tipoRol = tipoRol;
	}

	@OneToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "T3SEGR_CAPLI_CROL",  schema="BDDSEG01", joinColumns = { @JoinColumn(name = "ROL", nullable = false, updatable = false) }, inverseJoinColumns = { @JoinColumn(name = "APLICACION", nullable = false, updatable = false) })
	public List<T7segcApli> getTsegcAplicacions() {
		return this.tsegcAplicacions;
	}

	public void setTsegcAplicacions(List<T7segcApli> tsegcAplicacions) {
		this.tsegcAplicacions = tsegcAplicacions;
	}
	
	@Column(name = "ESTATUS", nullable = false, precision = 22, scale = 0)
	public Integer getIdEstatus() {
		return this.estatus;
	}

	public void setIdEstatus(Integer estatus) {
		this.estatus = estatus;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rol == null) ? 0 : rol.hashCode());
		result = prime
				* result
				+ ((tsegcAplicacions == null) ? 0 : tsegcAplicacions.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		T7segcRol other = (T7segcRol) obj;
		if (rol == null) {
			if (other.rol != null){
				return false;
			}
		} else if (!rol.equals(other.rol)){
			return false;
		}
		if (tsegcAplicacions == null) {
			if (other.tsegcAplicacions != null){
				return false;
			}
		} else if (!tsegcAplicacions.equals(other.tsegcAplicacions)){
			return false;
		}
		return true;
	}

}

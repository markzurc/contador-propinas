package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * <h1>T7segcTipoComp</h1>
 * <p>
 * </p>
 * 
 * @author chcastro
 * @version 1.0
 * @since 27/05/2015
 */
@Entity
@Table(name = "T3SEGC_TIPO_COMP",  schema="BDDSEG01")
public class T7segcTipoComp implements java.io.Serializable {

	private static final long serialVersionUID = -1359744131694127880L;
	
	private Integer tipoComponete;
	private String valor;
	private String descripcion;

	public T7segcTipoComp() {
	}

	public T7segcTipoComp(Integer tipoComponete, String valor) {
		this.tipoComponete = tipoComponete;
		this.valor = valor;
	}

	public T7segcTipoComp(Integer tipoComponete, String valor,
			String descripcion) {
		this.tipoComponete = tipoComponete;
		this.valor = valor;
		this.descripcion = descripcion;
	}

	@Id
	@Column(name = "TIPO_COMPONETE", unique = true, nullable = false, precision = 22, scale = 0)
	public Integer getIdTipoComponete() {
		return this.tipoComponete;
	}

	public void setIdTipoComponete(Integer tipoComponete) {
		this.tipoComponete = tipoComponete;
	}

	@Column(name = "VALOR", nullable = false, length = 20)
	public String getValor() {
		return this.valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	@Column(name = "DESCRIPCION", length = 30)
	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

}

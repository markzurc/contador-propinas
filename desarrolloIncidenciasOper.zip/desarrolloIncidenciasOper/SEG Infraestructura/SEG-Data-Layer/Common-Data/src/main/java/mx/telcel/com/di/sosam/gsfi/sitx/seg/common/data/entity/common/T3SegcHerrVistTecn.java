package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "T3SEGC_HERR_VIST_TECN", schema="BDDSEG01")
public class T3SegcHerrVistTecn implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "herr_vist_tecn_seq")
    @SequenceGenerator(name = "herr_vist_tecn_seq", sequenceName = "BDDSEG01.SQSEGC_HERR_VIST_TECN", allocationSize = 1)
    @Column(name = "ID_HERRAMIENTA_VISITA_TECNICA")
    private Integer idHerramientaVisitaTecnica;

    @Column(name = "TIPO", length = 100)
    private String tipo;

    @Column(name = "DESCRIPCION", length = 250)
    private String descripcion;

    @Column(name = "GRUPO_OPERADOR", length = 25)
    private String grupoOperador;

    @Column(name = "ID_FOLIO", length = 9)
    private String idFolio;

    @Column(name = "USUARIO_CRECACION")
    private Integer usuarioCreacion;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "FECHA_CREACION")
    private Date fechaCreacion;

    @Column(name = "USUARIO_MODIFICACION")
    private Integer usuarioModificacion;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "FECHA_MODIFICACION")
    private Date fechaModificacion;

    
    // Getters y setters

    
    public T3SegcHerrVistTecn() {
		super();
	}
    
    public T3SegcHerrVistTecn(T3SegcHerrVistTecn original) {
        this.idHerramientaVisitaTecnica = original.idHerramientaVisitaTecnica;
        this.tipo = original.tipo;
        this.descripcion = original.descripcion;
        this.grupoOperador = original.grupoOperador;
        this.idFolio = original.idFolio;
        this.usuarioCreacion = original.usuarioCreacion;
        this.fechaCreacion = original.fechaCreacion ;
        this.usuarioModificacion = original.usuarioModificacion;
        this.fechaModificacion = original.fechaModificacion;
    }

	public String getTipo() {
        return tipo;
    }

    public Integer getIdHerramientaVisitaTecnica() {
		return idHerramientaVisitaTecnica;
	}

	public void setIdHerramientaVisitaTecnica(Integer idHerramientaVisitaTecnica) {
		this.idHerramientaVisitaTecnica = idHerramientaVisitaTecnica;
	}

	public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getGrupoOperador() {
        return grupoOperador;
    }

    public void setGrupoOperador(String grupoOperador) {
        this.grupoOperador = grupoOperador;
    }

    public String getIdFolio() {
        return idFolio;
    }

    public void setIdFolio(String idFolio) {
        this.idFolio = idFolio;
    }

    public Integer getUsuarioCreacion() {
        return usuarioCreacion;
    }

    public void setUsuarioCreacion(Integer usuarioCreacion) {
        this.usuarioCreacion = usuarioCreacion;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public Integer getUsuarioModificacion() {
        return usuarioModificacion;
    }

    public void setUsuarioModificacion(Integer usuarioModificacion) {
        this.usuarioModificacion = usuarioModificacion;
    }

    public Date getFechaModificacion() {
        return fechaModificacion;
    }

    public void setFechaModificacion(Date fechaModificacion) {
        this.fechaModificacion = fechaModificacion;
    }
}

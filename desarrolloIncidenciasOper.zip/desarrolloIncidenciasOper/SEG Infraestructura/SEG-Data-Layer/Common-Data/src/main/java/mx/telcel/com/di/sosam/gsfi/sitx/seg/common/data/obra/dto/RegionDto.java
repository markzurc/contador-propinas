package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto;

import java.io.Serializable;

public class RegionDto implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6218698161040816587L;
	private String idRegion;
	private String descripcion;
	private Long estatus;
	
	public RegionDto(String idRegion, String descripcion, Long estatus) {
		super();
		this.idRegion = idRegion;
		this.descripcion = descripcion;
		this.estatus = estatus;
	}

	public RegionDto() {

	}

	/**
	 * @return the idRegion
	 */
	public String getIdRegion() {
		return idRegion;
	}

	/**
	 * @param idRegion the idRegion to set
	 */
	public void setIdRegion(String idRegion) {
		this.idRegion = idRegion;
	}

	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}

	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	/**
	 * @return the estatus
	 */
	public Long getEstatus() {
		return estatus;
	}

	/**
	 * @param estatus the estatus to set
	 */
	public void setEstatus(Long estatus) {
		this.estatus = estatus;
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * <h1>T7segcApli</h1>
 * <p>
 * Class for mapping the table "TsegcAplicacion" of database.
 * </p>
 * @author VI7XXEX
 * @version 1.0
 * @since 16/04/2015
 *
 */
@Entity
@Table(name = "T3SEGC_APLI",  schema="BDDSEG01")
public class T7segcApli implements java.io.Serializable {

	private static final long serialVersionUID = 4042575034756705689L;
	
	private Integer aplicacion;
	private String nombre;
	private String descripcion;
	private String nombreBean;
	private Integer estatus;

	public T7segcApli() {
	}

	public T7segcApli(Integer aplicacion) {
		this.aplicacion = aplicacion;
	}

	public T7segcApli(Integer aplicacion, String nombre,
			String descripcion, String nombreBean) {
		this.aplicacion = aplicacion;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.nombreBean = nombreBean;
	}
	
	@Id
	@Column(name = "APLICACION", unique = true, nullable = false, precision = 22, scale = 0)
	public Integer getIdAplicacion() {
		return this.aplicacion;
	}

	public void setIdAplicacion(Integer aplicacion) {
		this.aplicacion = aplicacion;
	}

	@Column(name = "NOMBRE", length = 45)
	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "DESCRIPCION", length = 45)
	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Column(name = "NOMBRE_BEAN", length = 20)
	public String getNombreBean() {
		return this.nombreBean;
	}

	public void setNombreBean(String nombreBean) {
		this.nombreBean = nombreBean;
	}
	
	@Column(name = "ESTATUS", nullable = false, precision = 22, scale = 0)
	public Integer getIdEstatus() {
		return this.estatus;
	}

	public void setIdEstatus(Integer estatus) {
		this.estatus = estatus;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((aplicacion == null) ? 0 : aplicacion.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		T7segcApli other = (T7segcApli) obj;
		if (aplicacion == null) {
			if (other.aplicacion != null){
				return false;
			}
		} else if (!aplicacion.equals(other.aplicacion)){
			return false;
		}
		return true;
	}


}

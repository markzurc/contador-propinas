package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * 
 * <h1>TsegcContactousuarioId</h1>
 * <p>
 * Class for mapping the table "TsegcContactousuarioId" of database.
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 25/03/2015
 *
 */

@Embeddable
public class TsegcContactousuarioId implements java.io.Serializable {

	private static final long serialVersionUID = 8616957984816435668L;
	
	private Integer idUsuario;
	private String telefonoContacto;
	private String emailContacto;

	public TsegcContactousuarioId() {
	}

	public TsegcContactousuarioId(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	public TsegcContactousuarioId(Integer idUsuario,
			String telefonoContacto, String emailContacto) {
		this.idUsuario = idUsuario;
		this.telefonoContacto = telefonoContacto;
		this.emailContacto = emailContacto;
	}

	@Column(name = "USUARIO", nullable = false, precision = 22, scale = 0)
	public Integer getIdUsuario() {
		return this.idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	@Column(name = "TELEFONO_CONTACTO", length = 20)
	public String getTelefonoContacto() {
		return this.telefonoContacto;
	}

	public void setTelefonoContacto(String telefonoContacto) {
		this.telefonoContacto = telefonoContacto;
	}

	@Column(name = "EMAIL_CONTACTO", length = 45)
	public String getEmailContacto() {
		return this.emailContacto;
	}

	public void setEmailContacto(String emailContacto) {
		this.emailContacto = emailContacto;
	}

	public boolean equals(Object other) {
		if ((this == other)){
			return true;
		}
		if ((other == null)){
			return false;
		}
		if (!(other instanceof TsegcContactousuarioId)){
			return false;
		}
		TsegcContactousuarioId castOther = (TsegcContactousuarioId) other;

		return ((this.getIdUsuario() != null && castOther.getIdUsuario() != null && this
				.getIdUsuario().equals(castOther.getIdUsuario())))
				&& ((this.getTelefonoContacto() == castOther
						.getTelefonoContacto()) || (this.getTelefonoContacto() != null
						&& castOther.getTelefonoContacto() != null && this
						.getTelefonoContacto().equals(
								castOther.getTelefonoContacto())))
				&& ((this.getEmailContacto() == castOther.getEmailContacto()) || (this
						.getEmailContacto() != null
						&& castOther.getEmailContacto() != null && this
						.getEmailContacto()
						.equals(castOther.getEmailContacto())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getIdUsuario() == null ? 0 : this.getIdUsuario().hashCode());
		result = 37
				* result
				+ (getTelefonoContacto() == null ? 0 : this
						.getTelefonoContacto().hashCode());
		result = 37
				* result
				+ (getEmailContacto() == null ? 0 : this.getEmailContacto()
						.hashCode());
		return result;
	}

}

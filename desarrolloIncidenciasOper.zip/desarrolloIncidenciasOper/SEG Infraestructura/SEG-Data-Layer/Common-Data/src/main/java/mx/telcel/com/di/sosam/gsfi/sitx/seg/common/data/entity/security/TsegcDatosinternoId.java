package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * 
 * <h1>TsegcDatosinternoId</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 16/04/2015
 *
 */
@Embeddable
public class TsegcDatosinternoId implements java.io.Serializable {

	private static final long serialVersionUID = -5688331145960277582L;
	
	private Integer idUsuario;
	

	public TsegcDatosinternoId() {
	}

	public TsegcDatosinternoId(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	@Column(name = "USUARIO", nullable = false, precision = 22, scale = 0)
	public Integer getIdUsuario() {
		return this.idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idUsuario == null) ? 0 : idUsuario.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		TsegcDatosinternoId other = (TsegcDatosinternoId) obj;
		if (idUsuario == null) {
			if (other.idUsuario != null){
				return false;
			}
		} else if (!idUsuario.equals(other.idUsuario)){
			return false;
		}
		return true;
	}
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Example;

/**
 * 
 * <h1></h1>
 * <p>
 * Generic functions for managing database
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 27/03/2015
 *
 */

public abstract class GenericFunctionDaoImpl {
	
	@PersistenceContext(unitName="entityManagerFactoryOVITAPP")
	protected EntityManager entityManager;
	
	private static final Logger logger = LogManager.getLogger(GenericFunctionDaoImpl.class);
	
	private Session session = null;
	
	/**
	 * Make an insert into database
	 * @param e {@link E}
	 */
	public <E> void create(E e) {
		logger.info("Ejecutando GenericFunctionDaoImpl.create");
		Session session = getSession();
		session.persist(e);
		
	}

	/**
	 * Make an update into database
	 * @param e {@link E}
	 */
	public <E> void update(E e) {
		logger.info("Ejecutando GenericFunctionDaoImpl.update");
		Session session = getSession();
		session.update(e);
	}
	
	/**
	 * Make an update into database
	 * @param e {@link E}
	 */
	public <E> void merge(E e) {
		logger.info("Ejecutando GenericFunctionDaoImpl.update");
		Session session = getSession();
		session.merge(e);
	}
	
	/**
	 * Make an delete into database
	 * @param e {@link E}
	 */
	public <E> void delete(E e) {
		logger.info("Ejecutando GenericFunctionDaoImpl.create");
		Session session = getSession();
		session.delete(e);
	}

	/**
	 * Search in database using the example object, 
	 * if the object is empty, returns all content in table
	 * 
	 * @param e {@link E}
	 */
	@SuppressWarnings("unchecked")
	public <E> List<E> findByExample(E e) {
		logger.info("Ejecutando GenericFunctionDaoImpl.findByExample");
		Session session = getSession();
		Example example = Example.create(e);
	    return session.createCriteria(e.getClass()).add(example).list();
	}

	/**
	 * @return the session
	 */
	public Session getSession() {
		if(session == null || !session.isOpen()){
			session = (Session) entityManager.getDelegate();
			logger.info("Nueva Sesion.");
		}
		return session;
	}

	/**
	 * @param session the session to set
	 */
	public void setSession(Session session) {
		this.session = session;
	}

}

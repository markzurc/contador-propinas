package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * <h1>T7sgcConf</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 17/04/2015
 *
 */
@Entity
@Table(name = "T3SEGC_PARA",  schema="BDDSEG01")
public class T7segcPara implements java.io.Serializable {

	private static final long serialVersionUID = -5247956158259850496L;
	private Integer parametro;
	private String nombreParametro;
	private String identificador;
	private String descripcion;
	private String valor;
	private Integer activo;
	private Integer editable;
	private Integer tipoDato;
	private String descripcionDetalle;

	public T7segcPara() {
	}

	public T7segcPara(Integer parametro, String nombreParametro,
			String identificador, String valor, Integer activo,
			Integer editable) {
		this.parametro = parametro;
		this.nombreParametro = nombreParametro;
		this.identificador = identificador;
		this.valor = valor;
		this.activo = activo;
		this.editable = editable;
	}

	public T7segcPara(Integer parametro, String nombreParametro,
			String identificador, String descripcion, String valor,
			Integer activo, Integer editable, Integer tipoDato,
			String descripcionDetalle) {
		this.parametro = parametro;
		this.nombreParametro = nombreParametro;
		this.identificador = identificador;
		this.descripcion = descripcion;
		this.valor = valor;
		this.activo = activo;
		this.editable = editable;
		this.tipoDato = tipoDato;
		this.descripcionDetalle = descripcionDetalle;
	}

	@Id
	@Column(name = "PARAMETRO", unique = true, nullable = false, precision = 22, scale = 0)
	public Integer getIdParametro() {
		return this.parametro;
	}

	public void setIdParametro(Integer parametro) {
		this.parametro = parametro;
	}

	@Column(name = "NOMBRE_PARAMETRO", nullable = false, length = 45)
	public String getNombreParametro() {
		return this.nombreParametro;
	}

	public void setNombreParametro(String nombreParametro) {
		this.nombreParametro = nombreParametro;
	}

	@Column(name = "IDENTIFICADOR", nullable = false, length = 45)
	public String getIdentificador() {
		return this.identificador;
	}

	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}

	@Column(name = "DESCRIPCION", length = 45)
	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Column(name = "VALOR", nullable = false, length = 100)
	public String getValor() {
		return this.valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	@Column(name = "ACTIVO", nullable = false, precision = 22, scale = 0)
	public Integer getActivo() {
		return this.activo;
	}

	public void setActivo(Integer activo) {
		this.activo = activo;
	}

	@Column(name = "EDITABLE", nullable = false, precision = 22, scale = 0)
	public Integer getEditable() {
		return this.editable;
	}

	public void setEditable(Integer editable) {
		this.editable = editable;
	}
	
	@Column(name = "TIPO_DATO", precision = 22, scale = 0)
	public Integer getIdTipo() {
		return this.tipoDato;
	}

	public void setIdTipo(Integer idTipo) {
		this.tipoDato = idTipo;
	}

	@Column(name = "DESCRIPCION_DETALLE", length = 100)
	public String getDescripcionDetalle() {
		return this.descripcionDetalle;
	}

	public void setDescripcionDetalle(String descripcionDetalle) {
		this.descripcionDetalle = descripcionDetalle;
	}

}

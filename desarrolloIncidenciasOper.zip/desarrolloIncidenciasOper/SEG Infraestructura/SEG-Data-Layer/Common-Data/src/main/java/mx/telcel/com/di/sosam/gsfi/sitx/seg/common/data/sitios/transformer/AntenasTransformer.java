package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.transformer;

import java.math.BigDecimal;
import java.util.List;
import org.hibernate.transform.ResultTransformer;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.AntenaDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;

public class AntenasTransformer implements ResultTransformer {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4569880860719168302L;

	@Override
	public Object transformTuple(Object[] tuple, String[] aliases) {
		Integer idAntena =  ((BigDecimal) tuple[0]).intValue();
		String tipo = checkStrNotNull(tuple[1]);
		String dimenciones = checkStrNotNull(tuple[2]);
		String peso = checkStrNotNull(tuple[3]);
		Integer idFactibilidad = ((BigDecimal) tuple[0]).intValue();
		
		AntenaDto antena = new AntenaDto(idAntena, tipo, dimenciones, peso, idFactibilidad);
		
		return antena;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List collection) {
		return collection;
	}
	
	private String checkStrNotNull(Object object) {
		return null != object ? object.toString() : " ";
	}
}

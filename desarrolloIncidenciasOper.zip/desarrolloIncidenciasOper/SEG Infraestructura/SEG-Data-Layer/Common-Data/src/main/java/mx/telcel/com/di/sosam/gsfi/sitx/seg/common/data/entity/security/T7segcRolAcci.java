package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * <h1>T7segcRolAcci</h1>
 * <p>
 * </p>
 * @author VI7XXIX
 * @version 1.0
 * @since 15/07/2020
 */
@Entity
@Table(name="T3SEGC_ROL_ACCI", schema="BDDSEG01")
public class T7segcRolAcci implements Serializable{

	private static final long serialVersionUID = -1332556771771533502L;
	private Integer rol;
	private Integer accion;
	private Integer estatus;
	
	public T7segcRolAcci(Integer rol, Integer accion, Integer estatus) {
		super();
		this.rol = rol;
		this.accion = accion;
		this.estatus = estatus;
	}

	@Id
	@Column(name = "ROL", nullable = false, precision = 22, scale = 0)
	public Integer getRol() {
		return rol;
	}

	public void setRol(Integer rol) {
		this.rol = rol;
	}

	@Id
	@Column(name = "ACCION", nullable = false, precision = 22, scale = 0)
	public Integer getAccion() {
		return accion;
	}

	public void setAccion(Integer accion) {
		this.accion = accion;
	}

	@Id
	@Column(name = "ESTATUS", nullable = false, precision = 22, scale = 0)
	public Integer getEstatus() {
		return estatus;
	}

	public void setEstatus(Integer estatus) {
		this.estatus = estatus;
	}
	
	
}

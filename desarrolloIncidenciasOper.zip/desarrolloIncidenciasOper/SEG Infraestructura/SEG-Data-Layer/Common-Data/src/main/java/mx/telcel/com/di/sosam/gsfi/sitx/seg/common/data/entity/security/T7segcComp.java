package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * <h1>T7segcComp</h1>
 * <p>
 * Class for mapping the table "TsegrAplicaionAcl" of database.
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 27/03/2015
 *
 */
@Entity
@Table(name = "T3SEGC_COMP",  schema="BDDSEG01")
public class T7segcComp implements java.io.Serializable {

	private static final long serialVersionUID = 639197060080304601L;
	
	private Integer componente;
	private String flujo;
	private Integer padre;
	private String nombre;
	private String descripcion;
	private Integer tipoComponente;
	private Integer aplicacion;
	private Integer nivel;

	public T7segcComp() {
	}

	public T7segcComp(Integer componente,
			Integer aplicacion) {
		this.componente = componente;
		this.aplicacion = aplicacion;
	}

	public T7segcComp(Integer componente,
			Integer aplicacion, String flujo, Integer padre,
			String nombre, String descripcion, Integer tipoComponente) {
		this.componente = componente;
		this.aplicacion = aplicacion;
		this.flujo = flujo;
		this.padre = padre;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.tipoComponente = tipoComponente;
	}

	@Id
	@Column(name = "COMPONENTE", unique = true, nullable = false, precision = 22, scale = 0)
	public Integer getIdComponente() {
		return this.componente;
	}

	public void setIdComponente(Integer componente) {
		this.componente = componente;
	}

	@Column(name = "APLICACION", nullable = false)
	public Integer getIdAplicacion() {
		return this.aplicacion;
	}

	public void setIdAplicacion(Integer aplicacion) {
		this.aplicacion = aplicacion;
	}

	@Column(name = "FLUJO", length = 45)
	public String getFlujo() {
		return this.flujo;
	}

	public void setFlujo(String flujo) {
		this.flujo = flujo;
	}

	@Column(name = "PADRE", precision = 22, scale = 0)
	public Integer getIdPadre() {
		return this.padre;
	}

	public void setIdPadre(Integer padre) {
		this.padre = padre;
	}

	@Column(name = "NOMBRE", length = 20)
	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "DESCRIPCION", length = 45)
	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Column(name = "TIPO_COMPONENTE", length = 20)
	public Integer getTipo() {
		return this.tipoComponente;
	}

	public void setTipo(Integer tipoComponente) {
		this.tipoComponente = tipoComponente;
	}
	
	@Column(name = "NIVEL", precision = 22, scale = 0)
	public Integer getNivel() {
		return this.nivel;
	}

	public void setNivel(Integer nivel) {
		this.nivel = nivel;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((aplicacion == null) ? 0 : aplicacion.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		T7segcComp other = (T7segcComp) obj;
		if (aplicacion == null) {
			if (other.aplicacion != null){
				return false;
			}
		} else if (!aplicacion.equals(other.aplicacion)){
			return false;
		}
		return true;
	}

}

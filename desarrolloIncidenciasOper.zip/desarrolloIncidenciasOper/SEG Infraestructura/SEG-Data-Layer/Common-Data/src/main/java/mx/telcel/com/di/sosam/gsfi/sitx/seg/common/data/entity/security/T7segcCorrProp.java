package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="T3SEGC_CORR_PROP", schema="BDDSEG01")
public class T7segcCorrProp implements Serializable{

	private static final long serialVersionUID = 6379490405346213956L;
	
	private String cve;
	
	private String valor;

	public T7segcCorrProp(String cve, String valor) {
		super();
		this.cve = cve;
		this.valor = valor;
	}

	@Id
	@Column(name = "CLAVE", nullable = false, precision = 22, scale = 0)
	public String getCve() {
		return cve;
	}

	public void setCve(String cve) {
		this.cve = cve;
	}

	@Column(name = "VALOR", nullable = false, precision = 22, scale = 0)
	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}
	
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T3SEGO_DATO_USUA_EXTE",  schema="BDDSEG01")
public class T3segoDatoUsuaExte implements java.io.Serializable {

	private static final long serialVersionUID = 7650599446956993748L;
	
	@Id
	@Column(name = "USUARIO")
	private Integer  idUsuario;
	
	@Column(name = "ID_OPERADOR")
	private Integer  idOperador;

	public Integer getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	public Integer getIdOperador() {
		return idOperador;
	}

	public void setIdOperador(Integer idOperador) {
		this.idOperador = idOperador;
	}
	
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date; // <--- USAR ESTE IMPORT

@Entity
@Table(name = "T3SINB_INCI_MOVI", schema = "BDDSEG01")
public class IncidenciaBitacora implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID_MOVI", nullable = false)
    private Long id;

    @Column(name = "ID_INCI", nullable = false)
    private Long idIncidencia;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_INCI", referencedColumnName = "ID_INCI", insertable = false, updatable = false)
    private Incidencia incidencia;

    @Column(name = "ID_ESTA_INCI", nullable = false)
    private Long idEstatusIncidencia;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_ESTA_INCI", referencedColumnName = "ID_ESTA_INCI", insertable = false, updatable = false)
    private IncidenciaEstatusCatalogo estatusCatalogo;

    @Column(name = "ID_RESP_INCI", nullable = false)
    private Long idResponsabilidad;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_RESP_INCI", referencedColumnName = "ID_RESP_INCI", insertable = false, updatable = false)
    private IncidenciaResponsabilidadCatalogo responsabilidadCatalogo;

    @Column(name = "PERF_MOVI", nullable = false, length = 1)
    private String perfilMovimiento;

    @Column(name = "USU_MOVI", nullable = false, length = 60)
    private String usuarioMovimiento;

    // --- CAMBIO: LocalDateTime -> Date ---
    @Column(name = "FEC_MOVI", nullable = false)
    @Temporal(TemporalType.TIMESTAMP) // <--- Importante para Oracle
    private Date fechaEvento;

    @Lob
    @Column(name = "COMENTARIO")
    private String comentario;

    @Column(name = "ACTIVO", nullable = false, length = 1)
    private String activo = "S";

    @PrePersist
    private void prePersist() {
        if (activo == null)
            activo = "S";
        // --- CAMBIO: LocalDateTime.now() -> new Date() ---
        if (fechaEvento == null)
            fechaEvento = new Date();
    }

    // Compatibilidad con UI (no existen en BD)
    @Transient
    private String evento;
    @Transient
    private String estatusAnterior;
    @Transient
    private String estatusNuevo;

    // Getters/Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getIdIncidencia() {
        return idIncidencia;
    }

    public void setIdIncidencia(Long idIncidencia) {
        this.idIncidencia = idIncidencia;
    }

    public Long getIdEstatusIncidencia() {
        return idEstatusIncidencia;
    }

    public void setIdEstatusIncidencia(Long idEstatusIncidencia) {
        this.idEstatusIncidencia = idEstatusIncidencia;
    }

    public Long getIdResponsabilidad() {
        return idResponsabilidad;
    }

    public void setIdResponsabilidad(Long idResponsabilidad) {
        this.idResponsabilidad = idResponsabilidad;
    }

    public String getPerfilMovimiento() {
        return perfilMovimiento;
    }

    public void setPerfilMovimiento(String perfilMovimiento) {
        this.perfilMovimiento = perfilMovimiento;
    }

    public String getUsuarioMovimiento() {
        return usuarioMovimiento;
    }

    public void setUsuarioMovimiento(String usuarioMovimiento) {
        this.usuarioMovimiento = usuarioMovimiento;
    }

    // --- CAMBIO: Getters/Setters usan Date ---
    public Date getFechaEvento() {
        return fechaEvento;
    }

    public void setFechaEvento(Date fechaEvento) {
        this.fechaEvento = fechaEvento;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public String getActivo() {
        return activo;
    }

    public void setActivo(String activo) {
        this.activo = activo;
    }

    public String getEvento() {
        return evento;
    }

    public void setEvento(String evento) {
        this.evento = evento;
    }

    public String getEstatusAnterior() {
        return estatusAnterior;
    }

    public void setEstatusAnterior(String estatusAnterior) {
        this.estatusAnterior = estatusAnterior;
    }

    public String getEstatusNuevo() {
        if (estatusCatalogo != null && estatusCatalogo.getClave() != null)
            return estatusCatalogo.getClave();
        return estatusNuevo;
    }

    public void setEstatusNuevo(String estatusNuevo) {
        this.estatusNuevo = estatusNuevo;
    }
}
package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto;

import java.io.Serializable;

public class SitioDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7776453995074889145L;
	private String sitio;
	private String nombre;
	private String concesionario;
	private String colonia;
	private String codigoPostal;
	private String municipio;
	private String estado;
	private String idEstado;
	private String latitud;
	private String longitud;
	private String altura;
	private String tipoSitio;
	private String tipoTorre;
	private String viento;
	private String clasificacion;
	private String region;
	private String folio;
	private String disponible;
	
	public SitioDto(String sitio, String nombre, String concesionario, String colonia, String codigoPostal,
			String municipio, String estado, String latitud, String longitud, String altura, String tipoSitio,
			String tipoTorre, String viento, String clasificacion, String region, String folio, String disponible) {
		super();
		this.sitio = sitio;
		this.nombre = nombre;
		this.concesionario = concesionario;
		this.colonia = colonia;
		this.codigoPostal = codigoPostal;
		this.municipio = municipio;
		this.estado = estado;
		this.latitud = latitud;
		this.longitud = longitud;
		this.altura = altura;
		this.tipoSitio = tipoSitio;
		this.tipoTorre = tipoTorre;
		this.viento = viento;
		this.clasificacion = clasificacion;
		this.region = region;
		this.folio = folio;
		this.disponible = disponible;
	}
	
	/**
	 * @return the sitio
	 */
	public String getSitio() {
		return sitio;
	}

	/**
	 * @param sitio the sitio to set
	 */
	public void setSitio(String sitio) {
		this.sitio = sitio;
	}

	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the concesionario
	 */
	public String getConcesionario() {
		return concesionario;
	}

	/**
	 * @param concesionario the concesionario to set
	 */
	public void setConcesionario(String concesionario) {
		this.concesionario = concesionario;
	}

	/**
	 * @return the colonia
	 */
	public String getColonia() {
		return colonia;
	}

	/**
	 * @param colonia the colonia to set
	 */
	public void setColonia(String colonia) {
		this.colonia = colonia;
	}

	/**
	 * @return the codigoPostal
	 */
	public String getCodigoPostal() {
		return codigoPostal;
	}

	/**
	 * @param codigoPostal the codigoPostal to set
	 */
	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}

	/**
	 * @return the municipio
	 */
	public String getMunicipio() {
		return municipio;
	}

	/**
	 * @param municipio the municipio to set
	 */
	public void setMunicipio(String municipio) {
		this.municipio = municipio;
	}

	/**
	 * @return the estado
	 */
	public String getEstado() {
		return estado;
	}

	/**
	 * @param estado the estado to set
	 */
	public void setEstado(String estado) {
		this.estado = estado;
	}

	/**
	 * @return the latitud
	 */
	public String getLatitud() {
		return latitud;
	}

	/**
	 * @param latitud the latitud to set
	 */
	public void setLatitud(String latitud) {
		this.latitud = latitud;
	}

	/**
	 * @return the longitud
	 */
	public String getLongitud() {
		return longitud;
	}

	/**
	 * @param longitud the longitud to set
	 */
	public void setLongitud(String longitud) {
		this.longitud = longitud;
	}

	/**
	 * @return the altura
	 */
	public String getAltura() {
		return altura;
	}

	/**
	 * @param altura the altura to set
	 */
	public void setAltura(String altura) {
		this.altura = altura;
	}

	/**
	 * @return the tipoSitio
	 */
	public String getTipoSitio() {
		return tipoSitio;
	}
	
	/**
	 * @param tipoSitio the tipoSitio to set
	 */
	public void setTipoSitio(String tipoSitio) {
		this.tipoSitio = tipoSitio;
	}

	/**
	 * @return the tipoTorre
	 */
	public String getTipoTorre() {
		return tipoTorre;
	}

	/**
	 * @param tipoTorre the tipoTorre to set
	 */
	public void setTipoTorre(String tipoTorre) {
		this.tipoTorre = tipoTorre;
	}

	/**
	 * @return the viento
	 */
	public String getViento() {
		return viento;
	}

	/**
	 * @param viento the viento to set
	 */
	public void setViento(String viento) {
		this.viento = viento;
	}

	/**
	 * @return the clasificacion
	 */
	public String getClasificacion() {
		return clasificacion;
	}
	
	/**
	 * @param clasificacion the clasificacion to set
	 */
	public void setClasificacion(String clasificacion) {
		this.clasificacion = clasificacion;
	}
	
	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}

	/**
	 * @param region the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}

	public SitioDto() {
	
	}

	/**
	 * @return the idEstado
	 */
	public String getIdEstado() {
		return idEstado;
	}

	/**
	 * @param idEstado the idEstado to set
	 */
	public void setIdEstado(String idEstado) {
		this.idEstado = idEstado;
	}

	/**
	 * @return the folio
	 */
	public String getFolio() {
		return folio;
	}

	/**
	 * @param folio the folio to set
	 */
	public void setFolio(String folio) {
		this.folio = folio;
	}

	/**
	 * @return the disponible
	 */
	public String getDisponible() {
		return disponible;
	}

	/**
	 * @param disponible the disponible to set
	 */
	public void setDisponible(String disponible) {
		this.disponible = disponible;
	}
		
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "T3SEGO_VISI_TECN_SOLI", schema = "BDDSEG01")
public class T3segoVisiTecnSoli implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID_FOLIO", nullable = false, length = 9)
    private String idFolio;

    @Temporal(TemporalType.DATE)
    @Column(name = "FECHA_VISITA")
    private Date fechaVisita;

    @Column(name = "HORA_VISITA", length = 10)
    private String horaVisita;

    @Column(name = "USUARIO_CREACION")
    private Integer usuarioCreacion;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "FECHA_CREACION")
    private Date fechaCreacion;

    @Column(name = "USUARIO_MODIFICACION")
    private Integer usuarioModificacion;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "FECHA_MODIFICACION")
    private Date fechaModificacion;

    @Column(name = "MOTIVO_RECHAZO ", length = 100)
    private String motivoRechazo;
    
    @Column(name = "MOTIVO_APROBACION ", length = 100)
    private String motivoAprobacion;
 
    // Getters y Setters

    public String getIdFolio() {
        return idFolio;
    }

    public void setIdFolio(String idFolio) {
        this.idFolio = idFolio;
    }

    public Date getFechaVisita() {
        return fechaVisita;
    }

    public void setFechaVisita(Date fechaVisita) {
        this.fechaVisita = fechaVisita;
    }

    public String getHoraVisita() {
        return horaVisita;
    }

    public void setHoraVisita(String horaVisita) {
        this.horaVisita = horaVisita;
    }

  
    public Integer getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(Integer usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public Integer getUsuarioModificacion() {
        return usuarioModificacion;
    }

    public void setUsuarioModificacion(Integer usuarioModificacion) {
        this.usuarioModificacion = usuarioModificacion;
    }

    public Date getFechaModificacion() {
        return fechaModificacion;
    }

    public void setFechaModificacion(Date fechaModificacion) {
        this.fechaModificacion = fechaModificacion;
    }

	public String getMotivoRechazo() {
		return motivoRechazo;
	}

	public void setMotivoRechazo(String motivoRechazo) {
		this.motivoRechazo = motivoRechazo;
	}

	public String getMotivoAprobacion() {
		return motivoAprobacion;
	}

	public void setMotivoAprobacion(String motivoAprobacion) {
		this.motivoAprobacion = motivoAprobacion;
	}  
}
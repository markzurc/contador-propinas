package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dao.impl;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.stereotype.Repository;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SolicitudDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dao.IConsultaSolicitudesDao;


@Repository
public class ConsultaSolicitudesDaoImpl extends GenericFunctionDaoImpl implements IConsultaSolicitudesDao {

	@Override
	public List<SolicitudDto> getListaSolicitudes(Integer operador, Integer idRol) {
	    try {
	        Session session = getSession();
	        StringBuilder sql = new StringBuilder();
	        sql.append("SELECT ")
	           .append("  to_number(SOLICITUD.id_folio) AS \"folio\", ")
	           .append("  SITIO.SITIO AS \"sitio\", ")
	           .append("  SITIO.nombre AS \"nombre\", ")
	           .append("  BDDOVI01.FNOBT_CAMP_OPER('DESCRIPCION_CORTA',go.GRUPO_OPERADOR,gr.grupo_Producto,1) AS \"concesionario\", ")
	           .append("  GO.GRUPO_OPERADOR AS \"grupoOperador\", ")
	           .append("  USUARIO.NOMBRE || ' ' || USUARIO.APELLIDO_PATERNO || ' ' || USUARIO.APELLIDO_MATERNO AS \"solicitante\", ")
	           .append("  TO_CHAR(SOLICITUD.FECHA_CREACION,'YYYYMMDDHH24MMSS')||'-'||to_char(SOLICITUD.FECHA_CREACION,'DD/MM/YYYY HH:MI:SS a.m. ') AS \"fechaSol\", ")
	           .append("  ESTADO_SOLICITUD.DESCRIPCION AS \"estatus\",SITIO.latitud AS \"latitud\" ,SITIO.longitud AS \"longitud\" ,SITIO.REGION AS \"region\" , SOLICITUD.ID_ESTADO_SOLI AS \"idEstado\", ")
	           .append("  CASE WHEN TIPOR.DESCRIPCION IS NOT NULL THEN CASE WHEN TIPOR.DESCRIPCION<>'Concesionario' AND (:PARA_ROL=12 OR :PARA_ROL=13 OR :PARA_ROL=14) THEN 'Telcel' else tipor.descripcion END ELSE '-' END AS pendiente ")
	           .append("FROM BDDSEG01.T3SEGO_SOLI SOLICITUD ")
	           .append("INNER JOIN BDDSEG01.T3SEGC_SITI SITIO ON SOLICITUD.ID_SITIO = SITIO.SITIO ")
	           .append("INNER JOIN BDDOVI01.T1ALLC_GRUP_OPER go ON SOLICITUD.GRUPO_OPERADOR = GO.GRUPO_OPERADOR ")
	           .append("INNER JOIN BDDOVI01.T1ALLR_CGROP_CGRPR gr ON GO.GRUPO_OPERADOR = GR.GRUPO_OPERADOR ")
	           .append("INNER JOIN BDDSEG01.T3SEGO_USUA USUARIO ON SOLICITUD.USUARIO = USUARIO.USUARIO ")
	           .append("INNER JOIN BDDSEG01.T3SEGC_ESTA_SOLI ESTADO_SOLICITUD ON SOLICITUD.ID_ESTADO_SOLI = ESTADO_SOLICITUD.ID_ESTADO_SOLI ")
	           .append("LEFT JOIN BDDSEG01.T3SEGC_TRAN_ESTA_INFR INFR ON SOLICITUD.ID_ESTADO_SOLI = INFR.ID_ESTATUS_ACTUAL ")
	           .append("LEFT JOIN BDDSEG01.T3SEGC_ROL ROL ON INFR.ROL = ROL.ROL ")
	           .append("LEFT JOIN BDDSEG01.T3SEGC_TIPO_ROL TIPOR ON ROL.TIPO_ROL = TIPOR.TIPO_ROL ");
	       
	        if (operador != null) {
	            sql.append("WHERE SOLICITUD.GRUPO_OPERADOR = :OPERADOR ");
	            sql.append("AND GR.GRUPO_PRODUCTO = 32 ");
	        } else {
	        	sql.append("WHERE GR.GRUPO_PRODUCTO = 32 ");
	        }
	        sql.append("GROUP BY to_number(SOLICITUD.id_folio), SITIO.SITIO, SITIO.nombre, BDDOVI01.FNOBT_CAMP_OPER('DESCRIPCION_CORTA',go.GRUPO_OPERADOR,gr.grupo_Producto,1), GO.GRUPO_OPERADOR,  USUARIO.NOMBRE || ' ' || USUARIO.APELLIDO_PATERNO || ' ' || USUARIO.APELLIDO_MATERNO, TO_CHAR(SOLICITUD.FECHA_CREACION,'YYYYMMDDHH24MMSS')||'-'||to_char(SOLICITUD.FECHA_CREACION,'DD/MM/YYYY HH:MI:SS a.m. '), ESTADO_SOLICITUD.DESCRIPCION,SITIO.latitud,SITIO.longitud, SITIO.REGION, SOLICITUD.ID_ESTADO_SOLI, TIPOR.DESCRIPCION ");
	        sql.append("ORDER BY to_number(SOLICITUD.id_folio) DESC");
	        Query query = session.createSQLQuery(sql.toString())
	        		.addScalar("folio",StandardBasicTypes.STRING)
	        		.addScalar("sitio",StandardBasicTypes.STRING)
	        		.addScalar("nombre",StandardBasicTypes.STRING)
	        		.addScalar("concesionario",StandardBasicTypes.STRING)
	        		.addScalar("solicitante",StandardBasicTypes.STRING)
	        		.addScalar("fechaSol",StandardBasicTypes.STRING)
	        		.addScalar("estatus",StandardBasicTypes.STRING)
	        		.addScalar("latitud",StandardBasicTypes.STRING)
	        		.addScalar("longitud",StandardBasicTypes.STRING)
	        		.addScalar("region",StandardBasicTypes.STRING)
	        		.addScalar("idEstado",StandardBasicTypes.STRING)
	        		.addScalar("pendiente",StandardBasicTypes.STRING)
	        		.addScalar("grupoOperador",StandardBasicTypes.STRING)
	            .setResultTransformer(Transformers.aliasToBean(SolicitudDto.class));

	        if (operador != null) {
	            query.setParameter("OPERADOR", operador);
	        }
	        query.setParameter("PARA_ROL", idRol);
	        return query.list();

	    } catch (Exception e) {
	        e.printStackTrace();
	        return new ArrayList<>();
	    }
	}

	@Override
	public Integer getOperadorUsuario(Integer idUsuario) {
		try {
			Session session = getSession();
			String sql="SELECT idOperador FROM T3segoDatoUsuaExte WHERE idUsuario=:USUARIO ";
			Query query = session.createQuery(sql);
			query.setParameter("USUARIO", idUsuario);
			return (Integer) query.uniqueResult();
			}catch (Exception e) {
				e.printStackTrace();
				return null;
			}	
	}
	
	@Override
	public Boolean getValidarOperador(Integer rol) {
		try {
			Session session = getSession();
			String sql="SELECT G.VALIDAR_OPERADOR FROM BDDSEG01.T3SEGC_GRUP G INNER JOIN  BDDSEG01.T3SEGR_GRUP_ROL GR ON G.ID_GRUPO=GR.ID_GRUPO WHERE GR.ID_ROL=:ROL ";
			Query query = session.createSQLQuery(sql);
			query.setParameter("ROL", rol);
			Object result = query.uniqueResult();
			Boolean validarOperador = (result != null) ? "1".equals(result.toString()) : null;
			return validarOperador;
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}	
		
	}
			

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * @author cavilezg
 * entidad de la table T7PFAC_GRUP_PERF_NOTI
 */
@Entity
@Table(name = "T3PFAC_GRUP_PERF_NOTI",  schema="BDDSEG01")
public class T7pfacGrupPerfNoti {
	
	private Integer idGrupoRol;//ID_GRUPO_ROL	NUMBER(3,0)
	private Integer idGrupo;//ID_GRUPO	NUMBER(3,0)
	private Integer rol;//ROL	NUMBER(3,0)
	private Integer estatus;//ESTATUS	NUMBER(1,0)
	private Integer usuarioModificacion;//USUARIO_MODIFICACION	NUMBER(9,0)
	private Date fechaModificacion;//FECHA_MODIFICACION	DATE
	public T7pfacGrupPerfNoti() {
		super();
	}
	public T7pfacGrupPerfNoti(Integer idGrupoRol, Integer idGrupo, Integer rol, Integer estatus,
			Integer usuarioModificacion, Date fechaModificacion) {
		super();
		this.idGrupoRol = idGrupoRol;
		this.idGrupo = idGrupo;
		this.rol = rol;
		this.estatus = estatus;
		this.usuarioModificacion = usuarioModificacion;
		this.fechaModificacion = fechaModificacion;
	}
	
	@Id
	@Column(name = "ID_GRUPO_ROL", unique = true, nullable = false, precision = 3, scale = 0)
	public Integer getIdGrupoRol() {
		return idGrupoRol;
	}
	public void setIdGrupoRol(Integer idGrupoRol) {
		this.idGrupoRol = idGrupoRol;
	}
	
	
	@Column(name = "ID_GRUPO", unique = true, nullable = false, precision = 3, scale = 0)
	public Integer getIdGrupo() {
		return idGrupo;
	}
	public void setIdGrupo(Integer idGrupo) {
		this.idGrupo = idGrupo;
	}
	
	
	@Column(name = "ROL", unique = true, nullable = false, precision = 3, scale = 0)
	public Integer getRol() {
		return rol;
	}
	public void setRol(Integer rol) {
		this.rol = rol;
	}
	
	@Column(name = "ESTATUS", unique = true, nullable = false, precision = 3, scale = 0)
	public Integer getEstatus() {
		return estatus;
	}
	public void setEstatus(Integer estatus) {
		this.estatus = estatus;
	}
	
	@Column(name = "USUARIO_MODIFICACION")
	public Integer getUsuarioModificacion() {
		return usuarioModificacion;
	}
	public void setUsuarioModificacion(Integer usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}
	
	@Column(name="FECHA_MODIFICACION")
	public Date getFechaModificacion() {
		return fechaModificacion;
	}
	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
	
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.transformer;

import java.util.List;
import org.hibernate.transform.ResultTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.FiltroSitioDto;;

public class FiltroSitioTransformer implements ResultTransformer {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4569880860719168302L;

	@Override
	public Object transformTuple(Object[] tuple, String[] aliases) {
		String region = checkStrNotNull(tuple[0]);
		String estado = checkStrNotNull(tuple[1]);
		String municipio = checkStrNotNull(tuple[2]);
		
		FiltroSitioDto detalleSitio = new FiltroSitioDto(region, estado, municipio);
		return detalleSitio;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List collection) {
		return collection;
	}
	
	private String checkStrNotNull(Object object) {
		return null != object ? object.toString() : " ";
	}
}

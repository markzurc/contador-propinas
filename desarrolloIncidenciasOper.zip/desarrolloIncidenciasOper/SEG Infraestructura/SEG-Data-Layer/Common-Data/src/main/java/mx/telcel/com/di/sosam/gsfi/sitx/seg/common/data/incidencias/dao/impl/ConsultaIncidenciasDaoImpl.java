package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.impl;

import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IConsultaIncidenciasDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaGestionDto;

@Repository
@Transactional(readOnly = true)
@SuppressWarnings({ "deprecation", "unchecked" })
public class ConsultaIncidenciasDaoImpl extends GenericFunctionDaoImpl implements IConsultaIncidenciasDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public List<IncidenciaGestionDto> buscarGestion(String filtroFolio, String filtroSitio, String filtroEstatus) {
        // Delego a la versi�n extendida (si la quieres conservar)
        return buscarGestionExtendido(filtroFolio, filtroSitio, filtroEstatus, null, true);
    }
    
    
    public List<IncidenciaGestionDto> buscarGestionExtendido(
            String filtroFolio,
            String filtroSitio,
            String filtroEstatus,
            String filtroConcesionario,
            boolean soloActivas) {

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT ");
        sql.append("  i.ID_INCI        AS idIncidencia, ");
        sql.append("  i.FOLI_INCI      AS folioIncidencia, ");
        sql.append("  i.ID_SITIO       AS idSitio, ");
        sql.append("  i.CONC_ID        AS concesionario, ");
        sql.append("  t.DSC_TIPO_INCI  AS tipoIncidencia, ");
        sql.append("  e.DSC_ESTA_INCI  AS estatus, ");
        sql.append("  r.DSC_RESP_INCI  AS responsabilidad, ");
        sql.append("  i.FEC_ALTA       AS fechaCreacion, ");
        sql.append("  i.FEC_ULT_MOV    AS fechaUltimoMovimiento ");
        sql.append("FROM BDDSEG01.T3SINO_INCI i ");
        sql.append("JOIN BDDSEG01.T3SINC_INCI_TIPO t ON t.ID_TIPO_INCI = i.ID_TIPO_INCI ");
        sql.append("JOIN BDDSEG01.T3SINC_INCI_ESTA e ON e.ID_ESTA_INCI = i.ID_ESTA_INCI ");
        sql.append("JOIN BDDSEG01.T3SINC_INCI_RESP r ON r.ID_RESP_INCI = i.ID_RESP_INCI ");
        sql.append("WHERE 1=1 ");

        if (soloActivas) {
            sql.append("AND i.ACTIVO = 'S' ");
        }

        if (!isBlank(filtroFolio)) {
            sql.append("AND UPPER(i.FOLI_INCI) LIKE UPPER(:folio) ");
        }

        if (!isBlank(filtroSitio)) {
            sql.append("AND i.ID_SITIO = :idSitio ");
        }

        if (!isBlank(filtroConcesionario)) {
            sql.append("AND i.CONC_ID = :idConcesionario ");
        }

        if (!isBlank(filtroEstatus)) {
            sql.append("AND ( ");
            sql.append("  UPPER(e.CVE_ESTA_INCI) = UPPER(:estatus) ");
            sql.append("  OR TRANSLATE(UPPER(e.DSC_ESTA_INCI), '�����', 'AEIOU') = TRANSLATE(UPPER(:estatus), '�����', 'AEIOU') ");
            sql.append(") ");
        }

        sql.append("ORDER BY i.FEC_ULT_MOV DESC ");

        SQLQuery query = sessionFactory.getCurrentSession().createSQLQuery(sql.toString());
        query.setResultTransformer(Transformers.aliasToBean(IncidenciaGestionDto.class));

        if (!isBlank(filtroFolio)) {
            query.setParameter("folio", "%" + filtroFolio.trim() + "%");
        }
        if (!isBlank(filtroSitio)) {
            query.setParameter("idSitio", filtroSitio.trim());
        }
        if (!isBlank(filtroConcesionario)) {
            query.setParameter("idConcesionario", filtroConcesionario.trim());
        }
        if (!isBlank(filtroEstatus)) {
            query.setParameter("estatus", filtroEstatus.trim());
        }

        return (List<IncidenciaGestionDto>) query.list();
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception;

/**
 * 
 * <h1>TransactionalOVITException</h1>
 * <p>
 * Exception thrown for "OVIT" system when exist a error of database level.
 * </p>
 * 
 * @author chcastro
 * @version 1.0
 * @since 27/03/2015
 *
 */
public class TransactionalOVITException extends Exception {

	private static final long serialVersionUID = 1848601303912063645L;
	
	private String messageError;
	private String codeMessage;
	
	
	/**
	 * Constructor.
	 * 
	 * @param messageError
	 * @param codeMessage
	 */
	public TransactionalOVITException(String codeMessage, String messageError) {
		super();
		this.messageError = messageError;
		this.codeMessage = codeMessage;
	}
	
	/**
	 * @return the messageError
	 */
	public String getMessageError() {
		return messageError;
	}
	/**
	 * @param messageError the messageError to set
	 */
	public void setMessageError(String messageError) {
		this.messageError = messageError;
	}
	/**
	 * @return the codeMessage
	 */
	public String getCodeMessage() {
		return codeMessage;
	}
	/**
	 * @param codeMessage the codeMessage to set
	 */
	public void setCodeMessage(String codeMessage) {
		this.codeMessage = codeMessage;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TransactionalOVITException [messageError=");
		builder.append(messageError);
		builder.append(", codeMessage=");
		builder.append(codeMessage);
		builder.append("]");
		return builder.toString();
	}
	
	
	 

}

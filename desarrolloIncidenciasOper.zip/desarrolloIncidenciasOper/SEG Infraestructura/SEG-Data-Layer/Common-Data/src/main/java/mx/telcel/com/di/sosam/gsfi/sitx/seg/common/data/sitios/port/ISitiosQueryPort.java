package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.port;

import java.util.List;

public interface ISitiosQueryPort {
    boolean existeYActivo(String sitioId);
    List<?> listarSitiosVisiblesParaUsuario();
}
package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * <h1>T7segcEsta</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 20/04/2015
 *
 */
@Entity
@Table(name = "T3SEGC_ESTA",  schema="BDDSEG01")
public class T7segcEsta implements java.io.Serializable {

	private static final long serialVersionUID = -6584319588769237454L;
	private Integer estatus;
	private String valor;
	private String descripcion;

	public T7segcEsta() {
	}

	public T7segcEsta(Integer estatus) {
		this.estatus = estatus;
	}

	public T7segcEsta(Integer estatus, String valor, String descripcion) {
		this.estatus = estatus;
		this.valor = valor;
		this.descripcion = descripcion;
	}

	@Id
	@Column(name = "ESTATUS", unique = true, nullable = false, precision = 22, scale = 0)
	public Integer getIdEstatus() {
		return this.estatus;
	}

	public void setIdEstatus(Integer estatus) {
		this.estatus = estatus;
	}

	@Column(name = "VALOR", length = 20)
	public String getValor() {
		return this.valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	@Column(name = "DESCRIPCION", length = 45)
	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

}

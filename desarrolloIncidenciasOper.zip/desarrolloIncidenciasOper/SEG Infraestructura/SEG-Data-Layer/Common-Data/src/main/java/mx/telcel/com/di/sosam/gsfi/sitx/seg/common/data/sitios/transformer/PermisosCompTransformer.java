package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.transformer;

import java.util.List;

import org.hibernate.transform.ResultTransformer;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.PermisosCompDto;;

public class PermisosCompTransformer implements ResultTransformer{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7550551214930722113L;
	
	@Override
	public Object transformTuple(Object[] tuple, String[] aliases) {
		PermisosCompDto componentes = new PermisosCompDto();
		String nombreComponente = checkStrNotNull(tuple[0]);
		String permiso = checkStrNotNull(tuple[1]);
		componentes.setNombreComponente(nombreComponente);
		componentes.setPermiso(permiso);
		return componentes;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List collection) {
		return collection;
	}

	private String checkStrNotNull(Object object) {
		return null != object ? object.toString() : " ";
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "T3SEGD_SOLI_ARCH", schema = "BDDSEG01")
public class T3SegdSoliArch implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "segd_soli_arch_seq")
    @SequenceGenerator(
        name = "segd_soli_arch_seq",
        sequenceName = "BDDSEG01.SQ3SEGD_ARCH",
        allocationSize = 1
    )
    @Column(name = "ID_ARCHIVO", nullable = false)
    private Integer idArchivo;

    @Column(name = "RUTA", length = 50)
    private String ruta;

    @Column(name = "DESCRIPCION", length = 35)
    private String descripcion;

    @Column(name = "NOMBRE_ARCHIVO", length = 100)
    private String nombreArchivo;

    @Column(name = "TAMANIO", length = 25)
    private String tamanio;

    @Column(name = "FECHA_CARGA")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaCarga;

    @Column(name = "REVISION", length = 10)
    private String revision;

    @Column(name = "USUARIO")
    private Integer usuario;

    @Column(name = "ID_SECCION")
    private Integer idSeccion;

    @Column(name = "ID_FOLIO", nullable = false, length = 20)
    private String idFolio;

    // Getters y setters

    public Integer getIdArchivo() {
        return idArchivo;
    }

    public void setIdArchivo(Integer idArchivo) {
        this.idArchivo = idArchivo;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

    public void setNombreArchivo(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    public String getTamanio() {
        return tamanio;
    }

    public void setTamanio(String tamanio) {
        this.tamanio = tamanio;
    }

    public Date getFechaCarga() {
        return fechaCarga;
    }

    public void setFechaCarga(Date fechaCarga) {
        this.fechaCarga = fechaCarga;
    }

    public String getRevision() {
        return revision;
    }

    public void setRevision(String revision) {
        this.revision = revision;
    }

    public Integer getUsuario() {
        return usuario;
    }

    public void setUsuario(Integer usuario) {
        this.usuario = usuario;
    }

    public Integer getIdSeccion() {
        return idSeccion;
    }

    public void setIdSeccion(Integer idSeccion) {
        this.idSeccion = idSeccion;
    }

    public String getIdFolio() {
        return idFolio;
    }

    public void setIdFolio(String idFolio) {
        this.idFolio = idFolio;
    }
}

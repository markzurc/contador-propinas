package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class EstadoDto implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3660880568288907128L;
	private BigDecimal idEstado;
	private String nombre;
	private BigDecimal estatus;
	
	public EstadoDto(BigDecimal idEstado, String nombre, BigDecimal estatus) {
		super();
		this.idEstado = idEstado;
		this.nombre = nombre;
		this.estatus = estatus;
	}
		
	public EstadoDto() {

	}

	/**
	 * @return the idEstado
	 */
	public BigDecimal getIdEstado() {
		return idEstado;
	}
	/**
	 * @param idEstado the idEstado to set
	 */
	public void setIdEstado(BigDecimal idEstado) {
		this.idEstado = idEstado;
	}
	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @return the estatus
	 */
	public BigDecimal getEstatus() {
		return estatus;
	}
	/**
	 * @param estatus the estatus to set
	 */
	public void setEstatus(BigDecimal estatus) {
		this.estatus = estatus;
	}
	
}

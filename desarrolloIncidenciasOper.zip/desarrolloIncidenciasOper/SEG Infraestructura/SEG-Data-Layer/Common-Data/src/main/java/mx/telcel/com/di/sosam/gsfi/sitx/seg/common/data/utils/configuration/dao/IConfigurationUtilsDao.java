package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.utils.configuration.dao;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcPara;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.utils.session.ISession;

/**
 * 
 * <h1>IConstantUtilsDao</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 17/04/2015
 *
 */
public interface IConfigurationUtilsDao extends ISession {
	List<T7segcPara> getConstantOfDataBase();
	void updateConfiguration(T7segcPara tsegcConfiguracion);
}

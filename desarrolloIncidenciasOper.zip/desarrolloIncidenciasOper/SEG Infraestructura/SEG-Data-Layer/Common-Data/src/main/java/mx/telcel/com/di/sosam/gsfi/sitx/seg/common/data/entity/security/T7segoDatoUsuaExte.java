package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * 
 * <h1>T7segoDatoUsuaExte</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 16/04/2015
 *
 */
@Entity
@Table(name = "T3SEGO_DATO_USUA_EXTE",  schema="BDDSEG01")
public class T7segoDatoUsuaExte implements java.io.Serializable {

	private static final long serialVersionUID = -1004463529126636455L;
	private TsegcDatosexternoId id;
	private Integer responsable;
	private String correo;
	private String numeroEmpleado;

	public T7segoDatoUsuaExte() {
	}

	public T7segoDatoUsuaExte(TsegcDatosexternoId id) {
		this.id = id;
	}

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "idUsuario", column = @Column(name = "USUARIO", nullable = false, precision = 22, scale = 0)) })
	public TsegcDatosexternoId getId() {
		return this.id;
	}

	public void setId(TsegcDatosexternoId id) {
		this.id = id;
	}
	
	@Column(name = "RESPONSABLE", nullable = false, precision = 22, scale = 0)
	public Integer getIdResponsable() {
		return this.responsable;
	}

	public void setIdResponsable(Integer responsable) {
		this.responsable = responsable;
	}

	@Column(name = "CORREO", length = 45)
	public String getCorreo() {
		return this.correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}
	
	@Column(name = "NUMERO_EMPLEADO", nullable = false, unique = true, length = 15)
	public String getNumeroEmpleado() {
		return this.numeroEmpleado;
	}

	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}
}

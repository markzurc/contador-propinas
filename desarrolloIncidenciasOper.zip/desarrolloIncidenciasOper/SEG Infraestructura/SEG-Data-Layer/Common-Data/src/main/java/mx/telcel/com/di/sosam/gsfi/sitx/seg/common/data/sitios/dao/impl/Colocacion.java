package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.impl;

import java.util.Collections;
import java.util.List;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.IColocacion;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ColocacionTablaEspacioPisoDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ColocacionTablaEspacioTorreDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ProgramaColocacionDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SoliArchDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.VerificacionColocacionDto;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Jair Javier
 */
@Repository(value = "colocacionDao")
@Scope("prototype")
public class Colocacion extends GenericFunctionDaoImpl implements IColocacion{
    private static final String INSERTA_TABLA_PRINCIPAL_SOL_COL = "T3SEGO_SOLI_COLO_INSERCION";
    private static final String ACTUALIZA_TABLA_PRINCIPAL_SOL_COL = "T3SEGO_SOLI_COLO_ACTUALIZAR";
    private static final String INSERTA_ESPACIO_TORRE_SOL_COL = "T3SEGO_SOLI_COLO_ESP_TOR_INSERCION";
    private static final String ACTUALIZA_ESPACIO_TORRE_SOL_COL = "T3SEGO_SOLI_COLO_ESP_TOR_ACTUALIZAR";
    private static final String ELIMINA_ESPACIO_TORRE_SOL_COL = "T3SEGO_SOLI_COLO_ESP_TOR_ELIMINAR";
    private static final String INSERTA_ESPACIO_PISO_SOL_COL = "T3SEGO_SOLI_COLO_ESP_PIS_INSERCION";
    private static final String ACTUALIZA_ESPACIO_PISO_SOL_COL = "T3SEGO_SOLI_COLO_ESP_PIS_ACTUALIZAR";
    private static final String ELIMINA_ESPACIO_PISO_SOL_COL = "T3SEGO_SOLI_COLO_ESP_PIS_ELIMINAR";
    private static final String INSERTA_ARCHIVO_EN_TABLA = "T3SEGD_SOLI_ARCH_INSERCION";
    private static final String ACTUALIZA_ARCHIVO_EN_TABLA =  "T3SEGD_SOLI_ARCH_UPDATE";
    private static final String ELIMINA_ARCHIVO_EN_TABLA =  "T3SEGD_SOLI_ARCH_DELETE";
    private static final String INSERTA_PROGRAMA_COLOCACION = "T3SEGO_PROG_COLO";
    private static final String INSERTA_VERIFICACION_COL = "T3SEGO_VERI_COLO_INSERCION";
    private static final String ACTUALIZA_VERIFICACION_COL = "T3SEGO_VERI_COLO_UPDATE";
    private static final String CORRECCION_VERIFICACION_COL = "T3SEGO_VERI_COLO_CORRECCION_UPDATE";
    
    @Override
    public boolean insertaPrincipalSolicitudColocacion(
    String folio, String calibreRF, String calibreMW, String superficie, String transformador, String observaciones, String observacionesTelcel){
        Session session = getSession();
        try{
            Query query = session.getNamedQuery(INSERTA_TABLA_PRINCIPAL_SOL_COL)
                    .setString(0, folio)
                    .setString(1, calibreRF)
                    .setString(2, calibreMW)
                    .setString(3, superficie)
                    .setString(4, transformador)
                    .setString(5, observaciones)
                    .setString(6, observacionesTelcel);
            query.executeUpdate();
            return true;
        } catch (HibernateException error){
            System.err.println("Colocacion:insertaPrincipalSolicitudColocacion: "+error);
            return false;
        }
    }
    
    @Override
    public boolean actualizaPrincipalSolicitudColocacion(String folio, String calibreRF, String calibreMW, String superficie, String transformador, String observaciones, String observacionesTelcel){
        Session session = getSession();
        try{
            Query query = session.getNamedQuery(ACTUALIZA_TABLA_PRINCIPAL_SOL_COL)
                    .setString(0, calibreRF)
                    .setString(1, calibreMW)
                    .setString(2, superficie)
                    .setString(3, transformador)
                    .setString(4, observaciones)
                    .setString(5, observacionesTelcel)
                    .setString(6, folio);
            query.executeUpdate();
            return true;
        } catch (HibernateException error){
            System.err.println("Colocacion:actualizaPrincipalSolicitudColocacion: "+error);
            return false;
        }
    }

    @Override
    public boolean insertaSolicitudColocacionEspacioTorre(String string, List<ColocacionTablaEspacioTorreDTO> list) {
        Session session = getSession();
        try{
            for (ColocacionTablaEspacioTorreDTO t : list){
                Query querty = session.getNamedQuery(INSERTA_ESPACIO_TORRE_SOL_COL)
                        .setString(0, string)
                        .setString(1, t.getTipoAntena())
                        .setString(2, t.getOrientacion())
                        .setString(3, t.getNcr())
                        .setString(4, t.getDimensiones())
                        .setString(5, t.getFrecuenciasRX())
                        .setString(6, t.getFrecuenciasTX())
                        .setString(7, t.getPeso());
                querty.executeUpdate();
            }
            return true;
        }catch(HibernateException e){
            System.err.println("Colocacion:insertaSolicitudColocacionEspacioTorre: error: "+e);
            return false;
        }
    }
    
    @Override
    public boolean actualizaSolicitudColocacionEspacioTorre(String folio, List<ColocacionTablaEspacioTorreDTO> listaEspacioTorre){
        Session session = getSession();
        try{
            for (ColocacionTablaEspacioTorreDTO t : listaEspacioTorre){
                Query querty = session.getNamedQuery(ACTUALIZA_ESPACIO_TORRE_SOL_COL)
                        .setString(0, t.getOrientacion())
                        .setString(1, t.getNcr())
                        .setString(2, t.getDimensiones())
                        .setString(3, t.getFrecuenciasRX())
                        .setString(4, t.getFrecuenciasTX())
                        .setString(5, t.getPeso())
                        .setString(6, folio)
                        .setString(7, t.getTipoAntena());
                querty.executeUpdate();
            }
            return true;            
        }catch(HibernateException e){
            System.err.println("Colocacion:actualizaSolicitudColocacionEspacioTorre: error: "+e);
            return false;
        }
    }
    
    @Override
    public boolean eliminaSolicitudColocacionEspacioTorre(String folio, List<ColocacionTablaEspacioTorreDTO> listaEspacioTorre){
        Session session = getSession();
        try{
            for (ColocacionTablaEspacioTorreDTO t : listaEspacioTorre){
                Query querty = session.getNamedQuery(ELIMINA_ESPACIO_TORRE_SOL_COL)
                        .setString(0, folio)
                        .setString(1, t.getTipoAntena());
                querty.executeUpdate();
            }
            return true;            
        }catch(HibernateException e){
            System.err.println("Colocacion:eliminaSolicitudColocacionEspacioTorre: error: "+e);
            return false;
        }
    }

    @Override
    public boolean insertaSolicitudColocacionEspacioPiso(String string, List<ColocacionTablaEspacioPisoDTO> list) {
        Session session = getSession();
        try {
            for(ColocacionTablaEspacioPisoDTO t : list){
                Query query = session.getNamedQuery(INSERTA_ESPACIO_PISO_SOL_COL)
                        .setString(0, string)
                        .setString(1, t.getGabinete())
                        .setString(2, t.getTecnologia())
                        .setString(3, t.getSuperficie());
                query.executeUpdate();
            }
            return true;
        } catch (HibernateException error){
            System.err.println("Colocacion:insertaSolicitudColocacionEspacioPiso: error: "+error);
            return false;
        }
    }
    
    @Override
    public boolean actualizaSolicitudColocacionEspacioPiso(String folio, List<ColocacionTablaEspacioPisoDTO> listaEspacioPiso){
        Session session = getSession();
        try {
            for(ColocacionTablaEspacioPisoDTO t : listaEspacioPiso){
                Query query = session.getNamedQuery(ACTUALIZA_ESPACIO_PISO_SOL_COL)
                        .setString(0, t.getTecnologia())
                        .setString(1, t.getSuperficie())
                        .setString(2, folio)
                        .setString(3, t.getGabinete());
                query.executeUpdate();
            }
            return true;
        } catch (HibernateException error){
            System.err.println("Colocacion:actualizaSolicitudColocacionEspacioPiso: error: "+error);
            return false;
        }
    }
    
    @Override
    public boolean eliminarSolicitudColocacionEspacioPiso(String folio, List<ColocacionTablaEspacioPisoDTO> listaEspacioPiso){
        Session session = getSession();
        try {
            for(ColocacionTablaEspacioPisoDTO t : listaEspacioPiso){
                Query query = session.getNamedQuery(ELIMINA_ESPACIO_PISO_SOL_COL)
                        .setString(0, folio)
                        .setString(1, t.getGabinete());
                query.executeUpdate();
            }
            return true;
        } catch (HibernateException error){
            System.err.println("Colocacion:actualizaSolicitudColocacionEspacioPiso: error: "+error);
            return false;
        }
    }

    @Override
    public boolean insertaArchivoEnTabla(String folio, List<SoliArchDto> list) {
        Session session = getSession();
        try {
            for (SoliArchDto t : list){
                Query query = session.getNamedQuery(INSERTA_ARCHIVO_EN_TABLA)
                        .setString(0, t.getRuta())
                        .setString(1, t.getDescripcion())
                        .setString(2, t.getNombreArch())
                        .setString(3, t.getTamanio())
                        .setString(4, t.getRevision())
                        .setString(5, t.getUsuario())
                        .setString(6, String.valueOf(t.getIdSeccion()))
                        .setString(7, folio);
                query.executeUpdate(); 
            }
            return true;
        }catch(HibernateException error){
            return false;
        }
    }
    
    @Override
    public boolean actualizaArchivoEnTabla(String folio, String ruta, List<SoliArchDto> listaArchivo){
        Session session = getSession();
        try {
            for (SoliArchDto t : listaArchivo){
                Query query = session.getNamedQuery(ACTUALIZA_ARCHIVO_EN_TABLA)
                        .setString(0, ruta)
                        .setString(1, t.getDescripcion())
                        .setString(2, t.getNombreArch())
                        .setString(3, t.getTamanio())
                        .setString(4, t.getRevision())
                        .setString(5, t.getUsuario())
                        .setString(6, String.valueOf(t.getIdSeccion()))
                        .setString(7, t.getNombreArch())
                        .setString(8, folio);
                query.executeUpdate();
            }
            return true;
        }catch(HibernateException error){
            return false;
        }
    }
    
    @Override
    public boolean eliminaArchivoEnTabla(String folio, List<SoliArchDto> listaArchivo){
        Session session = getSession();
        try {
            for (SoliArchDto t : listaArchivo){
                Query query = session.getNamedQuery(ELIMINA_ARCHIVO_EN_TABLA)
                        .setString(0, folio)
                        .setString(1, t.getNombreArch());
                query.executeUpdate(); 
            }
            return true;
        }catch(HibernateException error){
            return false;
        }
    }

    @Override
    public List<SoliArchDto> obtenerArchivoEnTabla(String folio, String ruta) {
        Session session = getSession();
        try {
            String sentencia = "SELECT ARCHIVO.ID_ARCHIVO AS idArchivo,\n" +
                                "            ARCHIVO.RUTA AS ruta,\n" +
                                "            ARCHIVO.DESCRIPCION AS descripcion,\n" +
                                "            ARCHIVO.NOMBRE_ARCHIVO AS nombreArch,\n" +
                                "            ARCHIVO.TAMANIO AS tamanio,\n" +
                                "            to_char(ARCHIVO.FECHA_CARGA, 'dd/mm/yyyy hh:mi:ss a.m.') AS fechaCarga,\n" +
                                "            ARCHIVO.REVISION AS revision,\n" +
                                "            USUARIO.NOMBRE || ' ' || USUARIO.APELLIDO_PATERNO || ' ' || USUARIO.APELLIDO_MATERNO AS usuario,\n" +
                                "            ARCHIVO.ID_SECCION AS idSeccion,\n" +
                                "            ARCHIVO.ID_FOLIO AS folio,\n" +
                                "            'true' AS botonEliminar\n" +
                                "            FROM BDDSEG01.T3SEGD_SOLI_ARCH ARCHIVO\n" +
                                "            INNER JOIN  BDDSEG01.T3SEGO_USUA USUARIO ON ARCHIVO.USUARIO = USUARIO.USUARIO\n" +
                                "            WHERE ARCHIVO.ID_FOLIO = :FOLIO\n" +
                                "            AND ARCHIVO.RUTA = :RUTA";
            Query query = session.createSQLQuery(sentencia)
                    .addScalar("idArchivo", StandardBasicTypes.INTEGER)
                    .addScalar("ruta", StandardBasicTypes.STRING)
                    .addScalar("descripcion", StandardBasicTypes.STRING)
                    .addScalar("nombreArch", StandardBasicTypes.STRING)
                    .addScalar("tamanio", StandardBasicTypes.STRING)
                    .addScalar("fechaCarga", StandardBasicTypes.STRING)
                    .addScalar("revision", StandardBasicTypes.STRING)
                    .addScalar("usuario", StandardBasicTypes.STRING)
                    .addScalar("idSeccion", StandardBasicTypes.INTEGER)
                    .addScalar("folio", StandardBasicTypes.STRING)
                    .addScalar("botonEliminar",StandardBasicTypes.STRING)
                    .setResultTransformer(Transformers.aliasToBean(SoliArchDto.class));
            		query.setParameter("FOLIO", folio)
                    .setParameter("RUTA", ruta);
            return query.list();
        } catch (HibernateException e){
            return null;
        }
    }
    
    @Override
    public List<ColocacionTablaEspacioTorreDTO> obtenerEspacioTorre(String folio){
        Session session = getSession();
        try{
            String sentencia = "SELECT\n" +
                "ESP_TOR.TIPO_ANTENA AS tipoAntena,\n" +
                "ESP_TOR.ORIENTACION AS orientacion,\n" +
                "ESP_TOR.NCR AS ncr,\n" +
                "ESP_TOR.DIMENSIONES AS dimensiones,\n" +
                "ESP_TOR.FRE_RX AS frecuenciasRX,\n" +
                "ESP_TOR.FRE_TX AS frecuenciasTX,\n" +
                "ESP_TOR.PESO AS peso\n" +
                "FROM BDDSEG01.T3SEGO_SOLI_COLO_ESP_TOR ESP_TOR\n" +
                "WHERE ESP_TOR.ID_FOLIO = :FOLIO";
                Query query = session.createSQLQuery(sentencia)
                        .addScalar("tipoAntena", StandardBasicTypes.STRING)
                        .addScalar("orientacion", StandardBasicTypes.STRING)
                        .addScalar("ncr", StandardBasicTypes.STRING)
                        .addScalar("dimensiones", StandardBasicTypes.STRING)
                        .addScalar("frecuenciasRX", StandardBasicTypes.STRING)
                        .addScalar("frecuenciasTX", StandardBasicTypes.STRING)
                        .addScalar("peso", StandardBasicTypes.STRING)
                        .setResultTransformer(Transformers.aliasToBean(ColocacionTablaEspacioTorreDTO.class));
                query.setParameter("FOLIO", folio);
                return query.list();
        } catch (HibernateException error){
            return null;
        }
    }
    
    @Override
    public List<ColocacionTablaEspacioPisoDTO> obtenerEspacioPiso (String folio){
        Session session = getSession();
        try {
            String sentencia = "SELECT ESP_PIS.GABINETE AS gabinete,\n" +
                "ESP_PIS.TECNOLOGIA AS tecnologia,\n" +
                "ESP_PIS.SUPERFICIE AS superficie\n" +
                "FROM BDDSEG01.T3SEGO_SOLI_COLO_ESP_PIS ESP_PIS\n" +
                "WHERE ID_FOLIO = :FOLIO";
            Query query = session.createSQLQuery(sentencia)
                    .addScalar("gabinete", StandardBasicTypes.STRING)
                    .addScalar("tecnologia", StandardBasicTypes.STRING)
                    .addScalar("superficie", StandardBasicTypes.STRING)
                    .setResultTransformer(Transformers.aliasToBean(ColocacionTablaEspacioPisoDTO.class));
            query.setParameter("FOLIO", folio);
            return query.list();            
        } catch (HibernateException e){
            return null;
        }
    }

    @Override
    public String obtenerDatosSolicitudColocacion(String folio) {
        Session session = getSession();
        try{
            String sentencia = "SELECT COLO.ID_FOLIO||'~'||COLO.L_TRANS_RF_CALIBRE||'~'||COLO.L_TRANS_MW_CALIBRE||'~'||COLO.SUPERFICIE||'~'||COLO.C_TRANSFORMADOR||'~'||CASE WHEN COLO.OBSERVACIONES IS NOT NULL THEN COLO.OBSERVACIONES ELSE 'X' END||'~'||CASE WHEN COLO.OBSERVACIONES_TELCEL IS NOT NULL THEN COLO.OBSERVACIONES_TELCEL ELSE 'X' END\n" +
                                "FROM BDDSEG01.T3SEGO_SOLI_COLO COLO\n" +
                                "WHERE COLO.ID_FOLIO = :FOLIO";
            Query query = session.createSQLQuery(sentencia);
            query.setParameter("FOLIO", folio);
            return query.uniqueResult().toString();
        }catch(HibernateException e){
            return "";
        }
    }

    @Override
    public String consultaExistenciaSolicitudColocacion(String folio) {
        Session session = getSession();
        try{
            String sentencia = "SELECT COUNT(*) FROM BDDSEG01.T3SEGO_BITA \n"
                    + "WHERE ID_ESTATUS_FLUJO IN(SELECT ID_ESTADO_SOLI \n"
                    + "FROM BDDSEG01.T3SEGC_ESTA_SOLI WHERE UPPER(DESCRIPCION) = 'SOLICITUD DE COLOCACION GENERADA') \n"
                    + "AND ID_SOLICITUD = :FOLIO";
            Query query = session.createSQLQuery(sentencia);
            query.setParameter("FOLIO", folio);
            return query.uniqueResult().toString();            
        }catch(HibernateException e){
            return "";
        }
    }
    
    @Override
    public boolean insertaProgramaColocacion(List<ProgramaColocacionDto> list) {
        Session session = getSession();
        try {
            for (ProgramaColocacionDto pc : list){
                Query query = session.getNamedQuery(INSERTA_PROGRAMA_COLOCACION)
                        .setString(0, pc.getSemana())
                        .setString(1, pc.getActividad())
                		.setString(2, pc.getFechaInicioProgramada())
                		.setString(3, pc.getFechaFinalProgramada())
                		.setString(4, pc.getIdFolio());
                query.executeUpdate(); 
            }
            return true;
        }catch(HibernateException error){
            return false;
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<ProgramaColocacionDto> obtenerProgramaColocacion(String folio){
        Session session = getSession();
        try {
            String sentencia = "SELECT ID_PROGRAMA_COLOCACION AS idProgramaColocacion,\n" +
            					"SEMANA AS semana,\n" +
            					"ACTIVIDAD AS actividad,\n" +
            					"FECHA_INICIO_PROGRAMADA AS fechaInicioProgramada,\n" +
            					"FECHA_FINAL_PROGRAMADA AS fechaFinalProgramada\n" +
            					"FROM BDDSEG01.T3SEGO_PROG_COLO\n" +
            					"WHERE ID_FOLIO = :FOLIO";
            Query query = session.createSQLQuery(sentencia)
            		.addScalar("idProgramaColocacion", StandardBasicTypes.INTEGER)
                    .addScalar("semana", StandardBasicTypes.STRING)
                    .addScalar("actividad", StandardBasicTypes.STRING)
                    .addScalar("fechaInicioProgramada", StandardBasicTypes.STRING)
                    .addScalar("fechaFinalProgramada", StandardBasicTypes.STRING)
                    .setResultTransformer(Transformers.aliasToBean(ProgramaColocacionDto.class));
            query.setParameter("FOLIO", folio);
            return query.list();            
        } catch (HibernateException e){
			return Collections.<ProgramaColocacionDto>emptyList();
        }
    }
    
    @Override
	public boolean insertaVerificacionColocacion(VerificacionColocacionDto colocacion) {
		Session session = getSession();
        try{
            Query query = session.getNamedQuery(INSERTA_VERIFICACION_COL)
                    .setString(0, colocacion.getAreaPiso())
                    .setString(1, colocacion.getEspacioLineal())
                    .setString(2, colocacion.getRevisionPiso())
                    .setString(3, colocacion.getRevisionTorre())
                    .setString(4, colocacion.getIdFolio());
            query.executeUpdate();
            return true;
        } catch (HibernateException error){
            System.err.println("Colocacion:insertaVerificacionColocacion: "+error);
            return false;
        }
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<VerificacionColocacionDto> consultaListaVerificacion(String folio) {
		try {
			 Session session = getSession();
			 StringBuilder sql= new StringBuilder();
			 sql.append("SELECT ID_VERIFICACION_COLOCACION AS \"idVerificacionColocacion\", ")
			 .append("OBSERVACIONES_VERIFICACION AS \"observacionesVerificacion\", ")
			 .append("AREA_PISO AS \"areaPiso\", ESPACIO_LINEAL AS \"espacioLineal\", ")
			 .append("REVISION_PISO AS \"revisionPiso\", REVISION_TORRE AS \"revisionTorre\", ")
			 .append("FECHA_CREACION AS \"fechaCreacion\", ID_FOLIO AS \"idFolio\" ")
		     .append("FROM BDDSEG01.T3SEGO_VERI_COLO ")
		     .append("WHERE ID_FOLIO = :folio");
		     Query query= session.createSQLQuery(sql.toString())
		        		.addScalar("idVerificacionColocacion",StandardBasicTypes.STRING)
		        		.addScalar("observacionesVerificacion",StandardBasicTypes.STRING)
		        		.addScalar("areaPiso",StandardBasicTypes.STRING)
		        		.addScalar("espacioLineal",StandardBasicTypes.STRING)
		        		.addScalar("revisionPiso",StandardBasicTypes.STRING)
		        		.addScalar("revisionTorre",StandardBasicTypes.STRING)
		        		.addScalar("fechaCreacion",StandardBasicTypes.STRING)
		        		.addScalar("idFolio",StandardBasicTypes.STRING)
		        		.setResultTransformer(Transformers.aliasToBean(VerificacionColocacionDto.class));
			 query.setParameter("folio", folio);
			 return query.list();
		} catch (Exception e) {
			System.err.println("Colocacion:consultaListaVerificacion: " + e);
			return Collections.<VerificacionColocacionDto>emptyList();
		}
	}

	@Override
	public int consultaEstadoBitacora(String folio, String estatus) {
		Session session = getSession();
        try{
            String sentencia = "SELECT COUNT(*) FROM BDDSEG01.T3SEGO_BITA \n" + 
            		"WHERE ID_ESTATUS_FLUJO IN(SELECT ID_ESTADO_SOLI \n" + 
            		"FROM BDDSEG01.T3SEGC_ESTA_SOLI WHERE UPPER(DESCRIPCION) = :ESTADO)\n" + 
            		"AND ID_SOLICITUD = :FOLIO\n";
                                
            Query query = session.createSQLQuery(sentencia);
            query.setParameter("FOLIO", folio);
            query.setParameter("ESTADO", estatus);
            String variable = query.list().get(0).toString();
    		return Integer.parseInt(variable);
        }catch(HibernateException e){
            return 0;
        }
	}

	@Override
	public boolean updateVerificacionColocacion(VerificacionColocacionDto colocacion) {
		boolean indicador;
		try {
			Session session = getSession();
			Query query = session.getNamedQuery(ACTUALIZA_VERIFICACION_COL)
					.setString(0, colocacion.getObservacionesVerificacion())
					.setString(1, colocacion.getIdFolio());
			query.executeUpdate();
			indicador = true;
		} catch (Exception e) {
			indicador = false;
		}
		return indicador;
	}

	@Override
	public boolean corregirVerificacionColocacion(VerificacionColocacionDto colocacion) {
		boolean indicador;
		try {
			Session session = getSession();
			Query query = session.getNamedQuery(CORRECCION_VERIFICACION_COL)
					.setString(0, colocacion.getAreaPiso())
					.setString(1, colocacion.getEspacioLineal())
					.setString(2, colocacion.getRevisionPiso())
					.setString(3, colocacion.getRevisionTorre())
					.setString(4, colocacion.getIdFolio());
			query.executeUpdate();
			indicador = true;
		} catch (Exception e) {
			indicador = false;
		}
		return indicador;
	}
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dao.impl;

import java.io.Serializable;
import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dao.IBitacoraSoxDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dto.BitacoraSoxDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.transformer.BitacoraSoxTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segbBita;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

/**
 * 
 * <h1>BitacoraSoxDaoImpl</h1>
 * <p>
 * </p>
 * 
 * @author chcastro
 * @version 1.0
 * @since 11/05/2015
 */
@Repository(value = "bitacoraSoxDao")
@Scope("prototype")
public class BitacoraSoxDaoImpl extends GenericFunctionDaoImpl implements
		IBitacoraSoxDao, Serializable {

	private static final long serialVersionUID = 116325373110679489L;

	private static final String SELECT_COUNT_BITACORA_BY_ID = "TsegcBitacoraSox.SELECT_COUNT_BITACORA_BY_ID";
	private static final String SELECT_COUNT_BITACORA = "TsegcBitacoraSox.SELECT_COUNT_BITACORA";
	private static final String SELECT_BITACORA_BY_ID = "TsegcBitacoraSox.SELECT_BITACORA_BY_ID";
	private static final String SELECT_BITACORA = "TsegcBitacoraSox.SELECT_BITACORA";

	private static final Logger logger = LogManager.getLogger(BitacoraSoxDaoImpl.class);

	@Override
	public void createBitacoraSox(T7segbBita tsegcBitacoraSox) {
		logger.info("Ejecutando BitacoraSoxDaoImpl.createBitacoraSox");
		create(tsegcBitacoraSox);
	}

	@Override
	public Integer getNumberOfElements(Integer idUsuario) {
		logger.info("Ejecutando BitacoraSoxDaoImpl.getNumberOfPages");
		Session session = getSession();
		Query query = null;
		if (idUsuario != null) {
			query = session.getNamedQuery(SELECT_COUNT_BITACORA_BY_ID)
					.setInteger("idUsuario", idUsuario);
		} else {
			query = session.getNamedQuery(SELECT_COUNT_BITACORA);
		}

		return ((Long)query.uniqueResult()).intValue();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BitacoraSoxDto> getContentPage(Integer idUsuario,
			Integer sizePage, Integer pageNomber) {
		logger.info("Ejecutando BitacoraSoxDaoImpl.getContentPage");
		Session session = getSession();
		Query query = null;
		if (idUsuario != null) {
			query = session.getNamedQuery(SELECT_BITACORA_BY_ID)
					.setInteger("idUsuario", idUsuario);
		} else {
			query = session.getNamedQuery(SELECT_BITACORA);
		}
		query.setResultTransformer(new BitacoraSoxTransformer());
		query.setFirstResult((sizePage * (pageNomber - 1)));
		query.setMaxResults(sizePage);
		
		return query.list();
	}
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.proyecto.dto;

import java.io.Serializable;

public class ProyectoPresupuestoDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 9085840808713573905L;
	private String idProyecto;
	private String observacionesSolicitud;
	private String observacionesAtencion;
	private String motivoRechazo;
	private String observacionesAdecuacion;
	private String observacionesRecuperacion;
	private String fechaCreacion;
	private String idFolio;
	private String idTipoSolicitud;
	
	public ProyectoPresupuestoDto(String idProyecto, String observacionesSolicitud, String observacionesAtencion,
			String motivoRechazo, String observacionesAdecuacion, String observacionesRecuperacion,
			String fechaCreacion, String idFolio, String idTipoSolicitud) {
		super();
		this.idProyecto = idProyecto;
		this.observacionesSolicitud = observacionesSolicitud;
		this.observacionesAtencion = observacionesAtencion;
		this.motivoRechazo = motivoRechazo;
		this.observacionesAdecuacion = observacionesAdecuacion;
		this.observacionesRecuperacion = observacionesRecuperacion;
		this.fechaCreacion = fechaCreacion;
		this.idFolio = idFolio;
		this.idTipoSolicitud = idTipoSolicitud;
	}
		
	public ProyectoPresupuestoDto() {

	}

	/**
	 * @return the idProyecto
	 */
	public String getIdProyecto() {
		return idProyecto;
	}
	/**
	 * @param idProyecto the idProyecto to set
	 */
	public void setIdProyecto(String idProyecto) {
		this.idProyecto = idProyecto;
	}
	/**
	 * @return the observacionesSolicitud
	 */
	public String getObservacionesSolicitud() {
		return observacionesSolicitud;
	}
	/**
	 * @param observacionesSolicitud the observacionesSolicitud to set
	 */
	public void setObservacionesSolicitud(String observacionesSolicitud) {
		this.observacionesSolicitud = observacionesSolicitud;
	}
	/**
	 * @return the observacionesAtencion
	 */
	public String getObservacionesAtencion() {
		return observacionesAtencion;
	}
	/**
	 * @param observacionesAtencion the observacionesAtencion to set
	 */
	public void setObservacionesAtencion(String observacionesAtencion) {
		this.observacionesAtencion = observacionesAtencion;
	}
	/**
	 * @return the motivoRechazo
	 */
	public String getMotivoRechazo() {
		return motivoRechazo;
	}
	/**
	 * @param motivoRechazo the motivoRechazo to set
	 */
	public void setMotivoRechazo(String motivoRechazo) {
		this.motivoRechazo = motivoRechazo;
	}
	/**
	 * @return the observacionesAdecuacion
	 */
	public String getObservacionesAdecuacion() {
		return observacionesAdecuacion;
	}
	/**
	 * @param observacionesAdecuacion the observacionesAdecuacion to set
	 */
	public void setObservacionesAdecuacion(String observacionesAdecuacion) {
		this.observacionesAdecuacion = observacionesAdecuacion;
	}
	/**
	 * @return the observacionesRecuperacion
	 */
	public String getObservacionesRecuperacion() {
		return observacionesRecuperacion;
	}
	/**
	 * @param observacionesRecuperacion the observacionesRecuperacion to set
	 */
	public void setObservacionesRecuperacion(String observacionesRecuperacion) {
		this.observacionesRecuperacion = observacionesRecuperacion;
	}
	/**
	 * @return the fechaCreacion
	 */
	public String getFechaCreacion() {
		return fechaCreacion;
	}
	/**
	 * @param fechaCreacion the fechaCreacion to set
	 */
	public void setFechaCreacion(String fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	/**
	 * @return the idFolio
	 */
	public String getIdFolio() {
		return idFolio;
	}
	/**
	 * @param idFolio the idFolio to set
	 */
	public void setIdFolio(String idFolio) {
		this.idFolio = idFolio;
	}
	/**
	 * @return the idTipoSolicitud
	 */
	public String getIdTipoSolicitud() {
		return idTipoSolicitud;
	}
	/**
	 * @param idTipoSolicitud the idTipoSolicitud to set
	 */
	public void setIdTipoSolicitud(String idTipoSolicitud) {
		this.idTipoSolicitud = idTipoSolicitud;
	}
	
}

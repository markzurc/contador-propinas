package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


/**
 * 
 * <h1>TsegrAplicaionAcl</h1>
 * <p>
 * Class for mapping the table "TsegrAplicaionAcl" of database.
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 27/03/2015
 *
 */
@Entity
@Table(name = "TSEGR_APLICAION_ACL",  schema="BDDOVI01" )
public class TsegrAplicaionAcl implements java.io.Serializable {

	private static final long serialVersionUID = 639197060080304601L;
	private static final Logger logger = LogManager.getLogger(TsegrAplicaionAcl.class.getName());
	private Integer idComponente;
	private String flujo;
	private Integer idPadre;
	private String nombre;
	private String descripcion;
	private Integer idTipoComponente;
	private Integer idAplicacion;
	private Integer nivel;

        public TsegrAplicaionAcl() {
            logger.info("TSEGR_APLICATION_ACL");
	}
	public TsegrAplicaionAcl(Integer idComponente,
			Integer idAplicacion) {
		this.idComponente = idComponente;
		this.idAplicacion = idAplicacion;
	}

	public TsegrAplicaionAcl(Integer idComponente,
			Integer idAplicacion, String flujo, Integer idPadre,
			String nombre, String descripcion, Integer idTipoComponente) {
		this.idComponente = idComponente;
		this.idAplicacion = idAplicacion;
		this.flujo = flujo;
		this.idPadre = idPadre;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.idTipoComponente = idTipoComponente;
	}

	@Id
	@Column(name = "COMPONENTE", unique = true, nullable = false, precision = 22, scale = 0)
	public Integer getIdComponente() {
		return this.idComponente;
	}

	public void setIdComponente(Integer idComponente) {
		this.idComponente = idComponente;
	}

	@Column(name = "APLICACION", nullable = false)
	public Integer getIdAplicacion() {
		return this.idAplicacion;
	}

	public void setIdAplicacion(Integer idAplicacion) {
		this.idAplicacion = idAplicacion;
	}

	@Column(name = "FLUJO", length = 45)
	public String getFlujo() {
		return this.flujo;
	}

	public void setFlujo(String flujo) {
		this.flujo = flujo;
	}

	@Column(name = "PADRE", precision = 22, scale = 0)
	public Integer getIdPadre() {
		return this.idPadre;
	}

	public void setIdPadre(Integer idPadre) {
		this.idPadre = idPadre;
	}

	@Column(name = "NOMBRE", length = 20)
	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "DESCRIPCION", length = 45)
	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Column(name = "TIPO_COMPONENTE", length = 20)
	public Integer getTipo() {
		return this.idTipoComponente;
	}

	public void setTipo(Integer idTipoComponente) {
		this.idTipoComponente = idTipoComponente;
	}
	
	@Column(name = "NIVEL", precision = 22, scale = 0)
	public Integer getNivel() {
		return this.nivel;
	}

	public void setNivel(Integer nivel) {
		this.nivel = nivel;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idAplicacion == null) ? 0 : idAplicacion.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		TsegrAplicaionAcl other = (TsegrAplicaionAcl) obj;
		if (idAplicacion == null) {
			if (other.idAplicacion != null){
				return false;
			}
		} else if (!idAplicacion.equals(other.idAplicacion)){
			return false;
		}
		return true;
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * 
 * 
 * <h1>T7segbHistPass</h1>
 * <p>
 * </p>
 * 
 * @author chcastro
 * @version 1.0
 * @since 21/05/2015
 */
@Entity
@Table(name = "T3SEGB_HIST_PASS",  schema="BDDSEG01")
public class T7segbHistPass implements java.io.Serializable {

	private static final long serialVersionUID = -3362261537271658446L;
	private TsegcHistoricopasswordId id;

	public T7segbHistPass() {
	}

	public T7segbHistPass(TsegcHistoricopasswordId id) {
		this.id = id;
	}

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "idUsuario", column = @Column(name = "USUARIO", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "password", column = @Column(name = "PASSWORD", length = 45)),
			@AttributeOverride(name = "fechaCambioPassword", column = @Column(name = "FECHA_CAMBIO_PASSWORD")),
			@AttributeOverride(name = "idMotivo", column = @Column(name = "MOTIVO", nullable = false, precision = 22, scale = 0)) })
	public TsegcHistoricopasswordId getId() {
		return this.id;
	}

	public void setId(TsegcHistoricopasswordId id) {
		this.id = id;
	}

}

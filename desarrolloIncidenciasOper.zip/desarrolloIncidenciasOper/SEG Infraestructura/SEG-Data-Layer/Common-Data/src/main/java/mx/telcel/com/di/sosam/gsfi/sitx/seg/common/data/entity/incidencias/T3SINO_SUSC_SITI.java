package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias;

import java.io.Serializable;
import java.time.LocalDateTime;
import javax.persistence.*;

@Entity
@Table(name = "T3SINO_SUSC_SITI", schema = "BDDSEG01")
public class T3SINO_SUSC_SITI implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID_SUSC", nullable = false)
	private Long id;

	@Column(name = "CONC_ID", nullable = false, length = 50)
	private String idConcesionario;

	@Column(name = "ID_SITIO", nullable = false, length = 30)
	private String idSitio;

	@Column(name = "ACTIVO", nullable = false, length = 1)
	private String activo = "S";

	@Column(name = "USU_ALTA", nullable = false, length = 60)
	private String usuarioAlta;

	@Column(name = "FEC_ALTA", nullable = false)
	private LocalDateTime fechaAlta;

	@Column(name = "USU_BAJA", length = 60)
	private String usuarioBaja;

	@Column(name = "FEC_BAJA")
	private LocalDateTime fechaBaja;

	@PrePersist
	private void prePersist() {
		if (activo == null)
			activo = "S";
		if (fechaAlta == null)
			fechaAlta = LocalDateTime.now();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getIdConcesionario() {
		return idConcesionario;
	}

	public void setIdConcesionario(String idConcesionario) {
		this.idConcesionario = idConcesionario;
	}

	public String getIdSitio() {
		return idSitio;
	}

	public void setIdSitio(String idSitio) {
		this.idSitio = idSitio;
	}

	public String getActivo() {
		return activo;
	}

	public void setActivo(String activo) {
		this.activo = activo;
	}

	public String getUsuarioAlta() {
		return usuarioAlta;
	}

	public void setUsuarioAlta(String usuarioAlta) {
		this.usuarioAlta = usuarioAlta;
	}

	public LocalDateTime getFechaAlta() {
		return fechaAlta;
	}

	public void setFechaAlta(LocalDateTime fechaAlta) {
		this.fechaAlta = fechaAlta;
	}

	public String getUsuarioBaja() {
		return usuarioBaja;
	}

	public void setUsuarioBaja(String usuarioBaja) {
		this.usuarioBaja = usuarioBaja;
	}

	public LocalDateTime getFechaBaja() {
		return fechaBaja;
	}

	public void setFechaBaja(LocalDateTime fechaBaja) {
		this.fechaBaja = fechaBaja;
	}
}

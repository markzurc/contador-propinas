package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;

public class SolicitudDto implements Serializable {

	private static final long serialVersionUID = 7869211751497603247L;
	private String folio;
	private String sitio;
	private String nombre;
	private String concesionario;
	private String solicitante;
	private String latitud;
	private String longitud;
	private String fechaSol;
	private String estatus;
	private String pendiente;
	
	private String grupoOperador;
	private String usuario;
	private String idEstado;
	private String region;
	
	
	public SolicitudDto() {

	}
	
	public SolicitudDto(String folio, String sitio, String nombre, String concesionario, String solicitante,
			String latitud, String longitud, String fechaSol, String estatus, String grupoOperador, String usuario,
			String idEstado, String region) {
		super();
		this.folio = folio;
		this.sitio = sitio;
		this.nombre = nombre;
		this.concesionario = concesionario;
		this.solicitante = solicitante;
		this.latitud = latitud;
		this.longitud = longitud;
		this.fechaSol = fechaSol;
		this.estatus = estatus;
		this.grupoOperador = grupoOperador;
		this.usuario = usuario;
		this.idEstado = idEstado;
		this.region = region;
	}
	
	@XmlElement(nillable = true)
	public String getFolio() {
		return folio;
	}

	public void setFolio(String folio) {
		this.folio = folio;
	}

	@XmlElement(nillable = true)
	public String getSitio() {
		return sitio;
	}

	public void setSitio(String sitio) {
		this.sitio = sitio;
	}

	@XmlElement(nillable = true)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@XmlElement(nillable = true)
	public String getConcesionario() {
		return concesionario;
	}

	public void setConcesionario(String concesionario) {
		this.concesionario = concesionario;
	}
	
	@XmlElement(nillable = true)
	public String getSolicitante() {
		return solicitante;
	}

	public void setSolicitante(String solicitante) {
		this.solicitante = solicitante;
	}

	@XmlElement(nillable = true)
	public String getLatitud() {
		return latitud;
	}

	public void setLatitud(String latitud) {
		this.latitud = latitud;
	}

	@XmlElement(nillable = true)
	public String getLongitud() {
		return longitud;
	}

	public void setLongitud(String longitud) {
		this.longitud = longitud;
	}

	@XmlElement(nillable = true)
	public String getFechaSol() {
		return fechaSol;
	}

	public void setFechaSol(String fechaSol) {
		this.fechaSol = fechaSol;
	}

	@XmlElement(nillable = true)
	public String getEstatus() {
		return estatus;
	}

	public void setEstatus(String estatus) {
		this.estatus = estatus;
	}

	@XmlElement(nillable = true)
	public String getGrupoOperador() {
		return grupoOperador;
	}

	public void setGrupoOperador(String grupoOperador) {
		this.grupoOperador = grupoOperador;
	}

	@XmlElement(nillable = true)
	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	
	@XmlElement(nillable = true)
	public String getIdEstado() {
		return idEstado;
	}

	public void setIdEstado(String idEstado) {
		this.idEstado = idEstado;
	}

	@XmlElement(nillable = true)
	public String getRegion() {
		return region;
	}
	
	public void setRegion(String region) {
		this.region = region;
	}

	@XmlElement(nillable = true)
	public String getPendiente() {
		return pendiente;
	}

	public void setPendiente(String pendiente) {
		this.pendiente = pendiente;
	}
}

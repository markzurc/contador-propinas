package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * <h1>T7allcNoti</h1>
 * <p>
 * Class for mapping the table "T7allcNoti" of database.
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 04/05/2015
 *
 */
@Entity
@Table(name = "T7ALLC_NOTI",  schema="BDDOVI01")
public class T7allcNoti implements java.io.Serializable {

	private static final long serialVersionUID = 7650599446956993748L;
	private Integer notificacion;
	private String nombreCorreo;
	private String valor;
	private String asunto;

	public T7allcNoti() {
	}

	public T7allcNoti(Integer notificacion) {
		this.notificacion = notificacion;
	}

	public T7allcNoti(Integer notificacion, String nombreCorreo,
			String valor, String asunto) {
		this.notificacion = notificacion;
		this.nombreCorreo = nombreCorreo;
		this.valor = valor;
		this.asunto = asunto;
	}

	@Id
	@Column(name = "NOTIFICACION", unique = true, nullable = false, precision = 22, scale = 0)
	public Integer getIdCorreo() {
		return this.notificacion;
	}

	public void setIdCorreo(Integer notificacion) {
		this.notificacion = notificacion;
	}

	@Column(name = "NOMBRE_CORREO", length = 45)
	public String getNombreCorreo() {
		return this.nombreCorreo;
	}

	public void setNombreCorreo(String nombreCorreo) {
		this.nombreCorreo = nombreCorreo;
	}

	@Column(name = "VALOR", length = 512)
	public String getValor() {
		return this.valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	@Column(name = "ASUNTO", length = 45)
	public String getAsunto() {
		return this.asunto;
	}

	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}

}

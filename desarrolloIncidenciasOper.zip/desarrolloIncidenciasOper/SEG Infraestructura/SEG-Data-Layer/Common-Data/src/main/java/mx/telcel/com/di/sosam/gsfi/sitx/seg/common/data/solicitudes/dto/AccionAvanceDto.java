package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dto;

import java.io.Serializable;

public class AccionAvanceDto implements Serializable {
	
	private static final long serialVersionUID = -6272628604679992129L;
	private int accion;
	private String descripcion;
	
	/**
	 * @return the accion
	 */
	public int getAccion() {
		return accion;
	}
	
	/**
	 * @param accion the accion to set
	 */
	public void setAccion(int accion) {
		this.accion = accion;
	}
	
	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}
	
	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	

//	public ServicioDto() {
//
//	}
	
	@Override
	public String toString() {
		return "ServicioDto [accion=" + accion + ", descripcion=" + descripcion + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((descripcion == null) ? 0 : descripcion.hashCode());
		result = prime * result + accion;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccionAvanceDto other = (AccionAvanceDto) obj;
		if (descripcion == null) {
			if (other.descripcion != null)
				return false;
		} else if (!descripcion.equals(other.descripcion))
			return false;
		if (accion != other.accion)
			return false;
		return true;
	}
	
}

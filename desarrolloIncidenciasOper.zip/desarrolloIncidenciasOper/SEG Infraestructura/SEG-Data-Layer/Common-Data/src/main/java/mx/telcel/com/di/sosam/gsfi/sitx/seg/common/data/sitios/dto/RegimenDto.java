package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto;

import java.io.Serializable;

public class RegimenDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2359353414675854L;
	private String idRegion;
	private String descripcion;
	private String estatus;
		
	public RegimenDto(String idRegion, String descripcion, String estatus) {
		super();
		this.idRegion = idRegion;
		this.descripcion = descripcion;
		this.estatus = estatus;
	}
		
	public RegimenDto() {

	}

	/**
	 * @return the idRegion
	 */
	public String getIdRegion() {
		return idRegion;
	}
	
	/**
	 * @param idRegion the idRegion to set
	 */
	public void setIdRegion(String idRegion) {
		this.idRegion = idRegion;
	}
	
	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}
	
	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	/**
	 * @return the estatus
	 */
	public String getEstatus() {
		return estatus;
	}
	
	/**
	 * @param estatus the estatus to set
	 */
	public void setEstatus(String estatus) {
		this.estatus = estatus;
	}
	
	
	
	

	
}

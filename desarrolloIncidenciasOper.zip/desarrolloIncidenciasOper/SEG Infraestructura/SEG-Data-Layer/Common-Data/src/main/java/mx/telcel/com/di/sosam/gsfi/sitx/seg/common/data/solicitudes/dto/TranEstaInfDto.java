package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dto;

import java.io.Serializable;

public class TranEstaInfDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5816053035982158338L;
	private int idEstatusActual;
	private int idEstatusSiguiente;
	private String idAccion;
	private String descripcion;
	private String flujo;
	private String estatusSiguiente;
	
	public TranEstaInfDto() {

	}
	
	public TranEstaInfDto(int idEstatusActual, int idEstatusSiguiente,String idAccion, String descripcion, String flujo, String estatusSiguiente) {
		super();
		this.idEstatusActual = idEstatusActual;
		this.idEstatusSiguiente = idEstatusSiguiente;
		this.idAccion = idAccion;
		this.descripcion = descripcion;
		this.flujo = flujo;
		this.estatusSiguiente = estatusSiguiente;
	}

	public int getIdEstatusActual() {
		return idEstatusActual;
	}
	
	public void setIdEstatusActual(int idEstatusActual) {
		this.idEstatusActual = idEstatusActual;
	}
	
	public int getIdEstatusSiguiente() {
		return idEstatusSiguiente;
	}
	
	public void setIdEstatusSiguiente(int idEstatusSiguiente) {
		this.idEstatusSiguiente = idEstatusSiguiente;
	}
	
	public String getIdAccion() {
		return idAccion;
	}

	public void setIdAccion(String idAccion) {
		this.idAccion = idAccion;
	}

	public String getDescripcion() {
		return descripcion;
	}
	
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getFlujo() {
		return flujo;
	}

	public void setFlujo(String flujo) {
		this.flujo = flujo;
	}

	public String getEstatusSiguiente() {
		return estatusSiguiente;
	}

	public void setEstatusSiguiente(String estatusSiguiente) {
		this.estatusSiguiente = estatusSiguiente;
	}

}

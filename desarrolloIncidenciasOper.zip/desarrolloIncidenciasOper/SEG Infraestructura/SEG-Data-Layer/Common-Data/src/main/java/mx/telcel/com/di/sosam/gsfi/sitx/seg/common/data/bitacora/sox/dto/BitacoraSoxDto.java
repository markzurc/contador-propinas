package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * 
 * <h1>BitacoraSoxDto</h1>
 * <p>
 * </p>
 * 
 * @author chcastro
 * @version 1.0
 * @since 30/06/2015
 */
public class BitacoraSoxDto implements Serializable {

	private static final long serialVersionUID = -2640446722779677528L;
	
	private Integer idBitacora;
	private Integer idUsuario;
	private String numeroEmpleado;
	private String folioSua;
	private Date fechaOperacion;
	private String objetoInicial;
	private String objetoFinal;
	private Integer idAccion;
	private String accionDescripcion;
	
	public BitacoraSoxDto() {
	}

	/**
	 * @param idBitacora
	 * @param idUsuario
	 * @param numeroEmpleado
	 * @param folioSua
	 * @param fechaOperacion
	 * @param objetoInicial
	 * @param objetoFinal
	 * @param idAccion
	 * @param accionDescripcion
	 */
	public BitacoraSoxDto(Integer idBitacora, Integer idUsuario,
			String numeroEmpleado, String folioSua, Date fechaOperacion,
			String objetoInicial, String objetoFinal, Integer idAccion,
			String accionDescripcion) {
		super();
		this.idBitacora = idBitacora;
		this.idUsuario = idUsuario;
		this.numeroEmpleado = numeroEmpleado;
		this.folioSua = folioSua;
		this.fechaOperacion = fechaOperacion;
		this.objetoInicial = objetoInicial;
		this.objetoFinal = objetoFinal;
		this.idAccion = idAccion;
		this.accionDescripcion = accionDescripcion;
	}

	/**
	 * @return the idBitacora
	 */
	public Integer getIdBitacora() {
		return idBitacora;
	}

	/**
	 * @param idBitacora the idBitacora to set
	 */
	public void setIdBitacora(Integer idBitacora) {
		this.idBitacora = idBitacora;
	}

	/**
	 * @return the idUsuario
	 */
	public Integer getIdUsuario() {
		return idUsuario;
	}

	/**
	 * @param idUsuario the idUsuario to set
	 */
	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	/**
	 * @return the numeroEmpleado
	 */
	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}

	/**
	 * @param numeroEmpleado the numeroEmpleado to set
	 */
	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	/**
	 * @return the folioSua
	 */
	public String getFolioSua() {
		return folioSua;
	}

	/**
	 * @param folioSua the folioSua to set
	 */
	public void setFolioSua(String folioSua) {
		this.folioSua = folioSua;
	}

	/**
	 * @return the fechaOperacion
	 */
	public Date getFechaOperacion() {
		return fechaOperacion;
	}

	/**
	 * @param fechaOperacion the fechaOperacion to set
	 */
	public void setFechaOperacion(Date fechaOperacion) {
		this.fechaOperacion = fechaOperacion;
	}

	/**
	 * @return the objetoInicial
	 */
	public String getObjetoInicial() {
		return objetoInicial;
	}

	/**
	 * @param objetoInicial the objetoInicial to set
	 */
	public void setObjetoInicial(String objetoInicial) {
		this.objetoInicial = objetoInicial;
	}

	/**
	 * @return the objetoFinal
	 */
	public String getObjetoFinal() {
		return objetoFinal;
	}

	/**
	 * @param objetoFinal the objetoFinal to set
	 */
	public void setObjetoFinal(String objetoFinal) {
		this.objetoFinal = objetoFinal;
	}

	/**
	 * @return the idAccion
	 */
	public Integer getIdAccion() {
		return idAccion;
	}

	/**
	 * @param idAccion the idAccion to set
	 */
	public void setIdAccion(Integer idAccion) {
		this.idAccion = idAccion;
	}

	/**
	 * @return the accionDescripcion
	 */
	public String getAccionDescripcion() {
		return accionDescripcion;
	}

	/**
	 * @param accionDescripcion the accionDescripcion to set
	 */
	public void setAccionDescripcion(String accionDescripcion) {
		this.accionDescripcion = accionDescripcion;
	}

}

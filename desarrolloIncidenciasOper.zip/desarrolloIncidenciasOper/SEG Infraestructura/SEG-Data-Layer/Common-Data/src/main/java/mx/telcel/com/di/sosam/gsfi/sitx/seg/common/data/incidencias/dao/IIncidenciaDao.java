package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.T3SINO_INCI;

public interface IIncidenciaDao {

	
	Long obtenerSiguienteId();

	void persist(T3SINO_INCI incidencia);

	T3SINO_INCI merge(T3SINO_INCI incidencia);

	T3SINO_INCI findById(Long idIncidencia);

	T3SINO_INCI findByFolio(String folioIncidencia);

	List<T3SINO_INCI> findAll();

	List<T3SINO_INCI> findAllByConcesionario(String idConcesionario);

	List<T3SINO_INCI> findBySitioAndEstatus(String idSitio, String estatus);

	T3SINO_INCI findBySitioAndConcesionario(String idSitio, String idConcesionario);

	String obtenerCorreoExternoPorUsuario(Integer idUsuario, Integer idRol);
	
	String obtenerNombreCompletoUsuarioPorId(Integer idUsuario);
}

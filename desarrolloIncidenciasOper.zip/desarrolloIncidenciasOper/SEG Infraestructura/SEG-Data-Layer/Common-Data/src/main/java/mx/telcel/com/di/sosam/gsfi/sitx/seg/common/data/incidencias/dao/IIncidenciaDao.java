package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.Incidencia;

public interface IIncidenciaDao {

	/**
	 * Obtiene el siguiente ID disponible para la tabla de incidencias (sin
	 * secuencias).
	 */
	Long obtenerSiguienteId();

	void persist(Incidencia incidencia);

	Incidencia merge(Incidencia incidencia);

	Incidencia findById(Long idIncidencia);

	Incidencia findByFolio(String folioIncidencia);

	List<Incidencia> findAll();

	List<Incidencia> findAllByConcesionario(String idConcesionario);

	List<Incidencia> findBySitioAndEstatus(String idSitio, String estatus);

	Incidencia findBySitioAndConcesionario(String idSitio, String idConcesionario);

	String obtenerCorreoExternoPorUsuario(Integer idUsuario, Integer idRol);
	
	String obtenerNombreCompletoUsuarioPorId(Integer idUsuario);
}

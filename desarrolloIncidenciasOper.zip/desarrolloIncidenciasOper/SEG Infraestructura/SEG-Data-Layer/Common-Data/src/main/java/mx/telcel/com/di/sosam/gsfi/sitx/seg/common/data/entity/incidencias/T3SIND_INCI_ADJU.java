package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "T3SIND_INCI_ADJU", schema = "BDDSEG01")
public class T3SIND_INCI_ADJU implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID_ADJU", nullable = false)
	private Long idAdjunto;

	@Column(name = "ID_INCI", nullable = false)
	private Long idIncidencia;

	@Column(name = "NOM_ARCH", nullable = false, length = 255)
	private String nombreArchivo;

	@Column(name = "RUTA_ARCH", nullable = false, length = 400)
	private String rutaArchivo;

	@Column(name = "EXT_ARCH", nullable = false, length = 10)
	private String extensionArchivo;

	@Column(name = "TAM_BYTES", nullable = false)
	private Long tamanioBytes;

	@Column(name = "ACTIVO", nullable = false, length = 1)
	private String activo;

	@Column(name = "USU_ALTA", nullable = false, length = 60)
	private String usuarioAlta;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FEC_ALTA", nullable = false)
	private Date fechaAlta;

	@Column(name = "USU_BAJA", length = 60)
	private String usuarioBaja;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FEC_BAJA")
	private Date fechaBaja;

	public Long getIdAdjunto() {
		return idAdjunto;
	}

	public void setIdAdjunto(Long idAdjunto) {
		this.idAdjunto = idAdjunto;
	}

	public Long getIdIncidencia() {
		return idIncidencia;
	}

	public void setIdIncidencia(Long idIncidencia) {
		this.idIncidencia = idIncidencia;
	}

	public String getNombreArchivo() {
		return nombreArchivo;
	}

	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}

	public String getRutaArchivo() {
		return rutaArchivo;
	}

	public void setRutaArchivo(String rutaArchivo) {
		this.rutaArchivo = rutaArchivo;
	}

	public String getExtensionArchivo() {
		return extensionArchivo;
	}

	public void setExtensionArchivo(String extensionArchivo) {
		this.extensionArchivo = extensionArchivo;
	}

	public Long getTamanioBytes() {
		return tamanioBytes;
	}

	public void setTamanioBytes(Long tamanioBytes) {
		this.tamanioBytes = tamanioBytes;
	}

	public String getActivo() {
		return activo;
	}

	public void setActivo(String activo) {
		this.activo = activo;
	}

	public String getUsuarioAlta() {
		return usuarioAlta;
	}

	public void setUsuarioAlta(String usuarioAlta) {
		this.usuarioAlta = usuarioAlta;
	}

	public Date getFechaAlta() {
		return fechaAlta;
	}

	public void setFechaAlta(Date fechaAlta) {
		this.fechaAlta = fechaAlta;
	}

	public String getUsuarioBaja() {
		return usuarioBaja;
	}

	public void setUsuarioBaja(String usuarioBaja) {
		this.usuarioBaja = usuarioBaja;
	}

	public Date getFechaBaja() {
		return fechaBaja;
	}

	public void setFechaBaja(Date fechaBaja) {
		this.fechaBaja = fechaBaja;
	}

	public boolean isActivo() {
		return activo != null && "S".equalsIgnoreCase(activo);
	}
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.proyecto.dao;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegdSoliArch;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.proyecto.dto.ProyectoPresupuestoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.proyecto.dto.TipoSolicitudDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SoliArchDto;

public interface IProyectoPresupuestoDao {

	List<SoliArchDto> getArchivos(String folio, String tipoArchivo);

	boolean crearProyectoPresupuesto(ProyectoPresupuestoDto proyecto);

	boolean updateEstadoSolicitud(String folio, String estatus);

	boolean guardarArchivo(T3SegdSoliArch archivo);

	List<ProyectoPresupuestoDto> getDatosProyectoPorFolio(String folio);

	boolean atenderProyectoPresupuesto(ProyectoPresupuestoDto proyecto);

	boolean rechazarProyectoPresupuesto(ProyectoPresupuestoDto proyecto);

	boolean corregirProyectoPresupuesto(ProyectoPresupuestoDto proyecto);

	boolean eliminarArchivo(SoliArchDto archivo);

	List<TipoSolicitudDto> getDatosTipoSolicitud();

	boolean solicitarAdecuacionRecuperacion(ProyectoPresupuestoDto proyecto);

	String consultaIdEstadoBitacora(String folio);

}

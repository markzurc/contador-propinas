package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.proyecto.dto;

import java.io.Serializable;

public class TipoSolicitudDto implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6074510408590754024L;
	private String idTipoSolicitud;
	private String descripcion;
	
	public String getIdTipoSolicitud() {
		return idTipoSolicitud;
	}

	public void setIdTipoSolicitud(String idTipoSolicitud) {
		this.idTipoSolicitud = idTipoSolicitud;
	}

	public String getDescripcion() {
		return descripcion;
	}
	
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public TipoSolicitudDto() {
	
	}
	
	public TipoSolicitudDto(String idTipoSolicitud, String descripcion) {
		super();
		this.idTipoSolicitud = idTipoSolicitud;
		this.descripcion = descripcion;
	}

	@Override
	public String toString() {
		return "TipoSolicitudDto [idTipoSolicitud=" + idTipoSolicitud + ", descripcion=" + descripcion + "]";
	}

}

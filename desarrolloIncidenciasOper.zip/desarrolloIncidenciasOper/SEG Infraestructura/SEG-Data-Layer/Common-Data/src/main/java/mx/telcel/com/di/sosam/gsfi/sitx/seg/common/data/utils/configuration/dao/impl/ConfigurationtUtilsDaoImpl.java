package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.utils.configuration.dao.impl;

import java.io.Serializable;
import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcPara;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.utils.configuration.dao.IConfigurationUtilsDao;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

/**
 * 
 * <h1>ConstantUtilsDaoImpl</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 17/04/2015
 *
 */

@Repository(value="configurationtUtilsDao")
@Scope("prototype")
public class ConfigurationtUtilsDaoImpl extends GenericFunctionDaoImpl implements
		IConfigurationUtilsDao, Serializable {

	private static final long serialVersionUID = -1742575697984313270L;

	@Override
	public List<T7segcPara> getConstantOfDataBase() {
		return findByExample(new T7segcPara());
	}

	@Override
	public void updateConfiguration(T7segcPara tsegcConfiguracion) {
		update(tsegcConfiguracion);
	}

}

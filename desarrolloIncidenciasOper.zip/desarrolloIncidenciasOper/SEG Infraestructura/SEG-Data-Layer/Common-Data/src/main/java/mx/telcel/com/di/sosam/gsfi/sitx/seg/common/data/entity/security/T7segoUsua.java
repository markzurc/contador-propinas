package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * <h1>T7segoUsua</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 15/05/2015
 */
@Entity
@Table(name = "T3SEGO_USUA",  schema="BDDSEG01")
public class T7segoUsua implements java.io.Serializable {
	
	private static final long serialVersionUID = -1849461423972779317L;
	private Integer usuario;
	private String nombre;
	private String apellidoPaterno;
	private String apellidoMaterno;
	private String rfc;
	private Integer tipoUsuario;
	private Integer estatus;
	private Date fechaLogueo;
	private T7segcRol tsegcRol;
	private Date fechaCreacion;
	private String usuarioCreacion;
	private Date fechaModificacion;
	private String usuarioModificacion;

	public T7segoUsua() {
	}

	/**
	 * @param usuario
	 */
	public T7segoUsua(Integer usuario) {
		super();
		this.usuario = usuario;
	}

	/**
	 * @param usuario
	 * @param nombre
	 * @param apellidoPaterno
	 * @param apellidoMaterno
	 * @param rfc
	 * @param tipoUsuario
	 * @param estatus
	 * @param fechaLogueo
	 * @param tsegcRol
	 * @param fechaCreacion
	 * @param usuarioCreacion
	 * @param fechaModificacion
	 * @param usuarioModificacion
	 */
	public T7segoUsua(Integer usuario, String nombre,
			String apellidoPaterno, String apellidoMaterno, String rfc,
			Integer tipoUsuario, Integer estatus, Date fechaLogueo,
			T7segcRol tsegcRol, Date fechaCreacion,
			String usuarioCreacion, Date fechaModificacion,
			String usuarioModificacion) {
		super();
		this.usuario = usuario;
		this.nombre = nombre;
		this.apellidoPaterno = apellidoPaterno;
		this.apellidoMaterno = apellidoMaterno;
		this.rfc = rfc;
		this.tipoUsuario = tipoUsuario;
		this.estatus = estatus;
		this.fechaLogueo = fechaLogueo!=null?(Date)fechaLogueo.clone():null;
		this.tsegcRol = tsegcRol;
		this.fechaCreacion = fechaCreacion!=null?(Date)fechaCreacion.clone():null;
		this.usuarioCreacion = usuarioCreacion;
		this.fechaModificacion = fechaModificacion!=null?(Date)fechaModificacion.clone():null;
		this.usuarioModificacion = usuarioModificacion;
	}



	@Id
	@Column(name = "USUARIO", unique = true, nullable = false, precision = 22, scale = 0)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQ7SEGO_USUA")
	@SequenceGenerator(name = "SQ7SEGO_USUA", sequenceName = "BDDSEG01.SQ7SEGO_USUA",schema="BDDSEG01", allocationSize = 1)
	public Integer getIdUsuario() {
		return this.usuario;
	}

	public void setIdUsuario(Integer usuario) {
		this.usuario = usuario;
	}

	@Column(name = "NOMBRE", length = 250)
	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "APELLIDO_PATERNO", length = 250)
	public String getApellidoPaterno() {
		return this.apellidoPaterno;
	}

	public void setApellidoPaterno(String apellidoPaterno) {
		this.apellidoPaterno = apellidoPaterno;
	}

	@Column(name = "APELLIDO_MATERNO", length = 250)
	public String getApellidoMaterno() {
		return this.apellidoMaterno;
	}

	public void setApellidoMaterno(String apellidoMaterno) {
		this.apellidoMaterno = apellidoMaterno;
	}

	@Column(name = "RFC", length = 13)
	public String getRfc() {
		return this.rfc;
	}

	public void setRfc(String rfc) {
		this.rfc = rfc;
	}

	@Column(name = "TIPO_USUARIO", nullable = false, precision = 22, scale = 0)
	public Integer getIdTipoUsuario() {
		return this.tipoUsuario;
	}

	public void setIdTipoUsuario(Integer tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}

	@Column(name = "ESTATUS", nullable = false, precision = 22, scale = 0)
	public Integer getIdEstatus() {
		return this.estatus;
	}

	public void setIdEstatus(Integer estatus) {
		this.estatus = estatus;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECHA_LOGUEO", length = 7)
	public Date getFechaLogueo() {
		return fechaLogueo!=null?(Date)fechaLogueo.clone():null;
	}

	public void setFechaLogueo(Date fechaLogueo) {
		this.fechaLogueo = fechaLogueo!=null?(Date)fechaLogueo.clone():null;
	}

	@OneToOne(fetch = FetchType.LAZY)
	@JoinTable(name = "T3SEGR_CROL_CUSUA",  schema="BDDSEG01" , joinColumns = { @JoinColumn(name = "USUARIO", nullable = false, updatable = true) }, inverseJoinColumns = { @JoinColumn(name = "ROL", nullable = false, updatable = true) })
	public T7segcRol getTsegcRol() {
		return this.tsegcRol;
	}

	public void setTsegcRol(T7segcRol tsegcRol) {
		this.tsegcRol = tsegcRol;
	}

	@Column(name = "FECHA_CREACION", nullable = false)
	public Date getFechaCreacion() {
		return fechaCreacion!=null?(Date)fechaCreacion.clone():null;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion!=null?(Date)fechaCreacion.clone():null;
	}

	@Column(name = "USUARIO_CREACION", nullable = false, length = 15)
	public String getUsuarioCreacion() {
		return this.usuarioCreacion;
	}

	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	@Column(name = "FECHA_MODIFICACION")
	public Date getFechaModificacion() {
		return fechaModificacion!=null?(Date)fechaModificacion.clone():null;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion!=null?(Date)fechaModificacion.clone():null;
	}

	@Column(name = "USUARIO_MODIFICACION", length = 15)
	public String getUsuarioModificacion() {
		return this.usuarioModificacion;
	}

	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((usuario == null) ? 0 : usuario.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		T7segoUsua other = (T7segoUsua) obj;
		if (usuario == null) {
			if (other.usuario != null){
				return false;
			}
		} else if (!usuario.equals(other.usuario)){
			return false;
		}
		return true;
	}
	
	
}

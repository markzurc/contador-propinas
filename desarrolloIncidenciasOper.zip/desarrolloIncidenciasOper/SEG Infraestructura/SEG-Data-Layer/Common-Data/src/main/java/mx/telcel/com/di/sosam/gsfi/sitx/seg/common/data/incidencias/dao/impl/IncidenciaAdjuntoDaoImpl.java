package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.impl;

import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.IncidenciaAdjunto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaAdjuntoDao;

@Repository
public class IncidenciaAdjuntoDaoImpl implements IIncidenciaAdjuntoDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void persist(IncidenciaAdjunto adj) {
        entityManager.persist(adj);
    }

    @Override
    public IncidenciaAdjunto merge(IncidenciaAdjunto entity) {
        if (entity == null) return null;
        return entityManager.merge(entity);
    }

    @Override
    public List<IncidenciaAdjunto> findByIncidencia(Long idIncidencia) {
        if (idIncidencia == null) return Collections.emptyList();

        TypedQuery<IncidenciaAdjunto> query = entityManager.createQuery(
                "SELECT a FROM IncidenciaAdjunto a " +
                "WHERE a.idIncidencia = :idIncidencia " +
                "AND a.activo = 'S' " +
                "ORDER BY a.fechaAlta DESC, a.idAdjunto DESC",
                IncidenciaAdjunto.class
        );
        query.setParameter("idIncidencia", idIncidencia);
        return query.getResultList();
    }

    @Override
    public IncidenciaAdjunto findActivoByIncidenciaAndNombre(Long idIncidencia, String nombreArchivo) {
        if (idIncidencia == null || nombreArchivo == null || nombreArchivo.trim().isEmpty()) return null;

        TypedQuery<IncidenciaAdjunto> query = entityManager.createQuery(
                "SELECT a FROM IncidenciaAdjunto a " +
                "WHERE a.idIncidencia = :idIncidencia " +
                "AND a.nombreArchivo = :nombreArchivo " +
                "AND a.activo = 'S'",
                IncidenciaAdjunto.class
        );
        query.setParameter("idIncidencia", idIncidencia);
        query.setParameter("nombreArchivo", nombreArchivo.trim());

        List<IncidenciaAdjunto> r = query.setMaxResults(1).getResultList();
        return r.isEmpty() ? null : r.get(0);
    }

    @Override
    public void remove(IncidenciaAdjunto entity) {
        if (entity == null) return;
        IncidenciaAdjunto managed = entityManager.contains(entity) ? entity : entityManager.merge(entity);
        entityManager.remove(managed);
    }
    
    @Override
    public Long obtenerSiguienteId() {
        try {
            // Consulta nativa segura para Oracle (NVL maneja el caso de tabla vac�a)
            String sql = "SELECT NVL(MAX(ID_ADJU), 0) + 1 FROM BDDSEG01.T3SIND_INCI_ADJU";
            Object resultado = entityManager.createNativeQuery(sql).getSingleResult();
            
            if (resultado != null) {
                return ((Number) resultado).longValue();
            }
            return 1L;
        } catch (Exception e) {
            // Si falla algo, retornamos null o lanzamos error, 
            // pero con Max+1 es raro que falle si la tabla existe.
            return 1L;
        }
    }
}

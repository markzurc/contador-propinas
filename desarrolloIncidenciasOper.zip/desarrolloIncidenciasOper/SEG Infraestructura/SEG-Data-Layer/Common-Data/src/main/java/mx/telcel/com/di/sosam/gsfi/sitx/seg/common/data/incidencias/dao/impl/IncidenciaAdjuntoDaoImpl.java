package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.impl;

import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.IncidenciaAdjunto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaAdjuntoDao;

public class IncidenciaAdjuntoDaoImpl implements IIncidenciaAdjuntoDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void persist(IncidenciaAdjunto adj) {
        entityManager.persist(adj);
    }

    @Override
    public List<IncidenciaAdjunto> findByIncidencia(Long idIncidencia) {
        if (idIncidencia == null) {
            return Collections.emptyList();
        }

        TypedQuery<IncidenciaAdjunto> q = entityManager.createQuery(
            "SELECT a " +
            "FROM IncidenciaAdjunto a " +
            "WHERE a.incidencia.id = :idIncidencia " +
            "ORDER BY a.id",
            IncidenciaAdjunto.class
        );
        q.setParameter("idIncidencia", idIncidencia);
        return q.getResultList();
    }

    @Override
    public void remove(IncidenciaAdjunto entity) {
        if (entity == null) {
            return;
        }
        IncidenciaAdjunto managed = entityManager.contains(entity)
                ? entity
                : entityManager.merge(entity);
        entityManager.remove(managed);
    }
}


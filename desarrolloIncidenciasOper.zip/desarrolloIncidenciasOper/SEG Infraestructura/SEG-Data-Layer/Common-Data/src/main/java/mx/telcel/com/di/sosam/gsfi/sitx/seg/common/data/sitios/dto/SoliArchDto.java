package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto;

import java.io.Serializable;

public class SoliArchDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4696068639029540302L;
	
	private Integer idArchivo;
    private String ruta;
    private String descripcion;
    private String nombreArch;
    private String tamanio;
    private String fechaCarga;
    private String revision;
    private String usuario;
    private String nombreUsu;
    private Integer idSeccion;
    private String folio;
    private String botonEliminar;

    public SoliArchDto() {
    }

    public SoliArchDto(Integer idArchivo, String ruta, String descripcion, String nombreArch, String tamanio,
                       String fechaCarga, String revision, String usuario, Integer idSeccion, String folio, String nombreUsu) {
        this.idArchivo = idArchivo;
        this.ruta = ruta;
        this.descripcion = descripcion;
        this.nombreArch = nombreArch;
        this.tamanio = tamanio;
        this.fechaCarga = fechaCarga;
        this.revision = revision;
        this.usuario = usuario;
        this.idSeccion = idSeccion;
        this.folio = folio;
        this.nombreUsu = nombreUsu;
    }

    public Integer getIdArchivo() {
        return idArchivo;
    }

    public void setIdArchivo(Integer idArchivo) {
        this.idArchivo = idArchivo;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNombreArch() {
        return nombreArch;
    }

    public void setNombreArch(String nombreArch) {
        this.nombreArch = nombreArch;
    }

    public String getTamanio() {
        return tamanio;
    }

    public void setTamanio(String tamanio) {
        this.tamanio = tamanio;
    }

    public String getFechaCarga() {
        return fechaCarga;
    }

    public void setFechaCarga(String fechaCarga) {
        this.fechaCarga = fechaCarga;
    }

    public String getRevision() { 
        return revision;
    }

    public void setRevision(String revision) { 
        this.revision = revision;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public Integer getIdSeccion() {
        return idSeccion;
    }

    public void setIdSeccion(Integer idSeccion) {
        this.idSeccion = idSeccion;
    }

    public String getFolio() {
        return folio;
    }

    public void setFolio(String folio) {
        this.folio = folio;
    }

	public String getNombreUsu() {
		return nombreUsu;
	}

	public void setNombreUsu(String nombreUsu) {
		this.nombreUsu = nombreUsu;
	}

	public String getBotonEliminar() {
		return botonEliminar;
	}

	public void setBotonEliminar(String botonEliminar) {
		this.botonEliminar = botonEliminar;
	}
	
}

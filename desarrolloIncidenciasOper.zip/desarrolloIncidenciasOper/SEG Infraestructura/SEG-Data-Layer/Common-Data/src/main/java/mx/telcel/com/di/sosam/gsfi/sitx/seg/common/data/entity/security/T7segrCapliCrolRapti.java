package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * <h1>T7segrCapliCrolRapti</h1>
 * <p>
 * Class for mapping the table "T7SEGR_CAPLI_CROL_RAPTI" of database.
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 31/03/2015
 *
 */
@Entity
@Table(name = "T3SEGR_CAPLI_CROL_RAPTI",  schema="BDDSEG01")
public class T7segrCapliCrolRapti implements java.io.Serializable {

	private static final long serialVersionUID = -2587749206600076527L;
	
	private Integer rol;
	private Integer aplicacion;
	private Integer componente;
	private Character permiso;

	public T7segrCapliCrolRapti() {
	}
	

	public T7segrCapliCrolRapti(Integer rol, Integer aplicacion, Integer componente) {
		super();
		this.rol = rol;
		this.aplicacion = aplicacion;
		this.componente = componente;
	}

	/**
	 * @param rol
	 * @param aplicacion
	 * @param componente
	 * @param permiso
	 */
	public T7segrCapliCrolRapti(Integer rol, Integer aplicacion,
			Integer componente, Character permiso) {
		super();
		this.rol = rol;
		this.aplicacion = aplicacion;
		this.componente = componente;
		this.permiso = permiso;
	}


	@Id
	@Column(name = "ROL", nullable = false, precision = 22, scale = 0)
	public Integer getIdRol() {
		return this.rol;
	}

	public void setIdRol(Integer rol) {
		this.rol = rol;
	}
	
	@Id
	@Column(name = "APLICACION", nullable = false, precision = 22, scale = 0)
	public Integer getIdAplicacion() {
		return this.aplicacion;
	}

	public void setIdAplicacion(Integer aplicacion) {
		this.aplicacion = aplicacion;
	}
	
	@Id
	@Column(name = "COMPONENTE", nullable = false, precision = 22, scale = 0)
	public Integer getIdComponente() {
		return this.componente;
	}

	public void setIdComponente(Integer componente) {
		this.componente = componente;
	}
	
	@Column(name = "PERMISO", length = 1)
	public Character getPermiso() {
		return this.permiso;
	}

	public void setPermiso(Character permiso) {
		this.permiso = permiso;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((aplicacion == null) ? 0 : aplicacion.hashCode());
		result = prime * result
				+ ((componente == null) ? 0 : componente.hashCode());
		result = prime * result + ((rol == null) ? 0 : rol.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		T7segrCapliCrolRapti other = (T7segrCapliCrolRapti) obj;
		if (aplicacion == null) {
			if (other.aplicacion != null){
				return false;
			}
		} else if (!aplicacion.equals(other.aplicacion)){
			return false;
		}
		if (componente == null) {
			if (other.componente != null){
				return false;
			}
		} else if (!componente.equals(other.componente)){
			return false;
		}
		if (rol == null) {
			if (other.rol != null){
				return false;
			}
		} else if (!rol.equals(other.rol)){
			return false;
		}
		
		return true;
	}

}

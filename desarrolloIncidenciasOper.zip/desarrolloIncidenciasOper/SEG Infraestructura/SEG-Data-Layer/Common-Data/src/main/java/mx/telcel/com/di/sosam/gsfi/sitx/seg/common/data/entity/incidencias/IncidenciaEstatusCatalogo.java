package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias;

import java.io.Serializable;
import java.time.LocalDateTime;
import javax.persistence.*;

@Entity
@Table(name = "T3SINC_INCI_ESTA", schema = "BDDSEG01")
public class IncidenciaEstatusCatalogo implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID_ESTA_INCI", nullable = false)
    private Long id;

    @Column(name = "CVE_ESTA_INCI", nullable = false, length = 30)
    private String clave;

    @Column(name = "DSC_ESTA_INCI", nullable = false, length = 200)
    private String descripcion;

    @Column(name = "ORDEN_FLUJO", nullable = false)
    private Integer ordenFlujo;

    @Column(name = "ACTIVO", nullable = false, length = 1)
    private String activo;

    @Column(name = "USU_ALTA", nullable = false, length = 60)
    private String usuarioAlta;

    @Column(name = "FEC_ALTA", nullable = false)
    private LocalDateTime fechaAlta;

    @Column(name = "USU_ULT_MOD", length = 60)
    private String usuarioUltimaModificacion;

    @Column(name = "FEC_ULT_MOD")
    private LocalDateTime fechaUltimaModificacion;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getClave() { return clave; }
    public void setClave(String clave) { this.clave = clave; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public Integer getOrdenFlujo() { return ordenFlujo; }
    public void setOrdenFlujo(Integer ordenFlujo) { this.ordenFlujo = ordenFlujo; }

    public String getActivo() { return activo; }
    public void setActivo(String activo) { this.activo = activo; }

    public String getUsuarioAlta() { return usuarioAlta; }
    public void setUsuarioAlta(String usuarioAlta) { this.usuarioAlta = usuarioAlta; }

    public LocalDateTime getFechaAlta() { return fechaAlta; }
    public void setFechaAlta(LocalDateTime fechaAlta) { this.fechaAlta = fechaAlta; }

    public String getUsuarioUltimaModificacion() { return usuarioUltimaModificacion; }
    public void setUsuarioUltimaModificacion(String usuarioUltimaModificacion) { this.usuarioUltimaModificacion = usuarioUltimaModificacion; }

    public LocalDateTime getFechaUltimaModificacion() { return fechaUltimaModificacion; }
    public void setFechaUltimaModificacion(LocalDateTime fechaUltimaModificacion) { this.fechaUltimaModificacion = fechaUltimaModificacion; }
}

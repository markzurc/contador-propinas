package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto;

import java.io.Serializable;

public class FiltroSitioDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4696068639029540302L;
	private String region;
	private String estado;
	private String municipio;
	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * @param region the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	/**
	 * @return the estado
	 */
	public String getEstado() {
		return estado;
	}
	/**
	 * @param estado the estado to set
	 */
	public void setEstado(String estado) {
		this.estado = estado;
	}
	/**
	 * @return the municipio
	 */
	public String getMunicipio() {
		return municipio;
	}
	/**
	 * @param municipio the municipio to set
	 */
	
	public void setMunicipio(String municipio) {
		this.municipio = municipio;
	}
	
	public FiltroSitioDto(String region, String estado, String municipio) {
		super();
		this.region = region;
		this.estado = estado;
		this.municipio = municipio;
	}
	public FiltroSitioDto() {

	}
	
	
}

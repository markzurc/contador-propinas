package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.visitaTecnica.dao;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegcHerrVistTecn;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegcPersVistTecn;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegdSoliArch;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3segoVisiTecnSoli;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SoliArchDto;

public interface IVisitaTecnicaDao {
	
	public void guardarVisitaTecnica(T3segoVisiTecnSoli visitaTecnica);
	
	public void guardarPersonal(T3SegcPersVistTecn personalVisita);
	
	public void guardarHerramienta(T3SegcHerrVistTecn herramientelVisita);
	
	public void guardarArchivo(T3SegdSoliArch archivo);
	
	public  void actualizarSolicitud(String folio,String transicion) ;
	
	public List<T3SegcPersVistTecn> getPersonal(String folioSolicitud,String grupoOperador);

	public List<T3SegcHerrVistTecn> getHerramientas(String folioSolicitud,String grupoOperador);
	
	public List<SoliArchDto> getArchivos(String folioSolicitud,Integer idSeccion,String descripcion);
	
	public T3segoVisiTecnSoli getSolicitudVisita(String folioSolicitud);
	
	public void eliminarPersonal(T3SegcPersVistTecn personalVisita) ;
	
	public void eliminarHerramienta(T3SegcHerrVistTecn herramientalVisita);
	
	public void eliminarArchivo(Integer idArchivo);
	
	public List<String> getTipoHerramientas();
}

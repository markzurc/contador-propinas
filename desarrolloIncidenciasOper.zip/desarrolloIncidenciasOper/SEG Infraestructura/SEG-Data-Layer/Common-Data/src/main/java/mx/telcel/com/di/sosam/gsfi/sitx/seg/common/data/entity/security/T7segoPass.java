package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * <h1>T7segoPass</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 05/05/2015
 */
@Entity
@Table(name = "T3SEGO_PASS",  schema="BDDSEG01")
public class T7segoPass implements java.io.Serializable {

	private static final long serialVersionUID = -3861889223980757371L;
	private TsegcPasswordId id;
	private String password;
	private Integer intentos;
	private Date fechaCambioPassword;

	public T7segoPass() {
	}

	public T7segoPass(TsegcPasswordId id) {
		this.id = id;
	}

	/**
	 * @param id
	 * @param password
	 * @param intentos
	 * @param fechaCambioPassword
	 */
	public T7segoPass(TsegcPasswordId id, String password, Integer intentos,
			Date fechaCambioPassword) {
		super();
		this.id = id;
		this.password = password;
		this.intentos = intentos;
		this.fechaCambioPassword = fechaCambioPassword!=null?(Date)fechaCambioPassword.clone():null;
	}

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "idUsuario", column = @Column(name = "USUARIO", nullable = false, precision = 22, scale = 0))})
	public TsegcPasswordId getId() {
		return this.id;
	}

	public void setId(TsegcPasswordId id) {
		this.id = id;
	}
	
	@Column(name = "PASSWORD", nullable = false, length = 45)
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	@Column(name = "INTENTOS", precision = 22, scale = 0)
	public Integer getIntentos() {
		return this.intentos;
	}

	public void setIntentos(Integer intentos) {
		this.intentos = intentos;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECHA_CAMBIO_PASSWORD", nullable = false)
	public Date getFechaCambioPassword() {
		return  fechaCambioPassword!=null?(Date)fechaCambioPassword.clone():null;
	}

	public void setFechaCambioPassword(Date fechaCambioPassword) {
		this.fechaCambioPassword = fechaCambioPassword!=null?(Date)fechaCambioPassword.clone():null;
	}

}

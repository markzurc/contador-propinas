package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * <h1>TsegcHistoricopasswordId</h1>
 * <p>
 * </p>
 * 
 * @author chcastro
 * @version 1.0
 * @since 21/05/2015
 */
@Embeddable
public class TsegcHistoricopasswordId implements java.io.Serializable {

	private static final long serialVersionUID = 3580895814694768409L;
	private Integer idUsuario;
	private String contra;
	private Date fechaCambioPassword;
	private Integer idMotivo;

	public TsegcHistoricopasswordId() {
	}

	public TsegcHistoricopasswordId(Integer idUsuario, Integer idMotivo) {
		this.idUsuario = idUsuario;
		this.idMotivo = idMotivo;
	}

	public TsegcHistoricopasswordId(Integer idUsuario, String contra,
			Date fechaCambioPassword, Integer idMotivo) {
		this.idUsuario = idUsuario;
		this.contra = contra;
		this.fechaCambioPassword = fechaCambioPassword!=null?(Date)fechaCambioPassword.clone():null;
		this.idMotivo = idMotivo;
	}

	@Column(name = "USUARIO", nullable = false, precision = 22, scale = 0)
	public Integer getIdUsuario() {
		return this.idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	@Column(name = "PASSWORD", nullable = false, length = 45)
	public String getContra() {
		return this.contra;
	}

	public void setContra(String contra) {
		this.contra = contra;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECHA_CAMBIO_PASSWORD", nullable = false)
	public Date getFechaCambioPassword() {
		return fechaCambioPassword!=null?(Date)fechaCambioPassword.clone():null;
	}

	public void setFechaCambioPassword(Date fechaCambioPassword) {
		this.fechaCambioPassword = fechaCambioPassword!=null?(Date)fechaCambioPassword.clone():null;
	}

	@Column(name = "MOTIVO", nullable = false, precision = 22, scale = 0)
	public Integer getIdMotivo() {
		return this.idMotivo;
	}

	public void setIdMotivo(Integer idMotivo) {
		this.idMotivo = idMotivo;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		TsegcHistoricopasswordId other = (TsegcHistoricopasswordId) obj;
		if (idUsuario == null) {
			if (other.idUsuario != null){
				return false;
			}
		} else if (!idUsuario.equals(other.idUsuario)){
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idUsuario == null) ? 0 : idUsuario.hashCode());
		return result;
	}

}

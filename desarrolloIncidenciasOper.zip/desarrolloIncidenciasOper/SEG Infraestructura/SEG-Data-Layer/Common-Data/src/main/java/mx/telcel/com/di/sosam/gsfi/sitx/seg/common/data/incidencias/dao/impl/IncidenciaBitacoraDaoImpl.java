package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.impl;

import java.util.Collections;
import java.util.List;
import java.util.Date; // <--- USAR DATE
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.IncidenciaBitacora;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaBitacoraDao;

@Repository
@Transactional
public class IncidenciaBitacoraDaoImpl implements IIncidenciaBitacoraDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Long obtenerSiguienteId() {
        Number siguiente = (Number) entityManager
                .createNativeQuery("SELECT NVL(MAX(ID_MOVI), 0) + 1 FROM BDDSEG01.T3SINB_INCI_MOVI")
                .getSingleResult();
        return siguiente.longValue();
    }

    @Override
    public void persist(IncidenciaBitacora bitacora) {
        if (bitacora == null) {
            return;
        }

        if (bitacora.getId() == null) {
            bitacora.setId(obtenerSiguienteId());
        }

        prepararDefaultsAntesDePersistir(bitacora);
        entityManager.persist(bitacora);
    }

    @Override
    public IncidenciaBitacora merge(IncidenciaBitacora bitacora) {
        if (bitacora == null) {
            return null;
        }

        prepararDefaultsAntesDePersistir(bitacora);
        return entityManager.merge(bitacora);
    }

    @Override
    public List<IncidenciaBitacora> findByIncidenciaId(Long idIncidencia) {
        if (idIncidencia == null) {
            return Collections.emptyList();
        }

        TypedQuery<IncidenciaBitacora> query = entityManager.createQuery(
                "SELECT b FROM IncidenciaBitacora b " +
                "WHERE b.idIncidencia = :idIncidencia AND b.activo = 'S' " +
                "ORDER BY b.fechaEvento DESC",
                IncidenciaBitacora.class);

        query.setParameter("idIncidencia", idIncidencia);
        return query.getResultList();
    }

    private void prepararDefaultsAntesDePersistir(IncidenciaBitacora bitacora) {
        // --- CAMBIO: Usar Date ---
        Date ahora = new Date();

        if (bitacora.getFechaEvento() == null) {
            bitacora.setFechaEvento(ahora);
        }

        if (bitacora.getActivo() == null || bitacora.getActivo().trim().isEmpty()) {
            bitacora.setActivo("S");
        }
    }
}
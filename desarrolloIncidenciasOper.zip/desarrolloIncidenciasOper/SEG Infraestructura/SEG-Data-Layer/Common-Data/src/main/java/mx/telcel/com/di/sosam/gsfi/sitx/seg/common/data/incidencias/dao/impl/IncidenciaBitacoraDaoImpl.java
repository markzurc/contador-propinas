package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.impl;

import java.util.Collections;
import java.util.List;
import java.util.Date; 
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.T3SINB_INCI_MOVI;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaBitacoraDao;

@Repository
@Transactional
public class IncidenciaBitacoraDaoImpl implements IIncidenciaBitacoraDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Long obtenerSiguienteId() {
        Number siguiente = (Number) entityManager
                .createNativeQuery("SELECT NVL(MAX(ID_MOVI), 0) + 1 FROM BDDSEG01.T3SINB_INCI_MOVI")
                .getSingleResult();
        return siguiente.longValue();
    }

    @Override
    public void persist(T3SINB_INCI_MOVI bitacora) {
        if (bitacora == null) {
            return;
        }

        if (bitacora.getId() == null) {
            bitacora.setId(obtenerSiguienteId());
        }

        prepararDefaultsAntesDePersistir(bitacora);
        entityManager.persist(bitacora);
    }

    @Override
    public T3SINB_INCI_MOVI merge(T3SINB_INCI_MOVI bitacora) {
        if (bitacora == null) {
            return null;
        }

        prepararDefaultsAntesDePersistir(bitacora);
        return entityManager.merge(bitacora);
    }

    @Override
    public List<T3SINB_INCI_MOVI> findByIncidenciaId(Long idIncidencia) {
        if (idIncidencia == null) {
            return Collections.emptyList();
        }

        TypedQuery<T3SINB_INCI_MOVI> query = entityManager.createQuery(
                "SELECT b FROM T3SINB_INCI_MOVI b " +
                "WHERE b.idIncidencia = :idIncidencia AND b.activo = 'S' " +
                "ORDER BY b.fechaEvento ASC, b.id ASC",
                T3SINB_INCI_MOVI.class);


        query.setParameter("idIncidencia", idIncidencia);
        return query.getResultList();
    }

    private void prepararDefaultsAntesDePersistir(T3SINB_INCI_MOVI bitacora) {
        Date ahora = new Date();

        if (bitacora.getFechaEvento() == null) {
            bitacora.setFechaEvento(ahora);
        }

        if (bitacora.getActivo() == null || bitacora.getActivo().trim().isEmpty()) {
            bitacora.setActivo("S");
        }
    }
}
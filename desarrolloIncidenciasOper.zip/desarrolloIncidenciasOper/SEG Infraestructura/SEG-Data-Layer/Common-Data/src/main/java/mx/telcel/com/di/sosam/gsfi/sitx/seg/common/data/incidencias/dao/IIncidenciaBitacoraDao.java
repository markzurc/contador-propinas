package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.IncidenciaBitacora;

public interface IIncidenciaBitacoraDao {

    Long obtenerSiguienteId();

    void persist(IncidenciaBitacora bitacora);

    IncidenciaBitacora merge(IncidenciaBitacora bitacora);

    List<IncidenciaBitacora> findByIncidenciaId(Long idIncidencia);
}

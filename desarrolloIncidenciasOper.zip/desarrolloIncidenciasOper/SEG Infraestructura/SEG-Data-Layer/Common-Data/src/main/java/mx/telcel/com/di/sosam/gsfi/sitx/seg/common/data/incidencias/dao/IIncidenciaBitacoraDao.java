package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.T3SINB_INCI_MOVI;


public interface IIncidenciaBitacoraDao {

    Long obtenerSiguienteId();

    void persist(T3SINB_INCI_MOVI bitacora);

    T3SINB_INCI_MOVI merge(T3SINB_INCI_MOVI bitacora);

    List<T3SINB_INCI_MOVI> findByIncidenciaId(Long idIncidencia);
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dao;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ConfiguracionElementoEditableDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ElementosPantallaDTO;

public interface IElementosPantallaDao {

	public List<ElementosPantallaDTO> getElementosPantalla(String flujo,Integer idRolUsuario);
	public List<ConfiguracionElementoEditableDTO> getConfiguracionEditableElemento(Integer idElementoPantalla);
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.transformer;

import java.util.List;
import org.hibernate.transform.ResultTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;

public class ConsultaSitiosTransformer implements ResultTransformer {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4569880860719168302L;

	@Override
	public Object transformTuple(Object[] tuple, String[] aliases) {
		String sitio =  checkStrNotNull(tuple[0]);
		String nombre = checkStrNotNull(tuple[1]);
		String concesionario = checkStrNotNull(tuple[2]);
		String colonia = checkStrNotNull(tuple[3]);
		String codigoPostal = checkStrNotNull(tuple[4]);
		String municipio = checkStrNotNull(tuple[5]);
		String estado = checkStrNotNull(tuple[6]);
		String latitud = checkStrNotNull(tuple[7]);
		String longitud = checkStrNotNull(tuple[8]);
		String altura = checkStrNotNull(tuple[9]);
		String tipoSitio = checkStrNotNull(tuple[10]);
		String tipoTorre = checkStrNotNull(tuple[11]);
		String viento = checkStrNotNull(tuple[12]);
		String clasificacion = checkStrNotNull(tuple[13]);
		String region = checkStrNotNull(tuple[14]);
		String folio = null;
		String disponible = checkStrNotNull(tuple[15]);
		
		SitioDto datos = new SitioDto(sitio, nombre, concesionario, colonia, codigoPostal, municipio, estado, latitud, longitud, altura, tipoSitio, tipoTorre, viento, clasificacion, region, folio, disponible);
		return datos;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List collection) {
		return collection;
	}
	
	private String checkStrNotNull(Object object) {
		return null != object ? object.toString() : " ";
	}
}

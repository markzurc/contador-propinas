package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto;

import java.io.Serializable;

public class ArchSoliDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4696068639029540302L;
	
	private Integer idArchivo;
	private String ruta;
	private String descripcion;
	private String nombreArch;
	private String tamanio;
	private String fechaCarga;
	private String revision;
	private String usuario;
	private Integer idTipoInf;
	private String folio;
	
	public Integer getIdArchivo() {
		return idArchivo;
	}
	public void setIdArchivo(Integer idArchivo) {
		this.idArchivo = idArchivo;
	}
	public String getRuta() {
		return ruta;
	}
	public void setRuta(String ruta) {
		this.ruta = ruta;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getNombreArch() {
		return nombreArch;
	}
	public void setNombreArch(String nombreArch) {
		this.nombreArch = nombreArch;
	}
	public String getTamanio() {
		return tamanio;
	}
	public void setTamanio(String tamanio) {
		this.tamanio = tamanio;
	}
	public String getFechaCarga() {
		return fechaCarga;
	}
	public void setFechaCarga(String fechaCarga) {
		this.fechaCarga = fechaCarga;
	}
	public String getRevision() {
		return revision;
	}
	public void setRevision(String revision) {
		this.revision = revision;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public Integer getIdTipoInf() {
		return idTipoInf;
	}
	public void setIdTipoInf(Integer idTipoInf) {
		this.idTipoInf = idTipoInf;
	}
	public String getFolio() {
		return folio;
	}
	public void setFolio(String folio) {
		this.folio = folio;
	}
	
	public ArchSoliDto(Integer idArchivo, String ruta, String descripcion, String nombreArch, String tamanio,
			String fechaCarga, String revision, String usuario, Integer idTipoInf, String folio) {
		super();
		this.idArchivo = idArchivo;
		this.ruta = ruta;
		this.descripcion = descripcion;
		this.nombreArch = nombreArch;
		this.tamanio = tamanio;
		this.fechaCarga = fechaCarga;
		this.revision = revision;
		this.usuario = usuario;
		this.idTipoInf = idTipoInf;
		this.folio = folio;
	}
	
	
	
	
	
}

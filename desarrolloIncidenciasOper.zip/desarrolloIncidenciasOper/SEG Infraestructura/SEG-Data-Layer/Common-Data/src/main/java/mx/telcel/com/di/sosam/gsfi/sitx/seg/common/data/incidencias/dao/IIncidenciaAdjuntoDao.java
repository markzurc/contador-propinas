package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao;

import java.util.List;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.IncidenciaAdjunto;

public interface IIncidenciaAdjuntoDao {

    void persist(IncidenciaAdjunto adj);

    IncidenciaAdjunto merge(IncidenciaAdjunto entity);

    /** Regresa adjuntos activos ('S') por incidencia */
    List<IncidenciaAdjunto> findByIncidencia(Long idIncidencia);

    /** Busca un adjunto activo por incidencia y nombre de archivo */
    IncidenciaAdjunto findActivoByIncidenciaAndNombre(Long idIncidencia, String nombreArchivo);

    void remove(IncidenciaAdjunto entity);
}

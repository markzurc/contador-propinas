package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.IncidenciaAdjunto;

public interface IIncidenciaAdjuntoDao {

    void persist(IncidenciaAdjunto adj);

    List<IncidenciaAdjunto> findByIncidencia(Long idIncidencia);
    void remove(IncidenciaAdjunto entity);

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.application.thirdparty.request;



/**
 * 
 * <h1>ApplicationGenericRequest</h1>
 * <p>
 * Generic request for all third-party applications
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 17/03/2015
 *
 */

public abstract class ApplicationGenericRequest implements IApplicationGenericRequest{
}

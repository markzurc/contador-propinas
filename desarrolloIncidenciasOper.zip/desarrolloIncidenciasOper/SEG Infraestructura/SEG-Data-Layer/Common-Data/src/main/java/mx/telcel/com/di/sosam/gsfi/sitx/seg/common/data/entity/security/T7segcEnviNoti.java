package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name="T3SEGC_ENVI_NOTI", schema="BDDSEG01")
public class T7segcEnviNoti implements Serializable{

	private static final long serialVersionUID = 9027987136388431761L;
	private Integer producto;
	private String productoDesc;
	private String correoDest;
	private String correoCc;
	private Integer estado;
	
	public T7segcEnviNoti(Integer producto, String productoDesc, String correoDest, String correoCc, Integer estado) {
		super();
		this.producto = producto;
		this.productoDesc = productoDesc;
		this.correoDest = correoDest;
		this.correoCc = correoCc;
		this.estado = estado;
	}

	@Id
	@Column(name = "PRODUCTO", nullable = false, precision = 22, scale = 0)
	public Integer getProducto() {
		return producto;
	}

	public void setProducto(Integer producto) {
		this.producto = producto;
	}

	@Column(name = "PRODUCTO_DESC", nullable = false, precision = 22, scale = 0)
	public String getProductoDesc() {
		return productoDesc;
	}

	public void setProductoDesc(String productoDesc) {
		this.productoDesc = productoDesc;
	}

	@Lob
	@Column(name = "CORREO_DEST", nullable = false, precision = 22, scale = 0)
	public String getCorreoDest() {
		return correoDest;
	}

	public void setCorreoDest(String correoDest) {
		this.correoDest = correoDest;
	}

	@Lob
	@Column(name = "CORREO_CC", nullable = false, precision = 22, scale = 0)
	public String getCorreoCc() {
		return correoCc;
	}

	public void setCorreoCc(String correoCc) {
		this.correoCc = correoCc;
	}

	@Column(name = "ESTADO", nullable = false, precision = 22, scale = 0)
	public Integer getEstado() {
		return estado;
	}

	public void setEstado(Integer estado) {
		this.estado = estado;
	}
	
}

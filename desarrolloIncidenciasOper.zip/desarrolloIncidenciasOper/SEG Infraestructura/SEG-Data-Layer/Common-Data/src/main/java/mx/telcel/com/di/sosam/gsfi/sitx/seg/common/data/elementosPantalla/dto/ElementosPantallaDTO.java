package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto;


public class ElementosPantallaDTO {
	private Integer idElementoPantalla; //llave primaria tabla T3SEGC_ELEM_PANT 
	private String idElemento;  //identificador que le damos al componente de la pantalla
	private boolean visible;
	private boolean editable;
	
	public Integer getIdElementoPantalla() {
		return idElementoPantalla;
	}
	public void setIdElementoPantalla(Integer idElementoPantalla) {
		this.idElementoPantalla = idElementoPantalla;
	}
	public String getIdElemento() {
		return idElemento;
	}
	public void setIdElemento(String idElemento) {
		this.idElemento = idElemento;
	}
	public boolean isVisible() {
		return visible;
	}
	public void setVisible(boolean visible) {
		this.visible = visible;
	}
	public boolean isEditable() {
		return editable;
	}
	public void setEditable(boolean editable) {
		this.editable = editable;
	}
	
	
}

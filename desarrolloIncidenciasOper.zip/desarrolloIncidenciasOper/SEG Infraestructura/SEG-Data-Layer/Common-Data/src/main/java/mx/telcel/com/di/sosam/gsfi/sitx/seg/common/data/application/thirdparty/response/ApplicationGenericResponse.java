package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.application.thirdparty.response;

/**
 * 
 * <h1>ApplicationGenericResponse</h1>
 * <p>
 * Generic response for all third-party applications
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 17/03/2015
 *
 */
public class ApplicationGenericResponse {
	
	private String message;
	private String error;
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @return the error
	 */
	public String getError() {
		return error;
	}
	/**
	 * @param error the error to set
	 */
	public void setError(String error) {
		this.error = error;
	}
	
	

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto;

import java.io.Serializable;

public class ServicioDto implements Serializable {
	
	private static final long serialVersionUID = -6272628604679992129L;
	private int idServicio;
	private String descripcion;
	
	/**
	 * @return the idServicio
	 */
	public int getIdServicio() {
		return idServicio;
	}
	
	/**
	 * @param idServicio the idServicio to set
	 */
	public void setIdServicio(int idServicio) {
		this.idServicio = idServicio;
	}
	
	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}
	
	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	

	public ServicioDto(int idServicio, String descripcion) {
		super();
		this.idServicio = idServicio;
		this.descripcion = descripcion;
	}

//	public ServicioDto() {
//
//	}
	
	@Override
	public String toString() {
		return "ServicioDto [idServicio=" + idServicio + ", descripcion=" + descripcion + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((descripcion == null) ? 0 : descripcion.hashCode());
		result = prime * result + idServicio;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ServicioDto other = (ServicioDto) obj;
		if (descripcion == null) {
			if (other.descripcion != null)
				return false;
		} else if (!descripcion.equals(other.descripcion))
			return false;
		if (idServicio != other.idServicio)
			return false;
		return true;
	}
	
}

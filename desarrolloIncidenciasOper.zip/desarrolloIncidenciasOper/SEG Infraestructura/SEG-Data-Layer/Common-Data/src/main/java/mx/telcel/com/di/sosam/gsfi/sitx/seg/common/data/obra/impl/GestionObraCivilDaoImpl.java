package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.impl;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dao.IGestionObraCivilDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto.EstadoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto.MunicipioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto.ObraCivilDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.FiltroSitioDto;

@Repository(value = "gestionObraCivilDao")
@Scope("prototype")
public class GestionObraCivilDaoImpl extends GenericFunctionDaoImpl implements IGestionObraCivilDao, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4427249639060406305L;
	private Logger LOGGER = LogManager.getLogger(GestionObraCivilDaoImpl.class);
	private static final String SELECT_GESTION_OBRA_CIVIL = "T3SEGC_OBRA.SELECT_GESTION_OBRA_CIVIL";
	private static final String SELECT_LISTA_REGION = "T3SEGC_MUNICIPIO.SELECT_LISTA_REGION";
	private static final String SELECT_LISTA_ESTADO = "T3SEGC_MUNICIPIO.SELECT_LISTA_ESTADO";
	private static final String SELECT_LISTA_MUNICIPIO = "T3SEGC_MUNICIPIO.SELECT_LISTA_MUNICIPIO";
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ObraCivilDto> getListaObraCivil(FiltroSitioDto filtro) {
		Session session = getSession();
		try {
			Query query = session.getNamedQuery(SELECT_GESTION_OBRA_CIVIL);
			query.setParameter("region", filtro.getRegion().equals("null") ? "0" : filtro.getRegion());
			query.setParameter("estado", filtro.getEstado().equals("null") ? 0 : filtro.getEstado());
			query.setParameter("municipio", filtro.getMunicipio().equals("null") ? 0 : filtro.getMunicipio());
			query.setResultTransformer(Transformers.aliasToBean(ObraCivilDto.class));
			return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar las Obras: " + e);
			return Collections.<ObraCivilDto>emptyList();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getListaRegion() {
		Session session = getSession();
		try {
			Query query = session.getNamedQuery(SELECT_LISTA_REGION);
			return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar las regiones: " + e);
			return Collections.<String>emptyList();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EstadoDto> getListaEstado(String region) {
		Session session = getSession();
		try {
			Query query = session.getNamedQuery(SELECT_LISTA_ESTADO);
			query.setParameter("region", region);
			query.setResultTransformer(Transformers.aliasToBean(EstadoDto.class));
			return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar los estados: " + e);
			return Collections.<EstadoDto>emptyList();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MunicipioDto> getListaMunicipio(String region, String estado) {
		Session session = getSession();
		try {
			Query query = session.getNamedQuery(SELECT_LISTA_MUNICIPIO);
			query.setParameter("region", region);
			query.setParameter("estado", estado);
			query.setResultTransformer(Transformers.aliasToBean(MunicipioDto.class));
			return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar los municipios: " + e);
			return Collections.<MunicipioDto>emptyList();
		}
	}

}

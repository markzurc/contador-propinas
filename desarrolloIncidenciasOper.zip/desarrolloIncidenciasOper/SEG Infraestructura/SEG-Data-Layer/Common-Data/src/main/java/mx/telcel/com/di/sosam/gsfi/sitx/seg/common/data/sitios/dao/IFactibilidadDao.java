package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.AntenaDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.FactibilidadDto;

public interface IFactibilidadDao {

	public List<FactibilidadDto> getFactibilidad();

	public List<AntenaDto> getAntenas(String idFacti);

	public List<String> getTorres();
	
	public List<String> getTipoAntenas();
	
	public boolean crearSolicitud(FactibilidadDto factibilidadDto);
	
	public boolean crearResultado(FactibilidadDto factibilidadDto);
	
	public boolean actualizarMotivoRechazo(FactibilidadDto factibilidadDto);
	
	public boolean crearAntena(List<AntenaDto> antenaDto);
	
	public boolean modificarSitioEstado(String idFolio, String estado);
	
	public List<FactibilidadDto> getFacti(String idFacti);
	
	public String getFactiPorFolio(String idFolio);
	
	public String getTorrePorId(String idTorre);

}

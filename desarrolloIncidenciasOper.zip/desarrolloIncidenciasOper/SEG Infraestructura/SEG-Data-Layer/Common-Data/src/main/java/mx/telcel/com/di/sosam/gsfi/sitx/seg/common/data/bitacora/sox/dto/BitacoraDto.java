package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dto;

import java.io.Serializable;
import java.util.Date;

public class BitacoraDto implements Serializable {

	private static final long serialVersionUID = 3818195196158409122L;
	private Integer idBitacora;
	private String idSolicitud;
	private String idUsuario;
	private String idEmpresa;
	private String idEstatusFlujo;
	private String fechaMovimiento;
	private String idAccion;
	private String motivoRechazo;
	private String rol;

	public Integer getIdBitacora() {
		return idBitacora;
	}

	public void setIdBitacora(Integer idBitacora) {
		this.idBitacora = idBitacora;
	}

	public String getIdSolicitud() {
		return idSolicitud;
	}

	public void setIdSolicitud(String idSolicitud) {
		this.idSolicitud = idSolicitud;
	}

	public String getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(String idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getIdEmpresa() {
		return idEmpresa;
	}

	public void setIdEmpresa(String idEmpresa) {
		this.idEmpresa = idEmpresa;
	}

	public String getIdEstatusFlujo() {
		return idEstatusFlujo;
	}

	public void setIdEstatusFlujo(String idEstatusFlujo) {
		this.idEstatusFlujo = idEstatusFlujo;
	}

	public String getFechaMovimiento() {
		return fechaMovimiento;
	}

	public void setFechaMovimiento(String fechaMovimiento) {
		this.fechaMovimiento = fechaMovimiento;
	}

	public String getIdAccion() {
		return idAccion;
	}

	public void setIdAccion(String idAccion) {
		this.idAccion = idAccion;
	}

	public String getMotivoRechazo() {
		return motivoRechazo;
	}

	public void setMotivoRechazo(String motivoRechazo) {
		this.motivoRechazo = motivoRechazo;
	}

	public String getRol() {
		return rol;
	}

	public void setRol(String rol) {
		this.rol = rol;
	}
}

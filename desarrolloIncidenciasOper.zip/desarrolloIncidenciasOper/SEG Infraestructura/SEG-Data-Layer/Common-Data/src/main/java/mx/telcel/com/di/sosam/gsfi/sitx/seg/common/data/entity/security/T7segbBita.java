package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * <h1>T7segbBita</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 11/05/2015
 */
@Entity
@Table(name = "T3SEGB_BITA",  schema="BDDSEG01")
public class T7segbBita implements java.io.Serializable {

	private static final long serialVersionUID = 828175637021781973L;
	private Integer bitacora;
	private Integer usuario;
	private String numeroEmpleado;
	private String folioSua;
	private Date fechaOperacion;
	private String datoInicial;
	private String datoFinal;
	private Integer accion;

	public T7segbBita() {
	}

	public T7segbBita(Integer bitacora, Integer usuario,
			String numeroEmpleado, String folioSua, Date fechaOperacion,
			String datoInicial, Integer accion) {
		this.bitacora = bitacora;
		this.usuario = usuario;
		this.numeroEmpleado = numeroEmpleado;
		this.folioSua = folioSua;
		this.fechaOperacion = fechaOperacion!=null?(Date)fechaOperacion.clone():null;
		this.datoInicial = datoInicial;
		this.accion = accion;
	}

	public T7segbBita(Integer bitacora, Integer usuario,
			String numeroEmpleado, String folioSua, Date fechaOperacion,
			String datoInicial, String datoFinal, Integer accion) {
		this.bitacora = bitacora;
		this.usuario = usuario;
		this.numeroEmpleado = numeroEmpleado;
		this.folioSua = folioSua;
		this.fechaOperacion = fechaOperacion!=null?(Date)fechaOperacion.clone():null;
		this.datoInicial = datoInicial;
		this.datoFinal = datoFinal;
		this.accion = accion;
	}

	@Id
	@Column(name = "BITACORA", unique = true, nullable = false, precision = 22, scale = 0)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQ7SEGB_BITA")
	@SequenceGenerator(name = "SQ7SEGB_BITA", sequenceName = "BDDSEG01.SQ7SEGB_BITA",schema="BDDSEG01", allocationSize = 1)
	public Integer getIdBitacora() {
		return this.bitacora;
	}

	public void setIdBitacora(Integer bitacora) {
		this.bitacora = bitacora;
	}

	@Column(name = "USUARIO", nullable = false, precision = 22, scale = 0)
	public Integer getIdUsuario() {
		return this.usuario;
	}

	public void setIdUsuario(Integer usuario) {
		this.usuario = usuario;
	}

	@Column(name = "NUMERO_EMPLEADO", nullable = false, length = 20)
	public String getNumeroEmpleado() {
		return this.numeroEmpleado;
	}

	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	@Column(name = "FOLIO_SUA", nullable = false, length = 20)
	public String getFolioSua() {
		return this.folioSua;
	}

	public void setFolioSua(String folioSua) {
		this.folioSua = folioSua;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECHA_OPERACION", nullable = false, length = 7)
	public Date getFechaOperacion() {
		return fechaOperacion!=null?(Date)fechaOperacion.clone():null;
	}

	public void setFechaOperacion(Date fechaOperacion) {
		this.fechaOperacion = fechaOperacion!=null?(Date)fechaOperacion.clone():null;
	}

	@Column(name = "DATO_INICIAL")
	public String getDatoInicial() {
		return this.datoInicial;
	}

	public void setDatoInicial(String datoInicial) {
		this.datoInicial = datoInicial;
	}

	@Column(name = "DATO_FINAL", nullable = false)
	public String getDatoFinal() {
		return this.datoFinal;
	}

	public void setDatoFinal(String datoFinal) {
		this.datoFinal = datoFinal;
	}

	@Column(name = "ACCION", nullable = false, precision = 22, scale = 0)
	public Integer getIdAccion() {
		return this.accion;
	}

	public void setIdAccion(Integer accion) {
		this.accion = accion;
	}

}

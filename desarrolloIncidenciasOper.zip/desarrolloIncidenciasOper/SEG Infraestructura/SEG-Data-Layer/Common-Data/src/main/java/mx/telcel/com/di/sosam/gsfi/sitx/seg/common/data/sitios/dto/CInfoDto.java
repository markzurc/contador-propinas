package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto;

import java.io.Serializable;

public class CInfoDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4696068639029540302L;
	private String idTipoInfo;
	private String descripcion;
	private String estatus;
	
	public String getIdTipoInfo() {
		return idTipoInfo;
	}
	public void setIdTipoInfo(String idTipoInfo) {
		this.idTipoInfo = idTipoInfo;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getEstatus() {
		return estatus;
	}
	public void setEstatus(String estatus) {
		this.estatus = estatus;
	}
	
	public CInfoDto(String idTipoInfo, String descripcion, String estatus) {
		super();
		this.idTipoInfo = idTipoInfo;
		this.descripcion = descripcion;
		this.estatus = estatus;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((descripcion == null) ? 0 : descripcion.hashCode());
		result = prime * result + ((estatus == null) ? 0 : estatus.hashCode());
		result = prime * result + ((idTipoInfo == null) ? 0 : idTipoInfo.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CInfoDto other = (CInfoDto) obj;
		if (descripcion == null) {
			if (other.descripcion != null)
				return false;
		} else if (!descripcion.equals(other.descripcion))
			return false;
		if (estatus == null) {
			if (other.estatus != null)
				return false;
		} else if (!estatus.equals(other.estatus))
			return false;
		if (idTipoInfo == null) {
			if (other.idTipoInfo != null)
				return false;
		} else if (!idTipoInfo.equals(other.idTipoInfo))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "InfoReqDto [idTipoInfo=" + idTipoInfo + ", descripcion=" + descripcion + ", estatus=" + estatus + "]";
	}
	

	
}

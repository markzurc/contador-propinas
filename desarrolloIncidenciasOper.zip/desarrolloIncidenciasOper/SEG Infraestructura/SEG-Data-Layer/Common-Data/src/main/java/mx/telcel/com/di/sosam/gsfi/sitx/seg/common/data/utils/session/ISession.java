package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.utils.session;

import org.hibernate.Session;

/**
 * 
 * <h1>ISession</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 04/05/2015
 *
 */
public interface ISession {
	Session getSession();
	void setSession(Session session);
}

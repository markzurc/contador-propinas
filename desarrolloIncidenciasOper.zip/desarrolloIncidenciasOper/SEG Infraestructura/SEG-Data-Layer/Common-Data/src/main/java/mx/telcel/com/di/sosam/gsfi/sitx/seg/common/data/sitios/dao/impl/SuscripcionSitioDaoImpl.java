package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.impl;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.ISuscripcionSitioDao;

@Repository
public class SuscripcionSitioDaoImpl extends GenericFunctionDaoImpl implements ISuscripcionSitioDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(SuscripcionSitioDaoImpl.class);

    private static final String PARAM_GRUPO_OPERADOR = "GRUPO_OPERADOR";
    private static final String PARAM_CONC_ID = "CONC_ID";
    private static final String PARAM_ID_SITIO = "ID_SITIO";
    private static final String PARAM_ID_SUSC = "ID_SUSC";
    private static final String PARAM_USU_ALTA = "USU_ALTA";
    private static final String PARAM_USU_BAJA = "USU_BAJA";

 
 
    private static final String SQL_CANDIDATOS_DESDE_SOLICITUDES =
        "SELECT DISTINCT SOL.ID_SITIO " +
        "  FROM BDDSEG01.T3SEGO_SOLI SOL " +
        " WHERE (:" + PARAM_GRUPO_OPERADOR + " LIKE SOL.GRUPO_OPERADOR || '%') " + 
        "   AND SOL.ID_ESTADO_SOLI = 12 " + 
        "   AND SOL.ID_SITIO IS NOT NULL";

    private static final String SQL_SUSC_LIST =
            "SELECT S.ID_SITIO " +
            "  FROM BDDSEG01.T3SINO_SUSC_SITI S " +
            " WHERE S.CONC_ID = :" + PARAM_CONC_ID +
            "   AND S.ACTIVO = 'S'";

    private static final String SQL_SUSC_EXISTS =
            "SELECT COUNT(1) " +
            "  FROM BDDSEG01.T3SINO_SUSC_SITI S " +
            " WHERE S.CONC_ID = :" + PARAM_CONC_ID +
            "   AND S.ID_SITIO = :" + PARAM_ID_SITIO +
            "   AND S.ACTIVO = 'S'";

    private static final String SQL_MAX_ID_SUSC =
            "SELECT NVL(MAX(S.ID_SUSC), 0) " +
            "  FROM BDDSEG01.T3SINO_SUSC_SITI S";

    private static final String SQL_INSERT_SUSC =
            "INSERT INTO BDDSEG01.T3SINO_SUSC_SITI (ID_SUSC, CONC_ID, ID_SITIO, ACTIVO, USU_ALTA, FEC_ALTA) " +
            "VALUES (:" + PARAM_ID_SUSC + ", :" + PARAM_CONC_ID + ", :" + PARAM_ID_SITIO + ", 'S', :" + PARAM_USU_ALTA + ", SYSDATE)";

    private static final String SQL_CANCEL_SUSC =
            "UPDATE BDDSEG01.T3SINO_SUSC_SITI " +
            "   SET ACTIVO = 'N', USU_BAJA = :" + PARAM_USU_BAJA + ", FEC_BAJA = SYSDATE " +
            " WHERE CONC_ID = :" + PARAM_CONC_ID +
            "   AND ID_SITIO = :" + PARAM_ID_SITIO +
            "   AND ACTIVO = 'S'";

    @PersistenceContext
    private EntityManager entityManager;

    private Session getHibernateSession() {
        if (entityManager == null) {
            throw new IllegalStateException("[SUSC][DAO] EntityManager es null (no hay @PersistenceContext disponible).");
        }
        return entityManager.unwrap(Session.class);
    }

    @Override
	public Set<String> listarSitiosSuscritos(String concesionarioId) {
		LOGGER.info("[SUSC][DAO] Iniciando sincronización automática para: {}", concesionarioId);

		try {
			// 1. PRIMERO LIMPIAMOS: Apagamos ('N') los que ya no están en estatus 12
			autoLimpiarSuscripcionesInvalidas(concesionarioId);

			// 2. DESPUÉS POBLAMOS: Agregamos ('S') los nuevos que sí llegaron al 12
			int detectados = autoPoblarSuscripcionesDesdeSolicitudes(concesionarioId);
			if (detectados > 0) {
				LOGGER.info("[SUSC][DAO] Se detectaron y activaron {} sitios del historial.", detectados);
			}
		} catch (Exception e) {
			LOGGER.warn("[SUSC][DAO] No se pudo sincronizar historial: {}", e.getMessage());
		}

		// 3. RETORNO DE DATOS: Consultamos la tabla final ya limpia y sincronizada
		return consultarSitiosSuscritosEnTabla(concesionarioId);
	}

	// ---> VERIFICA QUE ESTE MÉTODO ESTÉ AQUÍ, CREADO CORRECTAMENTE <---
	private int autoLimpiarSuscripcionesInvalidas(String concesionarioId) {
		Session session = getHibernateSession();
		SQLQuery update = session.createSQLQuery(SQL_AUTO_CLEANUP);
		update.setParameter(PARAM_CONC_ID, concesionarioId);
		update.setParameter(PARAM_GRUPO_OPERADOR, concesionarioId);
		
		int rows = update.executeUpdate();
		if (rows > 0) {
			LOGGER.info("[SUSC][DAO] autoLimpiar OK - Se desactivaron {} sitios que retrocedieron de estatus para el concesionario {}", rows, concesionarioId);
		}
		return rows;
	}

    @Override
    public void registrarSuscripcion(String concesionarioId, String sitioId, String usuarioAlta) {
        if (concesionarioId == null || concesionarioId.trim().isEmpty()) {
            throw new IllegalArgumentException("[SUSC][DAO] concesionarioId es obligatorio.");
        }
        if (sitioId == null || sitioId.trim().isEmpty()) {
            throw new IllegalArgumentException("[SUSC][DAO] sitioId es obligatorio.");
        }
        if (usuarioAlta == null || usuarioAlta.trim().isEmpty()) {
            throw new IllegalArgumentException("[SUSC][DAO] usuarioAlta es obligatorio.");
        }

        Session session = getHibernateSession();

        long siguienteId = getMaxIdSuscripcionSitio() + 1L;
        SQLQuery insert = session.createSQLQuery(SQL_INSERT_SUSC);
        insert.setParameter(PARAM_ID_SUSC, siguienteId);
        insert.setParameter(PARAM_CONC_ID, concesionarioId);
        insert.setParameter(PARAM_ID_SITIO, sitioId);
        insert.setParameter(PARAM_USU_ALTA, usuarioAlta);

        insert.executeUpdate();
    }

    @Override
    public boolean existeSuscripcionActiva(String concesionarioId, String sitioId) {
        Session session = getHibernateSession();

        SQLQuery query = session.createSQLQuery(SQL_SUSC_EXISTS);
        query.setParameter(PARAM_CONC_ID, concesionarioId);
        query.setParameter(PARAM_ID_SITIO, sitioId);

        Number count = (Number) query.uniqueResult();
        return count != null && count.intValue() > 0;
    }

    @Override
    public void cancelarSuscripcion(String concesionarioId, String sitioId, String usuarioBaja) {
        if (concesionarioId == null || concesionarioId.trim().isEmpty()) {
            throw new IllegalArgumentException("[SUSC][DAO] concesionarioId es obligatorio.");
        }
        if (sitioId == null || sitioId.trim().isEmpty()) {
            throw new IllegalArgumentException("[SUSC][DAO] sitioId es obligatorio.");
        }
        if (usuarioBaja == null || usuarioBaja.trim().isEmpty()) {
            throw new IllegalArgumentException("[SUSC][DAO] usuarioBaja es obligatorio.");
        }

        Session session = getHibernateSession();

        SQLQuery update = session.createSQLQuery(SQL_CANCEL_SUSC);
        update.setParameter(PARAM_USU_BAJA, usuarioBaja);
        update.setParameter(PARAM_CONC_ID, concesionarioId);
        update.setParameter(PARAM_ID_SITIO, sitioId);

        update.executeUpdate();
    }

    private Set<String> consultarSitiosSuscritosEnTabla(String concesionarioId) {
        Session session = getHibernateSession();

        SQLQuery query = session.createSQLQuery(SQL_SUSC_LIST);
        query.setParameter(PARAM_CONC_ID, concesionarioId);

        @SuppressWarnings("unchecked")
        List<String> lista = query.list();

        if (lista == null || lista.isEmpty()) {
            return Collections.emptySet();
        }
        return new LinkedHashSet<String>(lista);
    }

    private int autoPoblarSuscripcionesDesdeSolicitudes(String concesionarioId) {
        List<String> candidatos = consultarSitiosCandidatosDesdeSolicitudes(concesionarioId);
        if (candidatos == null || candidatos.isEmpty()) {
            LOGGER.info("[SUSC][DAO] No hay candidatos desde solicitudes - grupoOperador={}", concesionarioId);
            return 0;
        }

        long baseId = getMaxIdSuscripcionSitio() + 1L;
        int insertados = 0;

        Session session = getHibernateSession();

        for (int i = 0; i < candidatos.size(); i++) {
            String sitioId = candidatos.get(i);
            long idSusc = baseId + i;

            // Evita duplicados si el auto-poblar se corre más de una vez
            if (existeSuscripcionActiva(concesionarioId, sitioId)) {
                continue;
            }

            SQLQuery insert = session.createSQLQuery(SQL_INSERT_SUSC);
            insert.setParameter(PARAM_ID_SUSC, idSusc);
            insert.setParameter(PARAM_CONC_ID, concesionarioId);
            insert.setParameter(PARAM_ID_SITIO, sitioId);
            insert.setParameter(PARAM_USU_ALTA, "SYSTEM_AUTOP"); // ajusta si tienes usuario real

            insert.executeUpdate();
            insertados++;
        }

        LOGGER.info("[SUSC][DAO] autoPoblar OK - grupoOperador={}, candidatos={}, insertados={}",
                concesionarioId, candidatos.size(), insertados);

        return insertados;
    }

    private List<String> consultarSitiosCandidatosDesdeSolicitudes(String concesionarioId) {
        Session session = getHibernateSession();

        SQLQuery query = session.createSQLQuery(SQL_CANDIDATOS_DESDE_SOLICITUDES);
        query.setParameter(PARAM_GRUPO_OPERADOR, concesionarioId);

        @SuppressWarnings("unchecked")
        List<String> sitios = query.list();

        int size = (sitios == null) ? 0 : sitios.size();
        LOGGER.info("[SUSC][DAO] candidatosDesdeSolicitudes size={} - grupoOperador={}", size, concesionarioId);

        return sitios;
    }

    private long getMaxIdSuscripcionSitio() {
        Session session = getHibernateSession();

        SQLQuery query = session.createSQLQuery(SQL_MAX_ID_SUSC);
        Object result = query.uniqueResult();

        if (result == null) {
            return 0L;
        }
        if (result instanceof BigDecimal) {
            return ((BigDecimal) result).longValue();
        }
        if (result instanceof Number) {
            return ((Number) result).longValue();
        }
        return Long.parseLong(result.toString());
    }
    
    
    private static final String SQL_AUTO_CLEANUP =
			"UPDATE BDDSEG01.T3SINO_SUSC_SITI S " +
			"   SET S.ACTIVO = 'N', S.USU_BAJA = 'SYSTEM_SYNC', S.FEC_BAJA = SYSDATE " +
			" WHERE S.CONC_ID = :" + PARAM_CONC_ID +
			"   AND S.ACTIVO = 'S' " +
			"   AND NOT EXISTS ( " +
			"       SELECT 1 " +
			"         FROM BDDSEG01.T3SEGO_SOLI SOL " +
			"        WHERE SOL.ID_SITIO = S.ID_SITIO " +
			"          AND (:" + PARAM_GRUPO_OPERADOR + " LIKE SOL.GRUPO_OPERADOR || '%') " +
			"          AND SOL.ID_ESTADO_SOLI = 12 " +
			"   )";
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.impl;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.ISuscripcionSitioDao;

@Repository
@Transactional
@SuppressWarnings({ "deprecation", "unchecked" })
public class SuscripcionSitioDaoImpl extends GenericFunctionDaoImpl implements ISuscripcionSitioDao {

    private static final String TABLA_SUSCRIPCION = "BDDSEG01.T3SINO_SUSC_SITI";

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public int registrarSuscripcion(String sitioId, String concesionarioId, String folioSolicitud, Timestamp fechaRegistro) {
        if (isBlank(sitioId) || isBlank(concesionarioId)) {
            return 0;
        }

        if (existeSuscripcionActiva(sitioId, concesionarioId)) {
            return 0;
        }

        Session session = sessionFactory.getCurrentSession();
        Long siguienteId = obtenerSiguienteId(session);

        Timestamp fechaAlta = (fechaRegistro != null) ? fechaRegistro : new Timestamp(System.currentTimeMillis());
        String usuarioAlta = !isBlank(folioSolicitud) ? folioSolicitud.trim() : "FLUJO_COLOCACION";

        String sql = "INSERT INTO " + TABLA_SUSCRIPCION + " " +
                "(ID_SUSC, CONC_ID, ID_SITIO, ACTIVO, USU_ALTA, FEC_ALTA) " +
                "VALUES (:idSusc, :concId, :idSitio, 'S', :usuAlta, :fecAlta)";

        SQLQuery query = session.createSQLQuery(sql);
        query.setParameter("idSusc", siguienteId);
        query.setParameter("concId", concesionarioId.trim());
        query.setParameter("idSitio", sitioId.trim());
        query.setParameter("usuAlta", usuarioAlta);
        query.setParameter("fecAlta", fechaAlta);

        return query.executeUpdate();
    }

    @Override
    public int inactivarSuscripcion(String sitioId, String concesionarioId, String usuarioBaja, Date fechaBaja) {
        if (isBlank(sitioId) || isBlank(concesionarioId)) {
            return 0;
        }

        Timestamp fecha = (fechaBaja != null) ? new Timestamp(fechaBaja.getTime()) : new Timestamp(System.currentTimeMillis());
        String usuario = !isBlank(usuarioBaja) ? usuarioBaja.trim() : "SISTEMA";

        String sql = "UPDATE " + TABLA_SUSCRIPCION + " " +
                "SET ACTIVO = 'N', USU_BAJA = :usuBaja, FEC_BAJA = :fecBaja " +
                "WHERE CONC_ID = :concId AND ID_SITIO = :idSitio AND ACTIVO = 'S'";

        SQLQuery query = sessionFactory.getCurrentSession().createSQLQuery(sql);
        query.setParameter("usuBaja", usuario);
        query.setParameter("fecBaja", fecha);
        query.setParameter("concId", concesionarioId.trim());
        query.setParameter("idSitio", sitioId.trim());

        return query.executeUpdate();
    }

    @Override
    public boolean existeSuscripcionActiva(String sitioId, String concesionarioId) {
        if (isBlank(sitioId) || isBlank(concesionarioId)) {
            return false;
        }

        String sql = "SELECT COUNT(1) FROM " + TABLA_SUSCRIPCION + " " +
                "WHERE CONC_ID = :concId AND ID_SITIO = :idSitio AND ACTIVO = 'S'";

        SQLQuery query = sessionFactory.getCurrentSession().createSQLQuery(sql);
        query.setParameter("concId", concesionarioId.trim());
        query.setParameter("idSitio", sitioId.trim());

        Number total = (Number) query.uniqueResult();
        return total != null && total.longValue() > 0;
    }

    @Override
    public List<String> getSitiosSuscritosPorConcesionario(String concesionarioId) {
        if (isBlank(concesionarioId)) {
            return Collections.emptyList();
        }

        String sql = "SELECT ID_SITIO FROM " + TABLA_SUSCRIPCION + " " +
                "WHERE CONC_ID = :concId AND ACTIVO = 'S' " +
                "ORDER BY ID_SITIO";

        SQLQuery query = sessionFactory.getCurrentSession().createSQLQuery(sql);
        query.setParameter("concId", concesionarioId.trim());

        return (List<String>) query.list();
    }

    @Override
    public List<String> obtenerSitiosPorConcesionario(String idConcesionario) {
        return getSitiosSuscritosPorConcesionario(idConcesionario);
    }

    private Long obtenerSiguienteId(Session session) {
        String sql = "SELECT NVL(MAX(ID_SUSC), 0) + 1 FROM " + TABLA_SUSCRIPCION;
        Number siguiente = (Number) session.createSQLQuery(sql).uniqueResult();
        return (siguiente == null) ? 1L : siguiente.longValue();
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}

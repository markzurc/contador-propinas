package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.impl;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import org.hibernate.Session;
import org.hibernate.SQLQuery;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.ISuscripcionSitioDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.IncidenciaSuscripcionSitio;

@Repository("suscripcionSitioDao")
public class SuscripcionSitioDaoImpl extends GenericFunctionDaoImpl implements ISuscripcionSitioDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(SuscripcionSitioDaoImpl.class);

	private static final String TABLA_SUSCRIPCION = "BDDSEG01.T3SINO_SUSC_SITI";
	private static final String ACTIVO_SI = "S";

	/**
	 * Consideramos como candidatas las solicitudes en estados de COLOCACION.
	 *
	 * Nota: se usa T3SEGC_ESTA_SOLI por DESCRIPCION para evitar hardcodeo de IDs.
	 */
	private static final String SQL_CANDIDATOS_DESDE_SOLICITUDES =
			" SELECT DISTINCT SOL.ID_SITIO "
					+ "   FROM BDDSEG01.T3SEGO_SOLI SOL "
					+ "   JOIN BDDSEG01.T3SEGC_SITI SIT ON SIT.SITIO = SOL.ID_SITIO "
					+ "  WHERE SOL.GRUPO_OPERADOR = :GRUPO_OPERADOR "
					+ "    AND SOL.ID_SITIO IS NOT NULL "
					+ "    AND SOL.ID_ESTADO_SOLI IN ( "
					+ "          SELECT ES.ID_ESTADO_SOLI "
					+ "            FROM BDDSEG01.T3SEGC_ESTA_SOLI ES "
					+ "           WHERE ES.ESTADO = 1 "
					+ "             AND UPPER(ES.DESCRIPCION) LIKE '%COLOCACION%' "
					+ "        ) ";

	@Override
	public List<String> listarSitiosSuscritos(String concesionarioId) {

		if (isBlank(concesionarioId)) {
			return Collections.emptyList();
		}

		Session session = null;
		try {
			session = this.getSession();

			List<String> sitios = consultarSitiosSuscritos(session, concesionarioId);
			if (sitios != null && !sitios.isEmpty()) {
				return sitios;
			}

			// Si la tabla est� vac�a para ese concesionario, intentamos auto-poblar.
			final int insertados = autoPoblarSuscripcionesDesdeSolicitudes(session, concesionarioId);
			LOGGER.info("Auto-poblado de suscripciones para concesionario {}: insertados={}", concesionarioId, insertados);

			return consultarSitiosSuscritos(session, concesionarioId);

		} catch (Exception exception) {
			LOGGER.error("Error al listarSitiosSuscritos para concesionario={}", concesionarioId, exception);
			return Collections.emptyList();
		} finally {
			// Si tu getSession() devuelve una sesi�n administrada por JPA, no la cierres aqu�.
		}
	}

	private List<String> consultarSitiosSuscritos(Session session, String concesionarioId) {
		@SuppressWarnings("unchecked")
		List<String> sitios = session.createSQLQuery(
				"SELECT ID_SITIO FROM " + TABLA_SUSCRIPCION + " WHERE CONC_ID = :CONC_ID AND ACTIVO = :ACTIVO")
				.setParameter("CONC_ID", concesionarioId)
				.setParameter("ACTIVO", ACTIVO_SI)
				.list();
		return sitios == null ? Collections.<String>emptyList() : sitios;
	}

	/**
	 * Inserta suscripciones para el concesionario a partir de solicitudes en COLOCACION,
	 * �nicamente cuando no existan suscripciones activas para esos sitios.
	 *
	 * Evita el error ORA-00904 porque NO usa columnas inexistentes en SITIOS (como ACTIVO).
	 */
	private int autoPoblarSuscripcionesDesdeSolicitudes(Session session, String concesionarioId) {

		final Integer grupoOperador = extraerGrupoOperador(concesionarioId);
		if (grupoOperador == null) {
			LOGGER.warn("No se pudo extraer GRUPO_OPERADOR desde concesionarioId='{}' (formato esperado '1202:BUENOCELL')", concesionarioId);
			return 0;
		}

		try {
			// Evita colisiones de ID (sin secuencia, sin cambios en BD).
			session.createSQLQuery("LOCK TABLE " + TABLA_SUSCRIPCION + " IN EXCLUSIVE MODE NOWAIT").executeUpdate();
		} catch (Exception lockException) {
			// No bloqueamos la operaci�n de la vista; solo no auto-poblamos en este intento.
			LOGGER.warn("No se pudo bloquear {} para auto-poblado. Se omite auto-poblado en este intento. Motivo={}",
					TABLA_SUSCRIPCION, lockException.getMessage());
			return 0;
		}

		final long baseId = obtenerBaseId(session);

		// 1) Reactivar si exist�an suscripciones inactivas para esos candidatos.
		final int reactivados = session.createSQLQuery(
				"UPDATE " + TABLA_SUSCRIPCION + " S "
						+ "   SET S.ACTIVO = :ACTIVO, S.USU_BAJA = NULL, S.FEC_BAJA = NULL "
						+ " WHERE S.CONC_ID = :CONC_ID "
						+ "   AND NVL(S.ACTIVO, 'N') <> :ACTIVO "
						+ "   AND S.ID_SITIO IN ( " + SQL_CANDIDATOS_DESDE_SOLICITUDES + " )")
				.setParameter("ACTIVO", ACTIVO_SI)
				.setParameter("CONC_ID", concesionarioId)
				.setParameter("GRUPO_OPERADOR", grupoOperador)
				.executeUpdate();

		// 2) Insertar los que no existan activos.
		final int insertados = session.createSQLQuery(
				"INSERT INTO " + TABLA_SUSCRIPCION + " (ID_SUSC, CONC_ID, ID_SITIO, ACTIVO, USU_ALTA, FEC_ALTA) "
						+ "SELECT (:BASE_ID + ROW_NUMBER() OVER (ORDER BY SRC.ID_SITIO)) AS ID_SUSC, "
						+ "       :CONC_ID, SRC.ID_SITIO, :ACTIVO, :USU_ALTA, SYSTIMESTAMP "
						+ "  FROM ( " + SQL_CANDIDATOS_DESDE_SOLICITUDES + " ) SRC "
						+ " WHERE NOT EXISTS ( "
						+ "       SELECT 1 FROM " + TABLA_SUSCRIPCION + " EXISTE "
						+ "        WHERE EXISTE.CONC_ID = :CONC_ID "
						+ "          AND EXISTE.ID_SITIO = SRC.ID_SITIO "
						+ "          AND EXISTE.ACTIVO = :ACTIVO "
						+ " )")
				.setParameter("BASE_ID", baseId)
				.setParameter("CONC_ID", concesionarioId)
				.setParameter("ACTIVO", ACTIVO_SI)
				.setParameter("USU_ALTA", "AUTO_SUSCRIPCION")
				.setParameter("GRUPO_OPERADOR", grupoOperador)
				.executeUpdate();

		LOGGER.info("Auto-poblarSuscripcionesDesdeSolicitudes(concesionarioId={}): reactivados={}, insertados={}, baseId={}",
				concesionarioId, reactivados, insertados, baseId);

		return insertados;
	}

	private long obtenerBaseId(Session session) {
		final BigDecimal maxId = (BigDecimal) session.createSQLQuery(
				"SELECT NVL(MAX(ID_SUSC), 0) FROM " + TABLA_SUSCRIPCION).uniqueResult();

		final long max = maxId == null ? 0L : maxId.longValue();

		// Base por tiempo para evitar colisi�n en inserts m�ltiples (sin secuencia).
		final long timeBase = System.currentTimeMillis() * 1000L;

		return Math.max(max, timeBase);
	}

	private Integer extraerGrupoOperador(String concesionarioId) {
		try {
			final String[] partes = concesionarioId.split(":");
			if (partes.length == 0 || isBlank(partes[0])) {
				return null;
			}
			return Integer.valueOf(partes[0].trim());
		} catch (Exception exception) {
			return null;
		}
	}

	@Override
	public void registrarSuscripcion(String folioSolicitud, String concesionarioId, String sitioId, String usuarioAlta) {

		if (isBlank(concesionarioId) || isBlank(sitioId)) {
			return;
		}

		Session session = null;
		try {
			session = this.getSession();

			// Evitar duplicado si ya existe activa.
			final BigDecimal existente = (BigDecimal) session.createSQLQuery(
					"SELECT COUNT(1) FROM " + TABLA_SUSCRIPCION + " WHERE CONC_ID = :CONC_ID AND ID_SITIO = :ID_SITIO AND ACTIVO = :ACTIVO")
					.setParameter("CONC_ID", concesionarioId)
					.setParameter("ID_SITIO", sitioId)
					.setParameter("ACTIVO", ACTIVO_SI)
					.uniqueResult();

			if (existente != null && existente.intValue() > 0) {
				return;
			}

			session.createSQLQuery("LOCK TABLE " + TABLA_SUSCRIPCION + " IN EXCLUSIVE MODE NOWAIT").executeUpdate();
			BigDecimal maxId = (BigDecimal) session.createSQLQuery("SELECT NVL(MAX(ID_SUSC), 0) FROM " + TABLA_SUSCRIPCION).uniqueResult();
			long nuevoId = (maxId == null ? 0 : maxId.longValue()) + 1;

			IncidenciaSuscripcionSitio entidad = new IncidenciaSuscripcionSitio();
			entidad.setIdSuscripcion(nuevoId);
			entidad.setIdConcesionario(concesionarioId);
			entidad.setIdSitio(sitioId);
			entidad.setActivo(ACTIVO_SI);
			entidad.setUsuarioAlta(isBlank(usuarioAlta) ? "AUTO_SUSCRIPCION" : usuarioAlta);

			session.save(entidad);

		} catch (Exception exception) {
			LOGGER.error("Error al registrarSuscripcion concesionarioId={}, sitioId={}", concesionarioId, sitioId, exception);
		}
	}

	private boolean isBlank(String value) {
		return value == null || value.trim().isEmpty();
	}
}

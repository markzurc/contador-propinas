package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.impl;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.ISuscripcionSitioDao;

@Repository
public class SuscripcionSitioDaoImpl extends GenericFunctionDaoImpl implements ISuscripcionSitioDao {

    private static final Logger LOGGER = LogManager.getLogger(SuscripcionSitioDaoImpl.class);

    private static final String ESQUEMA_SEG = "BDDSEG01";
    private static final String TABLA_SUSCRIPCION_SITIO = ESQUEMA_SEG + ".T3SINO_SUSC_SITI";
    private static final String TABLA_SOLICITUDES = ESQUEMA_SEG + ".T3SEGO_SOLI";
    private static final String TABLA_ESTATUS_SOLICITUD = ESQUEMA_SEG + ".T3SEGC_ESTA_SOLI";

    /**
     * IDs de estado de solicitud que corresponden al flujo de COLOCACI�N.
     * Ajusta esta lista si el cliente confirma otro subconjunto.
     */
    private static final List<Integer> ESTADOS_SOLICITUD_COLOCACION = Arrays.asList(21, 24, 30, 32, 34);

    @Override
    public void registrarSuscripcion(String folioSolicitud, String concesionarioId, String sitioId, Date fechaAlta) {
        if (esBlank(concesionarioId) || esBlank(sitioId)) {
            return;
        }

        if (this.existeSuscripcionActiva(concesionarioId, sitioId)) {
            return;
        }

        Long siguienteId = this.obtenerSiguienteId();
        if (siguienteId == null) {
            throw new IllegalStateException("No se pudo obtener un nuevo ID para T3SINO_SUSC_SITI.");
        }

        Session session = this.getSession();
        String insertSql = "INSERT INTO " + TABLA_SUSCRIPCION_SITIO
                + " (ID_SUSC, CONC_ID, ID_SITIO, ACTIVO, USU_ALTA, FEC_ALTA) "
                + " VALUES (:id, :concesionario, :sitio, 'S', :usuarioAlta, SYSTIMESTAMP)";

        SQLQuery insertQuery = session.createSQLQuery(insertSql);
        insertQuery.setParameter("id", siguienteId);
        insertQuery.setParameter("concesionario", concesionarioId);
        insertQuery.setParameter("sitio", sitioId);
        insertQuery.setParameter("usuarioAlta", this.obtenerUsuarioAlta());
        insertQuery.executeUpdate();
    }

    /**
     * Lista sitios suscritos por concesionario y, si es necesario, intenta auto-poblar la
     * tabla de suscripci�n a partir del flujo de solicitudes (COLOCACI�N).
     */
    @Override
    public Set<String> listarSitiosSuscritos(String concesionarioId) {
        if (esBlank(concesionarioId)) {
            return Collections.emptySet();
        }

        String concesionarioNormalizado = normalizarConcesionarioId(concesionarioId);

        Set<String> sitiosSuscritos = this.consultarSitiosSuscritosActivos(concesionarioNormalizado);

        try {
            Set<String> sitiosCandidatos = this.consultarSitiosCandidatosDesdeSolicitudes(concesionarioNormalizado);
            Set<String> sitiosNuevos = new HashSet<String>(sitiosCandidatos);
            sitiosNuevos.removeAll(sitiosSuscritos);

            if (!sitiosNuevos.isEmpty()) {
                LOGGER.info("Auto-poblando suscripciones para concesionario {}. Nuevos sitios: {}",
                        concesionarioNormalizado, sitiosNuevos.size());

                Date fechaAlta = new Date();
                for (String sitioId : sitiosNuevos) {
                    this.registrarSuscripcion(null, concesionarioNormalizado, sitioId, fechaAlta);
                }

                sitiosSuscritos = this.consultarSitiosSuscritosActivos(concesionarioNormalizado);
            }
        } catch (Exception exception) {
            LOGGER.error("Error al auto-poblar suscripciones para concesionario {}.", concesionarioNormalizado, exception);
        }

        return sitiosSuscritos;
    }

    @Override
    public boolean existeSuscripcion(String concesionarioId, String sitioId) {
        if (esBlank(concesionarioId) || esBlank(sitioId)) {
            return false;
        }
        return this.existeSuscripcionActiva(normalizarConcesionarioId(concesionarioId), sitioId);
    }

    @Override
    public void cancelarSuscripcion(String concesionarioId, String sitioId, Date fechaBaja) {
        if (esBlank(concesionarioId) || esBlank(sitioId)) {
            return;
        }

        Session session = this.getSession();
        String sql = "UPDATE " + TABLA_SUSCRIPCION_SITIO
                + " SET ACTIVO = 'N', USU_BAJA = :usuarioBaja, FEC_BAJA = SYSTIMESTAMP "
                + " WHERE CONC_ID = :concesionario AND ID_SITIO = :sitio AND ACTIVO = 'S'";

        SQLQuery query = session.createSQLQuery(sql);
        query.setParameter("usuarioBaja", this.obtenerUsuarioAlta());
        query.setParameter("concesionario", normalizarConcesionarioId(concesionarioId));
        query.setParameter("sitio", sitioId);
        query.executeUpdate();
    }

    private Set<String> consultarSitiosSuscritosActivos(String concesionarioId) {
        Session session = this.getSession();
        String sql = "SELECT DISTINCT s.ID_SITIO "
                + "FROM " + TABLA_SUSCRIPCION_SITIO + " s "
                + "WHERE s.CONC_ID = :concesionario "
                + "AND s.ACTIVO = 'S'";

        SQLQuery query = session.createSQLQuery(sql);
        query.setParameter("concesionario", concesionarioId);

        @SuppressWarnings("unchecked")
        List<String> resultados = query.list();
        return resultados == null ? Collections.<String>emptySet() : new HashSet<String>(resultados);
    }

    /**
     * Obtiene los sitios "candidatos" desde solicitudes del concesionario en estados de COLOCACI�N.
     *
     * IMPORTANTE: En T3SEGC_ESTA_SOLI el campo correcto es ESTADO (no ACTIVO).
     * Esto corrige el ORA-00904: "S"."ACTIVO".
     */
    private Set<String> consultarSitiosCandidatosDesdeSolicitudes(String concesionarioId) {
        Session session = this.getSession();

        String sql = "SELECT DISTINCT so.ID_SITIO "
                + "FROM " + TABLA_SOLICITUDES + " so "
                + "JOIN " + TABLA_ESTATUS_SOLICITUD + " est ON est.ID_ESTADO_SOLI = so.ID_ESTADO_SOLI "
                + "WHERE so.GRUPO_OPERADOR = :concesionario "
                + "AND est.ESTADO = 1 "
                + "AND so.ID_SITIO IS NOT NULL "
                + "AND so.ID_ESTADO_SOLI IN (:estadosColocacion)";

        SQLQuery query = session.createSQLQuery(sql);
        query.setParameter("concesionario", concesionarioId);
        query.setParameterList("estadosColocacion", ESTADOS_SOLICITUD_COLOCACION);

        @SuppressWarnings("unchecked")
        List<String> resultados = query.list();
        return resultados == null ? Collections.<String>emptySet() : new HashSet<String>(resultados);
    }

    private String obtenerUsuarioAlta() {
        // Si ya tienes utilitario de usuario logueado, c�mbialo aqu�.
        return "SISTEMA";
    }

    private Long obtenerSiguienteId() {
        Session session = this.getSession();
        String sql = "SELECT NVL(MAX(ID_SUSC), 0) + 1 AS NEXT_ID FROM " + TABLA_SUSCRIPCION_SITIO;

        SQLQuery query = session.createSQLQuery(sql);
        Object resultado = query.uniqueResult();
        return resultado == null ? null : ((Number) resultado).longValue();
    }

    private boolean existeSuscripcionActiva(String concesionarioId, String sitioId) {
        Session session = this.getSession();
        String sql = "SELECT COUNT(1) FROM " + TABLA_SUSCRIPCION_SITIO
                + " WHERE CONC_ID = :concesionario AND ID_SITIO = :sitio AND ACTIVO = 'S'";

        SQLQuery query = session.createSQLQuery(sql);
        query.setParameter("concesionario", concesionarioId);
        query.setParameter("sitio", sitioId);

        Object resultado = query.uniqueResult();
        return resultado != null && ((Number) resultado).intValue() > 0;
    }

    private Session getSession() {
        return (Session) super.entityManager.getDelegate();
    }

    private boolean esBlank(String valor) {
        return valor == null || valor.trim().isEmpty();
    }

    /**
     * Normaliza el identificador del concesionario para uso en BD.
     * Ejemplo: "1202:BUENOCELL." -> "1202"
     */
    private String normalizarConcesionarioId(String concesionarioId) {
        if (esBlank(concesionarioId)) {
            return concesionarioId;
        }

        String valor = concesionarioId.trim();

        int separador = valor.indexOf(':');
        if (separador > 0) {
            String codigo = valor.substring(0, separador).trim();
            return codigo.isEmpty() ? valor : codigo;
        }

        // Por si viene con punto final
        if (valor.endsWith(".")) {
            valor = valor.substring(0, valor.length() - 1).trim();
        }

        return valor;
    }
}

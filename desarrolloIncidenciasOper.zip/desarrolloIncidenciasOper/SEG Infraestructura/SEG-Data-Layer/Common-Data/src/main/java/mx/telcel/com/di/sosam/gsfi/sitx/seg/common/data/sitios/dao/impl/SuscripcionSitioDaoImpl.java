package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.impl;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.ISuscripcionSitioDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.entity.SuscripcionSitio;

@Repository
public class SuscripcionSitioDaoImpl extends GenericFunctionDaoImpl implements ISuscripcionSitioDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(SuscripcionSitioDaoImpl.class);

    private static final String PARAM_GRUPO_OPERADOR = "GRUPO_OPERADOR";
    private static final String PARAM_CONC_ID = "CONC_ID";
    private static final String PARAM_ID_SITIO = "ID_SITIO";
    private static final String PARAM_ID_SUSC = "ID_SUSC";
    private static final String PARAM_USU_ALTA = "USU_ALTA";

    /**
     * Importante:
     * - NO usar SOL.ESTADO (no existe en T3SEGO_SOLI)
     * - El estado activo del catálogo va en ES.ESTADO
     * - La solicitud trae SOL.ID_ESTADO_SOLI
     */
    private static final String SQL_CANDIDATOS_DESDE_SOLICITUDES =
            "SELECT DISTINCT SOL.ID_SITIO " +
            "  FROM BDDSEG01.T3SEGO_SOLI SOL " +
            "  JOIN BDDSEG01.T3SEGC_ESTA_SOLI ES " +
            "    ON ES.ID_ESTADO_SOLI = SOL.ID_ESTADO_SOLI " +
            " WHERE SOL.GRUPO_OPERADOR = :" + PARAM_GRUPO_OPERADOR +
            "   AND ES.ESTADO = 1 " +
            "   AND UPPER(ES.DESCRIPCION) LIKE '%COLOCACION%'";

    private static final String SQL_SUSC_LIST =
            "SELECT S.ID_SITIO " +
            "  FROM BDDSEG01.T3SINO_SUSC_SITI S " +
            " WHERE S.CONC_ID = :" + PARAM_CONC_ID +
            "   AND S.ACTIVO = 'S'";

    private static final String SQL_SUSC_EXISTS =
            "SELECT COUNT(1) " +
            "  FROM BDDSEG01.T3SINO_SUSC_SITI S " +
            " WHERE S.CONC_ID = :" + PARAM_CONC_ID +
            "   AND S.ID_SITIO = :" + PARAM_ID_SITIO +
            "   AND S.ACTIVO = 'S'";

    private static final String SQL_MAX_ID_SUSC =
            "SELECT NVL(MAX(S.ID_SUSC), 0) " +
            "  FROM BDDSEG01.T3SINO_SUSC_SITI S";

    private static final String SQL_INSERT_SUSC =
            "INSERT INTO BDDSEG01.T3SINO_SUSC_SITI (ID_SUSC, CONC_ID, ID_SITIO, ACTIVO, USU_ALTA, FEC_ALTA) " +
            "VALUES (:" + PARAM_ID_SUSC + ", :" + PARAM_CONC_ID + ", :" + PARAM_ID_SITIO + ", 'S', :" + PARAM_USU_ALTA + ", SYSDATE)";

    @PersistenceContext
    private EntityManager entityManager;

    private Session getHibernateSession() {
        if (entityManager == null) {
            throw new IllegalStateException("[SUSC][DAO] EntityManager es null (no hay @PersistenceContext disponible).");
        }
        return entityManager.unwrap(Session.class);
    }

    @Override
    public Set<String> listarSitiosSuscritos(String concesionarioId) {
        LOGGER.info("[SUSC][DAO] listarSitiosSuscritos INICIO - grupoOperador={}", concesionarioId);

        Set<String> sitios = consultarSitiosSuscritosEnTabla(concesionarioId);
        LOGGER.info("[SUSC][DAO] sitiosEnTabla size={} - grupoOperador={}", sitios.size(), concesionarioId);

        if (sitios.isEmpty()) {
            int insertados = autoPoblarSuscripcionesDesdeSolicitudes(concesionarioId);
            LOGGER.info("[SUSC][DAO] autoPoblar insertados={} - grupoOperador={}", insertados, concesionarioId);

            sitios = consultarSitiosSuscritosEnTabla(concesionarioId);
            LOGGER.info("[SUSC][DAO] sitiosEnTabla POST-autoPoblar size={} - grupoOperador={}", sitios.size(), concesionarioId);
        }

        LOGGER.info("[SUSC][DAO] listarSitiosSuscritos FIN - grupoOperador={}, sitios.size={}", concesionarioId, sitios.size());
        return sitios;
    }

    @Override
    public void registrarSuscripcion(SuscripcionSitio entidad) {
        Session session = getHibernateSession();
        session.save(entidad);
    }

    @Override
    public boolean existeSuscripcionActiva(String concesionarioId, String sitioId) {
        Session session = getHibernateSession();
        SQLQuery query = session.createSQLQuery(SQL_SUSC_EXISTS);
        query.setParameter(PARAM_CONC_ID, concesionarioId);
        query.setParameter(PARAM_ID_SITIO, sitioId);

        Number count = (Number) query.uniqueResult();
        return count != null && count.intValue() > 0;
    }

    @Override
    public void cancelarTodasSuscripciones(String concesionarioId, String usuario) {
        // Si ya tienes implementación en tu base, déjala.
        // (No la toco para no romper tu flujo).
        throw new UnsupportedOperationException("cancelarTodasSuscripciones no implementado en este ajuste.");
    }

    private Set<String> consultarSitiosSuscritosEnTabla(String concesionarioId) {
        Session session = getHibernateSession();
        SQLQuery query = session.createSQLQuery(SQL_SUSC_LIST);
        query.setParameter(PARAM_CONC_ID, concesionarioId);

        @SuppressWarnings("unchecked")
        List<String> lista = query.list();

        if (lista == null || lista.isEmpty()) {
            return Collections.emptySet();
        }
        return new LinkedHashSet<String>(lista);
    }

    private int autoPoblarSuscripcionesDesdeSolicitudes(String concesionarioId) {
        List<String> candidatos = consultarSitiosCandidatosDesdeSolicitudes(concesionarioId);
        if (candidatos == null || candidatos.isEmpty()) {
            LOGGER.info("[SUSC][DAO] No hay candidatos desde solicitudes - grupoOperador={}", concesionarioId);
            return 0;
        }

        long baseId = getMaxIdSuscripcionSitio() + 1L;
        int insertados = 0;

        Session session = getHibernateSession();

        for (int i = 0; i < candidatos.size(); i++) {
            String sitioId = candidatos.get(i);
            long idSusc = baseId + i;

            // Evita duplicados si el auto-poblar se corre más de una vez
            if (existeSuscripcionActiva(concesionarioId, sitioId)) {
                continue;
            }

            SQLQuery insert = session.createSQLQuery(SQL_INSERT_SUSC);
            insert.setParameter(PARAM_ID_SUSC, idSusc);
            insert.setParameter(PARAM_CONC_ID, concesionarioId);
            insert.setParameter(PARAM_ID_SITIO, sitioId);
            insert.setParameter(PARAM_USU_ALTA, "SYSTEM_AUTOP"); // ajusta si tienes usuario real

            insert.executeUpdate();
            insertados++;
        }

        LOGGER.info("[SUSC][DAO] autoPoblar OK - grupoOperador={}, candidatos={}, insertados={}",
                concesionarioId, candidatos.size(), insertados);

        return insertados;
    }

    private List<String> consultarSitiosCandidatosDesdeSolicitudes(String concesionarioId) {
        Session session = getHibernateSession();

        SQLQuery query = session.createSQLQuery(SQL_CANDIDATOS_DESDE_SOLICITUDES);
        query.setParameter(PARAM_GRUPO_OPERADOR, concesionarioId);

        @SuppressWarnings("unchecked")
        List<String> sitios = query.list();

        int size = (sitios == null) ? 0 : sitios.size();
        LOGGER.info("[SUSC][DAO] candidatosDesdeSolicitudes size={} - grupoOperador={}", size, concesionarioId);

        return sitios;
    }

    private long getMaxIdSuscripcionSitio() {
        Session session = getHibernateSession();
        SQLQuery query = session.createSQLQuery(SQL_MAX_ID_SUSC);

        Object result = query.uniqueResult();
        if (result == null) {
            return 0L;
        }
        if (result instanceof BigDecimal) {
            return ((BigDecimal) result).longValue();
        }
        if (result instanceof Number) {
            return ((Number) result).longValue();
        }
        return Long.parseLong(result.toString());
    }
}

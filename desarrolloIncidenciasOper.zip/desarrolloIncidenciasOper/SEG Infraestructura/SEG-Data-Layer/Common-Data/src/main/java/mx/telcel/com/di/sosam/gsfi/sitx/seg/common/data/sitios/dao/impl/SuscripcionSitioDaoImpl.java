package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.impl;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.ISuscripcionSitioDao;

@Repository
@Transactional
@SuppressWarnings({ "deprecation", "unchecked" })
public class SuscripcionSitioDaoImpl extends GenericFunctionDaoImpl implements ISuscripcionSitioDao {

    private static final String TABLA_SUSCRIPCION = "BDDSEG01.T3SINO_SUSC_SITI";

    @Override
    public void registrarSuscripcion(String folioSolicitud, String concesionarioId, String sitioId, Date fechaAlta) {

        if (isBlank(sitioId) || isBlank(concesionarioId)) {
            return;
        }

        if (existeSuscripcion(concesionarioId, sitioId)) {
            return;
        }

        Session session = getSession();

        // Robustez (MAX+1 sin secuencias)
        aplicarLockTabla(session);

        Long siguienteId = obtenerSiguienteId(session);

        Date fecha = (fechaAlta != null) ? fechaAlta : new Date();
        String usuarioAlta = !isBlank(folioSolicitud) ? folioSolicitud.trim() : "FLUJO_COLOCACION";

        String sql = "INSERT INTO " + TABLA_SUSCRIPCION + " "
                + "(ID_SUSC, CONC_ID, ID_SITIO, ACTIVO, USU_ALTA, FEC_ALTA) "
                + "VALUES (:idSusc, :concId, :idSitio, 'S', :usuAlta, :fecAlta)";

        SQLQuery query = session.createSQLQuery(sql);
        query.setParameter("idSusc", siguienteId);
        query.setParameter("concId", concesionarioId.trim());
        query.setParameter("idSitio", sitioId.trim());
        query.setParameter("usuAlta", usuarioAlta);
        query.setParameter("fecAlta", new java.sql.Timestamp(fecha.getTime()));

        query.executeUpdate();
    }

    @Override
    public List<String> listarSitiosSuscritos(String concesionarioId) {

        if (isBlank(concesionarioId)) {
            return Collections.emptyList();
        }

        Session session = getSession();

        String sql = "SELECT ID_SITIO FROM " + TABLA_SUSCRIPCION + " "
                + "WHERE CONC_ID = :concId AND ACTIVO = 'S' "
                + "ORDER BY ID_SITIO";

        SQLQuery query = session.createSQLQuery(sql);
        query.setParameter("concId", concesionarioId.trim());

        return (List<String>) query.list();
    }

    @Override
    public boolean existeSuscripcion(String concesionarioId, String sitioId) {

        if (isBlank(sitioId) || isBlank(concesionarioId)) {
            return false;
        }

        Session session = getSession();

        String sql = "SELECT COUNT(1) FROM " + TABLA_SUSCRIPCION + " "
                + "WHERE CONC_ID = :concId AND ID_SITIO = :idSitio AND ACTIVO = 'S'";

        SQLQuery query = session.createSQLQuery(sql);
        query.setParameter("concId", concesionarioId.trim());
        query.setParameter("idSitio", sitioId.trim());

        Number total = (Number) query.uniqueResult();
        return total != null && total.longValue() > 0;
    }

    @Override
    public void cancelarSuscripcion(String folioSolicitud, String concesionarioId, String sitioId) {

        if (isBlank(sitioId) || isBlank(concesionarioId)) {
            return;
        }

        Session session = getSession();

        String usuarioBaja = !isBlank(folioSolicitud) ? folioSolicitud.trim() : "SISTEMA";
        java.sql.Timestamp fechaBaja = new java.sql.Timestamp(System.currentTimeMillis());

        String sql = "UPDATE " + TABLA_SUSCRIPCION + " "
                + "SET ACTIVO = 'N', USU_BAJA = :usuBaja, FEC_BAJA = :fecBaja "
                + "WHERE CONC_ID = :concId AND ID_SITIO = :idSitio AND ACTIVO = 'S'";

        SQLQuery query = session.createSQLQuery(sql);
        query.setParameter("usuBaja", usuarioBaja);
        query.setParameter("fecBaja", fechaBaja);
        query.setParameter("concId", concesionarioId.trim());
        query.setParameter("idSitio", sitioId.trim());

        query.executeUpdate();
    }

    private void aplicarLockTabla(Session session) {
        try {
            session.createSQLQuery("LOCK TABLE " + TABLA_SUSCRIPCION + " IN EXCLUSIVE MODE").executeUpdate();
        } catch (Exception ex) {
            // Si no se puede lockear por permisos/config, no rompemos el flujo.
        }
    }

    private Long obtenerSiguienteId(Session session) {
        String sql = "SELECT NVL(MAX(ID_SUSC), 0) + 1 FROM " + TABLA_SUSCRIPCION;
        Number siguiente = (Number) session.createSQLQuery(sql).uniqueResult();
        return (siguiente == null) ? 1L : siguiente.longValue();
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.impl;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.ISuscripcionSitioDao;

@Repository
public class SuscripcionSitioDaoImpl extends GenericFunctionDaoImpl implements ISuscripcionSitioDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(SuscripcionSitioDaoImpl.class);

    private static final String PARAM_GRUPO_OPERADOR = "GRUPO_OPERADOR";
    private static final String PARAM_CONC_ID = "CONC_ID";
    private static final String PARAM_ID_SITIO = "ID_SITIO";
    private static final String PARAM_ID_SUSC = "ID_SUSC";
    private static final String PARAM_USU_ALTA = "USU_ALTA";
    private static final String PARAM_USU_BAJA = "USU_BAJA";

 
 
    private static final String SQL_CANDIDATOS_DESDE_SOLICITUDES =
        "SELECT DISTINCT SOL.ID_SITIO " +
        "  FROM BDDSEG01.T3SEGO_SOLI SOL " +
        " WHERE (:" + PARAM_GRUPO_OPERADOR + " LIKE SOL.GRUPO_OPERADOR || '%') " + 
        "   AND SOL.ID_ESTADO_SOLI = 12 " + 
        "   AND SOL.ID_SITIO IS NOT NULL";

    private static final String SQL_SUSC_LIST =
            "SELECT S.ID_SITIO " +
            "  FROM BDDSEG01.T3SINO_SUSC_SITI S " +
            " WHERE S.CONC_ID = :" + PARAM_CONC_ID +
            "   AND S.ACTIVO = 'S'";

    private static final String SQL_SUSC_EXISTS =
            "SELECT COUNT(1) " +
            "  FROM BDDSEG01.T3SINO_SUSC_SITI S " +
            " WHERE S.CONC_ID = :" + PARAM_CONC_ID +
            "   AND S.ID_SITIO = :" + PARAM_ID_SITIO +
            "   AND S.ACTIVO = 'S'";

    private static final String SQL_MAX_ID_SUSC =
            "SELECT NVL(MAX(S.ID_SUSC), 0) " +
            "  FROM BDDSEG01.T3SINO_SUSC_SITI S";

    private static final String SQL_INSERT_SUSC =
            "INSERT INTO BDDSEG01.T3SINO_SUSC_SITI (ID_SUSC, CONC_ID, ID_SITIO, ACTIVO, USU_ALTA, FEC_ALTA) " +
            "VALUES (:" + PARAM_ID_SUSC + ", :" + PARAM_CONC_ID + ", :" + PARAM_ID_SITIO + ", 'S', :" + PARAM_USU_ALTA + ", SYSDATE)";

    private static final String SQL_CANCEL_SUSC =
            "UPDATE BDDSEG01.T3SINO_SUSC_SITI " +
            "   SET ACTIVO = 'N', USU_BAJA = :" + PARAM_USU_BAJA + ", FEC_BAJA = SYSDATE " +
            " WHERE CONC_ID = :" + PARAM_CONC_ID +
            "   AND ID_SITIO = :" + PARAM_ID_SITIO +
            "   AND ACTIVO = 'S'";
    private static final String SQL_SUSC_EXISTS_INACTIVE =
            "SELECT COUNT(1) " +
            "  FROM BDDSEG01.T3SINO_SUSC_SITI S " +
            " WHERE S.CONC_ID = :" + PARAM_CONC_ID +
            "   AND S.ID_SITIO = :" + PARAM_ID_SITIO +
            "   AND S.ACTIVO = 'N'";

    private static final String SQL_REACTIVATE_SUSC =
            "UPDATE BDDSEG01.T3SINO_SUSC_SITI S " +
            "   SET S.ACTIVO = 'S' " +
            " WHERE S.ID_SUSC = ( " +
            "       SELECT MAX(S2.ID_SUSC) " +
            "         FROM BDDSEG01.T3SINO_SUSC_SITI S2 " +
            "        WHERE S2.CONC_ID = :" + PARAM_CONC_ID +
            "          AND S2.ID_SITIO = :" + PARAM_ID_SITIO +
            "          AND S2.ACTIVO = 'N' " +
            " )";
    private static final String SQL_AUTO_CLEANUP =
 			"UPDATE BDDSEG01.T3SINO_SUSC_SITI S " +
 			"   SET S.ACTIVO = 'N', S.USU_BAJA = 'SYSTEM_SYNC', S.FEC_BAJA = SYSDATE " +
 			" WHERE S.CONC_ID = :" + PARAM_CONC_ID +
 			"   AND S.ACTIVO = 'S' " +
 			"   AND NOT EXISTS ( " +
 			"       SELECT 1 " +
 			"         FROM BDDSEG01.T3SEGO_SOLI SOL " +
 			"        WHERE SOL.ID_SITIO = S.ID_SITIO " +
 			"          AND (:" + PARAM_GRUPO_OPERADOR + " LIKE SOL.GRUPO_OPERADOR || '%') " +
 			"          AND SOL.ID_ESTADO_SOLI = 12 " +
 			"   )";
    @PersistenceContext
    private EntityManager entityManager;

    private Session getHibernateSession() {
        if (entityManager == null) {
            throw new IllegalStateException("EntityManager es null (no hay @PersistenceContext disponible).");
        }
        return entityManager.unwrap(Session.class);
    }

    @Override
	public Set<String> listarSitiosSuscritos(String concesionarioId) {

		try {
			autoLimpiarSuscripcionesInvalidas(concesionarioId);

			int detectados = autoPoblarSuscripcionesDesdeSolicitudes(concesionarioId);
			
		} catch (Exception e) {
			LOGGER.warn("No se pudo sincronizar historial: {}", e.getMessage());
		}

		return consultarSitiosSuscritosEnTabla(concesionarioId);
	}

	private int autoLimpiarSuscripcionesInvalidas(String concesionarioId) {
		Session session = getHibernateSession();
		SQLQuery update = session.createSQLQuery(SQL_AUTO_CLEANUP);
		update.setParameter(PARAM_CONC_ID, concesionarioId);
		update.setParameter(PARAM_GRUPO_OPERADOR, concesionarioId);
		
		int rows = update.executeUpdate();
		if (rows > 0) {
		}
		return rows;
	}

	@Override
	public void registrarSuscripcion(String concesionarioId, String sitioId, String usuarioAlta) {

	    if (concesionarioId == null || concesionarioId.trim().isEmpty()) {
	        return;
	    }
	    if (sitioId == null || sitioId.trim().isEmpty()) {
	        return;
	    }

	    if (existeSuscripcionActiva(concesionarioId, sitioId)) {
	        return;
	    }

	    if (existeSuscripcionInactiva(concesionarioId, sitioId)) {
	        reactivarSuscripcion(concesionarioId, sitioId);
	        return;
	    }

	    Session session = getHibernateSession();

	    long siguienteId = getMaxIdSuscripcionSitio() + 1L;

	    SQLQuery insert = session.createSQLQuery(SQL_INSERT_SUSC);
	    insert.setParameter(PARAM_ID_SUSC, siguienteId);
	    insert.setParameter(PARAM_CONC_ID, concesionarioId);
	    insert.setParameter(PARAM_ID_SITIO, sitioId);
	    insert.setParameter(PARAM_USU_ALTA, usuarioAlta);

	    insert.executeUpdate();
	}


    @Override
    public boolean existeSuscripcionActiva(String concesionarioId, String sitioId) {
        Session session = getHibernateSession();

        SQLQuery query = session.createSQLQuery(SQL_SUSC_EXISTS);
        query.setParameter(PARAM_CONC_ID, concesionarioId);
        query.setParameter(PARAM_ID_SITIO, sitioId);

        Number count = (Number) query.uniqueResult();
        return count != null && count.intValue() > 0;
    }

    @Override
    public void cancelarSuscripcion(String concesionarioId, String sitioId, String usuarioBaja) {
        if (concesionarioId == null || concesionarioId.trim().isEmpty()) {
            throw new IllegalArgumentException("concesionarioId es obligatorio.");
        }
        if (sitioId == null || sitioId.trim().isEmpty()) {
            throw new IllegalArgumentException("sitioId es obligatorio.");
        }
        if (usuarioBaja == null || usuarioBaja.trim().isEmpty()) {
            throw new IllegalArgumentException("usuarioBaja es obligatorio.");
        }

        Session session = getHibernateSession();

        SQLQuery update = session.createSQLQuery(SQL_CANCEL_SUSC);
        update.setParameter(PARAM_USU_BAJA, usuarioBaja);
        update.setParameter(PARAM_CONC_ID, concesionarioId);
        update.setParameter(PARAM_ID_SITIO, sitioId);

        update.executeUpdate();
    }

    private Set<String> consultarSitiosSuscritosEnTabla(String concesionarioId) {
        Session session = getHibernateSession();

        SQLQuery query = session.createSQLQuery(SQL_SUSC_LIST);
        query.setParameter(PARAM_CONC_ID, concesionarioId);

        @SuppressWarnings("unchecked")
        List<String> lista = query.list();

        if (lista == null || lista.isEmpty()) {
            return Collections.emptySet();
        }
        return new LinkedHashSet<String>(lista);
    }

    private int autoPoblarSuscripcionesDesdeSolicitudes(String concesionarioId) {
        List<String> candidatos = consultarSitiosCandidatosDesdeSolicitudes(concesionarioId);
        if (candidatos == null || candidatos.isEmpty()) {
            return 0;
        }

        long siguienteId = getMaxIdSuscripcionSitio() + 1L;
        int insertados = 0;

        Session session = getHibernateSession();

        for (String sitioId : candidatos) {

            if (existeSuscripcionActiva(concesionarioId, sitioId)) {
                continue;
            }

            if (existeSuscripcionInactiva(concesionarioId, sitioId)) {
                reactivarSuscripcion(concesionarioId, sitioId);
                continue;
            }

            SQLQuery insert = session.createSQLQuery(SQL_INSERT_SUSC);
            insert.setParameter(PARAM_ID_SUSC, siguienteId++);
            insert.setParameter(PARAM_CONC_ID, concesionarioId);
            insert.setParameter(PARAM_ID_SITIO, sitioId);
            insert.setParameter(PARAM_USU_ALTA, "SYSTEM_AUTOP");

            insert.executeUpdate();
            insertados++;
        }


                concesionarioId, candidatos.size(), insertados);

        return insertados;
    }

    private List<String> consultarSitiosCandidatosDesdeSolicitudes(String concesionarioId) {
        Session session = getHibernateSession();

        SQLQuery query = session.createSQLQuery(SQL_CANDIDATOS_DESDE_SOLICITUDES);
        query.setParameter(PARAM_GRUPO_OPERADOR, concesionarioId);

        @SuppressWarnings("unchecked")
        List<String> sitios = query.list();

        int size = (sitios == null) ? 0 : sitios.size();

        return sitios;
    }

    private long getMaxIdSuscripcionSitio() {
        Session session = getHibernateSession();

        SQLQuery query = session.createSQLQuery(SQL_MAX_ID_SUSC);
        Object result = query.uniqueResult();

        if (result == null) {
            return 0L;
        }
        if (result instanceof BigDecimal) {
            return ((BigDecimal) result).longValue();
        }
        if (result instanceof Number) {
            return ((Number) result).longValue();
        }
        return Long.parseLong(result.toString());
    }
    
    private boolean existeSuscripcionInactiva(String concesionarioId, String sitioId) {
        Session session = getHibernateSession();

        SQLQuery query = session.createSQLQuery(SQL_SUSC_EXISTS_INACTIVE);
        query.setParameter(PARAM_CONC_ID, concesionarioId);
        query.setParameter(PARAM_ID_SITIO, sitioId);

        Number count = (Number) query.uniqueResult();
        return count != null && count.intValue() > 0;
    }

    private void reactivarSuscripcion(String concesionarioId, String sitioId) {
        Session session = getHibernateSession();

        SQLQuery update = session.createSQLQuery(SQL_REACTIVATE_SUSC);
        update.setParameter(PARAM_CONC_ID, concesionarioId);
        update.setParameter(PARAM_ID_SITIO, sitioId);

        update.executeUpdate();
    }

 
}

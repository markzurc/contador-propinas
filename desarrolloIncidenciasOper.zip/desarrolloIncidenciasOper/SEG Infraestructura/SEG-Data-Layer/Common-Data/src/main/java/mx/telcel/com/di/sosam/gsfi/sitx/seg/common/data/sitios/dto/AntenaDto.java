package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto;

import java.io.Serializable;

public class AntenaDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7776453995074889145L;
	private Integer idAntena;
	private String tipo;
	private String dimenciones;
	private String peso;
	private Integer idFactibilidad;
	
	

	public AntenaDto() {
	}

	public AntenaDto(Integer idAntena, String tipo, String dimenciones, String peso, Integer idFactibilidad) {
		super();
		this.idAntena = idAntena;
		this.tipo = tipo;
		this.dimenciones = dimenciones;
		this.peso = peso;
		this.idFactibilidad = idFactibilidad;
	}

	public Integer getIdAntena() {
		return idAntena;
	}

	public void setIdAntena(Integer idAntena) {
		this.idAntena = idAntena;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getDimenciones() {
		return dimenciones;
	}

	public void setDimenciones(String dimenciones) {
		this.dimenciones = dimenciones;
	}

	public String getPeso() {
		return peso;
	}

	public void setPeso(String peso) {
		this.peso = peso;
	}

	public Integer getIdFactibilidad() {
		return idFactibilidad;
	}

	public void setIdFactibilidad(Integer idFactibilidad) {
		this.idFactibilidad = idFactibilidad;
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dao.impl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.CInfoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.InfoSoliDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ServicioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SoliArchDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SolicitudDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.transformer.InfoReqTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.transformer.ServicioTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dao.ISolicitudesServiciosDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dto.AccionAvanceDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dto.GraficaDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dto.TranEstaInfDto;

@Repository(value = "consultaServiciosDao")
@Scope("prototype")
public class SolicitudesServiciosDaoImpl extends GenericFunctionDaoImpl
implements ISolicitudesServiciosDao, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5927713844014847278L;
	private Logger LOGGER = LogManager.getLogger(SolicitudesServiciosDaoImpl.class);
	private static final String INSERT_SOLICITUD = "T3SEGO_SOLI.INSERT_SOLICITUD";
	private static final String INSERT_INFO_SOLICITUD = "T3SEGO_INFO.INSERT_INFO_SOLICITUD";
	private static final String INSERT_INFO_SOLICITUD_ARCH = "T3SEGD_ARCH.INSERT_ARCH";
	private static final String SELECT_INFO_USU_BY_ID = "SELECT_INFO_USU_BY_ID";
	private static final String SELECT_INFO_REQ = "SELECT_INFO_REQ";
	private static final String SELECT_SITIO_CON_SOLICITUD = "SELECT_SITIO_CON_SOLICITUD";
	private static final String UPDATE_SOLICITUD = "T3SEGO_SOLI.UPDATE_SOLICITUD";
	private static final String UPDATE_INFO_SOLICITUD = "T3SEGO_INFO.UPDATE_INFO_SOLICITUD";
	private static final String UPDATE_ARCH_SOLICITUD = "T3SEGD_SOLI_ARCH.UPDATE_ARCH_SOLICITUD";
	private static final String SELECT_NOMBRE_USU_BY_ID = "SELECT_NOMBRE_USU_BY_ID";
	private static final String SELECT_COUNT_SOLICITUD_INF = "SELECT_COUNT_SOLICITUD_INF";
	
    @PersistenceContext
    private EntityManager em;

	@SuppressWarnings("unchecked")
	@Override
	public List<ServicioDto> listaServicios() {
		Session session = getSession();
		try {
			String sql = "SELECT ID_SERVICIO, DESCRIPCION FROM BDDSEG01.T3SEGC_SERV";

			Query query = session.createSQLQuery(sql);
			LOGGER.info(query.toString());
			query.setResultTransformer(new ServicioTransformer());
			return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar los Sitios: " + e.getMessage());
			return Collections.<ServicioDto>emptyList();
		}
	}

	@Override
	@Transactional
	public String getGpoOperUsuById(String idUsuario) {
	    String grupoOperUsu = null;
	    try {
	        Session session = getSession();
	        Query query = session.getNamedQuery(SELECT_INFO_USU_BY_ID)
	                                     .setString("USUARIO", idUsuario);
	        grupoOperUsu = query.uniqueResult().toString();
	    } catch (Exception e) {
	        LOGGER.error("Error en el m�todo obtenGpoOperUsuById: " + e.getMessage());
	    }
	    return grupoOperUsu;
	}
//	@Override
//	public List<String> findAllCorrAuto(Long rolAutorizador) {
//		logger.info("Ejecutando UserDaoImpl.findAllCorrAuto");
//		Session session = getSession();
//		//Query query = session.createQuery("SELECT correo FROM T7segoDatoUsuaInte WHERE rol ="+rolAutorizador);
//		Query query = session.getNamedQuery(UserDaoImpl.SELECT_CORREOS_BY_ROL_AUT);
//		query.setParameter("rolAutorizador", rolAutorizador);
//		@SuppressWarnings("unchecked")
//		List<String> lstCorrAuto = query.list();
//		return lstCorrAuto;
//	}

	
	@SuppressWarnings("unchecked")
	@Override
	public List<CInfoDto> getInfoReq() {
		Session session = getSession();
		try {
			Query query = session.getNamedQuery(SELECT_INFO_REQ);
			LOGGER.info(query.toString());
			query.setResultTransformer(new InfoReqTransformer());
			return query.list();
		} catch (Exception e) {
	        LOGGER.error("Error en el m�todo getInfoReq: " + e.getMessage());
			return Collections.<CInfoDto>emptyList();
		}
	}
	
	@Override
	@Transactional
	public SolicitudDto generaSolicitud(SolicitudDto generaSoliDto) throws Exception {
		Session session = getSession();
		try {
	        BigDecimal folioGenerado = (BigDecimal) session.createSQLQuery("SELECT BDDSEG01.SQ3SEGO_SOLI.NEXTVAL FROM DUAL").uniqueResult();
	        generaSoliDto.setFolio(folioGenerado.toString());
			Query query = session.
					getNamedQuery(INSERT_SOLICITUD)
						.setString("FOLIO", folioGenerado.toString())
						.setString("IDSITIO", generaSoliDto.getSitio())
						.setString("GRUPOOPER", generaSoliDto.getGrupoOperador())
						.setString("USUARIO", generaSoliDto.getUsuario())
						.setString("IDESTADOSOLI", generaSoliDto.getEstatus());
			query.executeUpdate();
		} catch (Exception e) {
			LOGGER.error("Error en el guardado de la solicitud, causa: " + e);
	        generaSoliDto.setFolio(null);
	        throw new Exception("Error en el guardado de la solicitud, causa: " + e);
		}
		return generaSoliDto;
	}

	@Override
	@Transactional
	public void generaSolicitudInfo(SolicitudDto solicitudDto) {
		Session session = getSession();
		try {
			Query query = session.
					getNamedQuery(INSERT_INFO_SOLICITUD)
						.setString("FOLIO", solicitudDto.getFolio());
			query.executeUpdate();
		} catch (Exception e) {
			LOGGER.error("Error en el guardado de la informacion de la solicitud, causa: " + e);
		}
	}

	@Override
	@Transactional
	public void generaSolicitudArch(List<SoliArchDto> archSoliDto) {
		Session session = getSession();
		try {
			
			for (SoliArchDto archSoli: archSoliDto ) {
				Query query = session.
						getNamedQuery(INSERT_INFO_SOLICITUD_ARCH)
							.setString("RUTA", archSoli.getRuta())
							.setString("DESCRIPCION", archSoli.getDescripcion())
							.setString("NOMBRE_ARCH", archSoli.getNombreArch())
							.setString("TAMANIO", archSoli.getTamanio())
							.setString("FECHA_CARGA", archSoli.getFechaCarga())
							.setString("REVISION", archSoli.getRevision())
							.setString("USUARIO", archSoli.getUsuario())
							.setInteger("ID_SECCION", archSoli.getIdSeccion())
							.setString("FOLIO", archSoli.getFolio());
				query.executeUpdate();
			}
			
		} catch (Exception e) {
			LOGGER.error("Error en el guardado en metodo generaSolicitudArch(), causa: " + e);
		}
		
	}

	@Override
	public boolean getSitioConSolicitud(SitioDto parametroSitio, String grupoOperdor) {//posible eliminacion
	    boolean sitioConSolicitud = true;
	    String result; 
	    try {
	        Session session = getSession();
	        Query query = session.getNamedQuery(SELECT_SITIO_CON_SOLICITUD)
	                                     .setString("ID_SITIO", parametroSitio.getSitio())
	                                     .setString("GRUPO_OPERADOR", grupoOperdor);
	        result = query.uniqueResult().toString();
	        if (Integer.valueOf(result).equals(0)) {
	        	sitioConSolicitud = false;
			}
	        
	    } catch (Exception e) {
	        LOGGER.error("Error en el m�todo getSitioConSolicitud: " + e.getMessage());
	    }
	    return sitioConSolicitud;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<GraficaDto> getDatosGrafica(String idEstado) {
		try {
			Session session = getSession();
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT ID_ESTATUS_GRAFICA AS \"idEstatusGrafica\", ");
			sql.append("ID_ESTADO_SOLI AS \"idEstadoSoli\", ");
			sql.append("DESCRIPCION AS \"descripcion\", ");
			sql.append("VALOR_GRAFICA AS \"valorGrafica\", ");
			sql.append("VALOR_TAB AS \"valorTab\", ");
			sql.append("COLOR AS \"color\", ");
			sql.append("ESTATUS AS \"estatus\" ");
			sql.append("FROM BDDSEG01.T3SEGC_ESTA_GRAF ");
			sql.append("WHERE ID_ESTADO_SOLI = :idEstado");

			Query query = session.createSQLQuery(sql.toString())
					.addScalar("idEstatusGrafica", StandardBasicTypes.INTEGER)
					.addScalar("idEstadoSoli", StandardBasicTypes.INTEGER)
					.addScalar("descripcion", StandardBasicTypes.STRING)
					.addScalar("valorGrafica", StandardBasicTypes.INTEGER)
					.addScalar("valorTab", StandardBasicTypes.INTEGER)
					.addScalar("color", StandardBasicTypes.STRING)
					.addScalar("estatus", StandardBasicTypes.INTEGER)
					.setResultTransformer(Transformers.aliasToBean(GraficaDto.class));
			query.setParameter("idEstado", idEstado);
			return query.list();

		} catch (Exception e) {
			LOGGER.error("Error al consultar datos de la grafica: " + e);
			return Collections.<GraficaDto>emptyList();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TranEstaInfDto> getDatosTransicion(String idEstado, Integer idRol) {
		try {
			Session session = getSession();
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT tran.ID_ESTATUS_ACTUAL AS idEstatusActual, ");
			sql.append("tran.ID_ESTATUS_SIGUIENTE AS idEstatusSiguiente, ");
			sql.append("acci.ID_ACCION AS idAccion, ");
			sql.append("acci.DESCRIPCION AS descripcion, ");
			sql.append("tran.flujo AS flujo, ");
			sql.append("esta.DESCRIPCION AS estatusSiguiente ");
			sql.append("FROM BDDSEG01.T3SEGC_TRAN_ESTA_INFR tran, BDDSEG01.T3SEGC_ACCI_FLUJ_INFR acci, BDDSEG01.T3SEGC_ESTA_SOLI esta ");
			sql.append("WHERE tran.ID_ACCION = acci.ID_ACCION ");
			sql.append("AND tran.ID_ESTATUS_SIGUIENTE = esta.ID_ESTADO_SOLI ");
			sql.append("AND tran.ID_ESTATUS_ACTUAL = :idEstado ");
			sql.append("AND tran.rol = :idRol ");

			Query query = session.createSQLQuery(sql.toString())
					.addScalar("idEstatusActual", StandardBasicTypes.INTEGER)
					.addScalar("idEstatusSiguiente", StandardBasicTypes.INTEGER)
					.addScalar("idAccion", StandardBasicTypes.STRING)
					.addScalar("descripcion", StandardBasicTypes.STRING)
					.addScalar("flujo", StandardBasicTypes.STRING)
					.addScalar("estatusSiguiente", StandardBasicTypes.STRING)
					.setResultTransformer(Transformers.aliasToBean(TranEstaInfDto.class));
			query.setParameter("idEstado", idEstado).setParameter("idRol", idRol);
			return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar datos de la grafica: " + e);
			return Collections.<TranEstaInfDto>emptyList();
		}
	}
	
	@Override
	@Transactional
	public SolicitudDto getSitioConSolicitudCrea(SitioDto parametroSitio, String grupoOperdor) { //add
		SolicitudDto sitioConSolicitud = new SolicitudDto();
		 StringBuilder sql = new StringBuilder();
	    try {
	        Session session = getSession();
	        sql.append("SELECT ID_FOLIO AS folio, ID_SITIO AS sitio, GRUPO_OPERADOR AS grupoOperador, USUARIO AS usuario, ID_ESTADO_SOLI AS idEstado FROM BDDSEG01.T3SEGO_SOLI WHERE ID_SITIO = :ID_SITIO AND GRUPO_OPERADOR = :GRUPO_OPERADOR AND FECHA_CREACION = ")
	           .append("(SELECT MAX(FECHA_CREACION) FROM BDDSEG01.T3SEGO_SOLI WHERE ID_SITIO = :ID_SITIO AND GRUPO_OPERADOR = :GRUPO_OPERADOR)" );
	        
	        Query query = session.createSQLQuery(sql.toString())
		            .addScalar("folio", StandardBasicTypes.STRING)
		            .addScalar("sitio", StandardBasicTypes.STRING)
		            .addScalar("grupoOperador", StandardBasicTypes.STRING)
		            .addScalar("usuario", StandardBasicTypes.STRING)
		            .addScalar("idEstado", StandardBasicTypes.STRING)
		            .setResultTransformer(Transformers.aliasToBean(SolicitudDto.class));
	        
	        query.setParameter("ID_SITIO", parametroSitio.getSitio());
	        query.setParameter("GRUPO_OPERADOR", grupoOperdor);

	        sitioConSolicitud = (SolicitudDto) query.uniqueResult();
	        
	        return sitioConSolicitud;
	    } catch (Exception e) {
	        LOGGER.error("Error en el m�todo getSitioConSolicitudCrea: " + e.getMessage());
	    }
	    return sitioConSolicitud;
	}
	
	@Override
	@Transactional
	public SolicitudDto getSitioConSolicitudConsulta(SitioDto parametroSitio) { //add
		SolicitudDto sitioConSolicitud = new SolicitudDto();
		 StringBuilder sql = new StringBuilder();
	    try {
	        Session session = getSession();
	        sql.append("SELECT ID_FOLIO AS folio, ID_SITIO AS sitio, GRUPO_OPERADOR AS grupoOperador, USUARIO AS usuario, ID_ESTADO_SOLI AS idEstado ")
	           .append("FROM BDDSEG01.T3SEGO_SOLI ")
	           .append("WHERE ID_FOLIO = :ID_FOLIO ");
	        
	        Query query = session.createSQLQuery(sql.toString())
		            .addScalar("folio", StandardBasicTypes.STRING)
		            .addScalar("sitio", StandardBasicTypes.STRING)
		            .addScalar("grupoOperador", StandardBasicTypes.STRING)
		            .addScalar("usuario", StandardBasicTypes.STRING)
		            .addScalar("idEstado", StandardBasicTypes.STRING)
		            .setResultTransformer(Transformers.aliasToBean(SolicitudDto.class));
	        
	        query.setParameter("ID_FOLIO", parametroSitio.getFolio());

	        sitioConSolicitud = (SolicitudDto) query.uniqueResult();
	        
	        return sitioConSolicitud;
	    } catch (Exception e) {
	        LOGGER.error("Error en el m�todo getSitioConSolicitudConsulta: " + e.getMessage());
	    }
	    return sitioConSolicitud;
	}
	
	@Override
	@Transactional
	public InfoSoliDto getInfoConSolicitudConsulta(SitioDto parametroSitio) { //add
		InfoSoliDto infoSoliDto = new InfoSoliDto();
		 StringBuilder sql = new StringBuilder();
	    try {
	        Session session = getSession();
	        sql.append("SELECT ID_INFO as idInfo, ID_FOLIO_SOLI as idFolioSoli, INF_ENTREGADA as informacionEntregada FROM BDDSEG01.T3SEGO_INFO WHERE ID_FOLIO_SOLI = :FOLIO ");
	        
	        Query query = session.createSQLQuery(sql.toString())
		            .addScalar("idInfo", StandardBasicTypes.INTEGER)
		            .addScalar("idFolioSoli", StandardBasicTypes.STRING)
		            .addScalar("informacionEntregada", StandardBasicTypes.STRING)
		            .setResultTransformer(Transformers.aliasToBean(InfoSoliDto.class));
	        
	        query.setParameter("FOLIO", parametroSitio.getFolio());

	        infoSoliDto = (InfoSoliDto) query.uniqueResult();

	        infoSoliDto = (infoSoliDto == null) ? new InfoSoliDto() : infoSoliDto;
	        
	        return infoSoliDto;
	    } catch (Exception e) {
	        LOGGER.error("Error en el m�todo getInfoConSolicitudConsulta: " + e.getMessage());
	        infoSoliDto = (infoSoliDto == null) ? new InfoSoliDto() : infoSoliDto;
	        return infoSoliDto;
	    }
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<AccionAvanceDto> getListaAcciones() { //add
		List<AccionAvanceDto> accionesAvance = new ArrayList<AccionAvanceDto>();
		 StringBuilder sql = new StringBuilder();
		try {
	        Session session = getSession();
	        sql.append(" SELECT * FROM BDDSEG01.T3SEGC_ACCI");
	        
	        Query query = session.createSQLQuery(sql.toString())
		            .addScalar("accion", StandardBasicTypes.INTEGER)
		            .addScalar("descripcion", StandardBasicTypes.STRING)
		            .setResultTransformer(Transformers.aliasToBean(AccionAvanceDto.class));
			
	        accionesAvance = query.list();

	        return accionesAvance;
	        
		} catch (Exception e) {
			LOGGER.error("Error al consultar las acciones");
			return Collections.<AccionAvanceDto>emptyList();
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<SoliArchDto> getLstArchSoli(SitioDto parametroSitio, List<String> tipoDocumentos) { //add
		List<SoliArchDto> lstArchSoli = new ArrayList<SoliArchDto>();
		 StringBuilder sql = new StringBuilder();
		try {
	        Session session = getSession();
	        sql.append(" SELECT ID_ARCHIVO AS idArchivo, RUTA AS ruta, DESCRIPCION AS descripcion, NOMBRE_ARCHIVO AS nombreArch, TAMANIO AS tamanio, to_char(FECHA_CARGA,'dd/MM/yyyy hh:mi:ss a.m.') AS fechaCarga , REVISION AS revision, USUARIO AS usuario, ID_SECCION AS idSeccion, ID_FOLIO AS folio, (SELECT NOMBRE || ' ' || APELLIDO_PATERNO || ' ' || APELLIDO_MATERNO FROM BDDSEG01.T3SEGO_USUA WHERE USUARIO = T1.USUARIO) as nombreUsu FROM BDDSEG01.T3SEGD_SOLI_ARCH T1 WHERE ID_FOLIO = :FOLIO AND DESCRIPCION IN(:DOCUMENTOS)");
	        
	        Query query = session.createSQLQuery(sql.toString())
		            .addScalar("idArchivo", StandardBasicTypes.INTEGER)
		            .addScalar("ruta", StandardBasicTypes.STRING)
		            .addScalar("descripcion", StandardBasicTypes.STRING)
		            .addScalar("nombreArch", StandardBasicTypes.STRING)
		            .addScalar("tamanio", StandardBasicTypes.STRING)
		            .addScalar("fechaCarga", StandardBasicTypes.STRING)
		            .addScalar("revision", StandardBasicTypes.STRING)
		            .addScalar("usuario", StandardBasicTypes.STRING)
		            .addScalar("idSeccion", StandardBasicTypes.INTEGER)
		            .addScalar("folio", StandardBasicTypes.STRING)
		            .addScalar("nombreUsu", StandardBasicTypes.STRING)

		            .setResultTransformer(Transformers.aliasToBean(SoliArchDto.class));
	        
	        query.setParameter("FOLIO", parametroSitio.getFolio());
	        query.setParameterList("DOCUMENTOS", tipoDocumentos);
			
	        lstArchSoli = query.list();

	        return lstArchSoli;
	        
		} catch (Exception e) {
			LOGGER.error("Error al consultar la lista de archivos de la solicitud");
			return Collections.<SoliArchDto>emptyList();
		}
	}
	
	@Override
	@Transactional
	public boolean updateSolicitud(SitioDto sitioDTO, String transicion) { //add
		Session session = getSession();
		try {
			Query query = session.
					getNamedQuery(UPDATE_SOLICITUD)
					.setString("ESTATUS", transicion)
						.setString("FOLIO", sitioDTO.getFolio());
//			query.executeUpdate();
	        int rowsAffected = query.executeUpdate();
	        return rowsAffected > 0;
		} catch (Exception e) {
			LOGGER.error("Error en la actualizacion de la solicitud, causa: " + e);
			return false;
		}		
	}
	
	@Override
	@Transactional
	public boolean updateSolicitudInfo(SitioDto sitioDTO, String info) { //add
		Session session = getSession();
		try {
			Query query = session.
					getNamedQuery(UPDATE_INFO_SOLICITUD)
					.setString("INF_ENTREGADA", info)
						.setString("FOLIO", sitioDTO.getFolio());
//			query.executeUpdate();
	        int rowsAffected = query.executeUpdate();
	        return rowsAffected > 0;
		} catch (Exception e) {
			LOGGER.error("Error en la actualizacion de la informacion de la solicitud, causa: " + e);
			return false;
		}		
	}
	
	@Override
	@Transactional
	public boolean updateSolicitudArch(List<SoliArchDto> lstArchFinal, SitioDto sitioDTO) { //add
		Session session = getSession();
		int rowsAffected = 0;
		try {
			for (SoliArchDto archFinal : lstArchFinal) {
				Query query = session.
						getNamedQuery(UPDATE_ARCH_SOLICITUD)
						.setString("RUTA", archFinal.getRuta())
						.setString("NOMBREARCH", archFinal.getNombreArch())
						.setString("TAMANIO", archFinal.getTamanio())
						.setString("REVISION", archFinal.getRevision())
						.setString("USUARIO", archFinal.getUsuario())
						.setString("FOLIO", sitioDTO.getFolio())
						.setString("IDARCH", archFinal.getIdArchivo().toString());
//				query.executeUpdate();
				rowsAffected = query.executeUpdate();
			}
			return rowsAffected > 0;

			
		} catch (Exception e) {
			LOGGER.error("Error en la actualizacion de la lista de archivos de la solicitud, causa: " + e);
			return false;
		}		
	}
	
	@Override
	@Transactional
	public String getNombreUsu(Integer idUsuario) {
	    String nombreUsuario = null;
	    try {
	        Session session = getSession();
	        Query query = session.getNamedQuery(SELECT_NOMBRE_USU_BY_ID)
	                                     .setInteger("USUARIO", idUsuario);
	        nombreUsuario = query.uniqueResult().toString();
	    } catch (Exception e) {
	        LOGGER.error("Error en el m�todo getNombreUsu: " + e.getMessage());
	    }
	    return nombreUsuario;
	}

	@Override
	public int getCountSolicitudInf(String folio) {
		int conteo = 0;
		try {
			Session session = getSession();
			Query query = session.getNamedQuery(SELECT_COUNT_SOLICITUD_INF).setString("folio", folio);
			conteo = ((BigDecimal) query.uniqueResult()).intValue();
		} catch (Exception e) {
			conteo = 0;
			LOGGER.error("Error al consultar getCountSolicitudInf: " + e);
		}
		return conteo;
	}
	
	@Override
	public String getIdAccion(String accion) {
		Session session = getSession();
        try{
            String sentencia = "SELECT ID_ACCION FROM BDDSEG01.T3SEGC_ACCI_FLUJ_INFR WHERE UPPER(DESCRIPCION) = :accion";
            Query query = session.createSQLQuery(sentencia);
            query.setParameter("accion", accion);
            String variable = query.list().get(0).toString() != null ? query.list().get(0).toString() : "0";
    		return variable;
        }catch(Exception e){
            return "0";
        }
	}
	
}

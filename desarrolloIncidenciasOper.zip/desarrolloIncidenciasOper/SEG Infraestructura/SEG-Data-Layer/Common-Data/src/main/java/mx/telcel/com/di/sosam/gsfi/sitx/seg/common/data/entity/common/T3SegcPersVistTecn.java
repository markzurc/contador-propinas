package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common;
import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "T3SEGC_PERS_VIST_TECN", schema="BDDSEG01")
public class T3SegcPersVistTecn  implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQSEGC_PERS_VIST_TECN")
    @SequenceGenerator(name = "SQSEGC_PERS_VIST_TECN", sequenceName = "BDDSEG01.SQSEGC_PERS_VIST_TECN", allocationSize = 1)
    @Column(name = "ID_PERSONAL_VISITA_TECNICA")
    private Integer idPersonalVisita;

    @Column(name = "NOMBRE", length = 30)
    private String nombre;

    @Column(name = "APELLIDO_PATERNO", length =30 )
    private String apellidoPaterno;

    @Column(name = "APELLIDO_MATERNO", length = 30)
    private String apellidoMaterno;

    @Column(name = "GRUPO_OPERADOR", length = 25)
    private String grupoOperador;
  
    @Column(name = "USUARIO_CRECACION")
    private Integer usuarioCreacion;

    @Column(name = "FECHA_CREACION")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaCreacion;

    @Column(name = "USUARIO_MODIFICACION")
    private Integer usuarioModificacion;

    @Column(name = "FECHA_MODIFICACION")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaModificacion;
    
    @Column(name = "ID_FOLIO")
    private String idFolio;
    
   
    
    
	public T3SegcPersVistTecn() {
		super();
	}
	
	public T3SegcPersVistTecn(T3SegcPersVistTecn original) {
	    this.idPersonalVisita = original.getIdPersonalVisita();
	    this.nombre = original.getNombre();
	    this.apellidoPaterno = original.getApellidoPaterno();
	    this.apellidoMaterno = original.getApellidoMaterno();
	    this.grupoOperador = original.getGrupoOperador();
	    this.usuarioCreacion = original.getUsuarioCreacion();
	    this.fechaCreacion = original.getFechaCreacion();
	    this.usuarioModificacion = original.getUsuarioModificacion();
	    this.fechaModificacion = original.getFechaModificacion();
	    this.idFolio = original.getIdFolio();
	}

	public String getNombre() {
        return nombre;
    }

    public Integer getIdPersonalVisita() {
		return idPersonalVisita;
	}

	public void setIdPersonalVisita(Integer idPersonalVisita) {
		this.idPersonalVisita = idPersonalVisita;
	}

	public Integer getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(Integer usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public Integer getUsuarioModificacion() {
		return usuarioModificacion;
	}

	public void setUsuarioModificacion(Integer usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public String getGrupoOperador() {
        return grupoOperador;
    }

    public void setGrupoOperador(String grupoOperador) {
        this.grupoOperador = grupoOperador;
    }

	public String getIdFolio() {
		return idFolio;
	}

	public void setIdFolio(String idFolio) {
		this.idFolio = idFolio;
	}

}



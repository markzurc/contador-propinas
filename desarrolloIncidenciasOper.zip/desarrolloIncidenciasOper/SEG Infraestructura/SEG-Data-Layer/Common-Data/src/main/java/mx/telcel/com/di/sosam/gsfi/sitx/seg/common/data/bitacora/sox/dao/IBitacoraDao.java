package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dao;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dto.BitacoraDto;

public interface IBitacoraDao {

	public boolean insertaBitacora(BitacoraDto bitacoraDto);
	
	public List<BitacoraDto> obtenerAcciones(String idSoli);

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dao;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dto.BitacoraSoxDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segbBita;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.utils.session.ISession;

/**
 * 
 * <h1>IBitacoraSoxDao</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 11/05/2015
 */
public interface IBitacoraSoxDao extends ISession{
	
	/**
	 * 
	 * @param tsegcBitacoraSox {@link TsegcBitacoraSox}
	 */
	void createBitacoraSox(T7segbBita tsegcBitacoraSox);
	
	/**
	 * 
	 * @param idUsuario {@link Integer}
	 * @return {@link Integer}
	 */
	Integer getNumberOfElements(Integer idUsuario);
	
	/**
	 * 
	 * @param idUsuario {@link Integer}
	 * @param sizePage {@link Integer}
	 * @param pageNomber {@link Integer}
	 * @return {@link List}<{@link BitacoraSoxDto}>
	 */
	List<BitacoraSoxDto> getContentPage(Integer idUsuario, Integer sizePage, Integer pageNomber);
}

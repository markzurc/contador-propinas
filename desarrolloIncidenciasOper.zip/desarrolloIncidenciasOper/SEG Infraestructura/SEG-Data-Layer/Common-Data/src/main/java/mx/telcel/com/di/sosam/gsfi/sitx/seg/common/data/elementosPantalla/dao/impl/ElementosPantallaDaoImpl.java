package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.stereotype.Repository;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dao.IElementosPantallaDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ConfiguracionElementoEditableDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ElementosPantallaDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;

@Repository
public class ElementosPantallaDaoImpl   extends GenericFunctionDaoImpl  implements IElementosPantallaDao{


	public List<ElementosPantallaDTO> getElementosPantalla(String flujo, Integer idRol) {
	    List<ElementosPantallaDTO> resultado = new ArrayList<>();
	    
	    try {
	        Session session = getSession();
	        StringBuilder sql = new StringBuilder();
	        sql.append("SELECT ");
	        sql.append("elemento_pantalla.ID_ELEMENTO_PANTALLA AS \"idElementoPantalla\", ");
	        sql.append("elemento_pantalla.ID_ELEMENTO AS \"idElemento\", ");
	        sql.append("CASE WHEN rol_elemento.ID_ELEMENTO_PANTALLA IS NOT NULL THEN 1 ELSE 0 END AS \"visible\" ");
	        sql.append("FROM BDDSEG01.T3SEGC_ELEM_PANT elemento_pantalla ");
	        sql.append("INNER JOIN BDDSEG01.T3SEGC_PANT pantalla ");
	        sql.append("ON pantalla.ID_PANTALLA = elemento_pantalla.ID_PANTALLA ");
	        sql.append("LEFT JOIN BDDSEG01.T3SEGR_CROL_CELP rol_elemento ");
	        sql.append("ON rol_elemento.ID_ELEMENTO_PANTALLA = elemento_pantalla.ID_ELEMENTO_PANTALLA ");
	        sql.append("AND rol_elemento.ID_ROL = :ID_ROL ");
	        sql.append("WHERE LOWER(pantalla.FLUJO) = LOWER(:FLUJO) ");
	        
	        Query query = session.createSQLQuery(sql.toString())
	            .addScalar("idElementoPantalla", StandardBasicTypes.INTEGER)
	            .addScalar("idElemento", StandardBasicTypes.STRING)
	            .addScalar("visible", StandardBasicTypes.BOOLEAN)
	            .setResultTransformer(Transformers.aliasToBean(ElementosPantallaDTO.class));
	        query.setParameter("FLUJO", flujo);
	        query.setParameter("ID_ROL", idRol);
	        resultado = query.list();

	    } catch (Exception e) {
	        e.printStackTrace(); // Considera loguear esto con un logger
	    }
	    return resultado;
	}
	
	
	public List<ConfiguracionElementoEditableDTO> getConfiguracionEditableElemento(Integer idElementoPantalla) {
	    try {
	        Session session = getSession();
	        StringBuilder sql = new StringBuilder();

	        sql.append("SELECT ")
	           .append("validacion_elemento.ID_ELEMENTO_PANTALLA AS \"idElementoPantalla\", ")
	           .append("validacion_elemento.ID_TIPO_VALIDACION AS \"idTipoValidacion\", ")
	           .append("tipo_validacion.NOMBRE_TIPO_VALIDACION AS \"nombreValidacion\", ")
	           .append("validacion_elemento.VALORES_ESPERADOS AS \"valoresEsperado\", ")
	           .append("campo_validacion.NOMBRE_CAMPO AS \"nombreCampo\" ")
	           .append("FROM BDDSEG01.T3SEGO_VALI_EDIC_ELEM validacion_elemento ")
	           .append("INNER JOIN BDDSEG01.T3SEGC_CAMP_VALI campo_validacion ")
	           .append("ON campo_validacion.ID_CAMPO_VALIDACION = validacion_elemento.ID_CAMPO_VALIDACION ")
	           .append("INNER JOIN BDDSEG01.T3SEGC_TIPO_VALI tipo_validacion ")
	           .append("ON tipo_validacion.ID_TIPO_VALIDACION = validacion_elemento.ID_TIPO_VALIDACION ")
	           .append("WHERE validacion_elemento.ID_ELEMENTO_PANTALLA = :ID_ELEMENTO_PANTALLA ")
	           .append("AND validacion_elemento.ESTATUS = 1");

	        Query query = session.createSQLQuery(sql.toString())
	            .addScalar("idElementoPantalla", StandardBasicTypes.INTEGER)
	            .addScalar("idTipoValidacion", StandardBasicTypes.INTEGER)
	            .addScalar("nombreValidacion", StandardBasicTypes.STRING)
	            .addScalar("valoresEsperado", StandardBasicTypes.STRING)
	            .addScalar("nombreCampo", StandardBasicTypes.STRING)
	            .setResultTransformer(Transformers.aliasToBean(ConfiguracionElementoEditableDTO.class));

	        query.setParameter("ID_ELEMENTO_PANTALLA", idElementoPantalla);

	        return query.list();

	    } catch (Exception e) {
	        e.printStackTrace();
	        return new ArrayList<>();
	    }
	}

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto;

/**
 *
 * @author Jair Javier
 */
public class ColocacionTablaEspacioTorreDTO {
    private String tipoAntena;
    private String orientacion;
    private String ncr;
    private String dimensiones;
    private String frecuenciasRX;
    private String frecuenciasTX;
    private String peso;

    public String getTipoAntena() {
        return tipoAntena;
    }

    public void setTipoAntena(String tipoAntena) {
        this.tipoAntena = tipoAntena;
    }

    public String getOrientacion() {
        return orientacion;
    }

    public void setOrientacion(String orientacion) {
        this.orientacion = orientacion;
    }

    public String getNcr() {
        return ncr;
    }

    public void setNcr(String ncr) {
        this.ncr = ncr;
    }

    public String getDimensiones() {
        return dimensiones;
    }

    public void setDimensiones(String dimensiones) {
        this.dimensiones = dimensiones;
    }

    public String getFrecuenciasRX() {
        return frecuenciasRX;
    }

    public void setFrecuenciasRX(String frecuenciasRX) {
        this.frecuenciasRX = frecuenciasRX;
    }

    public String getFrecuenciasTX() {
        return frecuenciasTX;
    }

    public void setFrecuenciasTX(String frecuenciasTX) {
        this.frecuenciasTX = frecuenciasTX;
    }

    public String getPeso() {
        return peso;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }
    
    
}

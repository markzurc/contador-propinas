package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao;

import java.util.Date;
import java.util.Set;

public interface ISuscripcionSitioDao {

    void registrarSuscripcion(String folioSolicitud, String concesionarioId, String sitioId, Date fechaAlta);

    Set<String> listarSitiosSuscritos(String concesionarioId);

    boolean existeSuscripcion(String concesionarioId, String sitioId);

    void cancelarSuscripcion(String concesionarioId, String sitioId, Date fechaBaja);
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao;

import java.util.Set;

public interface ISuscripcionSitioDao {

    /**
     * Registra una suscripci�n activa (ACTIVO = 'S') para el par (CONC_ID, ID_SITIO).
     * El campo USU_ALTA es obligatorio en la tabla, por lo que se recibe expl�citamente.
     */
    void registrarSuscripcion(String concesionarioId, String sitioId, String usuarioAlta);

    Set<String> listarSitiosSuscritos(String concesionarioId);

    boolean existeSuscripcionActiva(String concesionarioId, String sitioId);

    /**
     * Cancela la suscripci�n activa (ACTIVO = 'N') para el par (CONC_ID, ID_SITIO).
     * Este m�todo no es requerido por el flujo actual, pero se deja completo para mantener el DAO consistente.
     */
    void cancelarSuscripcion(String concesionarioId, String sitioId, String usuarioBaja);
}

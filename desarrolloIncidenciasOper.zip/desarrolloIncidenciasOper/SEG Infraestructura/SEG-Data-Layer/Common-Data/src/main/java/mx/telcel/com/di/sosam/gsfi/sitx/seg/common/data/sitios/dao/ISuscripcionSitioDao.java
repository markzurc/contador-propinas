package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao;

import java.util.Date;
import java.util.List;

public interface ISuscripcionSitioDao {

    /**
     * Registra la suscripci�n de un sitio a un concesionario
     * (se invocar� al concluir exitosamente el flujo).
     */
    public void registrarSuscripcion(String folioSolicitud, String concesionarioId, String sitioId, Date fechaAlta);

    /**
     * Retorna los IDs de sitios suscritos para el concesionario.
     * (lo usar�s para filtrar el combo de Alta Incidencia).
     */
    public List<String> listarSitiosSuscritos(String concesionarioId);

    /**
     * Valida si existe una suscripci�n activa sitio-concesionario.
     */
    public boolean existeSuscripcion(String concesionarioId, String sitioId);
    
    public void cancelarSuscripcion(String folioSolicitud, String concesionarioId, String sitioId);
    


}

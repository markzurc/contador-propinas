package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class ObraCivilDto implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4965507069730208488L;
	
	private String idObra;
	private String nombre;
	private String colonia;
	private String codigoPostal;
	private String latitud;
	private String longitud;
	private String viento;
	private String clasificacion;
	private String tipoSitio;
	private String tipoTorre;
	private String region;
	private Date fechaInicio;
	private String grupoOperador;
	private BigDecimal idMunicipio;
	private String descMunicipio;
	private BigDecimal idEstado;
	private String descEstado;
	private BigDecimal idTipoSitio;
	private String descTipoSitio;
	private BigDecimal idTipoTorre;
	private String descTipoTorre;
	private BigDecimal estatus;
	private String fechaInicioStr;
	
	public ObraCivilDto(String idObra, String nombre, String colonia, String codigoPostal, String latitud,
			String longitud, String viento, String clasificacion, String tipoSitio, String tipoTorre, String region,
			Date fechaInicio, String grupoOperador, BigDecimal idMunicipio, String descMunicipio,
			BigDecimal idEstado, String descEstado, BigDecimal idTipoSitio, String descTipoSitio, BigDecimal idTipoTorre,
			String descTipoTorre, BigDecimal estatus) {
		super();
		this.idObra = idObra;
		this.nombre = nombre;
		this.colonia = colonia;
		this.codigoPostal = codigoPostal;
		this.latitud = latitud;
		this.longitud = longitud;
		this.viento = viento;
		this.clasificacion = clasificacion;
		this.tipoSitio = tipoSitio;
		this.tipoTorre = tipoTorre;
		this.region = region;
		this.fechaInicio = fechaInicio;
		this.grupoOperador = grupoOperador;
		this.idMunicipio = idMunicipio;
		this.descMunicipio = descMunicipio;
		this.idEstado = idEstado;
		this.descEstado = descEstado;
		this.idTipoSitio = idTipoSitio;
		this.descTipoSitio = descTipoSitio;
		this.idTipoTorre = idTipoTorre;
		this.descTipoTorre = descTipoTorre;
		this.estatus = estatus;
	}

	public ObraCivilDto() {

	}

	/**
	 * @return the idObra
	 */
	public String getIdObra() {
		return idObra;
	}

	/**
	 * @param idObra the idObra to set
	 */
	public void setIdObra(String idObra) {
		this.idObra = idObra;
	}

	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the colonia
	 */
	public String getColonia() {
		return colonia;
	}

	/**
	 * @param colonia the colonia to set
	 */
	public void setColonia(String colonia) {
		this.colonia = colonia;
	}

	/**
	 * @return the codigoPostal
	 */
	public String getCodigoPostal() {
		return codigoPostal;
	}

	/**
	 * @param codigoPostal the codigoPostal to set
	 */
	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}

	/**
	 * @return the latitud
	 */
	public String getLatitud() {
		return latitud;
	}

	/**
	 * @param latitud the latitud to set
	 */
	public void setLatitud(String latitud) {
		this.latitud = latitud;
	}

	/**
	 * @return the longitud
	 */
	public String getLongitud() {
		return longitud;
	}

	/**
	 * @param longitud the longitud to set
	 */
	public void setLongitud(String longitud) {
		this.longitud = longitud;
	}

	/**
	 * @return the viento
	 */
	public String getViento() {
		return viento;
	}

	/**
	 * @param viento the viento to set
	 */
	public void setViento(String viento) {
		this.viento = viento;
	}

	/**
	 * @return the clasificacion
	 */
	public String getClasificacion() {
		return clasificacion;
	}

	/**
	 * @param clasificacion the clasificacion to set
	 */
	public void setClasificacion(String clasificacion) {
		this.clasificacion = clasificacion;
	}

	/**
	 * @return the tipoSitio
	 */
	public String getTipoSitio() {
		return tipoSitio;
	}

	/**
	 * @param tipoSitio the tipoSitio to set
	 */
	public void setTipoSitio(String tipoSitio) {
		this.tipoSitio = tipoSitio;
	}

	/**
	 * @return the tipoTorre
	 */
	public String getTipoTorre() {
		return tipoTorre;
	}

	/**
	 * @param tipoTorre the tipoTorre to set
	 */
	public void setTipoTorre(String tipoTorre) {
		this.tipoTorre = tipoTorre;
	}

	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}

	/**
	 * @param region the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}

	/**
	 * @return the fechaInicio
	 */
	public Date getFechaInicio() {
		return fechaInicio;
	}

	/**
	 * @param fechaInicio the fechaInicio to set
	 */
	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	/**
	 * @return the grupoOperador
	 */
	public String getGrupoOperador() {
		return grupoOperador;
	}

	/**
	 * @param grupoOperador the grupoOperador to set
	 */
	public void setGrupoOperador(String grupoOperador) {
		this.grupoOperador = grupoOperador;
	}

	/**
	 * @return the idMunicipio
	 */
	public BigDecimal getIdMunicipio() {
		return idMunicipio;
	}

	/**
	 * @param idMunicipio the idMunicipio to set
	 */
	public void setIdMunicipio(BigDecimal idMunicipio) {
		this.idMunicipio = idMunicipio;
	}

	/**
	 * @return the idEstado
	 */
	public BigDecimal getIdEstado() {
		return idEstado;
	}

	/**
	 * @param idEstado the idEstado to set
	 */
	public void setIdEstado(BigDecimal idEstado) {
		this.idEstado = idEstado;
	}

	/**
	 * @return the descEstado
	 */
	public String getDescEstado() {
		return descEstado;
	}

	/**
	 * @param descEstado the descEstado to set
	 */
	public void setDescEstado(String descEstado) {
		this.descEstado = descEstado;
	}

	/**
	 * @return the descMunicipio
	 */
	public String getDescMunicipio() {
		return descMunicipio;
	}

	/**
	 * @param descMunicipio the descMunicipio to set
	 */
	public void setDescMunicipio(String descMunicipio) {
		this.descMunicipio = descMunicipio;
	}

	/**
	 * @return the idTipoSitio
	 */
	public BigDecimal getIdTipoSitio() {
		return idTipoSitio;
	}

	/**
	 * @param idTipoSitio the idTipoSitio to set
	 */
	public void setIdTipoSitio(BigDecimal idTipoSitio) {
		this.idTipoSitio = idTipoSitio;
	}

	/**
	 * @return the descTipoSitio
	 */
	public String getDescTipoSitio() {
		return descTipoSitio;
	}

	/**
	 * @param descTipoSitio the descTipoSitio to set
	 */
	public void setDescTipoSitio(String descTipoSitio) {
		this.descTipoSitio = descTipoSitio;
	}

	/**
	 * @return the idTipoTorre
	 */
	public BigDecimal getIdTipoTorre() {
		return idTipoTorre;
	}

	/**
	 * @param idTipoTorre the idTipoTorre to set
	 */
	public void setIdTipoTorre(BigDecimal idTipoTorre) {
		this.idTipoTorre = idTipoTorre;
	}

	/**
	 * @return the descTipoTorre
	 */
	public String getDescTipoTorre() {
		return descTipoTorre;
	}

	/**
	 * @param descTipoTorre the descTipoTorre to set
	 */
	public void setDescTipoTorre(String descTipoTorre) {
		this.descTipoTorre = descTipoTorre;
	}

	/**
	 * @return the estatus
	 */
	public BigDecimal getEstatus() {
		return estatus;
	}

	/**
	 * @param estatus the estatus to set
	 */
	public void setEstatus(BigDecimal estatus) {
		this.estatus = estatus;
	}

	/**
	 * @return the fechaInicioStr
	 */
	public String getFechaInicioStr() {
		return fechaInicioStr;
	}

	/**
	 * @param fechaInicioStr the fechaInicioStr to set
	 */
	public void setFechaInicioStr(String fechaInicioStr) {
		this.fechaInicioStr = fechaInicioStr;
	}
		
}

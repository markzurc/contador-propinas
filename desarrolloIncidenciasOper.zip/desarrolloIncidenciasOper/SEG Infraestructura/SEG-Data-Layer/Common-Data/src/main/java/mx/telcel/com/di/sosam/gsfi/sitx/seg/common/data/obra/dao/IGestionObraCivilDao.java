package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dao;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto.EstadoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto.MunicipioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto.ObraCivilDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.FiltroSitioDto;

public interface IGestionObraCivilDao {

	List<ObraCivilDto> getListaObraCivil(FiltroSitioDto filtro);

	List<String> getListaRegion();

	List<EstadoDto> getListaEstado(String region);

	List<MunicipioDto> getListaMunicipio(String region, String estado);

}

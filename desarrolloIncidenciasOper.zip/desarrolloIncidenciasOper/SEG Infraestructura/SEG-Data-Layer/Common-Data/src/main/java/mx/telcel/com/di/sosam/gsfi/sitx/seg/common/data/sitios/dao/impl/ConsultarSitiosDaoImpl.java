package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.impl;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.generic.dao.impl.GenericFunctionDaoImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.IConsultaSitiosDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.FiltroSitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ServicioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.transformer.ConsultaSitiosTransformer;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.transformer.FiltroSitioTransformer;

@Repository(value = "consultaSitiosDao")
@Scope("prototype")
public class ConsultarSitiosDaoImpl extends GenericFunctionDaoImpl
implements IConsultaSitiosDao, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5927713844014847278L;
	private Logger LOGGER = LogManager.getLogger(ConsultarSitiosDaoImpl.class);
	private static final String SELECT_SERVICIOS = "T3Segcserv.SELECT_SERVICIOS";
	
	@SuppressWarnings("unchecked")
	@Override
	public List<SitioDto> getListaSitios() {
		Session session = getSession();
		try {
			String sql = "SELECT SITIO, NOMBRE, CONCESIONARIO, COLONIA, CODIGO_POSTAL, MUNICIPIO, ESTADO, LATITUD, LONGITUD, ALTURA, TIPO_SITIO, TIPO_TORRE, VIENTO, CLASIFICACION, REGION, DISPONIBLE FROM BDDSEG01.T3SEGC_SITI ORDER BY 1";
			Query query = session.createSQLQuery(sql);
			LOGGER.info(query.toString());
			query.setResultTransformer(new ConsultaSitiosTransformer());
			return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar los Sitios");
			return Collections.<SitioDto>emptyList();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<FiltroSitioDto> getDatosFiltro() {
		Session session = getSession();
		try {
			String sql = "SELECT REGION, ESTADO, MUNICIPIO FROM BDDSEG01.T3SEGC_SITI GROUP BY REGION, ESTADO, MUNICIPIO ORDER BY 1";
			Query query = session.createSQLQuery(sql);
			LOGGER.info(query.toString());
			query.setResultTransformer(new FiltroSitioTransformer());
			return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar los Sitios");
			return Collections.<FiltroSitioDto>emptyList();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SitioDto> getListaSitiosFiltros(FiltroSitioDto filtro) {
		Session session = getSession();
		try {
			String sql = "SELECT SITIO, NOMBRE, CONCESIONARIO, COLONIA, CODIGO_POSTAL, MUNICIPIO, ESTADO, LATITUD, LONGITUD, ALTURA, TIPO_SITIO, TIPO_TORRE, VIENTO, CLASIFICACION, REGION "
					+ "FROM BDDSEG01.T3SEGC_SITI WHERE REGION = '"+filtro.getRegion()+"'";
			if(!filtro.getEstado().equals("null"))
				sql+=" AND TRIM(ESTADO) = '"+filtro.getEstado().trim()+"'";
			
			if(!filtro.getMunicipio().equals("null"))
				sql+=" AND TRIM(MUNICIPIO) = '"+filtro.getMunicipio().trim()+"'";
			
			sql+=" ORDER BY 1";
			Query query = session.createSQLQuery(sql);
			LOGGER.info(query.toString());
			query.setResultTransformer(new ConsultaSitiosTransformer());
			return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar los Sitios");
			return Collections.<SitioDto>emptyList();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ServicioDto> getListaServicios() {
		Session session = getSession();
		try {
			Query query = session.getNamedQuery(SELECT_SERVICIOS);
			LOGGER.info(query.toString());
			query.setResultTransformer(new ConsultaSitiosTransformer());
			return query.list();
		} catch (Exception e) {
			LOGGER.error("Error al consultar los Servicios");
			return Collections.<ServicioDto>emptyList();
		}
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto;

import java.io.Serializable;

public class IncidenciaGestionDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long idIncidencia;
	private String folio;
	private String idSitio;
	private String nombreSitio;
	private String concesionario;
	private String pendientePor;
	private String estatus;
	private String usuarioCreacion;
	private String fechaCreacion;
	private String tipo; 
	private String descripcion; 
	private String correoUsuarioCreacion;

	

	public Long getIdIncidencia() {
		return idIncidencia;
	}

	public void setIdIncidencia(Long idIncidencia) {
		this.idIncidencia = idIncidencia;
	}

	public String getFolio() {
		return folio;
	}

	public void setFolio(String folio) {
		this.folio = folio;
	}

	public String getIdSitio() {
		return idSitio;
	}

	public void setIdSitio(String idSitio) {
		this.idSitio = idSitio;
	}

	public String getNombreSitio() {
		return nombreSitio;
	}

	public void setNombreSitio(String nombreSitio) {
		this.nombreSitio = nombreSitio;
	}

	public String getConcesionario() {
		return concesionario;
	}

	public void setConcesionario(String concesionario) {
		this.concesionario = concesionario;
	}

	public String getPendientePor() {
		return pendientePor;
	}

	public void setPendientePor(String pendientePor) {
		this.pendientePor = pendientePor;
	}

	public String getEstatus() {
		return estatus;
	}

	public void setEstatus(String estatus) {
		this.estatus = estatus;
	}

	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	public String getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(String fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getCorreoUsuarioCreacion() {
		return correoUsuarioCreacion;
	}

	public void setCorreoUsuarioCreacion(String correoUsuarioCreacion) {
		this.correoUsuarioCreacion = correoUsuarioCreacion;

	}
}
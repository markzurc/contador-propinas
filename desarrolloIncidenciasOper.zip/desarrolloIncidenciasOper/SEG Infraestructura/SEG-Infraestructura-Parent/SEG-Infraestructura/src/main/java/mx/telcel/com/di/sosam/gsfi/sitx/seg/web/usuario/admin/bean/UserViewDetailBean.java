package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.usuario.admin.bean;

import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX0;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX1;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX10;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX11;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX2;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX3;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX4;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX5;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX6;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX7;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX8;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX9;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.SISTEMA_OVIT;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.USER_EXTENRO_TYPE;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.USER_EXTENRO_TYPE_STRING;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.USER_INETRNO_TYPE_STRING;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.USER_INTERNO_TYPE;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.VER_1;

import java.io.IOException;
import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ExternalUserFindVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.InternalUserFindVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.UserContraVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.UserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.LazyBitacoraSoxVoModel;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.rol.bean.RolViewDetailBean;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.user.service.UserCatalogService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.ReporteOvitUtil;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.webflow.execution.RequestContext;


@Controller("userViewDetailBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class UserViewDetailBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4488050752211072472L;
	private static final Logger logger = LogManager.getLogger(UserViewDetailBean.class);

	@Autowired
	@Qualifier("userCatalogService")
	private UserCatalogService userCatalogService;

	@Autowired
	@Qualifier("lazyBitacoraSoxVoModel")
	private LazyBitacoraSoxVoModel lazyModel;
	
	
	@Autowired
	private ApplicationContext appContext;
	private ReportUserVo userFromHome;
	private ReportUserVo userSelectedFromDlg;
	private RolVo currentRol;
	private String userType;
	private boolean internalUser;
	private InternalUserFindVo currentResponsibleUser;
	private InternalUserFindVo currentInternalUser;
	private ExternalUserFindVo currentExternalUser;
	private UserVo currentUser;
	private String numeroEmpleado;
	private String mailExternalUser;
	private RolViewDetailBean rolViewDetailBean;
	
	private Date lastPassChange;
	private String hashPass;
	private Date creationDate;
	private static Map<Integer,String> mapActions= new HashMap<Integer,String>();
	
	static{
		mapActions.put(INDEX0, "Creaci�n");
		mapActions.put(INDEX1, "Modificaci�n");
		mapActions.put(INDEX2, "Eliminaci�n");
		mapActions.put(INDEX3, "Consulta");
		mapActions.put(INDEX4, "Error Crear");
		mapActions.put(INDEX5, "Error Consulta");
		mapActions.put(INDEX6, "Error Modificaci�n");
		mapActions.put(INDEX7, "Error Lista");
		mapActions.put(INDEX8, "Error Baja");
		mapActions.put(INDEX9, "Error Habilitar");
		mapActions.put(INDEX10, "Bloq. Usr. Pass. Exp");
		mapActions.put(INDEX11, "Bloq. Usr. Expirados");
		
	}

	public void initUserDetail(RequestContext ctx) throws TransactionalOVITException{
		UserDetailsVo userDetailsVo =(UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		this.internalUser=false;
		lazyModel.setIdCurrentUser(userFromHome.getIdUsuario());
		
		if(userFromHome.getIdTipoUsuario().equals(USER_EXTENRO_TYPE)){
			UserContraVo userPasswordVo=userCatalogService.getDataSoxDatePass(userFromHome.getIdUsuario());
			lastPassChange =userPasswordVo.getFechaCambioPassword();
			if(userDetailsVo.getIdUsuario().equals(userFromHome.getIdUsuario())){
				   hashPass=userPasswordVo.getContra();
				}else{
					hashPass="**********";	
				}
			
			currentExternalUser=userCatalogService.loadUserExternal(userFromHome.getIdUsuario());
			creationDate=currentExternalUser.getUserVo().getFechaCreacion();
			currentUser=currentExternalUser.getUserVo();
			currentRol=userCatalogService.loadRolbyId(currentUser.getIdRol());
			userType=USER_EXTENRO_TYPE_STRING;
			currentResponsibleUser=new InternalUserFindVo();
			currentResponsibleUser.setInternalDataVo(currentExternalUser.getResponsibleUser().getInternalDataVo());
			currentResponsibleUser.setUserVo(currentExternalUser.getResponsibleUser().getUserVo());
			userSelectedFromDlg= new ReportUserVo();
			userSelectedFromDlg.setIdUsuario(currentResponsibleUser.getUserVo().getIdUsuario());
			userSelectedFromDlg.setNumeroEmpleado(currentResponsibleUser.getInternalDataVo().getNumeroEmpleado());
			numeroEmpleado=currentExternalUser.getExternalDataUser().getNumeroEmpleado();
			mailExternalUser=currentExternalUser.getExternalDataUser().getCorreo();
			this.internalUser=false;
			
		}else if(userFromHome.getIdTipoUsuario().equals(USER_INTERNO_TYPE)){
			userSelectedFromDlg= new ReportUserVo();
			currentInternalUser= userCatalogService.loadUserInternal(userFromHome.getIdUsuario());
			creationDate=currentInternalUser.getUserVo().getFechaCreacion();
			currentUser=currentInternalUser.getUserVo();
			numeroEmpleado=currentInternalUser.getInternalDataVo().getNumeroEmpleado();
			currentRol=userCatalogService.loadRolbyId(currentUser.getIdRol());
			userType=USER_INETRNO_TYPE_STRING;
			currentResponsibleUser=new InternalUserFindVo();
			this.internalUser=true;
			mailExternalUser=currentInternalUser.getInternalDataVo().getCorreo();
		}
		
		
		
		 rolViewDetailBean = (RolViewDetailBean) appContext
				.getBean("viewDetailRol");
		currentRol=userCatalogService.loadRolbyId(currentUser.getIdRol());
		//rolViewDetailBean.setCurrentRol(currentRol);
		//rolViewDetailBean.initDetailRol(ctx);
		
	}

	

	
	 public void getFile() {
		 UserDetailsVo userDetailsVo =(UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			
			String fechaReporte= ReporteOvitUtil.fechaReporte();
			String fechaYY=ReporteOvitUtil.fechaYY();
			currentUser.setNumeroEmpleado(this.numeroEmpleado);
	        /***XSSFWorkbook workbook=ReporteOvitUtil.cargaPlantilla(SISTEMA_OVIT,"SDS/GSF/"+fechaYY+"/OViT/Reporte OViT Detalle Usuario  "+ userDetailsVo.getNumeroEmpleado()+"",
	        		userDetailsVo.getNumeroEmpleado(),new Date(),"Detalle Usuario "+currentUser.getNumeroEmpleado(),VER_1);***/
	      
			
			FacesContext facesContext = FacesContext.getCurrentInstance();
		    ExternalContext externalContext = facesContext.getExternalContext();
		    externalContext.setResponseContentType("application/vnd.ms-excel");
		    externalContext.setResponseHeader("Content-Disposition", "attachment; filename=\"eporte OViT Detalle Usuario"+ this.numeroEmpleado +" "+fechaReporte+".xlsx\"");
		    facesContext.responseComplete();
		    
	       
	       
	    }
		
	 
	 
	 


	public UserCatalogService getUserCatalogService() {
		return userCatalogService;
	}

	public void setUserCatalogService(UserCatalogService userCatalogService) {
		this.userCatalogService = userCatalogService;
	}

	public RolVo getCurrentRol() {
		return currentRol;
	}

	public void setCurrentRol(RolVo currentRol) {
		this.currentRol = currentRol;
	}



	public boolean isInternalUser() {
		return internalUser;
	}



	public void setInternalUser(boolean internalUser) {
		this.internalUser = internalUser;
	}



	public String getUserType() {
		return userType;
	}



	public void setUserType(String userType) {
		this.userType = userType;
	}




	public ReportUserVo getUserFromHome() {
		return userFromHome;
	}




	public void setUserFromHome(ReportUserVo userFromHome) {
		this.userFromHome = userFromHome;
	}




	public ReportUserVo getUserSelectedFromDlg() {
		return userSelectedFromDlg;
	}




	public void setUserSelectedFromDlg(ReportUserVo userSelectedFromDlg) {
		this.userSelectedFromDlg = userSelectedFromDlg;
	}




	public InternalUserFindVo getCurrentResponsibleUser() {
		return currentResponsibleUser;
	}




	public void setCurrentResponsibleUser(InternalUserFindVo currentResponsibleUser) {
		this.currentResponsibleUser = currentResponsibleUser;
	}




	public InternalUserFindVo getCurrentInternalUser() {
		return currentInternalUser;
	}




	public void setCurrentInternalUser(InternalUserFindVo currentInternalUser) {
		this.currentInternalUser = currentInternalUser;
	}




	public ExternalUserFindVo getCurrentExternalUser() {
		return currentExternalUser;
	}




	public void setCurrentExternalUser(ExternalUserFindVo currentExternalUser) {
		this.currentExternalUser = currentExternalUser;
	}




	public UserVo getCurrentUser() {
		return currentUser;
	}




	public void setCurrentUser(UserVo currentUser) {
		this.currentUser = currentUser;
	}




	public String getMailExternalUser() {
		return mailExternalUser;
	}




	public void setMailExternalUser(String mailExternalUser) {
		this.mailExternalUser = mailExternalUser;
	}




	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}




	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}




	public Date getLastPassChange() {
		return lastPassChange;
	}




	public void setLastPassChange(Date lastPassChange) {
		this.lastPassChange = lastPassChange;
	}




	public String getHashPass() {
		return hashPass;
	}




	public void setHashPass(String hashPass) {
		this.hashPass = hashPass;
	}




	public Date getCreationDate() {
		return creationDate;
	}




	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}




	public LazyBitacoraSoxVoModel getLazyModel() {
		return lazyModel;
	}




	public void setLazyModel(LazyBitacoraSoxVoModel lazyModel) {
		this.lazyModel = lazyModel;
	}


	public  Map<Integer, String> getMapActions() {
		return mapActions;
	}

	public  void setMapActions(Map<Integer, String> mapActions) {
		UserViewDetailBean.mapActions = mapActions;
	}
	
		
}

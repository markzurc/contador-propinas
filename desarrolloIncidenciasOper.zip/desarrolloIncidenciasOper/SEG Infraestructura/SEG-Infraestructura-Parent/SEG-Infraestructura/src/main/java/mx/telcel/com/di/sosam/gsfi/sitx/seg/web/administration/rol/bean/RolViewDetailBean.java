package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.rol.bean;

import java.io.Serializable;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Controller;



@Controller("viewDetailRol")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class RolViewDetailBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5429605289446858946L;
	
	
}

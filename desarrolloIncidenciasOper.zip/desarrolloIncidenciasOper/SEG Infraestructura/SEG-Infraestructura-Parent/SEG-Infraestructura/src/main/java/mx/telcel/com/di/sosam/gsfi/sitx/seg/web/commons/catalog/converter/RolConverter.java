package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.catalog.converter;

import java.util.ArrayList;
import java.util.List;

import javax.faces.component.UIComponent;
import javax.faces.component.UISelectItems;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolVo;


/**
 *
 * @author VI7XXEY
 */

@FacesConverter("rolConverter")
public class RolConverter implements Converter {

    @SuppressWarnings("unchecked")
	@Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
       
		List<UIComponent> childs = component.getChildren();
		UISelectItems items;
		List<RolVo> aplicaciones = new ArrayList<RolVo>();
		for (UIComponent ui : childs) {
			if (ui instanceof UISelectItems) {
				items = (UISelectItems) ui;
				aplicaciones = (List<RolVo>) items.getValue();

			}
		}

		for (RolVo rol : aplicaciones) {
			if (rol.getIdRol().toString().equals(value)){
				return rol;
			}
		}

		return null;
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (value instanceof RolVo) {
			RolVo rol = (RolVo) value;
			if( rol.getIdRol() != null){
				return rol.getIdRol().toString();
			}else{
				return "0";}
		}
		return "";
    }
    
}

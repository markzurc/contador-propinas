package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util;

import java.util.Iterator;

import javax.el.ExpressionFactory;
import javax.el.MethodExpression;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

public class JsfUtil {

	private JsfUtil(){
	}
	
	public static UIComponent findComponent(UIComponent base, String id) {
		if (id.equals(base.getId())){
			return base;
			}

		UIComponent child = null;
		UIComponent result = null;
		@SuppressWarnings("rawtypes")
		Iterator childs = base.getFacetsAndChildren();
		while (childs.hasNext() && (result == null)) {
			child = (UIComponent) childs.next();
			if (id.equals(child.getId())) {
				result = child;
				break;
			}
			result = findComponent(child, id);
			if (result != null) {
				break;
			}
		}
		return result;
	}


	public static MethodExpression createMethodExpression(String valueExpression,
			Class<?> expectedReturnType,
			Class<?>[] expectedParamTypes) {
		MethodExpression methodExpression = null;

		try {
			FacesContext fc = FacesContext.getCurrentInstance();
			ExpressionFactory factory = fc.getApplication().getExpressionFactory();
			methodExpression = factory.
					createMethodExpression(fc.getELContext(), valueExpression, expectedReturnType, expectedParamTypes);
		} catch (Exception e) {

			throw new FacesException("Method expression '" + valueExpression + "' could not be created.");
		}

		return methodExpression;
	}

}

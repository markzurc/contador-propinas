package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.user.service;

import java.util.List;



public abstract class RestriccionCommonBean {

	public abstract List<? extends Object> getObjectsToPersist();
	
	
}          

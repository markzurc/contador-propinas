package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.sitios.bean;

import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.elementosPantalla.IElementosPantallaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.proyecto.IProyectoPresupuestoService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.IFactibilidadService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.solicitudes.ISolicitudesService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ElementosPantallaDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.AntenaDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.FactibilidadDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SolicitudDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.ValidacionUtil;



@Controller("solicitudAnalisisFactibilidadBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class SolicitudAnalisisFactibilidadBean implements Serializable {

	private static final long serialVersionUID = -8715496866982916388L;
	private static final Logger LOGGER = LogManager.getLogger(SolicitudAnalisisFactibilidadBean.class);
	private static final String ACCION_SOLICITAR_FACTIBILIDAD = "4";
	private static final String ESTADO_SOLICITAR_FACTIBILIDAD = "4";
	private static final String SERVICIO_FACTIBILIDAD = "2";
	private String valor = "";
	private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
	private String dimensionesTipoAntena;
	
	@Autowired
	private IFactibilidadService factibilidadService;
	
	@Autowired
	private IElementosPantallaService elementosPantalla;
	
	@Autowired
	private ISolicitudesService consultaServiciosServiceImpl;
	
	@Autowired
	private DetalleSolicitudBean detalleSolicitudBean;
	
	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;
	
	@Autowired
	private IProyectoPresupuestoService proyectoService;

	private List<FactibilidadDto> factibilidad;

	private List<AntenaDto> listAntenas;
	private List<String> listaTipoAntenas;
	
	private String dimensionAntenaC;
	private String dimensionAntenaC2;
	private String pesoAntenaC;
	private Integer idAntena;
	
	private String nivelCentroR;
	private String areaR;
	private String motivoRechazo;
	private String servicioSelect;
	private String idFactibilidad;
	private String motivoR;
	private String headerDialogo;
	private String mensajeDialogo;
	private String fecha;
	private String indexSelect;
	
	private List<ElementosPantallaDTO> list;
	
	private String seleccionadoOperacion;
	private SitioDto parametroSitio;
	private String seleccionadoAntena;
	
	boolean solicitudCreada;
	
	UserDetailsVo userDetailsVo;

	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		userDetailsVo = (UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		seleccionadoAntena = "";
		dimensionAntenaC = "";
		dimensionAntenaC2 = "";
		pesoAntenaC = "";
		areaR="";
		nivelCentroR= "";
		motivoRechazo = "";
		listAntenas = new ArrayList<>();
		listaTipoAntenas = new ArrayList<>();
		factibilidad = new ArrayList<>();
		idAntena = 1;
		solicitudCreada = false;
		fecha = "";
		indexSelect = "0";
		motivoR = "";
		dimensionesTipoAntena = "true";
		try {
			Date date = new Date();
			fecha = dateFormat.format(date);
			String nombreEstadoVista = "solicitudFactibilidad";
			String bandera = "";
			UserDetailsVo userDetailsVo =(UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			Map<String, Integer> mapa = new HashMap<String, Integer>();
			if (parametroSitio.getIdEstado()==null) {
				parametroSitio.setIdEstado("0");
			}
			
			ConfigurationUtilsVo configurationUtilsVo2 = configurationUtilsBusiness.
					getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.ESTADOS_PANEL_RESUL_FACTI);
			String estadosPanelResulFacti = configurationUtilsVo2.getValor();
			
			String[] val = estadosPanelResulFacti.split(",");
			for (String string : val) {
				if (parametroSitio.getIdEstado().equals(string)) {
					indexSelect = "1";
					break;
				}
			}
			
			mapa.put("Estados no validos btnCrearSolicitud", Integer.parseInt(parametroSitio.getIdEstado()));
			mapa.put("Estados no validos rechazar Factibilidad", Integer.parseInt(parametroSitio.getIdEstado()));
			
			String rolEstado = userDetailsVo.getIdRol()+ parametroSitio.getIdEstado();
			mapa.put("Rol y estado no valido para avanzar estatus", Integer.parseInt(rolEstado));
			mapa.put("Rol y estado no valido para resultado de Factibilidad", Integer.parseInt(rolEstado));
			mapa.put("Rol y estado valido para agregar antenas", Integer.parseInt(rolEstado));
			mapa.put("rol_estatus_btn_crear_soli_facti", Integer.parseInt(rolEstado));
			if (servicioSelect != null ) {
				bandera = (!servicioSelect.equals(SERVICIO_FACTIBILIDAD)) ? "" : SERVICIO_FACTIBILIDAD;
				
			}
			mapa.put("Rol_estado_no_valido_Factibilidad", Integer.parseInt(rolEstado + bandera));
			list=elementosPantalla.getElementosPermitidosPantalla(nombreEstadoVista, userDetailsVo.getIdRol(), mapa);
		
			listaTipoAntenas = factibilidadService.getTipoAntenas();
			
			if (parametroSitio.getFolio() != null) {
				idFactibilidad = factibilidadService.getFactiPorFolio(parametroSitio.getFolio());
			} else {
				idFactibilidad = null;
			}
			
			
			if (idFactibilidad !=null) {
				listAntenas = factibilidadService.getAntenas(idFactibilidad);
				factibilidad = factibilidadService.getFacti(idFactibilidad);
				if (factibilidad.size()>0) {
					nivelCentroR = factibilidad.get(0).getNivelCentroRadiacion() != null ? factibilidad.get(0).getNivelCentroRadiacion().toString() : "";
					areaR = factibilidad.get(0).getAreaRequerida() != null ? factibilidad.get(0).getAreaRequerida().toString() : "";
					fecha = factibilidad.get(0).getFecha() == null ? dateFormat.format(date) : factibilidad.get(0).getFecha();
				}
			}
			servicioSelect = null;
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al cargar la p�gina");
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","Ocurri� un error al cargar la p�gina"));
		}
	}
	
	public boolean getVisible(String nombreComponente) {
		boolean visible=false;
		for(ElementosPantallaDTO elemento:list) {
			if(elemento.getIdElemento().equals(nombreComponente)) {
				visible=elemento.isVisible();
			}
		}
		return visible;
	}
	
	public boolean getEditable(String nombreComponente) {
		boolean editable=false;
		for(ElementosPantallaDTO elemento:list) {
			if(elemento.getIdElemento().equals(nombreComponente)) {
				editable=elemento.isEditable();
			}
		}
		
		return editable;
	}
	
	public void avanzarSoliFacti(String trancision) {
		Boolean franjasD = true;
		Date date = new Date();
		if (!nivelCentroR.equals("")) {
			if (Double.parseDouble(nivelCentroR) <= 0) {
				franjasD = false;
				detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
				detalleSolicitudBean.setMensajeDialogo("Se espera un valor mayor a cero en el campo Franjas discontinuas.");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			}
		}
		if (!areaR.equals("")) {
			if (Double.parseDouble(areaR) <= 0) {
				franjasD = false;
				detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
				detalleSolicitudBean.setMensajeDialogo("Se espera un valor mayor a cero en el campo Franjas discontinuas.");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			}
		}
		
		if (franjasD) {
			if (listAntenas.size()>0) {
				FactibilidadDto factibilidadDto = new FactibilidadDto();
				factibilidadDto.setNivelCentroRadiacion(nivelCentroR);
				factibilidadDto.setAreaRequerida(areaR);
				factibilidadDto.setFolio(parametroSitio.getFolio());
				factibilidadDto.setFecha(dateFormat.format(date));

				boolean soli = factibilidadService.crearSolicitud(factibilidadDto);
				boolean ante = factibilidadService.crearAntena(listAntenas);

				boolean estado = factibilidadService.modificarSitioEstado(parametroSitio.getFolio(), trancision);

				if (soli && ante && estado) {
					detalleSolicitudBean.insertarBitacora("");
					detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad: Generada");
					detalleSolicitudBean.setMensajeDialogo("Solicitud de Factibilidad generada con exito.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli').show();");
				} else {
					detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad: Generada");
					detalleSolicitudBean.setMensajeDialogo("Solicitud de Factibilidad no generada con exito.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
				}
			} else {
				detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
				detalleSolicitudBean.setMensajeDialogo("Debes agregar una antena.");
				headerDialogo = "Solicitud de Factibilidad";
				mensajeDialogo = "Debes agregar una antena";
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
			}
		}
		
	}
	
	public void crearAntena() {
		try {
			if (dimensionesTipoAntena.equals("true")) {
				if (seleccionadoAntena.equals("") || dimensionAntenaC.trim().equals("") || dimensionAntenaC2.trim().equals("") || pesoAntenaC.trim().equals("")) {
					limpiarCampos();
					detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
					detalleSolicitudBean.setMensajeDialogo("No es posible crear la antena con datos incompletos");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
				} else if (Double.parseDouble(dimensionAntenaC) <= 0) {
					limpiarCampos();
					detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
					detalleSolicitudBean.setMensajeDialogo("Se espera un valor mayor a cero para los campos Dimensiones.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
				}  else if (Double.parseDouble(dimensionAntenaC2) <= 0) {
					limpiarCampos();
					detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
					detalleSolicitudBean.setMensajeDialogo("Se espera un valor mayor a cero para los campos Dimensiones.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
				}  else if (Double.parseDouble(pesoAntenaC) <= 0) {
					limpiarCampos();
					detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
					detalleSolicitudBean.setMensajeDialogo("Se espera un valor mayor a cero en el campo Peso.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
				} else {
					AntenaDto antena = new AntenaDto();
					antena.setIdAntena(idAntena);
					antena.setTipo(seleccionadoAntena);
					if (dimensionesTipoAntena.equals("true")) {
						antena.setDimenciones(dimensionAntenaC + " X " + dimensionAntenaC2);
					} else {
						antena.setDimenciones(dimensionAntenaC);
					}
					
					antena.setPeso(pesoAntenaC);
					
					listAntenas.add(antena);
					idAntena++;
					//limpiarCampos();
					detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
					detalleSolicitudBean.setMensajeDialogo("Se agrego la antena con exito.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli2').show();");
				}
			} else {
				if (seleccionadoAntena.equals("") || dimensionAntenaC.trim().equals("") || pesoAntenaC.trim().equals("")) {
					limpiarCampos();
					detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
					detalleSolicitudBean.setMensajeDialogo("No es posible crear la antena con datos incompletos");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
				} else if (Double.parseDouble(dimensionAntenaC) <= 0) {
					limpiarCampos();
					detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
					detalleSolicitudBean.setMensajeDialogo("Se espera un valor mayor a cero para los campos Dimensiones.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
				}else if (Double.parseDouble(pesoAntenaC) <= 0) {
					limpiarCampos();
					detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
					detalleSolicitudBean.setMensajeDialogo("Se espera un valor mayor a cero en el campo Peso.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
				} else {
					AntenaDto antena = new AntenaDto();
					antena.setIdAntena(idAntena);
					antena.setTipo(seleccionadoAntena);
					if (dimensionesTipoAntena.equals("true")) {
						antena.setDimenciones(dimensionAntenaC + " X " + dimensionAntenaC2);
					} else {
						antena.setDimenciones(dimensionAntenaC);
					}
					
					antena.setPeso(pesoAntenaC);
					
					listAntenas.add(antena);
					idAntena++;
					//limpiarCampos();
					detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
					detalleSolicitudBean.setMensajeDialogo("Se agrego la antena con exito.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli2').show();");
				}
			}
			
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error");
		}
	}
	
	public void eliminarAntena(AntenaDto antena) {
		try {
			listAntenas.remove(antena);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvdlgEliminarAntena').show();");
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error");
		}
		
	}
	
	public void limpiarCampos() {
		seleccionadoAntena = "";
		dimensionAntenaC ="";
		dimensionAntenaC2 ="";
		pesoAntenaC = "";
	}
	
	public void limpiarMotivoRechazo() {
		motivoR = "";	
	}
	
	public void rechazarSolibtnEnviar() {
		
		if(ValidacionUtil.isEmpty(motivoR)) {
			detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
			detalleSolicitudBean.setMensajeDialogo("Se debe especificar un valor para el campo Rechazo.");
			motivoR = "";
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			return;
		}
		
		if(!ValidacionUtil.validarCaracteres(motivoR)) {
			detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
			detalleSolicitudBean.setMensajeDialogo("No se permiten caracteres especiales para el campo Rechazo.");
			motivoR = "";
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			return;
		}
		FactibilidadDto factibilidadDto = new FactibilidadDto();
		factibilidadDto.setIdFactibilidad(Integer.parseInt(idFactibilidad));
		factibilidadDto.setMotivoRechazo(motivoR);
		boolean sitio = factibilidadService.modificarSitioEstado(parametroSitio.getFolio(), proyectoService.consultaIdEstadoBitacora("SOLICITUD CANCELADA"));
		boolean resultado = factibilidadService.actualizarMotivoRechazo(factibilidadDto);
		
		if (sitio && resultado) {
			detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad: Cancelar");
			detalleSolicitudBean.setMensajeDialogo("Solicitud de Factibilidad cancelada con exito.");
			detalleSolicitudBean.insertarBitacora(motivoR);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli').show();");
		} else {
			detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad: Cancelar");
			detalleSolicitudBean.setMensajeDialogo("Solicitud de Factibilidad no cancelada con exito.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
		motivoR = "";
	}
	
	public void crearSolicitud() {
		Date date = new Date();
		Boolean franjasD = true;
		
		if (!nivelCentroR.equals("")) {
			if (Double.parseDouble(nivelCentroR) <= 0) {
				franjasD = false;
				detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
				detalleSolicitudBean.setMensajeDialogo("Se espera un valor mayor a cero en el campo Franjas discontinuas");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			}
		}
		if (!areaR.equals("")) {
			if (Double.parseDouble(areaR) <= 0) {
				franjasD = false;
				detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
				detalleSolicitudBean.setMensajeDialogo("Se espera un valor mayor a cero en el campo Franjas discontinuas");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			}
		}
		
		if (franjasD) {
			if (listAntenas.size()==0) {
				detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
				detalleSolicitudBean.setMensajeDialogo("Debes agregar una Antena");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			} else { 
				FactibilidadDto factibilidadDto = new FactibilidadDto();
				factibilidadDto.setNivelCentroRadiacion(nivelCentroR);
				factibilidadDto.setAreaRequerida(areaR);
				factibilidadDto.setFecha(dateFormat.format(date));
				
				String folio = generaSolicitud();
				factibilidadDto.setFolio(folio);
				boolean soli = factibilidadService.crearSolicitud(factibilidadDto);
				boolean ante = factibilidadService.crearAntena(listAntenas);
				if (soli && ante) {
					solicitudCreada = true;
					detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad: Crear");
					detalleSolicitudBean.setMensajeDialogo("Solicitud de Infraestructura generada");
					detalleSolicitudBean.setIdAccionBitacora(ACCION_SOLICITAR_FACTIBILIDAD);
					detalleSolicitudBean.setIdEstatusBitacora(ESTADO_SOLICITAR_FACTIBILIDAD);
					detalleSolicitudBean.setIdGrupoOperadorBitacora(consultaServiciosServiceImpl.getGpoOperUsuById(userDetailsVo.getIdUsuario().toString()));
					detalleSolicitudBean.setIdSolicitudBitacora(folio);
					detalleSolicitudBean.insertarBitacora("");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli').show();");
				} else {
					detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad: Crear");
					detalleSolicitudBean.setMensajeDialogo("Ocurrio un error al crear la Solicitud de Infraestructura");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
				}
			}
		}
	}
	
	public String generaSolicitud() {
		SolicitudDto generaSoliDto = new SolicitudDto();
		generaSoliDto.setSitio(parametroSitio.getSitio());
		generaSoliDto.setUsuario(userDetailsVo.getIdUsuario().toString());
		generaSoliDto.setEstatus("4");
		
		try {
			//busca grupo operador por usuario
	        generaSoliDto.setGrupoOperador(consultaServiciosServiceImpl.getGpoOperUsuById(generaSoliDto.getUsuario()));
	        
	      //genera la solicitud
	        generaSoliDto = consultaServiciosServiceImpl.generaSolicitud(generaSoliDto);
	        
	        if (generaSoliDto.getFolio() != null) {
	        	return generaSoliDto.getFolio();
	        } else {
	        	return "";
	        }
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al generar la solicitud, causa: " + e);
			return "";
		}
		
	}
	
	public void cambiaDimensiones() {
		if (seleccionadoAntena.toUpperCase().contains("ANTENA MW")) {
			dimensionesTipoAntena = "false";
		} else {
			dimensionesTipoAntena = "true";
		}
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}


	public IFactibilidadService getFactibilidadService() {
		return factibilidadService;
	}


	public void setFactibilidadService(IFactibilidadService factibilidadService) {
		this.factibilidadService = factibilidadService;
	}


	public List<FactibilidadDto> getFactibilidad() {
		return factibilidad;
	}


	public void setFactibilidad(List<FactibilidadDto> factibilidad) {
		this.factibilidad = factibilidad;
	}


	public List<AntenaDto> getListAntenas() {
		return listAntenas;
	}


	public void setListAntenas(List<AntenaDto> listAntenas) {
		this.listAntenas = listAntenas;
	}


	public String getDimensionAntenaC() {
		return dimensionAntenaC;
	}


	public void setDimensionAntenaC(String dimensionAntenaC) {
		this.dimensionAntenaC = dimensionAntenaC;
	}

	
	public String getDimensionAntenaC2() {
		return dimensionAntenaC2;
	}


	public void setDimensionAntenaC2(String dimensionAntenaC2) {
		this.dimensionAntenaC2 = dimensionAntenaC2;
	}

	public String getPesoAntenaC() {
		return pesoAntenaC;
	}


	public void setPesoAntenaC(String pesoAntenaC) {
		this.pesoAntenaC = pesoAntenaC;
	}

	public String getNivelCentroR() {
		return nivelCentroR;
	}

	public void setNivelCentroR(String nivelCentroR) {
		this.nivelCentroR = nivelCentroR;
	}

	public String getAreaR() {
		return areaR;
	}

	public void setAreaR(String areaR) {
		this.areaR = areaR;
	}

	public String getSeleccionadoOperacion() {
		return seleccionadoOperacion;
	}

	public void setSeleccionadoOperacion(String seleccionadoOperacion) {
		this.seleccionadoOperacion = seleccionadoOperacion;
	}

	public SitioDto getParametroSitio() {
		return parametroSitio;
	}

	public void setParametroSitio(SitioDto parametroSitio) {
		this.parametroSitio = parametroSitio;
	}

	public String getMotivoRechazo() {
		return motivoRechazo;
	}

	public void setMotivoRechazo(String motivoRechazo) {
		this.motivoRechazo = motivoRechazo;
	}

	public String getServicioSelect() {
		return servicioSelect;
	}

	public void setServicioSelect(String servicioSelect) {
		this.servicioSelect = servicioSelect;
	}

	public String getMotivoR() {
		return motivoR;
	}

	public void setMotivoR(String motivoR) {
		this.motivoR = motivoR;
	}

	public String getHeaderDialogo() {
		return headerDialogo;
	}

	public void setHeaderDialogo(String headerDialogo) {
		this.headerDialogo = headerDialogo;
	}

	public String getMensajeDialogo() {
		return mensajeDialogo;
	}

	public void setMensajeDialogo(String mensajeDialogo) {
		this.mensajeDialogo = mensajeDialogo;
	}

	public List<String> getListaTipoAntenas() {
		return listaTipoAntenas;
	}

	public void setListaTipoAntenas(List<String> listaTipoAntenas) {
		this.listaTipoAntenas = listaTipoAntenas;
	}

	public String getSeleccionadoAntena() {
		return seleccionadoAntena;
	}

	public void setSeleccionadoAntena(String seleccionadoAntena) {
		this.seleccionadoAntena = seleccionadoAntena;
	}
	
	public String getIndexSelect() {
		return indexSelect;
	}

	public void setIndexSelect(String indexSelect) {
		this.indexSelect = indexSelect;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getDimensionesTipoAntena() {
		return dimensionesTipoAntena;
	}

	public void setDimensionesTipoAntena(String dimensionesTipoAntena) {
		this.dimensionesTipoAntena = dimensionesTipoAntena;
	}
}

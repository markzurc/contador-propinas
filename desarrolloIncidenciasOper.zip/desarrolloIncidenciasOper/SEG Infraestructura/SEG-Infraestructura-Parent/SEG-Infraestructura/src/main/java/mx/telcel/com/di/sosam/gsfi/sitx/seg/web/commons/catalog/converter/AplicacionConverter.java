package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.catalog.converter;

import java.util.ArrayList;
import java.util.List;

import javax.faces.component.UIComponent;
import javax.faces.component.UISelectItems;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ApplicationVo;

/**
 *
 * @author VI7XXEY
 */

@FacesConverter("aplicacionConverter")
public class AplicacionConverter implements Converter {

    @SuppressWarnings("unchecked")
	@Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
       
		List<UIComponent> childs = component.getChildren();
		UISelectItems items;
		List<ApplicationVo> aplicaciones = new ArrayList<ApplicationVo>();
		for (UIComponent ui : childs) {
			if (ui instanceof UISelectItems) {
				items = (UISelectItems) ui;
				aplicaciones = (List<ApplicationVo>) items.getValue();

			}
		}

		for (ApplicationVo app : aplicaciones) {
			if (app.getIdAplicacion().toString().equals(value)){
				return app;
				}
		}

		return null;
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (value instanceof ApplicationVo) {
			ApplicationVo acl = (ApplicationVo) value;
			if (acl.getIdAplicacion() != null){
				return acl.getIdAplicacion().toString();
			}else{
				return "0";}
		}
		return value.toString();
    }
    
}

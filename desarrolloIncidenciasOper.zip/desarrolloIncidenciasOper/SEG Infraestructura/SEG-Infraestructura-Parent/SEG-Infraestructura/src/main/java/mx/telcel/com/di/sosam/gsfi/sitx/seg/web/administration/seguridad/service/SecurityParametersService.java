package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.seguridad.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.IBitacoraSoxBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.mapper.MapperCustomFactory;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.BitacoraSeguridadUtil;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.WrapperConfigurationUtilsVo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Service;

@Service("securityParametersService")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class SecurityParametersService extends MapperCustomFactory implements Serializable{

	private static final long serialVersionUID = 6787145618586555818L;
	private static final String PARAMETERS_OVIT="PARAMETERS_OVIT";
	private static final Logger logger = LogManager.getLogger(SecurityParametersService.class);
	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;
	
	
	@Autowired
	@Qualifier("bitacoraSeguridadUtil")
	private BitacoraSeguridadUtil bitacoraSeguridadUtil;
	
	
	private List<ConfigurationUtilsVo> paramList;
	 
	
	public List<WrapperConfigurationUtilsVo> getAllSecurityParameters() throws TransactionalOVITException{
		ArrayList<WrapperConfigurationUtilsVo> listaBack= new ArrayList<WrapperConfigurationUtilsVo>(); 
		List<ConfigurationUtilsVo> paramListFromBussines=configurationUtilsBusiness.getListConstantOfDataBase(PARAMETERS_OVIT);
		paramList=  getMapper().mapAsList(paramListFromBussines, ConfigurationUtilsVo.class);
			for(ConfigurationUtilsVo configurationUtilsVo:paramList){
				listaBack.add(new WrapperConfigurationUtilsVo(configurationUtilsVo));
			}
		return listaBack;
	}
	
	
	public boolean saveParameter(WrapperConfigurationUtilsVo wrapperConfigurationUtilsVo,String oldList,String folio){
		try {
			configurationUtilsBusiness.updateConfiguration(wrapperConfigurationUtilsVo.getConfigurationUtilsVo());
			bitacoraSeguridadUtil.registraEntradaBitacora(oldList, wrapperConfigurationUtilsVo.getConfigurationUtilsVo(), folio, IBitacoraSoxBusiness.UPDATE);
			
			return true;
		} catch (TransactionalOVITException e) {
			logger.error("Error al ejecutar SecurityParametersService.saveParameter: " + e);
			return false;
		}
	}
	
	
	public void updateParamsOnCurrentSession(List<WrapperConfigurationUtilsVo> wrapperConfigurationUtilsVo)  throws TransactionalOVITException{
		configurationUtilsBusiness.getConstantOfDataBase();
	}
	
	
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util;


import java.util.HashMap;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.context.annotation.ScopedProxyMode;



@Controller("ovitConstants")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class Constants {
	
	
	public static final String SISTEMA_SEG="Sistema SEG";
	public final static int STATUS_ACTIVO=0;
	public final static int STATUS_BLOQUEADO=1;
	public final static int STATUS_BAJA=2;
	public final static int STATUS_NUEVO=3;
	public final static int STATUS_REINICIADO=4;
	public final static int STATUS_MANTENIMIENTO=5;
	public final static int STATUS_EXPIRADO=6;
	
	public static final String MSJ_FOL_REQ= "El folio es requerido.";
	public static final String MSJ_FOL_ALPHA= "El folio debe ser alfanumerico.";
	public static final String FOLIO_VAL= "[A-Za-z0-9]+";
	
	public static final String SUCCESS="success";
	public static final String VALIDATION="validation";
	
	public static final int USER_EXTENRO_TYPE=1;
	public static final int USER_INTERNO_TYPE=0;
	public static final String USER_EXTENRO_TYPE_STRING="EXTERNO";
	public static final String USER_INETRNO_TYPE_STRING="INTERNO";
		
	public static final Integer ROL_TYPE_INTERNAL=0;
	public static final Integer ROL_TYPE_EXTERNAL=1;
	public static final Integer ROL_TYPE_MAINTENANCE=2;
	
	public static final String TYPE_ROL_INTERNAL_STR="INTERNO";
	public static final String TYPE_ROL_EXTERNAL_STR="EXTERNO";
	public static final String TYPE_ROL_MAINTENANCE_STR="MANTENIMIENTO";
	
	public static final Map<Integer,String> TYPE_ROL_AS_STRING= new HashMap<Integer,String>();
	static{
		TYPE_ROL_AS_STRING.put(ROL_TYPE_INTERNAL, TYPE_ROL_INTERNAL_STR);
		TYPE_ROL_AS_STRING.put(ROL_TYPE_EXTERNAL, TYPE_ROL_EXTERNAL_STR);
		TYPE_ROL_AS_STRING.put(ROL_TYPE_MAINTENANCE, TYPE_ROL_MAINTENANCE_STR);
	}
		
	public static final int INDEX0=0;
	public static final int INDEX1=1;
	public static final int INDEX2=2;
	public static final int INDEX3=3;
	public static final int INDEX4=4;
	public static final int INDEX5=5;
	public static final int INDEX6=6;
	public static final int INDEX7=7;
	public static final int INDEX8=8;
	public static final int INDEX9=9;
	public static final int INDEX10=10;
	public static final int INDEX11=11;
	public static final String FONT_EXCELL="Century Gothic";
	public static final short FONT_SIZE=10;
	public static final short FONT_SIZE_8=8;
	public static final byte BYTE_RED=0;
	public static final byte BYTE_GREEN=47;
	public static final byte BYTE_BLUE=119;
	public static final short BYTE_INDEX=57;
	public static final String SISTEMA_OVIT="Sistema SEG";
	public static final String VER_1="Ver. 1.0";
	public static final String FORMATOREPORTE="yyyyMMdd";
	public static final String FORMATYY="yy";
	private static String testVariable="valor from statatic";
    private static String erMail="^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	
    static XSSFColor level1 =new XSSFColor(new java.awt.Color(15,36,62));
    static XSSFColor level2 =new XSSFColor(new java.awt.Color(33,89,103));
    static XSSFColor level3 =new XSSFColor(new java.awt.Color(49,134,155));
    static XSSFColor level4 =new XSSFColor(new java.awt.Color(146,205,220));
    static XSSFColor level5 =new XSSFColor(new java.awt.Color(255,255,255));
	public static final Map<Integer,XSSFColor> STYLE_LEVELS= new HashMap<Integer,XSSFColor>();
	static{
		STYLE_LEVELS.put(INDEX1,level1);
		STYLE_LEVELS.put(INDEX2,level2);
		STYLE_LEVELS.put(INDEX3,level3);
		STYLE_LEVELS.put(INDEX4,level4);
		STYLE_LEVELS.put(INDEX0,level5);
	}
    public static String PREAPARADO_POR=":PREAPARADO_POR";
    public static String DOCUMENT_NAME=":DOCUMENT_NAME";
    public static String APROBADO_POR=":APROBADO_POR";
    public static String FECHA=":FECHA";   
    public static String VERSION="VERSION";
    public static String TITULO=":TITULO";
    
    public static String ESTADO_NO_TIMBRADO = "1";
    public static String ESTADO_TIMBRADO = "1"; 
    
    public static String MENSAJE_PAC_TIMBRADO = "Procesado correctamente";
    public static String MENSAJE_PAC_RECUPERADO = "Recuperado correctamente";
    
   
	// Para pantalla DetalleSolicitud
    public static final int FILENAME_MAX_LENGTH = 100;
    public static final String ELEMENT_ARCHIVOS_ACTUALES = "5";
    public static final String ELEM_ACCI_VER_DESCARGAR = "1";
    public static final String ELEM_ACCI_CARGA_ARCHIVOS = "2";
    public static final String ELEM_ACCI_CALIFICAR = "3";
    public static final String ELEM_MOSTRAR_UPDATE = "1";
        
	public  String getTestVariable() {
		return testVariable;
	}

	public  void setTestVariable(String testVariable) {
		Constants.testVariable = testVariable;
	}

	public  String getErMail() {
		return erMail;
	}

	public  void setErMail(String erMail) {
		Constants.erMail = erMail;
	}
	
	public static  XSSFFont getFontReportes(XSSFWorkbook xssfWorkbook){
		XSSFFont fontCampo = xssfWorkbook.createFont();
		fontCampo.setFontName(FONT_EXCELL);
		fontCampo.setFontHeightInPoints(FONT_SIZE_8);
		return fontCampo;
	}
	public static  XSSFFont getFontReportesBold(XSSFWorkbook xssfWorkbook){
		XSSFFont fontCampo = xssfWorkbook.createFont();
		fontCampo.setFontName(FONT_EXCELL);
		fontCampo.setFontHeightInPoints(FONT_SIZE_8);
		fontCampo.setBold(true);
		return fontCampo;
	}
	public static XSSFCellStyle getLevelStyle(XSSFWorkbook hssfWorkbook,int level){
		XSSFCellStyle style = hssfWorkbook.createCellStyle();
		XSSFFont fontH = hssfWorkbook.createFont();
		fontH.setFontName(FONT_EXCELL); 
		fontH.setFontHeightInPoints(FONT_SIZE);
		if(STYLE_LEVELS.containsKey(level)){
			style.setFillForegroundColor(STYLE_LEVELS.get(level));
			fontH.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			fontH.setColor(IndexedColors.WHITE.getIndex());
		}else{
			style.setFillForegroundColor(STYLE_LEVELS.get(INDEX0));
			fontH.setColor(IndexedColors.BLACK.getIndex());
		}
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style.setFont(fontH);
 
		return style;
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.incidencia.bean;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.webflow.execution.RequestContext;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.IIncidenciaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaAdjuntoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaBitacoraDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaGestionDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.OperadorDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.user.service.UserCatalogService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

@Controller("consultaIncidenciasBean")
@Scope(value = "session", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ConsultaIncidenciasBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private static final Logger logger = LoggerFactory.getLogger(ConsultaIncidenciasBean.class);

	private static final String PATRON_FECHA = "dd/MM/yyyy HH:mm:ss";

	@Autowired
	private IIncidenciaService incidenciaService;

	@Autowired
	private UserCatalogService userCatalogService;

	private List<IIncidenciaService.AdjuntoUi> adjuntosPendientes = new ArrayList<>();

	private Map<String, String> mapaConcesionarios = new HashMap<>();

	private String operadorUsuario;
	private Long idIncidenciaDetalleCargada;
	private String concesionarioUsuario;

	private Long idPrimerMovimientoBitacora;

	private String filtroFolio;
	private String filtroSitio;
	private String filtroEstatus;

	private List<IncidenciaGestionDto> listaIncidencias = new ArrayList<>();

	private IncidenciaGestionDto incidenciaSeleccionada;

	private List<IncidenciaBitacoraDto> bitacoraIncidenciaSeleccionada = new ArrayList<>();

	private String detalleNombreSitio;
	private String detalleRegion;
	private String detalleLatitud;
	private String detalleLongitud;

	private String accionSeleccionada;

	private String comentarioAccion;

	private String detalleTipoIncidencia;
	private String detalleDescripcionIncidencia;

	private List<String> catalogoAcciones = new ArrayList<>();

	private int indiceEtapa;

	private boolean soloConsultaDetalle = false;

	private String mensajeAccionNoPermitida;

	private List<IncidenciaAdjuntoDto> adjuntosIncidenciaSeleccionada = new ArrayList<>();
	private IncidenciaAdjuntoDto adjuntoEvidenciaAEliminar;

	private int cmTotalLeidas = 0;
	private int cmTotalCreadas = 0;
	private int cmTotalErrores = 0;
	private String uploadErrTitle;
	private String uploadErrMsg;
	private byte[] cmCatalogoErroresBytes;
	private String cmCatalogoErroresNombre = "CatalogoErrores_CargaMasiva.xlsx";
	private List<IncidenciaAdjuntoDto> adjuntosIncidenciaSeleccionadaReal = new ArrayList<>();
	private long maxBytesAdjunto = 10L * 1024 * 1024;
	private int maxMb = 10;
	private String formatosHumanosAdjunto = "PDF";
	private java.util.Set<String> adjuntosOcultosUi = new java.util.HashSet<>();
	private static final Integer ID_ROL_IFT_14 = Integer.valueOf(14);
	private static final Integer ID_ROL_IFT_22 = Integer.valueOf(22);
	private Boolean esUsuarioIFTCache = null;
	private static final long ID_ESTATUS_CREADA = 1L;
	private static final long ID_RESP_CONCESIONARIO = 1L;
	private static final long ID_RESP_MANTENIMIENTO = 2L;

	@PostConstruct
	public void init() {
		cargarMapaConcesionarios();
		cargarConcesionarioDesdePerfil();
		initCatalogoAcciones();
		initParametrosAdjuntos();
		esUsuarioIFTCache = null;
	}

	public void cargaInicialConcesionario(RequestContext ctx) {
		try {
			buscarBitacoraConcesionario();
		} catch (Exception e) {
			logger.error("Error en cargaInicialConcesionario de consulta incidencias", e);
		}
	}

	private void initCatalogoAcciones() {
		catalogoAcciones = new ArrayList<>();
		catalogoAcciones.add("Rechazar");
		catalogoAcciones.add("En atención");
		catalogoAcciones.add("Finalizar");
		mensajeAccionNoPermitida = "La acción seleccionada no es válida para el estatus actual de la incidencia.";

	}

	private void ajustarAccionesPorEstatus(String estatusActual) {
		catalogoAcciones = new ArrayList<>();

		String e = (estatusActual != null) ? estatusActual.trim().toUpperCase() : "";

		boolean esEnAtencion = "EN ATENCIÓN".equals(e) || "EN ATENCION".equals(e);

		catalogoAcciones.add("Rechazar");

		if (!esEnAtencion) {
			catalogoAcciones.add("En atención");
		}

		catalogoAcciones.add("Finalizar");
	}

	public void cargaInicial(RequestContext ctx) {
		try {
			buscar();
		} catch (Exception e) {
			logger.error("Error en cargaInicial de consulta incidencias", e);
		}
	}

	public void cargaInicialBitacoraConcesionario(RequestContext ctx) {
		try {
			buscarBitacoraConcesionario();
		} catch (Exception e) {
			logger.error("Error en cargaInicialBitacoraConcesionario", e);
		}
	}

	public void buscar() {
		try {
			if (mapaConcesionarios == null || mapaConcesionarios.isEmpty()) {
				cargarMapaConcesionarios();
			}
			if (concesionarioUsuario == null || concesionarioUsuario.trim().isEmpty()) {
				cargarConcesionarioDesdePerfil();
			}

			listaIncidencias = incidenciaService.buscarIncidenciasMantenimiento(filtroFolio, filtroSitio,
					filtroEstatus);

		} catch (Exception e) {
			logger.error("Error al consultar incidencias (mantenimiento). folio={}, sitio={}, estatus={}", filtroFolio,
					filtroSitio, filtroEstatus, e);
			listaIncidencias = new ArrayList<>();
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
					"No fue posible consultar la gestión de incidencias."));
		}
	}

	public void buscarBitacoraConcesionario() {
		try {
			if (mapaConcesionarios == null || mapaConcesionarios.isEmpty()) {
				cargarMapaConcesionarios();
			}
			if (concesionarioUsuario == null || concesionarioUsuario.trim().isEmpty()) {
				cargarConcesionarioDesdePerfil();
			}

			if (concesionarioUsuario == null || concesionarioUsuario.trim().isEmpty()) {
				listaIncidencias = new ArrayList<>();
				return;
			}

			listaIncidencias = incidenciaService.buscarIncidenciasConcesionario(filtroFolio, filtroSitio, filtroEstatus,
					concesionarioUsuario);
		} catch (Exception e) {
			logger.error(
					"Error al consultar incidencias (concesionario). folio={}, sitio={}, estatus={}, concesionario={}",
					filtroFolio, filtroSitio, filtroEstatus, concesionarioUsuario, e);
			listaIncidencias = new ArrayList<>();
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
					"No fue posible consultar las incidencias del concesionario."));
		}
	}

	public void limpiarFiltros() {
		filtroFolio = null;
		filtroSitio = null;
		filtroEstatus = null;
		buscar();
	}

	public void verBitacora(IncidenciaGestionDto dto) {
		Long idIncidencia = (dto != null ? dto.getIdIncidencia() : null);
		String folio = (dto != null ? dto.getFolio() : null);
		incidenciaSeleccionada = dto;

		if (dto == null || dto.getIdIncidencia() == null) {
			bitacoraIncidenciaSeleccionada = new ArrayList<>();
			idPrimerMovimientoBitacora = null;
			adjuntosIncidenciaSeleccionada = new ArrayList<>();
			return;
		}

		if (incidenciaService == null) {
			bitacoraIncidenciaSeleccionada = new ArrayList<>();
			adjuntosIncidenciaSeleccionada = new ArrayList<>();
			idPrimerMovimientoBitacora = null;
			return;
		}

		try {
			bitacoraIncidenciaSeleccionada = incidenciaService.obtenerBitacoraIncidencia(dto.getIdIncidencia());
			if (bitacoraIncidenciaSeleccionada == null) {
				bitacoraIncidenciaSeleccionada = new ArrayList<>();
			}
		} catch (Exception e) {
			bitacoraIncidenciaSeleccionada = new ArrayList<>();
		}

		try {
			adjuntosIncidenciaSeleccionada = incidenciaService.obtenerAdjuntosIncidencia(dto.getIdIncidencia());
			if (adjuntosIncidenciaSeleccionada == null) {
				adjuntosIncidenciaSeleccionada = new ArrayList<>();
			}
		} catch (Exception e) {
			adjuntosIncidenciaSeleccionada = new ArrayList<>();
		}

		idPrimerMovimientoBitacora = null;
		if (bitacoraIncidenciaSeleccionada != null && !bitacoraIncidenciaSeleccionada.isEmpty()) {
			IncidenciaBitacoraDto primero = bitacoraIncidenciaSeleccionada.get(0);
			if (primero != null) {
				idPrimerMovimientoBitacora = primero.getId();
			}
		}

	}

	public String formatearFechaBitacora(IncidenciaBitacoraDto mov) {
		if (mov == null || mov.getFechaEvento() == null) {
			return "";
		}
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(PATRON_FECHA);
			return sdf.format(mov.getFechaEvento());
		} catch (Exception e) {
			return mov.getFechaEvento().toString();
		}
	}

	public String obtenerOperadorMovimiento(IncidenciaBitacoraDto movimiento) {
	    if (movimiento == null) return "";
	    // Comparamos el String directamente
	    if ("CREADA".equalsIgnoreCase(movimiento.getEstatusNuevo())) {
	        return "";
	    }
	    return (movimiento.getUsuarioMovimiento() == null) ? "" : movimiento.getUsuarioMovimiento().trim();
	}

	

	public String obtenerResponsabilidadMovimiento(IncidenciaBitacoraDto movimiento) {
		if (movimiento == null || movimiento.getResponsabilidad() == null) {
			return "";
		}
		return movimiento.getResponsabilidad();
	}

	public boolean tieneAdjuntoAlta(IncidenciaBitacoraDto mov, int rowIndex) {
		if (!esMovimientoInicial(mov)) {
			return false;
		}

		if (mov == null) {
			return false;
		}

		try {
			if (incidenciaSeleccionada != null && incidenciaSeleccionada.getIdIncidencia() != null) {
				if (adjuntosIncidenciaSeleccionada == null || adjuntosIncidenciaSeleccionada.isEmpty()) {
					adjuntosIncidenciaSeleccionada = incidenciaService
							.obtenerAdjuntosIncidencia(incidenciaSeleccionada.getIdIncidencia());
					if (adjuntosIncidenciaSeleccionada == null) {
						adjuntosIncidenciaSeleccionada = new ArrayList<>();
					}
				}
			} else {
				adjuntosIncidenciaSeleccionada = new ArrayList<>();
			}
		} catch (Exception e) {
		
			adjuntosIncidenciaSeleccionada = new ArrayList<>();
		}

		return adjuntosIncidenciaSeleccionada != null && !adjuntosIncidenciaSeleccionada.isEmpty();
	}

	private String construirNombreCompleto(String nombre, String apellidoPaterno, String apellidoMaterno) {
		StringBuilder sb = new StringBuilder();

		if (nombre != null && !nombre.trim().isEmpty()) {
			sb.append(nombre.trim());
		}
		if (apellidoPaterno != null && !apellidoPaterno.trim().isEmpty()) {
			if (sb.length() > 0)
				sb.append(" ");
			sb.append(apellidoPaterno.trim());
		}
		if (apellidoMaterno != null && !apellidoMaterno.trim().isEmpty()) {
			if (sb.length() > 0)
				sb.append(" ");
			sb.append(apellidoMaterno.trim());
		}

		return sb.toString().trim();
	}

	public void descargarBitacora() {
		FacesContext fc = FacesContext.getCurrentInstance();

		if (incidenciaSeleccionada == null || bitacoraIncidenciaSeleccionada == null
				|| bitacoraIncidenciaSeleccionada.isEmpty()) {

			fc.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Sin datos",
					"No hay movimientos de bitácora para exportar."));
			return;
		}

		XSSFWorkbook workbook = new XSSFWorkbook();
		try {
			Sheet sheet = workbook.createSheet("Bitácora Incidencia");
			sheet.setDisplayGridlines(false);
			sheet.setPrintGridlines(false);

			XSSFCellStyle styleTitulo = Constants.getLevelStyle(workbook, Constants.INDEX1);
			styleTitulo.setAlignment(CellStyle.ALIGN_CENTER);

			XSSFCellStyle styleHeader = Constants.getLevelStyle(workbook, Constants.INDEX2);
			styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
			styleHeader.setBorderBottom(CellStyle.BORDER_THIN);
			styleHeader.setBorderTop(CellStyle.BORDER_THIN);
			styleHeader.setBorderLeft(CellStyle.BORDER_THIN);
			styleHeader.setBorderRight(CellStyle.BORDER_THIN);

			XSSFCellStyle styleDato = Constants.getLevelStyle(workbook, Constants.INDEX5);
			styleDato.setBorderBottom(CellStyle.BORDER_THIN);
			styleDato.setBorderTop(CellStyle.BORDER_THIN);
			styleDato.setBorderLeft(CellStyle.BORDER_THIN);
			styleDato.setBorderRight(CellStyle.BORDER_THIN);

			int rowNum = 0;

			Row rowTitulo = sheet.createRow(rowNum++);
			Cell celdaTitulo = rowTitulo.createCell(0);
			celdaTitulo.setCellValue("BITÁCORA DETALLE DE INCIDENCIA");
			celdaTitulo.setCellStyle(styleTitulo);
			sheet.addMergedRegion(new CellRangeAddress(rowTitulo.getRowNum(), rowTitulo.getRowNum(), 0, 7));

			Row header = sheet.createRow(rowNum++);
			int col = 0;
			String[] titulos = new String[] { "Folio", "Operador", "Usuario", "Empresa", "Estatus Actual",
					"Fecha movimiento", "Responsabilidad Actual", "Comentario" };
			for (String t : titulos) {
				Cell c = header.createCell(col++);
				c.setCellValue(t);
				c.setCellStyle(styleHeader);
			}

			for (IncidenciaBitacoraDto mov : bitacoraIncidenciaSeleccionada) {
				Row row = sheet.createRow(rowNum++);
				int c = 0;

				String folio = (incidenciaSeleccionada != null && incidenciaSeleccionada.getFolio() != null)
						? incidenciaSeleccionada.getFolio()
						: "";
				String operadorExcel = obtenerOperadorMovimiento(mov);

				String usuarioExcel = (incidenciaSeleccionada != null
						&& incidenciaSeleccionada.getUsuarioCreacion() != null)
								? incidenciaSeleccionada.getUsuarioCreacion()
								: "";

				String empresaExcel;
				if (incidenciaSeleccionada != null && incidenciaSeleccionada.getConcesionario() != null) {
					empresaExcel = incidenciaSeleccionada.getConcesionario();
				} else if (concesionarioUsuario != null) {
					empresaExcel = concesionarioUsuario;
				} else {
					empresaExcel = "";
				}

				String estatusActual = (mov.getEstatusNuevo() != null) ? mov.getEstatusNuevo() : "";

				String fechaStr = "";
				if (mov.getFechaEvento() != null) {
					fechaStr = formatearFechaBitacora(mov);
				}

				String responsabilidad = obtenerResponsabilidadMovimiento(mov);

				String comentario = (mov.getComentario() != null) ? mov.getComentario() : "";

				Cell cFolio = row.createCell(c++);
				cFolio.setCellValue(folio);
				cFolio.setCellStyle(styleDato);

				Cell cOperador = row.createCell(c++);
				cOperador.setCellValue(operadorExcel);
				cOperador.setCellStyle(styleDato);

				Cell cUsuario = row.createCell(c++);
				cUsuario.setCellValue(usuarioExcel);
				cUsuario.setCellStyle(styleDato);

				Cell cEmpresa = row.createCell(c++);
				cEmpresa.setCellValue(empresaExcel);
				cEmpresa.setCellStyle(styleDato);

				Cell cEst = row.createCell(c++);
				cEst.setCellValue(estatusActual);
				cEst.setCellStyle(styleDato);

				Cell cFecha = row.createCell(c++);
				cFecha.setCellValue(fechaStr);
				cFecha.setCellStyle(styleDato);

				Cell cResp = row.createCell(c++);
				cResp.setCellValue(responsabilidad);
				cResp.setCellStyle(styleDato);

				Cell cCom = row.createCell(c++);
				cCom.setCellValue(comentario);
				cCom.setCellStyle(styleDato);
			}

			for (int i = 0; i < 8; i++) {
				sheet.autoSizeColumn(i);
			}

			ExternalContext ec = fc.getExternalContext();
			ec.setResponseContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

			String nombreArchivo = "BitacoraIncidencia_"
					+ (incidenciaSeleccionada != null ? incidenciaSeleccionada.getFolio() : "") + ".xlsx";

			ec.setResponseHeader("Content-Disposition", "attachment; filename=\"" + nombreArchivo + "\"");

			OutputStream out = ec.getResponseOutputStream();
			workbook.write(out);
			out.flush();
			fc.responseComplete();

		} catch (IOException e) {
			fc.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
					"No fue posible generar el archivo de bitácora."));
		} finally {
			try {
				workbook.close();
			} catch (IOException ignore) {
			}
		}
	}

	public void descargarGestionIncidencias() {
		FacesContext fc = FacesContext.getCurrentInstance();

		if (listaIncidencias == null || listaIncidencias.isEmpty()) {
			fc.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_WARN, "Sin datos", "No hay incidencias para exportar."));
			return;
		}

		XSSFWorkbook workbook = new XSSFWorkbook();
		try {
			Sheet sheet = workbook.createSheet("Gestión incidencias");
			sheet.setDisplayGridlines(false);
			sheet.setPrintGridlines(false);

			XSSFCellStyle styleTitulo = Constants.getLevelStyle(workbook, Constants.INDEX1);
			styleTitulo.setAlignment(CellStyle.ALIGN_CENTER);

			XSSFCellStyle styleHeader = Constants.getLevelStyle(workbook, Constants.INDEX2);
			styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
			styleHeader.setBorderBottom(CellStyle.BORDER_THIN);
			styleHeader.setBorderTop(CellStyle.BORDER_THIN);
			styleHeader.setBorderLeft(CellStyle.BORDER_THIN);
			styleHeader.setBorderRight(CellStyle.BORDER_THIN);

			XSSFCellStyle styleDato = Constants.getLevelStyle(workbook, Constants.INDEX5);
			styleDato.setBorderBottom(CellStyle.BORDER_THIN);
			styleDato.setBorderTop(CellStyle.BORDER_THIN);
			styleDato.setBorderLeft(CellStyle.BORDER_THIN);
			styleDato.setBorderRight(CellStyle.BORDER_THIN);

			int rowNum = 0;

			Row rowTitulo = sheet.createRow(rowNum++);
			Cell celdaTitulo = rowTitulo.createCell(0);
			celdaTitulo.setCellValue("GESTIÓN DE INCIDENCIAS");
			celdaTitulo.setCellStyle(styleTitulo);
			sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 7));

			Row header = sheet.createRow(rowNum++);
			int col = 0;

			String[] titulos = new String[] { "Folio", "ID Sitio", "Nombre Sitio", "Concesionario", "Pendiente por",
					"Estatus", "Usuario creación", "Fecha creación" };

			for (String t : titulos) {
				Cell c = header.createCell(col++);
				c.setCellValue(t);
				c.setCellStyle(styleHeader);
			}

			for (IncidenciaGestionDto dto : listaIncidencias) {
				Row row = sheet.createRow(rowNum++);
				int c = 0;

				Cell cFolio = row.createCell(c++);
				cFolio.setCellValue(dto.getFolio() != null ? dto.getFolio() : "");
				cFolio.setCellStyle(styleDato);

				Cell cIdSitio = row.createCell(c++);
				cIdSitio.setCellValue(dto.getIdSitio() != null ? dto.getIdSitio() : "");
				cIdSitio.setCellStyle(styleDato);

				Cell cNombreSitio = row.createCell(c++);
				cNombreSitio.setCellValue(dto.getNombreSitio() != null ? dto.getNombreSitio() : "");
				cNombreSitio.setCellStyle(styleDato);

				Cell cConcesionario = row.createCell(c++);
				cConcesionario.setCellValue(dto.getConcesionario() != null ? dto.getConcesionario() : "");
				cConcesionario.setCellStyle(styleDato);

				Cell cPendiente = row.createCell(c++);
				cPendiente.setCellValue(dto.getPendientePor() != null ? dto.getPendientePor() : "");
				cPendiente.setCellStyle(styleDato);

				Cell cEstatus = row.createCell(c++);
				cEstatus.setCellValue(dto.getEstatus() != null ? dto.getEstatus() : "");
				cEstatus.setCellStyle(styleDato);

				Cell cUsuario = row.createCell(c++);
				cUsuario.setCellValue(dto.getUsuarioCreacion() != null ? dto.getUsuarioCreacion() : "");
				cUsuario.setCellStyle(styleDato);

				Cell cFecha = row.createCell(c++);
				cFecha.setCellValue(dto.getFechaCreacion() != null ? dto.getFechaCreacion() : "");
				cFecha.setCellStyle(styleDato);
			}

			for (int i = 0; i < 8; i++) {
				sheet.autoSizeColumn(i);
			}

			ExternalContext ec = fc.getExternalContext();
			ec.setResponseContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			ec.setResponseHeader("Content-Disposition", "attachment; filename=\"GestionIncidencias.xlsx\"");

			OutputStream out = ec.getResponseOutputStream();
			workbook.write(out);
			out.flush();
			fc.responseComplete();

		} catch (IOException e) {
			fc.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
					"No fue posible generar el archivo de gestión de incidencias."));
		} finally {
			try {
				workbook.close();
			} catch (IOException ignore) {
			}
		}
	}

	private void cargarMapaConcesionarios() {
		mapaConcesionarios = new HashMap<>();
		if (userCatalogService == null) {
			return;
		}
		try {
			List<OperadorDto> empresas = userCatalogService.obtenerEmpresas();
			if (empresas != null) {
				for (OperadorDto op : empresas) {
					if (op == null || op.getGrupoOperador() == null) {
						continue;
					}
					String codigo = op.getGrupoOperador().trim();
					String desc = op.getDescripcion();
					if (!codigo.isEmpty() && desc != null && !desc.trim().isEmpty()) {
						mapaConcesionarios.put(codigo, desc.trim());
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error al cargar catálogo de concesionarios", e);
		}
	}

	private void cargarConcesionarioDesdePerfil() {
		try {
			Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

			if (!(principal instanceof UserDetailsVo)) {
				return;
			}

			UserDetailsVo userDetailsVo = (UserDetailsVo) principal;
			Integer idUsuario = userDetailsVo.getIdUsuario();

			if (idUsuario == null) {
				return;
			}

			String operadorRaw = null;

			
			try {
				if (userCatalogService != null) {
					operadorRaw = userCatalogService.obtenerOperadorUsuario(idUsuario);
				} else {
					logger.warn("userCatalogService NULO al intentar cargar operador.");
				}
			} catch (Exception ex) {
				logger.error("Error CONTROLADO al obtener operador del usuario {}. Se continuará sin filtro.",
						idUsuario, ex);
				operadorRaw = null;
			}

			this.operadorUsuario = operadorRaw;

			if (operadorRaw == null || operadorRaw.trim().isEmpty()) {
				return;
			}

			String operadorTrim = operadorRaw.trim();
			String codigoOperador = operadorTrim;
			String nombreDesdeRaw = null;

			int idx = operadorTrim.indexOf(':');
			if (idx >= 0) {
				codigoOperador = operadorTrim.substring(0, idx).trim();
				if (idx + 1 < operadorTrim.length()) {
					nombreDesdeRaw = operadorTrim.substring(idx + 1).trim();
				}
			}

			if (nombreDesdeRaw != null && !nombreDesdeRaw.isEmpty()) {
				concesionarioUsuario = nombreDesdeRaw;
				return;
			}

			if (mapaConcesionarios == null || mapaConcesionarios.isEmpty()) {
				cargarMapaConcesionarios();
			}

			String desc = mapaConcesionarios.get(codigoOperador);

			if (desc != null && !desc.trim().isEmpty()) {
				concesionarioUsuario = desc.trim();
			} else {
				concesionarioUsuario = codigoOperador;
			}

		} catch (Exception e) {
			logger.error("Error general al cargar concesionario desde perfil", e);
		}
	}

	public void prepararMantenimiento() {

		FacesContext fc = FacesContext.getCurrentInstance();

		Long idActual = (incidenciaSeleccionada != null ? incidenciaSeleccionada.getIdIncidencia() : null);
		String folio = (incidenciaSeleccionada != null ? incidenciaSeleccionada.getFolio() : null);

		try {
			if (incidenciaSeleccionada == null || incidenciaSeleccionada.getIdIncidencia() == null) {
				limpiarDetalleSitio();
				idIncidenciaDetalleCargada = null;
				adjuntosIncidenciaSeleccionada = new ArrayList<>();
				bitacoraIncidenciaSeleccionada = new ArrayList<>();
				idPrimerMovimientoBitacora = null;
				return;
			}

			boolean mismaIncidencia = (idIncidenciaDetalleCargada != null
					&& idIncidenciaDetalleCargada.equals(idActual));
			boolean esAjax = (fc != null && fc.getPartialViewContext() != null
					&& fc.getPartialViewContext().isAjaxRequest());

			if (fc != null && fc.isPostback() && esAjax && mismaIncidencia) {
				return;
			}

			try {
				bitacoraIncidenciaSeleccionada = incidenciaService.obtenerBitacoraIncidencia(idActual);

				sincronizarEstatusDesdeBitacora();
			} catch (Exception e) {
				logger.error("Error al refrescar bitácora en recarga", e);
			}
			idIncidenciaDetalleCargada = idActual;

			if (incidenciaSeleccionada.getIdSitio() == null || incidenciaSeleccionada.getIdSitio().trim().isEmpty()) {
				limpiarDetalleSitio();
				return;
			}

			cargarDetalleSitio(incidenciaSeleccionada.getIdSitio().trim());

			this.detalleTipoIncidencia = incidenciaSeleccionada.getTipo() != null ? incidenciaSeleccionada.getTipo()
					: "";
			this.detalleDescripcionIncidencia = incidenciaSeleccionada.getDescripcion() != null
					? incidenciaSeleccionada.getDescripcion()
					: "";

			this.indiceEtapa = calcularIndiceEtapaDesdeEstatus(incidenciaSeleccionada.getEstatus());
			ajustarAccionesPorEstatus(incidenciaSeleccionada.getEstatus());

			if (incidenciaService == null) {
				bitacoraIncidenciaSeleccionada = new ArrayList<>();
				adjuntosIncidenciaSeleccionada = new ArrayList<>();
				idPrimerMovimientoBitacora = null;
				return;
			}

			try {
				bitacoraIncidenciaSeleccionada = incidenciaService.obtenerBitacoraIncidencia(idActual);
				sincronizarEstatusDesdeBitacora();

				if (bitacoraIncidenciaSeleccionada == null) {
					bitacoraIncidenciaSeleccionada = new ArrayList<>();
				}
			} catch (Exception e) {
				logger.error("INC-JSF prepararMantenimiento FALLO al cargar bitácora. idIncidencia={}", idActual, e);
				bitacoraIncidenciaSeleccionada = new ArrayList<>();
			}

			try {
				if (!mismaIncidencia) {
					adjuntosOcultosUi.clear();
				}

				List<IncidenciaAdjuntoDto> tmpAdj = incidenciaService.obtenerAdjuntosIncidencia(idActual);
				this.adjuntosIncidenciaSeleccionadaReal = (tmpAdj != null) ? tmpAdj
						: new ArrayList<IncidenciaAdjuntoDto>();

				rebuildAdjuntosVisiblesDesdeReal();

			} catch (Exception e) {
				this.adjuntosIncidenciaSeleccionada = new ArrayList<>();
			}

			idPrimerMovimientoBitacora = null;
			if (bitacoraIncidenciaSeleccionada != null && !bitacoraIncidenciaSeleccionada.isEmpty()) {
				IncidenciaBitacoraDto primero = bitacoraIncidenciaSeleccionada.get(0);
				idPrimerMovimientoBitacora = (primero != null) ? primero.getId() : null;
			}

		} catch (Throwable t) {
		
			bitacoraIncidenciaSeleccionada = new ArrayList<>();
			adjuntosIncidenciaSeleccionada = new ArrayList<>();
			idPrimerMovimientoBitacora = null;
		}
	}

	private void cargarDetalleSitio(String idSitio) {
		limpiarDetalleSitio();
		try {
			List<?> listaSitios = incidenciaService.listarSitiosEnOperacionVisibles();
			if (listaSitios == null) {
				return;
			}

			for (Object obj : listaSitios) {
				if (!(obj instanceof SitioDto)) {
					continue;
				}
				SitioDto s = (SitioDto) obj;
				if (s.getSitio() != null && s.getSitio().trim().equals(idSitio)) {
					detalleNombreSitio = s.getNombre() != null ? s.getNombre() : "";
					detalleRegion = s.getRegion() != null ? String.valueOf(s.getRegion()) : "";
					detalleLatitud = s.getLatitud() != null ? String.valueOf(s.getLatitud()) : "";
					detalleLongitud = s.getLongitud() != null ? String.valueOf(s.getLongitud()) : "";
					break;
				}
			}
		} catch (Exception e) {
			limpiarDetalleSitio();
		}
	}

	private void limpiarDetalleSitio() {
		detalleNombreSitio = "";
		detalleRegion = "";
		detalleLatitud = "";
		detalleLongitud = "";
		detalleTipoIncidencia = "";
		detalleDescripcionIncidencia = "";
		indiceEtapa = 0;
	}

	private int calcularIndiceEtapaDesdeEstatus(String estatus) {
		if (estatus == null) {
			return 0;
		}
		String e = estatus.toUpperCase();
		if (e.contains("RECHAZ")) {
			return 1;
		}
		if (e.contains("ATEN")) {
			return 2;
		}
		if (e.contains("FINAL")) {
			return 3;
		}
		return 0;
	}

	private String calcularPendientePorLocal(String estatus) {
		if (estatus == null)
			return "-";

		String e = estatus.trim().toUpperCase();

		if ("CREADA".equals(e) || e.contains("ATEN")) {
			return "Mantenimiento";
		}

		return "-";
	}

	private String mapAccionAEstatus(String accion) {
		String a = accion.trim().toUpperCase();
		if (a.contains("RECHAZ"))
			return "RECHAZADA";
		if (a.contains("ATEN"))
			return "EN ATENCIÓN";
		if (a.contains("FINAL"))
			return "FINALIZADA";
		return a;
	}

	public void prepararAvanceIncidencia() {

		if (isEsUsuarioIFT()) {
			org.primefaces.context.RequestContext pfCtx = org.primefaces.context.RequestContext.getCurrentInstance();
			if (pfCtx != null) {
				pfCtx.addCallbackParam("accionNoPermitida", true);
				pfCtx.addCallbackParam("mostrarSeleccionAccion", false);
				pfCtx.addCallbackParam("mostrarConfirmacion", false);
			}
			mensajeAccionNoPermitida = "Operación no permitida: perfil IFT en modo solo consulta.";
			return;
		}

		if (soloConsultaDetalle) {
			org.primefaces.context.RequestContext pfCtx = org.primefaces.context.RequestContext.getCurrentInstance();
			if (pfCtx != null) {
				pfCtx.addCallbackParam("accionNoPermitida", true);
				pfCtx.addCallbackParam("mostrarSeleccionAccion", false);
				pfCtx.addCallbackParam("mostrarConfirmacion", false);
			}
			mensajeAccionNoPermitida = "Operación no permitida: la incidencia se encuentra en modo consulta.";
			return;
		}

		org.primefaces.context.RequestContext pfCtx = org.primefaces.context.RequestContext.getCurrentInstance();

		if (pfCtx == null) {
			return;
		}

		pfCtx.addCallbackParam("accionNoPermitida", false);
		pfCtx.addCallbackParam("mostrarSeleccionAccion", false);
		pfCtx.addCallbackParam("mostrarConfirmacion", false);

		if (incidenciaSeleccionada == null || incidenciaSeleccionada.getIdIncidencia() == null) {
			return;
		}

		if (accionSeleccionada == null || accionSeleccionada.trim().isEmpty()) {
			comentarioAccion = null;
			pfCtx.addCallbackParam("mostrarSeleccionAccion", true);
			return;
		}

		String estatusActual = incidenciaSeleccionada.getEstatus();
		String estatusUpper = (estatusActual != null) ? estatusActual.trim().toUpperCase() : "";
		String accionUpper = accionSeleccionada.trim().toUpperCase();

		if ("CREADA".equals(estatusUpper) && accionUpper.contains("FINAL")) {
			mensajeAccionNoPermitida = "Una incidencia en estado CREADA debe pasar primero a EN ATENCIÓN antes de finalizarse.";
			comentarioAccion = null;
			pfCtx.addCallbackParam("accionNoPermitida", true);
			return;
		}

		if (("EN ATENCIÓN".equals(estatusUpper) || "EN ATENCION".equals(estatusUpper))
				&& accionUpper.contains("ATEN")) {
			mensajeAccionNoPermitida = "La incidencia ya se encuentra EN ATENCIÓN.";
			comentarioAccion = null;
			pfCtx.addCallbackParam("accionNoPermitida", true);
			return;
		}

		if (("EN ATENCIÓN".equals(estatusUpper) || "EN ATENCION".equals(estatusUpper))
				&& accionUpper.contains("RECHAZ")) {
			mensajeAccionNoPermitida = "No es posible rechazar una incidencia que ya se encuentra EN ATENCIÓN.";
			comentarioAccion = null;
			pfCtx.addCallbackParam("accionNoPermitida", true);
			return;
		}

		comentarioAccion = null;
		pfCtx.addCallbackParam("mostrarConfirmacion", true);
	}

	public void avanzarIncidencia() {

		if (isEsUsuarioIFT()) {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
					"Acción no permitida", "Perfil IFT en modo solo consulta."));
			return;
		}

		if (soloConsultaDetalle) {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
					"Acción no permitida", "La incidencia se encuentra en modo consulta y no permite cambios."));
			return;
		}

		FacesContext ctx = FacesContext.getCurrentInstance();

		if (incidenciaSeleccionada == null || incidenciaSeleccionada.getIdIncidencia() == null) {
			ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Sin incidencia",
					"No hay incidencia seleccionada para avanzar."));
			return;
		}

		if (accionSeleccionada == null || accionSeleccionada.trim().isEmpty()) {
			ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Acción requerida",
					"Seleccione una acción en la barra de acciones."));
			return;
		}

		String estatusActual = incidenciaSeleccionada.getEstatus();
		String estatusActualTrim = estatusActual != null ? estatusActual.trim() : "";

		if ("FINALIZADA".equalsIgnoreCase(estatusActualTrim) || "RECHAZADA".equalsIgnoreCase(estatusActualTrim)) {
			ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Acción no permitida",
					"La incidencia ya se encuentra " + estatusActualTrim + " y no permite cambios de estatus."));
			return;
		}

		String estatusAnterior = estatusActual != null ? estatusActual : "SIN ESTATUS";

		try {
			String nuevoEstatus = mapAccionAEstatus(accionSeleccionada);

			if ("EN ATENCIÓN".equalsIgnoreCase(estatusActualTrim) && "RECHAZADA".equalsIgnoreCase(nuevoEstatus)) {
				ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Acción no permitida",
						"No es posible rechazar una incidencia que ya se encuentra EN ATENCIÓN."));
				return;
			}

			if ("CREADA".equalsIgnoreCase(estatusActualTrim) && "FINALIZADA".equalsIgnoreCase(nuevoEstatus)) {
				ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Acción no permitida",
						"Una incidencia en estado CREADA debe pasar primero a EN ATENCIÓN antes de finalizarse."));
				return;
			}

			Long idUsuarioMov = null;
			try {
				Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
				if (principal instanceof UserDetailsVo) {
					UserDetailsVo userDetailsVo = (UserDetailsVo) principal;
					if (userDetailsVo.getIdUsuario() != null) {
						idUsuarioMov = userDetailsVo.getIdUsuario().longValue();
					}
				}
			} catch (Exception e) {
				logger.warn("No se pudo obtener idUsuario del contexto de seguridad al avanzar incidencia", e);
			}

			incidenciaService.avanzarIncidencia(incidenciaSeleccionada.getIdIncidencia(), accionSeleccionada,
					comentarioAccion, idUsuarioMov);

			incidenciaSeleccionada.setEstatus(nuevoEstatus);
			incidenciaSeleccionada.setPendientePor(calcularPendientePorLocal(nuevoEstatus));

			ajustarAccionesPorEstatus(nuevoEstatus);

			accionSeleccionada = null;

			this.indiceEtapa = calcularIndiceEtapaDesdeEstatus(nuevoEstatus);

			bitacoraIncidenciaSeleccionada = incidenciaService
					.obtenerBitacoraIncidencia(incidenciaSeleccionada.getIdIncidencia());

			if (bitacoraIncidenciaSeleccionada != null && !bitacoraIncidenciaSeleccionada.isEmpty()) {
				IncidenciaBitacoraDto primero = bitacoraIncidenciaSeleccionada.get(0);
				idPrimerMovimientoBitacora = primero != null ? primero.getId() : null;
			} else {
				idPrimerMovimientoBitacora = null;
			}

			ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Movimiento registrado",
					"Estatus: " + estatusAnterior + " → " + nuevoEstatus));

			this.accionSeleccionada = null;
			this.comentarioAccion = null;

			
			buscar();

		} catch (Exception e) {
			ctx.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "No fue posible avanzar la incidencia."));
		} finally {
			comentarioAccion = null;
		}
	}

	public void handleCargaMasivaIncidenciasExternas(FileUploadEvent e) {
		FacesContext fc = FacesContext.getCurrentInstance();
		UploadedFile f = e.getFile();

		cmTotalLeidas = 0;
		cmTotalCreadas = 0;
		cmTotalErrores = 0;
		cmCatalogoErroresBytes = null;

		if (f == null) {
			fc.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Archivo inválido", "No se recibió el archivo."));
			return;
		}

		String nombre = (f.getFileName() != null) ? f.getFileName().trim() : "";
		String lower = nombre.toLowerCase();
		if (!(lower.endsWith(".xls") || lower.endsWith(".xlsx"))) {
			fc.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Formato inválido",
					"El archivo debe ser Excel (.xls o .xlsx)."));
			return;
		}

		try {
			DataFormatter fmt = new DataFormatter();

			Workbook wb = WorkbookFactory.create(new ByteArrayInputStream(f.getContents()));
			org.apache.poi.ss.usermodel.Sheet sh = wb.getSheet("Incidencias");
			if (sh == null)
				sh = wb.getSheetAt(0);

			List<?> sitios = incidenciaService.listarSitiosEnOperacionVisibles();
			List<String> tipos = incidenciaService.catalogoTiposIncidencia();

			List<Map<String, String>> errores = new ArrayList<>();
			List<Map<String, String>> capturados = new ArrayList<>();

			int renglonIncidencia = 0;
			for (int r = 1; r <= sh.getLastRowNum(); r++) {
				org.apache.poi.ss.usermodel.Row row = sh.getRow(r);
				if (row == null)
					continue;

				String idSitio = fmt.formatCellValue(row.getCell(0)).trim();
				String tipo = fmt.formatCellValue(row.getCell(1)).trim();
				String desc = fmt.formatCellValue(row.getCell(2)).trim();
				String nombreRep = fmt.formatCellValue(row.getCell(3)).trim();
				String correo = fmt.formatCellValue(row.getCell(4)).trim();
				String conces = fmt.formatCellValue(row.getCell(5)).trim();
				String estatusExcel = fmt.formatCellValue(row.getCell(6)).trim();

				boolean filaVacia = idSitio.isEmpty() && tipo.isEmpty() && desc.isEmpty() && nombreRep.isEmpty()
						&& correo.isEmpty() && conces.isEmpty() && estatusExcel.isEmpty();
				if (filaVacia)
					continue;

				renglonIncidencia++;
				cmTotalLeidas++;

				Map<String, String> err = new HashMap<>();
				Map<String, String> cap = new HashMap<>();
				cap.put("renglon", String.valueOf(renglonIncidencia));
				cap.put("idSitio", idSitio);
				cap.put("tipo", tipo);
				cap.put("desc", desc);
				cap.put("nombre", nombreRep);
				cap.put("correo", correo);
				cap.put("conces", conces);
				cap.put("estatus", estatusExcel);

				if (idSitio.isEmpty())
					err.put("idSitio", "ID de sitio faltante (campo obligatorio).");
				else if (!existeSitioEnCatalogo(idSitio, sitios))
					err.put("idSitio", "ID de sitio inexistente en el catálogo de sitios.");

				if (tipo.isEmpty())
					err.put("tipo", "Tipo de incidencia faltante (campo obligatorio).");
				else if (!existeTipoEnCatalogo(tipo, tipos))
					err.put("tipo", "Tipo de incidencia inexistente en el catálogo.");

				if (desc.isEmpty())
					err.put("desc", "Descripción detallada faltante (campo obligatorio).");

				if (nombreRep.isEmpty())
					err.put("nombre", "Nombre de quien reporta faltante (campo obligatorio).");

				if (correo.isEmpty())
					err.put("correo", "No se agregó correo de quien reporta.");
				else if (!correoValidoBasico(correo))
					err.put("correo", "Correo de quien reporta con formato inválido.");

				if (conces.isEmpty())
					err.put("conces", "Concesionario faltante (campo obligatorio).");
				else if (!existeConcesionarioEnCatalogo(conces))
					err.put("conces", "Concesionario inexistente en el catálogo.");

				String estatusCanon = normalizarEstatusExcel(estatusExcel);
				if (estatusExcel.isEmpty())
					err.put("estatus", "Estatus faltante (campo obligatorio).");
				else if (estatusCanon == null)
					err.put("estatus", "Estatus inválido. Permitidos: CREADA, EN ATENCIÓN, RECHAZADA, FINALIZADA.");

				if (!err.isEmpty()) {
					errores.add(err);
					capturados.add(cap);
					cmTotalErrores++;
					continue;
				}

				try {
					incidenciaService.crearIncidenciaExternaCargaMasiva(idSitio, normalizarTipo(tipo, tipos), desc,
							nombreRep, correo, conces, estatusCanon);
					cmTotalCreadas++;
				} catch (Exception ex) {
					err.put("desc", "Error al crear incidencia en el sistema: " + ex.getMessage());
					errores.add(err);
					capturados.add(cap);
					cmTotalErrores++;
				}
			}

			if (cmTotalErrores > 0) {
				cmCatalogoErroresBytes = generarCatalogoErrores(errores, capturados);
			}

			buscar();

		} catch (Exception ex) {
			logger.error("Error al procesar carga masiva", ex);
			fc.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "No fue posible procesar el archivo."));
		}
	}

	private boolean existeSitioEnCatalogo(String idSitio, List<?> sitios) {
		if (sitios == null)
			return false;
		for (Object o : sitios) {
			if (o instanceof SitioDto) {
				SitioDto s = (SitioDto) o;
				if (s.getSitio() != null && s.getSitio().trim().equalsIgnoreCase(idSitio.trim()))
					return true;
			}
		}
		return false;
	}

	private boolean existeTipoEnCatalogo(String tipo, List<String> tipos) {
		if (tipos == null)
			return false;
		for (String t : tipos) {
			if (t != null && t.trim().equalsIgnoreCase(tipo.trim()))
				return true;
		}
		return false;
	}

	private String normalizarTipo(String tipo, List<String> tipos) {

		if (tipos != null) {
			for (String t : tipos) {
				if (t != null && t.trim().equalsIgnoreCase(tipo.trim()))
					return t.trim();
			}
		}
		return tipo.trim();
	}

	private boolean correoValidoBasico(String correo) {
		String c = correo.trim();
		return c.contains("@") && c.indexOf('@') > 0 && c.indexOf('@') < c.length() - 3;
	}

	private boolean existeConcesionarioEnCatalogo(String cap) {
		if (mapaConcesionarios == null || mapaConcesionarios.isEmpty())
			return true;
		String v = cap.trim();
		if (mapaConcesionarios.containsKey(v))
			return true;
		for (String desc : mapaConcesionarios.values()) {
			if (desc != null && desc.trim().equalsIgnoreCase(v))
				return true;
		}
		return false;
	}

	private String normalizarEstatusExcel(String s) {
		if (s == null)
			return null;
		String v = s.trim().toUpperCase();

		if (v.contains("RECHAZ"))
			return "RECHAZADA";
		if (v.contains("FINAL"))
			return "FINALIZADA";
		if (v.contains("ATEN"))
			return "EN ATENCIÓN";
		if (v.contains("CREA"))
			return "CREADA";

		return null;
	}

	public void descargarCatalogoErroresCargaMasiva() {
		FacesContext fc = FacesContext.getCurrentInstance();
		if (cmCatalogoErroresBytes == null || cmCatalogoErroresBytes.length == 0) {
			fc.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Sin datos",
					"No hay catálogo de errores para descargar."));
			return;
		}

		try {
			ExternalContext ec = fc.getExternalContext();
			ec.setResponseContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			ec.setResponseHeader("Content-Disposition", "attachment; filename=\"" + cmCatalogoErroresNombre + "\"");

			OutputStream out = ec.getResponseOutputStream();
			out.write(cmCatalogoErroresBytes);
			out.flush();
			fc.responseComplete();

		} catch (Exception ex) {
			logger.error("Error al descargar catálogo de errores", ex);
			fc.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
					"No fue posible descargar el catálogo de errores."));
		}
	}

	public void handleUploadEvidenciaIncidencia(FileUploadEvent event) {
		UploadedFile file = (event != null) ? event.getFile() : null;

		if (file == null) {
			uploadErrTitle = "Archivo inválido";
			uploadErrMsg = "No se recibió el archivo.";
			addCallbackParamSafe("upOk", false);
			addCallbackParamSafe("upErrTitle", uploadErrTitle);
			addCallbackParamSafe("upErrMsg", uploadErrMsg);
			return;
		}

		if (incidenciaSeleccionada == null || incidenciaSeleccionada.getIdIncidencia() == null) {
			uploadErrTitle = "Incidencia no seleccionada";
			uploadErrMsg = "Seleccione una incidencia antes de adjuntar evidencia.";
			addCallbackParamSafe("upOk", false);
			addCallbackParamSafe("upErrTitle", uploadErrTitle);
			addCallbackParamSafe("upErrMsg", uploadErrMsg);
			return;
		}

		try {
			incidenciaService.validarAdjunto(file.getFileName(), file.getContentType(), file.getSize());
			long maxTotalBytes = getMaxBytesAdjunto();
			long totalActual = sumarBytesAdjuntosPendientesEvidencia() + getBytesOcupadosEnBaseDeDatos();
			long totalNuevo = totalActual + file.getSize();
			if (file.getSize() > maxTotalBytes) {
				uploadErrTitle = "Validación de archivo";
				uploadErrMsg = "El archivo excede el tamaño máximo permitido (10 MB).";
				addCallbackParamSafe("upOk", false);
				addCallbackParamSafe("upErrTitle", uploadErrTitle);
				addCallbackParamSafe("upErrMsg", uploadErrMsg);
				return;
			}

			if (totalNuevo > maxTotalBytes) {
				long disponible = maxTotalBytes - totalActual;

				uploadErrTitle = "Límite total de evidencias";
				uploadErrMsg = "El tamaño total permitido es 10 MB. Disponible: " + bytesToMb(disponible)
						+ " MB. Archivo: " + bytesToMb(file.getSize()) + " MB.";
				addCallbackParamSafe("upOk", false);
				addCallbackParamSafe("upErrTitle", uploadErrTitle);
				addCallbackParamSafe("upErrMsg", uploadErrMsg);
				return;
			}

			IIncidenciaService.AdjuntoUi a = new IIncidenciaService.AdjuntoUi(file.getFileName(), file.getSize(),
					file.getContents());

			String key = keyPendiente(a);
			boolean existe = false;
			for (IIncidenciaService.AdjuntoUi x : adjuntosPendientesEvidencia) {
				if (key != null && key.equals(keyPendiente(x))) {
					existe = true;
					break;
				}
			}
			if (!existe) {
				adjuntosPendientesEvidencia.add(a);
			}

			addCallbackParamSafe("upOk", true);

		} catch (IllegalArgumentException iae) {
			uploadErrTitle = "Validación de archivo";
			uploadErrMsg = iae.getMessage();
			addCallbackParamSafe("upOk", false);
			addCallbackParamSafe("upErrTitle", uploadErrTitle);
			addCallbackParamSafe("upErrMsg", uploadErrMsg);

		} catch (Exception e) {
			logger.error("Error al agregar evidencia a memoria (pendiente)", e);
			uploadErrTitle = "Error";
			uploadErrMsg = "No fue posible procesar el archivo.";
			addCallbackParamSafe("upOk", false);
			addCallbackParamSafe("upErrTitle", uploadErrTitle);
			addCallbackParamSafe("upErrMsg", uploadErrMsg);
		}
	}


	private java.util.List<IIncidenciaService.AdjuntoUi> adjuntosPendientesEvidencia = new java.util.ArrayList<>();
	private java.util.Set<String> adjuntosPendientesKeys = new java.util.HashSet<>();

	public java.util.List<IIncidenciaService.AdjuntoUi> getAdjuntosPendientesEvidencia() {
		return adjuntosPendientesEvidencia;
	}

	private String keyPendiente(IIncidenciaService.AdjuntoUi a) {
		if (a == null)
			return null;
		String n = (a.getNombre() != null) ? a.getNombre().trim().toLowerCase() : "";
		long s = a.getTamanio();
		return n + "|" + s;
	}

	public void quitarAdjuntoPendienteEvidencia() {
		Map<String, String> params = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
		String nombre = params.get("nombre");
		String sizeStr = params.get("size");

		if (nombre != null && sizeStr != null) {
			try {
				long size = Long.parseLong(sizeStr);

				
				if (adjuntosPendientesEvidencia != null) {
					java.util.Iterator<IIncidenciaService.AdjuntoUi> it = adjuntosPendientesEvidencia.iterator();

					while (it.hasNext()) {
						IIncidenciaService.AdjuntoUi a = it.next();

						if (a.getNombre() != null && a.getNombre().equals(nombre) && a.getTamanio() == size) {
							it.remove();
							logger.info("Adjunto eliminado correctamente: " + nombre);
							break;
						}
					}
				}

			} catch (NumberFormatException e) {
				logger.error("Error al parsear tamaño para eliminar adjunto", e);
			} catch (Exception e) {
				logger.error("Error general al eliminar adjunto", e);
			}
		}
	}

	private byte[] generarCatalogoErrores(List<Map<String, String>> errores, List<Map<String, String>> capturados)
			throws Exception {
		XSSFWorkbook workbook = new XSSFWorkbook();
		org.apache.poi.ss.usermodel.Sheet sheet = workbook.createSheet("Errores de carga");
		sheet.setDisplayGridlines(false);
		sheet.setPrintGridlines(false);

		XSSFCellStyle styleTitulo = Constants.getLevelStyle(workbook, Constants.INDEX1);
		XSSFCellStyle styleHeader = Constants.getLevelStyle(workbook, Constants.INDEX2);
		styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
		styleHeader.setBorderBottom(CellStyle.BORDER_THIN);
		styleHeader.setBorderTop(CellStyle.BORDER_THIN);
		styleHeader.setBorderLeft(CellStyle.BORDER_THIN);
		styleHeader.setBorderRight(CellStyle.BORDER_THIN);

		XSSFCellStyle styleDato = Constants.getLevelStyle(workbook, Constants.INDEX5);
		styleDato.setBorderBottom(CellStyle.BORDER_THIN);
		styleDato.setBorderTop(CellStyle.BORDER_THIN);
		styleDato.setBorderLeft(CellStyle.BORDER_THIN);
		styleDato.setBorderRight(CellStyle.BORDER_THIN);

		int rowIdx = 0;

		org.apache.poi.ss.usermodel.Row r0 = sheet.createRow(rowIdx++);
		org.apache.poi.ss.usermodel.Cell c0 = r0.createCell(0);
		c0.setCellValue("CATÁLOGO DE ERRORES DE CARGA MASIVA DE INCIDENCIAS");
		c0.setCellStyle(styleTitulo);
		sheet.addMergedRegion(new org.apache.poi.ss.util.CellRangeAddress(0, 0, 0, 14));

		org.apache.poi.ss.usermodel.Row rh = sheet.createRow(rowIdx++);
		String[] headers = new String[] { "Número de renglón", "ID de sitio (capturado)",
				"Error presentado en  ID de sitio", "Tipo de incidencia (capturado)", "Error presentado en  incidencia",
				"Descripción detallada (capturada)", "Error presentado en  descripción",
				"Nombre de quien reporta (capturado)", "Error presentado en  nombre de quien reporta",
				"Correo de quien reporta (capturado)", "Error presentado en correo de quien reporta",
				"Concesionario (capturado)", "Error presentado en concesionario", "Estatus (capturado)",
				"Error presentado en estatus" };

		for (int i = 0; i < headers.length; i++) {
			org.apache.poi.ss.usermodel.Cell ch = rh.createCell(i);
			ch.setCellValue(headers[i]);
			ch.setCellStyle(styleHeader);
		}

		for (int i = 0; i < errores.size(); i++) {
			Map<String, String> err = errores.get(i);
			Map<String, String> cap = capturados.get(i);

			org.apache.poi.ss.usermodel.Row rd = sheet.createRow(rowIdx++);

			setCell(rd, 0, cap.get("renglon"), styleDato);

			setCell(rd, 1, cap.get("idSitio"), styleDato);
			setCell(rd, 2, err.get("idSitio"), styleDato);

			setCell(rd, 3, cap.get("tipo"), styleDato);
			setCell(rd, 4, err.get("tipo"), styleDato);

			setCell(rd, 5, cap.get("desc"), styleDato);
			setCell(rd, 6, err.get("desc"), styleDato);

			setCell(rd, 7, cap.get("nombre"), styleDato);
			setCell(rd, 8, err.get("nombre"), styleDato);

			setCell(rd, 9, cap.get("correo"), styleDato);
			setCell(rd, 10, err.get("correo"), styleDato);

			setCell(rd, 11, cap.get("conces"), styleDato);
			setCell(rd, 12, err.get("conces"), styleDato);

			// NUEVO: Estatus
			setCell(rd, 13, cap.get("estatus"), styleDato);
			setCell(rd, 14, err.get("estatus"), styleDato);
		}

		for (int i = 0; i < headers.length; i++) {
			sheet.autoSizeColumn(i);
		}

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		workbook.write(baos);
		workbook.close();

		return baos.toByteArray();
	}

	private void setCell(org.apache.poi.ss.usermodel.Row r, int col, String val, XSSFCellStyle style) {
		org.apache.poi.ss.usermodel.Cell c = r.createCell(col);
		c.setCellValue(val != null ? val : "");
		c.setCellStyle(style);
	}

	public boolean esMovimientoInicial(IncidenciaBitacoraDto mov) {
		if (mov == null) {
			return false;
		}

		if (idPrimerMovimientoBitacora != null && mov.getId() != null) {
			return idPrimerMovimientoBitacora.equals(mov.getId());
		}

		if (bitacoraIncidenciaSeleccionada != null && !bitacoraIncidenciaSeleccionada.isEmpty()) {
			return mov == bitacoraIncidenciaSeleccionada.get(0);
		}

		return false;
	}

	public boolean tieneAdjuntoIncidencia() {
		return adjuntosIncidenciaSeleccionada != null && !adjuntosIncidenciaSeleccionada.isEmpty();
	}

	public int getMaxArchivosRestantes() {
		int max = incidenciaService.obtenerMaxArchivos();
		int usados = (adjuntosIncidenciaSeleccionadaReal != null) ? adjuntosIncidenciaSeleccionadaReal.size() : 0;
		int restantes = max - usados;
		return restantes < 0 ? 0 : restantes;
	}

	public void descargarAdjuntosIncidencia() {
		FacesContext fc = FacesContext.getCurrentInstance();

		if (incidenciaSeleccionada == null || incidenciaSeleccionada.getIdIncidencia() == null) {
			fc.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso de descarga",
					"No hay incidencia seleccionada para descargar evidencias."));
			return;
		}

		Long idInc = incidenciaSeleccionada.getIdIncidencia();
		List<IncidenciaAdjuntoDto> adjuntos = adjuntosIncidenciaSeleccionada;

		if (adjuntos == null || adjuntos.isEmpty()) {
			try {
				adjuntos = incidenciaService.obtenerAdjuntosIncidencia(idInc);
			} catch (Exception e) {
				adjuntos = new ArrayList<>();
			}
		}

		if (adjuntos == null || adjuntos.isEmpty()) {
			fc.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso de descarga",
					"La incidencia no tiene archivos adjuntos."));
			return;
		}

		boolean existeAlMenosUno = false;
		for (IncidenciaAdjuntoDto adj : adjuntos) {
			if (adj != null) {
				Path path = resolverPathAdjunto(adj);
				if (path != null && Files.exists(path)) {
					existeAlMenosUno = true;
					break;
				}
			}
		}

		if (!existeAlMenosUno) {
			fc.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
					"El archivo físico no se encuentra en el servidor. Es posible que haya sido eliminado de la carpeta o no se cargó correctamente."));
			return;
		}

		try {
			if (adjuntos.size() == 1) {
				IncidenciaAdjuntoDto adj = adjuntos.get(0);
				Path path = resolverPathAdjunto(adj);
				if (path != null && Files.exists(path)) {
					ExternalContext ec = fc.getExternalContext();
					ec.setResponseContentType("application/pdf");
					ec.setResponseHeader("Content-Disposition",
							"attachment; filename=\"" + adj.getNombreArchivo() + "\"");
					try (OutputStream out = ec.getResponseOutputStream()) {
						Files.copy(path, out);
						out.flush();
					}
					fc.responseComplete();
				}

			} else {
				String base = "Evidencias_";
				if (incidenciaSeleccionada.getFolio() != null && !incidenciaSeleccionada.getFolio().trim().isEmpty()) {
					base += incidenciaSeleccionada.getFolio().trim();
				} else {
					base += incidenciaSeleccionada.getIdIncidencia();
				}
				String nombreZip = sanitizarNombreArchivo(base) + ".zip";

				ExternalContext ec = fc.getExternalContext();
				ec.setResponseContentType("application/zip");
				ec.setResponseHeader("Content-Disposition", "attachment; filename=\"" + nombreZip + "\"");

				try (ZipOutputStream zos = new ZipOutputStream(ec.getResponseOutputStream())) {
					byte[] buffer = new byte[8192];
					Map<String, Integer> contadorNombres = new HashMap<>();

					for (IncidenciaAdjuntoDto a : adjuntos) {
						if (a == null)
							continue;
						Path path = resolverPathAdjunto(a);
						if (path == null || !Files.exists(path))
							continue;

						String entryName = sanitizarNombreArchivo(
								a.getNombreArchivo() != null ? a.getNombreArchivo() : "evidencia.pdf");
						entryName = hacerNombreUnico(entryName, contadorNombres);

						zos.putNextEntry(new ZipEntry(entryName));
						try (InputStream in = Files.newInputStream(path)) {
							int len;
							while ((len = in.read(buffer)) > 0) {
								zos.write(buffer, 0, len);
							}
						}
						zos.closeEntry();
					}
					zos.finish();
					zos.flush();
				}
				fc.responseComplete();
			}
		} catch (IOException e) {
			fc.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
					"Fallo al procesar los archivos para su descarga."));
		}
	}

	public void prepararDescarga() {
		if (incidenciaSeleccionada == null || incidenciaSeleccionada.getIdIncidencia() == null) {
			mostrarErrorDescarga("No hay incidencia seleccionada para descargar evidencias.");
			return;
		}

		List<IncidenciaAdjuntoDto> adjuntos = adjuntosIncidenciaSeleccionada;
		if (adjuntos == null || adjuntos.isEmpty()) {
			mostrarErrorDescarga("La incidencia no tiene archivos adjuntos para descargar.");
			return;
		}

		boolean existeAlMenosUno = false;
		for (IncidenciaAdjuntoDto adj : adjuntos) {
			if (adj != null) {
				java.nio.file.Path path = resolverPathAdjunto(adj);
				if (path != null && java.nio.file.Files.exists(path)) {
					existeAlMenosUno = true;
					break;
				}
			}
		}

		if (!existeAlMenosUno) {
			
			mostrarErrorDescarga(
					"El archivo físico no se encuentra en el servidor. Es posible que haya sido eliminado de la carpeta local.");
			return;
		}

		
		org.primefaces.context.RequestContext.getCurrentInstance()
				.execute("PF('wvDlgConfirmDescargaAdjuntos').show();");
	}

	public StreamedContent getDescargarAdjuntos() {
		FacesContext fc = FacesContext.getCurrentInstance();

		if (incidenciaSeleccionada == null || incidenciaSeleccionada.getIdIncidencia() == null) {
			mostrarErrorDescarga("No hay incidencia seleccionada para descargar evidencias.");
			return null;
		}

		Long idInc = incidenciaSeleccionada.getIdIncidencia();
		List<IncidenciaAdjuntoDto> adjuntos = adjuntosIncidenciaSeleccionada;

		if (adjuntos == null || adjuntos.isEmpty()) {
			try {
				adjuntos = incidenciaService.obtenerAdjuntosIncidencia(idInc);
			} catch (Exception e) {
				adjuntos = new ArrayList<>();
			}
		}

		if (adjuntos == null || adjuntos.isEmpty()) {
			mostrarErrorDescarga("La incidencia no tiene archivos adjuntos para descargar.");
			return null;
		}

		try {
			if (adjuntos.size() == 1) {
				IncidenciaAdjuntoDto adj = adjuntos.get(0);
				Path path = resolverPathAdjunto(adj);
				if (path == null || !Files.exists(path)) {
					mostrarErrorDescarga(
							"El archivo físico no se encuentra en el servidor. Es posible que haya sido eliminado de la carpeta o no se cargó correctamente.");
					return null;
				}
				InputStream is = Files.newInputStream(path);
				return new DefaultStreamedContent(is, "application/pdf", adj.getNombreArchivo());

			} else {
				boolean existeAlMenosUno = false;
				for (IncidenciaAdjuntoDto a : adjuntos) {
					Path p = resolverPathAdjunto(a);
					if (p != null && Files.exists(p)) {
						existeAlMenosUno = true;
						break;
					}
				}

				if (!existeAlMenosUno) {
					mostrarErrorDescarga("Ninguno de los archivos físicos se encuentra en el servidor.");
					return null;
				}

				String base = "Evidencias_";
				if (incidenciaSeleccionada.getFolio() != null && !incidenciaSeleccionada.getFolio().trim().isEmpty()) {
					base += incidenciaSeleccionada.getFolio().trim();
				} else {
					base += incidenciaSeleccionada.getIdIncidencia();
				}
				String nombreZip = sanitizarNombreArchivo(base) + ".zip";

				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				try (ZipOutputStream zos = new ZipOutputStream(baos)) {
					byte[] buffer = new byte[8192];
					Map<String, Integer> contadorNombres = new HashMap<>();
					for (IncidenciaAdjuntoDto a : adjuntos) {
						if (a == null)
							continue;
						Path path = resolverPathAdjunto(a);
						if (path == null || !Files.exists(path))
							continue;

						String entryName = sanitizarNombreArchivo(
								a.getNombreArchivo() != null ? a.getNombreArchivo() : "evidencia.pdf");
						entryName = hacerNombreUnico(entryName, contadorNombres);

						zos.putNextEntry(new ZipEntry(entryName));
						try (InputStream in = Files.newInputStream(path)) {
							int len;
							while ((len = in.read(buffer)) > 0) {
								zos.write(buffer, 0, len);
							}
						}
						zos.closeEntry();
					}
				}
				InputStream is = new ByteArrayInputStream(baos.toByteArray());
				return new DefaultStreamedContent(is, "application/zip", nombreZip);
			}

		} catch (Exception e) {
			mostrarErrorDescarga("Fallo al procesar los archivos para su descarga.");
			return null;
		}
	}

	private Path resolverPathAdjunto(IncidenciaAdjuntoDto adj) {
		if (adj == null)
			return null;
		if (adj.getRutaArchivo() == null || adj.getRutaArchivo().trim().isEmpty())
			return null;
		if (adj.getNombreArchivo() == null || adj.getNombreArchivo().trim().isEmpty())
			return null;
		return Paths.get(adj.getRutaArchivo().trim(), adj.getNombreArchivo().trim());
	}

	private String sanitizarNombreArchivo(String nombre) {
		if (nombre == null || nombre.trim().isEmpty())
			return "archivo";
		String n = nombre.trim().replace("\\", "/");
		if (n.contains("/"))
			n = n.substring(n.lastIndexOf('/') + 1);
		n = n.replaceAll("[^a-zA-Z0-9._-]", "_");
		if (n.length() > 120)
			n = n.substring(0, 120);
		return n;
	}

	private String hacerNombreUnico(String entryName, Map<String, Integer> contador) {
		Integer c = contador.get(entryName);
		if (c == null) {
			contador.put(entryName, 1);
			return entryName;
		}
		contador.put(entryName, c + 1);

		String base = entryName;
		String ext = "";
		int idx = entryName.lastIndexOf('.');
		if (idx > 0 && idx < entryName.length() - 1) {
			base = entryName.substring(0, idx);
			ext = entryName.substring(idx);
		}
		return base + "_" + c + ext;
	}

	private void addCallbackParamSafe(String key, Object value) {
		try {
			Class<?> pf = Class.forName("org.primefaces.PrimeFaces");
			Object current = pf.getMethod("current").invoke(null);
			Object ajax = current.getClass().getMethod("ajax").invoke(current);
			ajax.getClass().getMethod("addCallbackParam", String.class, Object.class).invoke(ajax, key, value);
			return;
		} catch (Exception ignore) {
			
		}
		try {
			Class<?> rc = Class.forName("org.primefaces.context.RequestContext");
			Object inst = rc.getMethod("getCurrentInstance").invoke(null);
			inst.getClass().getMethod("addCallbackParam", String.class, Object.class).invoke(inst, key, value);
		} catch (Exception ignore) {
			
		}
	}

	public void mostrarUploadErrorDesdeCliente() {
		FacesContext fc = FacesContext.getCurrentInstance();
		String t = fc.getExternalContext().getRequestParameterMap().get("t");
		String m = fc.getExternalContext().getRequestParameterMap().get("m");

		this.uploadErrTitle = (t != null && !t.trim().isEmpty()) ? t : "Aviso";
		this.uploadErrMsg = (m != null && !m.trim().isEmpty()) ? m : "No fue posible procesar el archivo.";
	}

	public boolean puedeSubirEvidencia(IncidenciaBitacoraDto mov) {
		if (incidenciaSeleccionada != null && "I".equalsIgnoreCase(incidenciaSeleccionada.getOrigenAlta())) {
			return false;
		}

		
		return esMovimientoInicial(mov) && !isIncidenciaCerrada() && getMaxArchivosRestantes() > 0;
	}

	public void quitarAdjuntoEvidencia(IncidenciaAdjuntoDto a) {
		if (a == null)
			return;

		String key = keyAdjuntoUi(a);
		if (key != null)
			adjuntosOcultosUi.add(key);

		if (adjuntosIncidenciaSeleccionada != null) {
			java.util.Iterator<IncidenciaAdjuntoDto> it = adjuntosIncidenciaSeleccionada.iterator();
			while (it.hasNext()) {
				IncidenciaAdjuntoDto x = it.next();
				if (mismoAdjunto(x, a)) {
					it.remove();
					break;
				}
			}
		}
	}

	private boolean same(String s1, String s2) {
		return s1 != null && s2 != null && s1.equals(s2);
	}

	private boolean mismoAdjunto(IncidenciaAdjuntoDto a, IncidenciaAdjuntoDto b) {
		if (a == b) {
			return true;
		}
		if (a == null || b == null) {
			return false;
		}

		String ra = normalizarRutaUi(a.getRutaArchivo());
		String rb = normalizarRutaUi(b.getRutaArchivo());
		if (ra != null && rb != null) {
			return ra.equals(rb);
		}

		String na = (a.getNombreArchivo() != null) ? a.getNombreArchivo().trim() : "";
		String nb = (b.getNombreArchivo() != null) ? b.getNombreArchivo().trim() : "";
		long ta = (a.getTamanioBytes() != null) ? a.getTamanioBytes().longValue() : 0L;
		long tb = (b.getTamanioBytes() != null) ? b.getTamanioBytes().longValue() : 0L;

		return na.equals(nb) && ta == tb;
	}

	private String normalizarRutaUi(String ruta) {
		if (ruta == null)
			return null;
		String r = ruta.trim().replace("\\", "/");
		if (!r.startsWith("/"))
			r = "/" + r;
		return r;
	}

	private String keyAdjuntoUi(IncidenciaAdjuntoDto a) {
		if (a == null) {
			return null;
		}

		if (a.getRutaArchivo() != null && !a.getRutaArchivo().trim().isEmpty()) {
			return normalizarRutaUi(a.getRutaArchivo());
		}

		String n = (a.getNombreArchivo() != null) ? a.getNombreArchivo().trim() : "";
		long t = (a.getTamanioBytes() != null) ? a.getTamanioBytes().longValue() : 0L;
		return n + "|" + t;
	}


	private void rebuildAdjuntosVisiblesDesdeReal() {
		if (adjuntosIncidenciaSeleccionadaReal == null) {
			adjuntosIncidenciaSeleccionadaReal = new ArrayList<>();
		}
		if (adjuntosOcultosUi == null) {
			adjuntosOcultosUi = new java.util.HashSet<>();
		}

		this.adjuntosIncidenciaSeleccionada = new ArrayList<>();

		for (IncidenciaAdjuntoDto a : adjuntosIncidenciaSeleccionadaReal) {
			if (a == null)
				continue;

			String key = keyAdjuntoUi(a);
			if (key != null && adjuntosOcultosUi.contains(key)) {
				continue;
			}
			this.adjuntosIncidenciaSeleccionada.add(a);
		}
	}

	public long getTotalBytesAdjuntos() {
		long total = 0L;

		List<IncidenciaAdjuntoDto> list = this.adjuntosIncidenciaSeleccionada;
		if (list == null || list.isEmpty()) {
			return 0L;
		}

		for (IncidenciaAdjuntoDto a : list) {
			if (a == null)
				continue;

			Long sz = a.getTamanioBytes();
			if (sz != null && sz.longValue() > 0) {
				total += sz.longValue();
			}
		}
		return total;
	}

	private void initParametrosAdjuntos() {
		try {
			if (incidenciaService != null) {
				Long maxBytes = incidenciaService.obtenerMaxBytesAdjunto();
				if (maxBytes != null && maxBytes > 0) {
					this.maxBytesAdjunto = maxBytes;
					this.maxMb = (int) (maxBytesAdjunto / (1024 * 1024));
				}

				String formatos = incidenciaService.obtenerFormatosHumanos();
				if (formatos != null && !formatos.trim().isEmpty()) {
					this.formatosHumanosAdjunto = formatos.trim();
				}
			}
		} catch (Exception e) {
			logger.warn("No fue posible cargar parámetros de adjuntos para mantenimiento, se usan valores por defecto.",
					e);
		}
	}

	
	private long sumarBytesAdjuntosVisibles() {
		long total = 0L;
		if (adjuntosIncidenciaSeleccionada != null) {
			for (IncidenciaAdjuntoDto a : adjuntosIncidenciaSeleccionada) {
				if (a != null && a.getTamanioBytes() != null) {
					total += a.getTamanioBytes();
				}
			}
		}
		return total;
	}

	public long getBytesOcupadosEnBaseDeDatos() {
		long total = 0L;
		if (adjuntosIncidenciaSeleccionada != null) {
			for (IncidenciaAdjuntoDto a : adjuntosIncidenciaSeleccionada) {
				if (a != null && a.getTamanioBytes() != null) {
					total += a.getTamanioBytes().longValue();
				}
			}
		}
		return total;
	}

	
	public java.math.BigDecimal getTotalMbAdjuntos() {
		long totalBytes = 0L;

		if (adjuntosPendientesEvidencia != null) {
			for (IIncidenciaService.AdjuntoUi a : adjuntosPendientesEvidencia) {
				if (a != null) {
					totalBytes += a.getTamanio();
				}
			}
		}

		return new java.math.BigDecimal(totalBytes).divide(new java.math.BigDecimal(1024L * 1024L), 2,
				java.math.RoundingMode.HALF_UP);
	}

	
	public String formatBytes(Long bytes) {
		if (bytes == null || bytes <= 0L) {
			return "0 MB";
		}
		double mb = bytes / (1024d * 1024d);
		return String.format(java.util.Locale.US, "%.2f MB", mb);
	}

	public void quitarAdjuntoPendiente(IIncidenciaService.AdjuntoUi a) {
		if (a == null || adjuntosPendientes == null)
			return;
		adjuntosPendientes.remove(a);
	}

	private boolean safeEquals(String a, String b) {
		return a == null ? b == null : a.equals(b);
	}

	public void eliminarAdjuntoPorIndice() {
		String idxStr = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("idx");

		if (idxStr != null && !idxStr.isEmpty()) {
			try {
				int index = Integer.parseInt(idxStr);
				if (adjuntosPendientesEvidencia != null && index >= 0 && index < adjuntosPendientesEvidencia.size()) {
					IIncidenciaService.AdjuntoUi eliminado = adjuntosPendientesEvidencia.remove(index);
				}
			} catch (Exception e) {
				logger.error("Error al eliminar adjunto por índice", e);
			}
		}
	}


	public void guardarEvidenciasPendientes() {
		FacesContext fc = FacesContext.getCurrentInstance();

		if (incidenciaSeleccionada == null || incidenciaSeleccionada.getIdIncidencia() == null) {
			fc.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "No hay incidencia seleccionada."));
			return;
		}

		if (adjuntosPendientesEvidencia == null || adjuntosPendientesEvidencia.isEmpty()) {
			fc.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", "No hay archivos pendientes para subir."));
			return;
		}

		Long idUsuario = null;
		try {
			Object principal = org.springframework.security.core.context.SecurityContextHolder.getContext()
					.getAuthentication().getPrincipal();
			if (principal instanceof mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo) {
				idUsuario = ((mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo) principal)
						.getIdUsuario().longValue();
			}
		} catch (Exception e) {
			logger.warn("No se pudo obtener usuario logueado", e);
		}

		int guardados = 0;
		try {
			for (IIncidenciaService.AdjuntoUi adj : adjuntosPendientesEvidencia) {
				incidenciaService.adjuntarEvidenciaIncidencia(incidenciaSeleccionada.getIdIncidencia(), adj, idUsuario);
				guardados++;
			}

			adjuntosPendientesEvidencia.clear();
			adjuntosIncidenciaSeleccionada = incidenciaService
					.obtenerAdjuntosIncidencia(incidenciaSeleccionada.getIdIncidencia());

			fc.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Éxito",
					"Se guardaron " + guardados + " archivos correctamente."));

			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvDlgSubirAdjunto').hide();");

		} catch (Exception e) {
			fc.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
					"Ocurrió un problema al guardar los archivos: " + e.getMessage()));
		}
	}

	public void limpiarEvidenciasPendientes() {
		if (adjuntosPendientesEvidencia != null) {
			adjuntosPendientesEvidencia.clear();
		}
		org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvDlgSubirAdjunto').hide();");
	}

	private void sincronizarEstatusDesdeBitacora() {
		if (bitacoraIncidenciaSeleccionada == null || bitacoraIncidenciaSeleccionada.isEmpty()) {
			return;
		}

		int ultimoIndice = bitacoraIncidenciaSeleccionada.size() - 1;
		IncidenciaBitacoraDto ultimo = bitacoraIncidenciaSeleccionada.get(ultimoIndice);

		String estatusActual = (ultimo != null && ultimo.getEstatusNuevo() != null) ? ultimo.getEstatusNuevo().trim()
				: null;

		if (estatusActual != null && !estatusActual.isEmpty()) {
			this.incidenciaSeleccionada.setEstatus(estatusActual);
			this.incidenciaSeleccionada.setPendientePor(calcularPendientePorLocal(estatusActual));
			this.indiceEtapa = calcularIndiceEtapaDesdeEstatus(estatusActual);
			ajustarAccionesPorEstatus(estatusActual);
		}
	}

	
	public boolean isEsUsuarioIFT() {

		if (esUsuarioIFTCache != null) {
			return esUsuarioIFTCache.booleanValue();
		}

		boolean esIFT = false;

		try {
			Object principal = null;
			if (SecurityContextHolder.getContext() != null
					&& SecurityContextHolder.getContext().getAuthentication() != null) {
				principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			}

			if (principal instanceof UserDetailsVo) {
				UserDetailsVo user = (UserDetailsVo) principal;

				if (user.getIdRol() != null) {
					if (ID_ROL_IFT_14.equals(user.getIdRol()) || ID_ROL_IFT_22.equals(user.getIdRol())) {
						esIFT = true;
					}
				}

				if (!esIFT && user.getIdUsuario() != null && incidenciaService != null) {

					String correoIft14 = incidenciaService.obtenerCorreoExternoPorUsuario(user.getIdUsuario(),
							ID_ROL_IFT_14);
					if (correoIft14 != null && correoIft14.trim().length() > 0) {
						esIFT = true;
					}

					if (!esIFT) {
						String correoIft22 = incidenciaService.obtenerCorreoExternoPorUsuario(user.getIdUsuario(),
								ID_ROL_IFT_22);
						if (correoIft22 != null && correoIft22.trim().length() > 0) {
							esIFT = true;
						}
					}
				}
			}

			if (!esIFT) {
				org.springframework.security.core.Authentication auth = org.springframework.security.core.context.SecurityContextHolder
						.getContext().getAuthentication();

				if (auth != null && auth.getAuthorities() != null) {
					for (org.springframework.security.core.GrantedAuthority authority : auth.getAuthorities()) {
						String rol = (authority != null) ? authority.getAuthority() : null;
						if (rol != null && (rol.equalsIgnoreCase("R3IFT01") || rol.equalsIgnoreCase("ROLE_R3IFT01"))) {
							esIFT = true;
							break;
						}
					}
				}
			}

		} catch (Exception e) {
			logger.error("Error al validar rol IFT por ID_ROL (14/22)", e);
			esIFT = false;
		}

		esUsuarioIFTCache = Boolean.valueOf(esIFT);
		return esIFT;
	}

	public String obtenerComentarioMovimiento(IncidenciaBitacoraDto movimiento) {
	    if (movimiento == null) return "";
	    if ("CREADA".equalsIgnoreCase(movimiento.getEstatusNuevo())) {
	        return "";
	    }
	    return (movimiento.getComentario() == null) ? "" : movimiento.getComentario();
	}

	private long sumarBytesAdjuntosPendientesEvidencia() {
		long total = 0L;
		if (adjuntosPendientesEvidencia == null) {
			return 0L;
		}
		for (IIncidenciaService.AdjuntoUi a : adjuntosPendientesEvidencia) {
			if (a != null) {
				total += a.getTamanio();
			}
		}
		return total;
	}

	private String bytesToMb(long bytes) {
		double mb = bytes / (1024d * 1024d);
		double red = Math.round(mb * 100d) / 100d;
		return String.valueOf(red);
	}

	public void validarDescargaEvidencias() {
		if (incidenciaSeleccionada == null || incidenciaSeleccionada.getIdIncidencia() == null) {
			mostrarErrorDescarga("No hay incidencia seleccionada para descargar evidencias.");
			return;
		}

		List<IncidenciaAdjuntoDto> adjuntos = adjuntosIncidenciaSeleccionada;
		if (adjuntos == null || adjuntos.isEmpty()) {
			mostrarErrorDescarga("La incidencia no tiene archivos adjuntos.");
			return;
		}

		boolean existeAlMenosUno = false;
		for (IncidenciaAdjuntoDto adj : adjuntos) {
			if (adj != null) {
				java.nio.file.Path path = resolverPathAdjunto(adj);
				if (path != null && java.nio.file.Files.exists(path)) {
					existeAlMenosUno = true;
					break;
				}
			}
		}

		if (!existeAlMenosUno) {
			mostrarErrorDescarga(
					"El archivo físico no se encuentra en el servidor. Es posible que haya sido eliminado de la carpeta o no se cargó correctamente.");
			return;
		}

		org.primefaces.context.RequestContext.getCurrentInstance()
				.execute("document.getElementById('formMantenimientoInc:btnDescargaEvidenciasOculto').click();");
	}

	private void mostrarErrorDescarga(String mensaje) {
		this.uploadErrTitle = "Aviso de descarga";
		this.uploadErrMsg = mensaje;
		org.primefaces.context.RequestContext.getCurrentInstance().update(":formMantenimientoInc:dlgUpErrContentMant");
		org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgUpErrMant').show();");
	}

	public void initGestionMantenimiento() {
		FacesContext fc = FacesContext.getCurrentInstance();
		
		if (fc != null && fc.isPostback()) {
			return;
		}
		buscar();
	}

	public void initGestionConcesionario() {
		FacesContext fc = FacesContext.getCurrentInstance();
		
		if (fc != null && fc.isPostback()) {
			return;
		}
		buscarBitacoraConcesionario();
	}

	public IncidenciaAdjuntoDto getAdjuntoEvidenciaAEliminar() {
		return adjuntoEvidenciaAEliminar;
	}

	public void setAdjuntoEvidenciaAEliminar(IncidenciaAdjuntoDto adjuntoEvidenciaAEliminar) {
		this.adjuntoEvidenciaAEliminar = adjuntoEvidenciaAEliminar;
	}

	public String getFiltroFolio() {
		return filtroFolio;
	}

	public void setFiltroFolio(String filtroFolio) {
		this.filtroFolio = filtroFolio;
	}

	public String getFiltroSitio() {
		return filtroSitio;
	}

	public void setFiltroSitio(String filtroSitio) {
		this.filtroSitio = filtroSitio;
	}

	public String getFiltroEstatus() {
		return filtroEstatus;
	}

	public void setFiltroEstatus(String filtroEstatus) {
		this.filtroEstatus = filtroEstatus;
	}

	public List<IncidenciaGestionDto> getListaIncidencias() {
		return listaIncidencias;
	}

	public void setListaIncidencias(List<IncidenciaGestionDto> listaIncidencias) {
		this.listaIncidencias = listaIncidencias;
	}

	public IncidenciaGestionDto getIncidenciaSeleccionada() {
		return incidenciaSeleccionada;
	}

	public void setIncidenciaSeleccionada(IncidenciaGestionDto incidenciaSeleccionada) {
		this.incidenciaSeleccionada = incidenciaSeleccionada;
		this.accionSeleccionada = null;
		this.comentarioAccion = null;
	}

	public List<IncidenciaBitacoraDto> getBitacoraIncidenciaSeleccionada() {
		return bitacoraIncidenciaSeleccionada;
	}

	public void setBitacoraIncidenciaSeleccionada(List<IncidenciaBitacoraDto> bitacoraIncidenciaSeleccionada) {
		this.bitacoraIncidenciaSeleccionada = bitacoraIncidenciaSeleccionada;
	}

	public String getOperadorUsuario() {
		return operadorUsuario;
	}

	public String getConcesionarioUsuario() {
		return concesionarioUsuario;
	}

	public String getDetalleNombreSitio() {
		return detalleNombreSitio;
	}

	public String getDetalleRegion() {
		return detalleRegion;
	}

	public String getDetalleLatitud() {
		return detalleLatitud;
	}

	public String getDetalleLongitud() {
		return detalleLongitud;
	}

	public String getAccionSeleccionada() {
		return accionSeleccionada;
	}

	public void setAccionSeleccionada(String accionSeleccionada) {
		this.accionSeleccionada = accionSeleccionada;
	}

	public String getComentarioAccion() {
		return comentarioAccion;
	}

	public void setTotalMbAdjuntos(java.math.BigDecimal totalMbAdjuntos) {

	}

	public boolean isIncidenciaCerrada() {
		if (incidenciaSeleccionada == null || incidenciaSeleccionada.getEstatus() == null) {
			return false;
		}
		String estatus = incidenciaSeleccionada.getEstatus().trim();
		return "FINALIZADA".equalsIgnoreCase(estatus) || "RECHAZADA".equalsIgnoreCase(estatus);
	}

	public void setComentarioAccion(String comentarioAccion) {
		this.comentarioAccion = comentarioAccion;
	}

	public String getDetalleTipoIncidencia() {
		return detalleTipoIncidencia;
	}

	public void setDetalleTipoIncidencia(String detalleTipoIncidencia) {
		this.detalleTipoIncidencia = detalleTipoIncidencia;
	}

	public String getDetalleDescripcionIncidencia() {
		return detalleDescripcionIncidencia;
	}

	public void setDetalleDescripcionIncidencia(String detalleDescripcionIncidencia) {
		this.detalleDescripcionIncidencia = detalleDescripcionIncidencia;
	}

	public List<String> getCatalogoAcciones() {
		return catalogoAcciones;
	}

	public void setCatalogoAcciones(List<String> catalogoAcciones) {
		this.catalogoAcciones = catalogoAcciones;
	}

	public int getIndiceEtapa() {
		return indiceEtapa;
	}

	public void setIndiceEtapa(int indiceEtapa) {
		this.indiceEtapa = indiceEtapa;
	}

	public List<IncidenciaAdjuntoDto> getAdjuntosIncidenciaSeleccionada() {
		return adjuntosIncidenciaSeleccionada;
	}

	public void setAdjuntosIncidenciaSeleccionada(List<IncidenciaAdjuntoDto> adjuntosIncidenciaSeleccionada) {
		this.adjuntosIncidenciaSeleccionada = adjuntosIncidenciaSeleccionada;
	}

	public Long getIdPrimerMovimientoBitacora() {
		return idPrimerMovimientoBitacora;
	}

	public void setIdPrimerMovimientoBitacora(Long idPrimerMovimientoBitacora) {
		this.idPrimerMovimientoBitacora = idPrimerMovimientoBitacora;
	}

	public String getMensajeAccionNoPermitida() {
		return mensajeAccionNoPermitida;
	}

	public void setMensajeAccionNoPermitida(String mensajeAccionNoPermitida) {
		this.mensajeAccionNoPermitida = mensajeAccionNoPermitida;

	}

	public boolean isSoloConsultaDetalle() {
		return soloConsultaDetalle;
	}

	public void setSoloConsultaDetalle(boolean soloConsultaDetalle) {
		this.soloConsultaDetalle = soloConsultaDetalle;
	}

	public int getCmTotalLeidas() {
		return cmTotalLeidas;
	}

	public int getCmTotalCreadas() {
		return cmTotalCreadas;
	}

	public int getCmTotalErrores() {
		return cmTotalErrores;
	}

	public String getUploadErrTitle() {
		return uploadErrTitle;
	}

	public void setUploadErrTitle(String uploadErrTitle) {
		this.uploadErrTitle = uploadErrTitle;
	}

	public String getUploadErrMsg() {
		return uploadErrMsg;
	}

	public void setUploadErrMsg(String uploadErrMsg) {
		this.uploadErrMsg = uploadErrMsg;
	}

	public String getFormatosHumanosAdjunto() {
		return (incidenciaService != null) ? incidenciaService.obtenerFormatosHumanos() : "PDF";
	}

	public String getAllowTypesAdjunto() {
		return (incidenciaService != null) ? incidenciaService.obtenerRegexExtensiones() : "/(\\.|\\/)(pdf)$/";
	}

	public long getMaxBytesAdjunto() {
		return (incidenciaService != null) ? incidenciaService.obtenerMaxBytesAdjunto() : (10L * 1024L * 1024L);
	}

	public long getMaxMb() {
		return getMaxBytesAdjunto() / (1024L * 1024L);
	}

	public List<IIncidenciaService.AdjuntoUi> getAdjuntosPendientes() {
		return adjuntosPendientes;
	}

	
	public void setBytesOcupadosEnBaseDeDatos(long bytesOcupadosEnBaseDeDatos) {
	}

	public String getNuevoEstatus() {
		if (accionSeleccionada == null || accionSeleccionada.trim().isEmpty()) {
			return "";
		}
		return mapAccionAEstatus(accionSeleccionada);
	}

	public void setNuevoEstatus(String nuevoEstatus) {
	}
}
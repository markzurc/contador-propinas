package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.client;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;


/**
 * <h1>Generic Client Class</h1>
 * <p>
 * Generic class to execute web services
 * </p>
 * @author chcastro
 * @version 1.0
 * @since January, 2015
 * 
 */

@Service("genericClient")
@Scope("prototype")
public class GenericClient {
	
	private Logger logger = LogManager.getLogger(GenericClient.class);

	/**
	 * 
	 * @param service {@link String} Service name.
	 * @param request {@link T} Request used by the Web service.
	 * @param response {@link Class} Class of response to be returned.
	 * @return {@link K} generic response
	 */
	@SuppressWarnings("unchecked")
	public <K, T> K testCreateEmployee(String service, T request, Class<?> response) {
		RestTemplate restTemplate = new RestTemplate();

		K genericResponse = null;

		try {
			String wsURL = System.getProperty("webservice.url.ovit");
			logger.info("wsURL: "+wsURL);
			wsURL =wsURL+service;
				genericResponse = (K) restTemplate.postForObject(wsURL, Class
						.forName(request.getClass().getName()).cast(request),
						response);
			} catch (RestClientException e) {
				logger.error("Error GenericClient.testCreateEmployee " + e);
			} catch (ClassNotFoundException e) {
				logger.error("Error GenericClient.testCreateEmployee " + e);
				
			}
		return genericResponse;
	}
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.exception;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import javax.faces.context.ExceptionHandler;
import javax.faces.context.ExceptionHandlerWrapper;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.ExceptionQueuedEvent;
import javax.faces.event.ExceptionQueuedEventContext;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.logging.Level;


public class CustomFacesExceptionHandler extends ExceptionHandlerWrapper {

	private ExceptionHandler wrapped;
	private String errorFlow;
	private String errorPageId;

	private static final Logger logger = LogManager
			.getLogger(CustomFacesExceptionHandler.class);

	public CustomFacesExceptionHandler(ExceptionHandler wrapped,
			String errorFlow, String errorPageId) {
		this.wrapped = wrapped;
		this.errorFlow = errorFlow;
		this.errorPageId = errorPageId;
	}

	@Override
	public ExceptionHandler getWrapped() {
		return this.wrapped;
	}

	@Override
	public void handle() {
		
		Iterator<ExceptionQueuedEvent> i = getUnhandledExceptionQueuedEvents().iterator();
		
		while (i.hasNext()) {
			
			ExceptionQueuedEvent event = (ExceptionQueuedEvent) i.next();
			ExceptionQueuedEventContext context = (ExceptionQueuedEventContext) event.getSource();

			Throwable t = context.getException();
			if ((t instanceof RuntimeException)) {
				
				FacesContext fc = FacesContext.getCurrentInstance();
				
				try {
					if (fc.getViewRoot().getViewId().equals(this.errorPageId)) {
						logger.error("Redirected back to ourselves, there must be a problem with the errorPage.xhtml page",t);
						getWrapped().handle();
						return;
					}
					ExternalContext externalContext = fc.getExternalContext();
					Map<String, Object> sessionMap = externalContext.getSessionMap();

					sessionMap.put("GLOBAL_RENDER_ERROR", t);

					((HttpServletResponse) fc.getExternalContext().getResponse()).sendRedirect(this.errorFlow);
				} catch (IOException ioe) {
					logger.error("Error al ejecutar CustomFacesExceptionHandler.handle " + ioe);
					logger.error("Could not process redirect to handle application error", t);
				}
			}
		}
		getWrapped().handle();
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.email.service;

import java.util.Arrays;

public class ArchivoEmailDTO {
	public String nombre;
	public String tipo;
	public byte[] contenido;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public byte[] getContenido() {
		return contenido;
	}
	public void setContenido(byte[] contenido) {
		this.contenido = contenido;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ArchivoEmailDTO [nombre=");
		builder.append(nombre);
		builder.append(", tipo=");
		builder.append(tipo);
		builder.append(", contenido=");
		builder.append(Arrays.toString(contenido));
		builder.append("]");
		return builder.toString();
	}
	
	
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.reportes.service;
 
import org.springframework.stereotype.Service;
 
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants;
 
import java.util.List;
 
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
 
 
@Service("sitiosService")
public class SitiosService {
	private static final Logger logger = LogManager.getLogger(SitiosService.class);
	private int index = 0;
	private static String[] columNamesSitio = { "Id Sitio ", "Nombre Sitio", "Latitud", "Longitud" };

	XSSFCellStyle bordeDerechoStyle = null;
	
	public void toExcel(XSSFWorkbook hssfWorkbook, List<SitioDto> listaSitios) {
		XSSFSheet sheet = hssfWorkbook.getSheetAt(Constants.INDEX0);
		sheet.setDisplayGridlines(false);
		sheet.setPrintGridlines(false);
		XSSFCellStyle headerStyle = Constants.getLevelStyle(hssfWorkbook, Constants.INDEX1);
		headerStyle.setAlignment(HorizontalAlignment.CENTER);
		XSSFCellStyle campoStyle = Constants.getLevelStyle(hssfWorkbook, Constants.INDEX5);
		campoStyle.setBorderBottom(CellStyle.BORDER_THIN);
		campoStyle.setBorderLeft(CellStyle.BORDER_THIN);
		campoStyle.setBorderRight(CellStyle.BORDER_THIN);
		campoStyle.setBorderTop(CellStyle.BORDER_THIN);
		// APPs
		
		//Estilo para el borde derecho
		bordeDerechoStyle = Constants.getLevelStyle(hssfWorkbook,Constants.INDEX2);
		bordeDerechoStyle.setBorderRight(CellStyle.BORDER_THIN);
		bordeDerechoStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		bordeDerechoStyle.setBorderTop(CellStyle.BORDER_THIN);
		bordeDerechoStyle.setTopBorderColor(IndexedColors.WHITE.getIndex());
		bordeDerechoStyle.setBorderBottom(CellStyle.BORDER_THIN);
		bordeDerechoStyle.setBottomBorderColor(IndexedColors.WHITE.getIndex());
		bordeDerechoStyle.setLeftBorderColor(CellStyle.BORDER_THIN);
		bordeDerechoStyle.setLeftBorderColor(IndexedColors.WHITE.getIndex());
		
		insertaCell(sheet, Constants.INDEX0, Constants.INDEX0, "Reporte Sitios", headerStyle);
		sheet.addMergedRegion(new CellRangeAddress(Constants.INDEX0, Constants.INDEX0, 0, 3));

		index = 2;
		addColumnsNames(sheet, Constants.INDEX1, Constants.getLevelStyle(hssfWorkbook, Constants.INDEX2),
				columNamesSitio);
		for (SitioDto sitio : listaSitios) {
			insertaCell(sheet, index, Constants.INDEX0, sitio.getSitio(), campoStyle);
			insertaCell(sheet, index, Constants.INDEX1, sitio.getNombre(), campoStyle);
			insertaCell(sheet, index, Constants.INDEX2, sitio.getLatitud(), campoStyle);
			insertaCell(sheet, index, Constants.INDEX3, sitio.getLongitud(), campoStyle);

			index++;
		}
	}

	private void insertaCell(XSSFSheet sheet, int rowIndex, int column, String value, XSSFCellStyle style) {
		XSSFRow commonRow = sheet.getRow(rowIndex);
		if (commonRow == null) {
			commonRow = sheet.createRow(rowIndex);
		}

		XSSFCell nombre = commonRow.createCell(column);
		nombre.setCellValue(value);
		sheet.autoSizeColumn(column);
		nombre.setCellStyle(style);

	}

	private void addColumnsNames(XSSFSheet sheet, int position, XSSFCellStyle style, String[] titles) {
		int column = Constants.INDEX0;
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setRightBorderColor(IndexedColors.WHITE.getIndex());
		style.setBorderTop(CellStyle.BORDER_THIN);
		style.setTopBorderColor(IndexedColors.WHITE.getIndex());
		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setBottomBorderColor(IndexedColors.WHITE.getIndex());
		style.setLeftBorderColor(CellStyle.BORDER_THIN);
		style.setLeftBorderColor(IndexedColors.WHITE.getIndex());
		for (String titleColumn : titles) {
			if (column == 3) {
				insertaCell(sheet, position, column, titleColumn, bordeDerechoStyle);
			}else {
				insertaCell(sheet, position, column, titleColumn, style);
			}
			column += 1;
		}

	}

}
package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.seguridad.bean;

import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.FOLIO_VAL;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.MSJ_FOL_ALPHA;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.MSJ_FOL_REQ;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.WrapperConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.seguridad.service.SecurityParametersService;

import org.primefaces.component.panelgrid.PanelGrid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.webflow.execution.RequestContext;


@Controller("securityParamsBean")
@SessionScoped
public class SecurityParamsBean  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3788286392537730479L;

	@Autowired
	@Qualifier("securityParametersService")
	private SecurityParametersService securityParametersService;
	
	private PanelGrid panelGrid;
	private List<String> listaTest;
	private Map<Integer,String> holdParamList= new HashMap<Integer,String>();
	private List<WrapperConfigurationUtilsVo> paramList;
	private String currentFolio;
	private String mensajeError;
	private boolean hasChanges;

	public void initSecurityParams(RequestContext ctx) throws TransactionalOVITException{
		paramList=securityParametersService.getAllSecurityParameters();
		
		String paramVersion= FacesContext.getCurrentInstance().getExternalContext().getInitParameterMap().get("ovitVersion").toString();
		
		
		for(WrapperConfigurationUtilsVo wrapperConfigurationUtilsVo :paramList){			
			if(wrapperConfigurationUtilsVo.getConfigurationUtilsVo().getNombreParametro().equals("OVIT_VERSION")){
				wrapperConfigurationUtilsVo.setGenericValor(paramVersion);
			}
		}
		
		holdParametersValues(paramList);
		currentFolio="";
		mensajeError="";
		org.primefaces.context.RequestContext.getCurrentInstance().update(":form:panel2 ");
	}
	
	
	private void holdParametersValues(List<WrapperConfigurationUtilsVo> paramList){
		for(WrapperConfigurationUtilsVo wrapperConfigurationUtilsVo:paramList){
			holdParamList.put(wrapperConfigurationUtilsVo.getConfigurationUtilsVo().getIdParametro(), wrapperConfigurationUtilsVo.getConfigurationUtilsVo().getValor().toString());
		}	
	}
	
	
	
	
	
	
	
	
	
	public void update() throws TransactionalOVITException {
		org.primefaces.context.RequestContext context = org.primefaces.context.RequestContext.getCurrentInstance();
		boolean validation = false;
		boolean succes = false;

		if (this.currentFolio.trim().isEmpty()) {
			mensajeError = MSJ_FOL_REQ;
		} else if (!this.currentFolio.matches(FOLIO_VAL)) {
			mensajeError = MSJ_FOL_ALPHA;
		} else {
			validation = true;
			currentFolio="";
			mensajeError="";
			for(WrapperConfigurationUtilsVo wrapperConfigurationUtilsVo:paramList){
				if(hasChange(wrapperConfigurationUtilsVo)){
					succes=securityParametersService.saveParameter(wrapperConfigurationUtilsVo,wrapperConfigurationUtilsVo.getInitState(),currentFolio);
				}
			}
			
		}

		if(succes){
			securityParametersService.updateParamsOnCurrentSession(paramList);
			org.primefaces.context.RequestContext.getCurrentInstance().update(":form:panel");
		}
		
		context.addCallbackParam("succes", succes);
		context.addCallbackParam("validation", validation);
		
	}
	
	
	
	
	
	public void checkValues(boolean confirm){
		
	boolean validacion=true;
	this.hasChanges=false;
		for(int x=0;x<paramList.size();x++){
			
			if(hasChange(paramList.get(x))){
				paramList.get(x).setHasChange(true);
				hasChanges=true;
			}else{
				paramList.get(x).setHasChange(false);
			}
		}
		
		org.primefaces.context.RequestContext.getCurrentInstance().update(":form:panel");
		if(validacion && confirm && hasChanges){
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlg').show()");
		}else if(validacion && confirm && !hasChanges){
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgNoCambios').show()");
		}
		
		
	}
	

	
	
	 private boolean hasChange(
			WrapperConfigurationUtilsVo wrapperConfigurationUtilsVo) {
		 wrapperConfigurationUtilsVo.isHasChange();
		 String storeValue= holdParamList.get(wrapperConfigurationUtilsVo.getConfigurationUtilsVo().getIdParametro());
		 
		return !storeValue.equals(wrapperConfigurationUtilsVo.getConfigurationUtilsVo().getValor());
	}

	

	public List<String> getListaTest() {
		return listaTest;
	}

	public void setListaTest(List<String> listaTest) {
		this.listaTest = listaTest;
	}


	public PanelGrid getPanelGrid() {
		return panelGrid;
	}


	public void setPanelGrid(PanelGrid panelGrid) {
		this.panelGrid = panelGrid;
	}


	public List<WrapperConfigurationUtilsVo> getParamList() {
		return paramList;
	}


	public void setParamList(List<WrapperConfigurationUtilsVo> paramList) {
		this.paramList = paramList;
	}



	public Map<Integer, String> getHoldParamList() {
		return holdParamList;
	}



	public void setHoldParamList(Map<Integer, String> holdParamList) {
		this.holdParamList = holdParamList;
	}



	public String getCurrentFolio() {
		return currentFolio;
	}



	public void setCurrentFolio(String currentFolio) {
		this.currentFolio = currentFolio;
	}



	public String getMensajeError() {
		return mensajeError;
	}



	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}



	public boolean isHasChanges() {
		return hasChanges;
	}



	public void setHasChanges(boolean hasChanges) {
		this.hasChanges = hasChanges;
	} 
	 
}


package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util;

import java.util.Date;

public  class ValidacionUtil {
	
	public static final String MENSAJE_CARACTER_INVALIDO= "No se permiten caracteres especiales en: ";
	public static final String MENSAJE_CAMPO_VACIO= "Se debe especificar un valor para:";
	
	public static String  mensajeLongitudInvalida(int caracteres) {
		return "Solo se permiten "+caracteres+" caracteres en:";
	}
	

	public static boolean isEmpty(String value) {
		if (value == null || value.trim().isEmpty()) {
			return true;
		}
		return false;
	}
	

	public static boolean validarCaracteres(String value) {
		if (value!=null && value.matches("^[a-zA-Z0-9 ������������.,/*-]+$")) {
			return true;
		}
		return false;
	}

	public static boolean validarSoloLetras(String value) {
		if (value!=null && value.matches("^[a-zA-Z������������ ]+$")) {
			return true;
		}
		return false;
	}
	
	public static boolean isEmptyDate(Date value) {
		if (value == null) {
			return true;
		}
		return false;
	}
	
	public static boolean validaLongitud(String cadena, int longitud) {
		return cadena.length() <= longitud ? true : false;
	}
	
	public  static String capitalizarPrimeraLetra(String str) {
		String nombreR="";
		String[] parts = str.split(" ");
		for (String string : parts) {
			if(string.trim().length() > 0){
				String nombre = string;
				String resultado = nombre.toUpperCase().charAt(0) + nombre.substring(1, nombre.length()).toLowerCase();
				nombreR = nombreR + resultado + " ";
			}
		}
		String nombreF = nombreR.substring(0, nombreR.length() - 1);
		return nombreF;
	}
	
}
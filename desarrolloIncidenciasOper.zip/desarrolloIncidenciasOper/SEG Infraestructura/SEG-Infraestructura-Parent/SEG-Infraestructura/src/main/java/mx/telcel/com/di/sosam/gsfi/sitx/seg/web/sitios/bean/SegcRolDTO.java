package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.sitios.bean;

public class SegcRolDTO {

	private Integer rol;
	private String nombre;
	private String descripcion;
	private Integer tipoRol;
	private Integer estatus;
	
	public SegcRolDTO() {
		super();
	}

	public SegcRolDTO(Integer rol, String nombre, String descripcion, Integer tipoRol, Integer estatus) {
		super();
		this.rol = rol;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.tipoRol = tipoRol;
		this.estatus = estatus;
	}

	public Integer getRol() {
		return rol;
	}

	public void setRol(Integer rol) {
		this.rol = rol;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Integer getTipoRol() {
		return tipoRol;
	}

	public void setTipoRol(Integer tipoRol) {
		this.tipoRol = tipoRol;
	}

	public Integer getEstatus() {
		return estatus;
	}

	public void setEstatus(Integer estatus) {
		this.estatus = estatus;
	}
	
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.sitios.bean;

import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.io.Serializable;


import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Controller;



@Controller("solicitudRecuperacionEspacioBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class SolicitudRecuperacionEspacioBean implements Serializable {

	private static final long serialVersionUID = -8715496866982916388L;
	private static final Logger LOGGER = LogManager.getLogger(SolicitudRecuperacionEspacioBean.class);
	private String valor = "";
	
	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		try {
			valor = "Solicitud de Recuperaci�n de Espacio";
			System.out.println("Entro pantalla SolicitudRecuperacionEspacioBean");
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al cargar la p�gina");
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","Ocurri� un error al cargar la p�gina"));
		}
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

}

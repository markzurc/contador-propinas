package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.usuario.admin.bean;

import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.elementosPantalla.IElementosPantallaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ElementosPantallaDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.WrapperReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.user.service.UserCatalogService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.ReporteOvitUtil;

@Controller("usuarioConcesionarioBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class UsuarioConcesionarioBean implements Serializable {
	
	private static final long serialVersionUID = 4582624686881827949L;
	
	private static final Logger logger = LogManager.getLogger(UserCatalogService.class);

	@Autowired
	@Qualifier("userCatalogService")
	private UserCatalogService userCatalogService;
	
	@Autowired
	private IElementosPantallaService elementosPantalla;
	
	private List<ReportUserVo> listAll;
	
	private List<WrapperReportUserVo> usersListAll;
	private UserDetailsVo userDetailsVo;
	private String operadorUsuario;
	private String banderaRolEditar;
	
	private List<String> filtroConcesionario;
	private List<String> filtroEstatus;
	
	private String selectFiltroConcesionario;
	private String selectFiltroEstatus;
	private List<ElementosPantallaDTO> listaElementosPantalla;
		
	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		try{
			listaElementosPantalla = new ArrayList<>();
			userDetailsVo = (UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			if (userDetailsVo.getIdRol()==12) {
				banderaRolEditar="true";
			} else {
				banderaRolEditar="false";
			}
			this.setOperadorUsuario(userCatalogService.obtenerOperadorUsuario(userDetailsVo.getIdUsuario()));
			listAll = userCatalogService.getUsersConcesionarioByOp(operadorUsuario);
			usersListAll = userCatalogService.wrapListUsers(listAll);
			filtroConcesionario = new ArrayList<String>();
			filtroEstatus = new ArrayList<String>();
			selectFiltroConcesionario = "null";
			selectFiltroEstatus = "null";
			cargaFiltrosUsuarios();
			String nombreEstadoVista = rc.getCurrentState().getId();
			UserDetailsVo userDetailsVo = (UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			listaElementosPantalla = elementosPantalla.getElementosPermitidosPantalla(nombreEstadoVista, userDetailsVo.getIdRol(), new HashMap<String,Integer>() );
		} catch (Exception e) {
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","Ocurri� un error al cargar la pagina"));
		}
	}

	private void cargaFiltrosUsuarios() {
		for (ReportUserVo insumos : listAll) {
			if (!filtroConcesionario.contains(insumos.getEmpresa())) {
				filtroConcesionario.add(insumos.getEmpresa());
			}
			
			if (!filtroEstatus.contains(insumos.getEstatusNombre())) {
				filtroEstatus.add(insumos.getEstatusNombre());
			}
		}
		Collections.sort(filtroConcesionario);
		Collections.sort(filtroEstatus);
	}
	
	public void getFile() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		try {
			UserDetailsVo userDetailsVo =(UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			String fechaReporte= ReporteOvitUtil.fechaReporte();
			XSSFWorkbook workbook = new XSSFWorkbook();
	        userCatalogService.toExcel(workbook, usersListAll);
		    ExternalContext externalContext = facesContext.getExternalContext();
		    externalContext.setResponseContentType("application/vnd.ms-excel");
		    externalContext.setResponseHeader("Content-Disposition", "attachment; filename=\"Reporte SEG Usuarios Operador "+ fechaReporte+" v01.xlsx\"");
 
			workbook.write(externalContext.getResponseOutputStream());
		}catch (IOException e) {
			logger.error("Error al generar el archivo excel " + e);
		}
	    facesContext.responseComplete();
	}
	

	public boolean getVisible(String nombreComponente) {
		boolean visible = false;
		for (ElementosPantallaDTO elemento : listaElementosPantalla) {
			if (elemento.getIdElemento().equals(nombreComponente)) {
				visible = elemento.isVisible();
			}
		}
		return visible;
	}

	public List<ReportUserVo> getListAll() {
		return listAll;
	}

	public void setListAll(List<ReportUserVo> listAll) {
		this.listAll = listAll;
	}

	public List<WrapperReportUserVo> getUsersListAll() {
		return usersListAll;
	}

	public void setUsersListAll(List<WrapperReportUserVo> usersListAll) {
		this.usersListAll = usersListAll;
	}
	
	public String getOperadorUsuario() {
		return operadorUsuario;
	}
 
	public void setOperadorUsuario(String operadorUsuario) {
		this.operadorUsuario = operadorUsuario;
	}
 
	public UserDetailsVo getUserDetailsVo() {
		return userDetailsVo;
	}
 
	public void setUserDetailsVo(UserDetailsVo userDetailsVo) {
		this.userDetailsVo = userDetailsVo;
	}

	public String getBanderaRolEditar() {
		return banderaRolEditar;
	}

	public void setBanderaRolEditar(String banderaRolEditar) {
		this.banderaRolEditar = banderaRolEditar;
	}

	public List<String> getFiltroConcesionario() {
		return filtroConcesionario;
	}

	public void setFiltroConcesionario(List<String> filtroConcesionario) {
		this.filtroConcesionario = filtroConcesionario;
	}

	public List<String> getFiltroEstatus() {
		return filtroEstatus;
	}

	public void setFiltroEstatus(List<String> filtroEstatus) {
		this.filtroEstatus = filtroEstatus;
	}

	public String getSelectFiltroConcesionario() {
		return selectFiltroConcesionario;
	}

	public void setSelectFiltroConcesionario(String selectFiltroConcesionario) {
		this.selectFiltroConcesionario = selectFiltroConcesionario;
	}

	public String getSelectFiltroEstatus() {
		return selectFiltroEstatus;
	}

	public void setSelectFiltroEstatus(String selectFiltroEstatus) {
		this.selectFiltroEstatus = selectFiltroEstatus;
	}

}

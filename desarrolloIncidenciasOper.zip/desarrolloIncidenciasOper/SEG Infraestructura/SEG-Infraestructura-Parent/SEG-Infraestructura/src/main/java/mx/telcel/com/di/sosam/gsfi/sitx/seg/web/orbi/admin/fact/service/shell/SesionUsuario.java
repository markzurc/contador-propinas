package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.orbi.admin.fact.service.shell;


public class SesionUsuario {
	
	private String contra;
	private String contraPhrase;

	public SesionUsuario(String contra, String contraPhrase) {
		this.contra = contra;
		this.contraPhrase = contraPhrase;
	}

	public String getPassphrase() {
		return contraPhrase;
	}

	public String getPassword() {
		return contra;
	}

	public boolean promptPassphrase(String arg0) {
		return true;
	}

	public boolean promptPassword(String arg0) {
		return false;
	}

	public boolean promptYesNo(String arg0) {
		return true;
	}

	public void showMessage(String arg0) {
		System.out.println("SUserInfo.showMessage(): " + arg0);
	}

}
package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.obra.bean;

import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.map.DefaultMapModel;
import org.primefaces.model.map.LatLng;
import org.primefaces.model.map.MapModel;
import org.primefaces.model.map.Marker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Controller;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto.ObraCivilDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto.ObraCivilVo;;

@Controller("detalleObraCivilBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class DetalleObraCivilBean implements Serializable {
	
	private static final long serialVersionUID = -2226579370912559241L;
	private static final Logger LOGGER = LogManager.getLogger(DetalleObraCivilBean.class);
	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;
	private ObraCivilVo parametroObra;
	private String coordenadas;
	private MapModel simpleModel;
	private String key;
	
	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		try {
			simpleModel = new DefaultMapModel();
			String latitud = "";
			String longitud = "";
			ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness.getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.KEY_API_MAPS);
			key = configurationUtilsVo.getValor();
			if(parametroObra.getLatitud().trim().contains(" ")){
				latitud = getLatitudDecimal(parametroObra.getLatitud().trim());
			} else {
				latitud = parametroObra.getLatitud();
			}
			if(parametroObra.getLongitud().toString().contains(" ")){
				longitud = getLongitudDecimal(parametroObra.getLongitud().trim());
			} else {
				longitud = parametroObra.getLongitud();
			}		
			LatLng coord1 = new LatLng(Double.parseDouble(latitud), Double.parseDouble(longitud));
			coordenadas = latitud+", "+longitud;
			simpleModel.addOverlay(new Marker(coord1, parametroObra.getNombre()));
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al cargar el detalle de la obra");
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","Ocurri� un error al cargar el detalle de la Obra"));
		}
	}
	
	private String getLatitudDecimal(String latitud) {
		FacesContext context = FacesContext.getCurrentInstance();
		String latitudDecimal = "";
		String[] coord = latitud.replaceAll(",", "\\.").split(" ");
		if(coord.length == 3){
			double d = Double.parseDouble(coord[0].replaceAll("\\.", ""));
			double m = Double.parseDouble(coord[1].replaceAll("\\.", ""));
			String seg = coord[2].substring(0,2);
			double s = Double.parseDouble(seg.replaceAll("\\.", ""));
			double signo = 1;
	        double resultado = signo * (Math.abs(d) + (m / 60.0) + (s / 3600.0));	
	        BigDecimal lat = new BigDecimal(""+resultado).setScale(8,BigDecimal.ROUND_HALF_UP);
	        latitudDecimal = String.valueOf(lat);
		} else {
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","No es posible convertir la latidud de la Obra"));			
		}
		return latitudDecimal;
	}

		
	private String getLongitudDecimal(String longitud) {
		FacesContext context = FacesContext.getCurrentInstance();
		String longitudDecimal = "";
		String[] coord = longitud.replaceAll(",", "\\.").split(" ");
		if(coord.length == 3){
			double d = Double.parseDouble(coord[0].replaceAll("\\.", ""));
			double m = Double.parseDouble(coord[1].replaceAll("\\.", ""));
			String seg = coord[2].substring(0,2);
			double s = Double.parseDouble(seg.replaceAll("\\.", ""));
			double signo = -1;
	        double resultado = signo * (Math.abs(d) + (m / 60.0) + (s / 3600.0));
	        BigDecimal lon = new BigDecimal(""+resultado).setScale(8,BigDecimal.ROUND_HALF_UP);
	        longitudDecimal = String.valueOf(lon);
		} else {
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","No es posible convertir la longitud de la Obra"));			
		}
		return longitudDecimal;
	}
	
	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}

	/**
	 * @return the simpleModel
	 */
	public MapModel getSimpleModel() {
		return simpleModel;
	}

	/**
	 * @return the coordenadas
	 */
	public String getCoordenadas() {
		return coordenadas;
	}

	/**
	 * @param coordenadas the coordenadas to set
	 */
	public void setCoordenadas(String coordenadas) {
		this.coordenadas = coordenadas;
	}

	/**
	 * @return the parametroObra
	 */
	public ObraCivilVo getParametroObra() {
		return parametroObra;
	}

	/**
	 * @param parametroObra the parametroObra to set
	 */
	public void setParametroObra(ObraCivilVo parametroObra) {
		this.parametroObra = parametroObra;
	}

}

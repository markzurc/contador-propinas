package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.email.service.impl;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.email.service.ArchivoEmailDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.email.service.IEnvioCorreos;



public class EnvioCorreos implements IEnvioCorreos, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5753660254118129760L;
	
	private static Logger logger = LogManager.getLogger(EnvioCorreos.class);

	@Override
	public String enviaCorreo(InternetAddress[] addressTo, InternetAddress[] addressCC, InternetAddress[] addressBCC,
                String asunto, String mensaje, Properties mailPropiedades, ArchivoEmailDTO imgFirma) {
		Properties mailProperties = mailPropiedades;
		boolean validaConexion = false; int contadorIntentos=1;
		StringBuilder error = new StringBuilder("");
                    while(!validaConexion && contadorIntentos<=3){
                    try {
                            Session mailSession = Session.getDefaultInstance(mailProperties, null);
                            mailSession.setDebug(false);

                            MimeMessage message = new MimeMessage(mailSession);

                            /*Se agrega asunto*/
                            message.setSubject(asunto);

                            /*Se agrega from*/
                            String from = mailProperties.get("mail.user").toString().concat("@mail.telcel.com");

                            /***if(logger.isDebugEnabled()){
                                    logger.debug(from);
                            }***/

                            message.setFrom(new InternetAddress(from));

                            /*Destinatarios TO*/
                            if(addressTo!=null){
                                    if(addressTo.length!=0){
                                            message.addRecipients(Message.RecipientType.TO, addressTo);
                                    }else{
                                            logger.error("Lista TO vacia.");
                                            error.append("Error al enviar correo - Lista TO vacia.");
                                    }
                            }else{
                                    logger.error("Lista TO vacia.");
                                    error.append("Error al enviar correo - Lista TO vacia.");
                            }

                            /*Destinatarios CC*/
                            if(addressCC!=null){
                                    if(addressCC.length!=0){
                                            message.addRecipients(Message.RecipientType.CC, addressCC);
                                    }
                            }

                            /*Destinatarios BCC*/
                            if(addressBCC!=null){
                                    if(addressBCC.length!=0){
                                            message.addRecipients(Message.RecipientType.BCC, addressBCC);
                                    }
                            }

                            MimeMultipart multipart = new MimeMultipart();
                            MimeBodyPart messageBodyPart = new MimeBodyPart();
                            messageBodyPart.setContent(mensaje, "text/html");
                            multipart.addBodyPart(messageBodyPart);

                            /*Se agrega imagen de firma*/
                            messageBodyPart = new MimeBodyPart();
                            DataSource fds = new ByteArrayDataSource(imgFirma.getContenido(),imgFirma.getTipo());
                            messageBodyPart.setDataHandler(new DataHandler(fds));
                            messageBodyPart.setHeader("Content-ID", "<firmaITx>");
                            multipart.addBodyPart(messageBodyPart);

                            message.setContent(multipart);

                            /*Se envia correo.*/
                            Transport transport =  mailSession.getTransport();
                            transport.connect();
                            if(transport.isConnected()){
                                logger.info("Se inicia envio de correo");
                                transport.sendMessage(message, message.getAllRecipients());
                                transport.close();
                                validaConexion = true;
                                contadorIntentos = 4;
                            }else{
                                logger.error("No se obtuvo conexion satisfactoria para envio de correo");
                                transport.close();
                            }

                    } catch (NoSuchProviderException e) {
                            logger.error("NoSuchProviderException: "+e);
                            logger.error("Error:" + e.getMessage() + " Cause by: " + e.getCause());
                            error.append(" No se envio correo a los siguientes destinatarios: ");
                            error.append(Arrays.toString(addressTo).replace("[","").replace("]", "") );

                            if(addressCC!=null){
                                    if (addressCC.length>0) {
                                            error.append(", ");
                                            error.append(Arrays.toString(addressCC).replace("[","").replace("]", ".") );
                                    }else{
                                            error.append(".");
                                    }
                            }else{
                                    error.append(".");
                            }

                    } catch (AddressException e) {
                            logger.error("AddressException: "+e);
                            logger.error("Error: " + e.getMessage() + " Cause by: " + e.getCause());
                            error.append(" No se envio correo a los siguientes destinatarios: ");
                            error.append(Arrays.toString(addressTo).replace("[","").replace("]", "") );

                            if(addressCC!=null){
                                    if (addressCC.length>0) {
                                            error.append(", ");
                                            error.append(Arrays.toString(addressCC).replace("[","").replace("]", ".") );
                                    }else{
                                            error.append(".");
                                    }
                            }else{
                                    error.append(".");
                            }

                    } catch (MessagingException e) {
                            logger.error("MessagingException: "+e);
                            logger.error("Error: " + e.getMessage() + " Cause by: " + e.getCause());
                            error.append(" No se envio correo a los siguientes destinatarios: ");
                            error.append(Arrays.toString(addressTo).replace("[","").replace("]", "") );

                            if(addressCC!=null){
                                    if (addressCC.length>0) {
                                            error.append(", ");
                                            error.append(Arrays.toString(addressCC).replace("[","").replace("]", ".") );
                                    }else{
                                            error.append(".");
                                    }
                            }else{
                                    error.append(".");
                            }

                    }catch(NullPointerException e){
                            logger.error("NullPointerException: "+e);
                            logger.error("Error: " + e.getMessage() + " Cause by: " + e.getCause());
                            error.append(e.getMessage());
                    }catch (Exception e ){
                            logger.error("Exception: "+e);
                            logger.error("Error: " + e.getMessage() + " Cause by: " + e.getCause());
                            error.append(e.getMessage());
                    }
                    contadorIntentos++;
                }
		return error.toString();
	}

	@Override
	public String enviaCorreo(InternetAddress[] addressTo, InternetAddress[] addressCC, InternetAddress[] addressBCC,
                String asunto, String mensaje, List<ArchivoEmailDTO> attachedFiles, Properties mailPropiedades, ArchivoEmailDTO imgFirma) {
		Properties mailProperties = mailPropiedades;
		boolean validaConexion = false; int contadorIntentos=1;
		StringBuilder error = new StringBuilder("");
		while(!validaConexion && contadorIntentos<=3){
                    try {
                            Session mailSession = Session.getDefaultInstance(mailProperties, null);
                            mailSession.setDebug(false);

                            MimeMessage message = new MimeMessage(mailSession);

                            /*Se agrega asunto*/
                            message.setSubject(asunto);

                            /*Se agrega from*/
                            String from = mailProperties.get("mail.user").toString().concat("@mail.telcel.com");
                            //logger.debug(from);
                            message.setFrom(new InternetAddress(from));

                            /*Destinatarios TO*/
                            if(addressTo!=null){
                                    if(addressTo.length!=0){
                                            message.addRecipients(Message.RecipientType.TO, addressTo);
                                    }else{
                                            logger.error("Lista TO vacia.");
                                            error.append("Error al enviar correo - Lista TO vacia.");
                                    }
                            }else{
                                    logger.error("Lista TO vacia.");
                                    error.append("Error al enviar correo - Lista TO vacia.");
                            }


                            /*Destinatarios CC*/
                            if(addressCC!=null){
                                    if(addressCC.length!=0){
                                            message.addRecipients(Message.RecipientType.CC, addressCC);
                                    }
                            }

                            /*Destinatarios BCC*/
                            if(addressBCC!=null){
                                    if(addressBCC.length!=0){
                                            message.addRecipients(Message.RecipientType.BCC, addressBCC);
                                    }
                            }

                            /*Se agrega mensaje de correo.*/
                            MimeMultipart multipart = new MimeMultipart();
                            MimeBodyPart messageBodyPart = new MimeBodyPart();
                            messageBodyPart.setContent(mensaje, "text/html");
                            multipart.addBodyPart(messageBodyPart);

                            /*Se agrega imagen de firma*/
                            messageBodyPart = new MimeBodyPart();
                            DataSource fds = new ByteArrayDataSource(imgFirma.getContenido(),imgFirma.getTipo());
                            messageBodyPart.setDataHandler(new DataHandler(fds));
                            messageBodyPart.setHeader("Content-ID", "<firmaITx>");
                            multipart.addBodyPart(messageBodyPart);

                            /*se agregan archivos adjuntos*/
                            multipart = this.getArchivosAdjuntos(attachedFiles, multipart);
                            message.setContent(multipart);

                            /*Se envia correo.*/
                            Transport transport =  mailSession.getTransport();
                            transport.connect();
                            if(transport.isConnected()){
                                logger.info("Se inicia envio de correo");
                                transport.sendMessage(message, message.getAllRecipients());
                                transport.close();
                                validaConexion = true;
                                contadorIntentos = 4;
                            }else{
                                logger.error("No se obtuvo conexion satisfactoria para envio de correo");
                                transport.close();
                            }

                    } catch (NoSuchProviderException e) {
                            logger.error("Error al ejecutar EnvioCorreos.enviaCorreo: " + e);
                            logger.error("Error: " + e.getMessage() + " Cause by: " + e.getCause());
                            error.append(" No se envio correo a los siguientes destinatarios: ");
                            error.append(Arrays.toString(addressTo).replace("[","").replace("]", "") );

                            if(addressCC!=null){
                                    if (addressCC.length>0) {
                                            error.append(", ");
                                            error.append(Arrays.toString(addressCC).replace("[","").replace("]", ".") );
                                    }else{
                                            error.append(".");
                                    }
                            }else{
                                    error.append(".");
                            }

                    } catch (AddressException e) {
                            logger.error("Error al ejecutar EnvioCorreos.enviaCorreo: " + e);
                            logger.error("Error: " + e.getMessage() + " Cause by: " + e.getCause());
                            error.append(" No se envio correo a los siguientes destinatarios: ");
                            error.append(Arrays.toString(addressTo).replace("[","").replace("]", "") );

                            if(addressCC!=null){
                                    if (addressCC.length>0) {
                                            error.append(", ");
                                            error.append(Arrays.toString(addressCC).replace("[","").replace("]", ".") );
                                    }else{
                                            error.append(".");
                                    }
                            }else{
                                    error.append(".");
                            }
                    } catch (MessagingException e) {
                            logger.error("Error al ejecutar EnvioCorreos.enviaCorreo: " + e);
                            logger.error("Error: " + e.getMessage() + " Cause by: " + e.getCause());
                            error.append(" No se envio correo a los siguientes destinatarios: ");
                            error.append(Arrays.toString(addressTo).replace("[","").replace("]", "") );

                            if(addressCC!=null){
                                    if (addressCC.length>0) {
                                            error.append(", ");
                                            error.append(Arrays.toString(addressCC).replace("[","").replace("]", ".") );
                                    }else{
                                            error.append(".");
                                    }
                            }else{
                                    error.append(".");
                            }
                    }catch(NullPointerException e){
                            logger.error("Error al ejecutar EnvioCorreos.enviaCorreo: " + e);
                            logger.error("Error: " + e.getMessage() + " Cause by: " + e.getCause());
                    }catch (Exception e ){
                            logger.error("Error al ejecutar EnvioCorreos.enviaCorreo: " + e);
                            logger.error("Error: " + e.getMessage() + " Cause by: " + e.getCause());
                            error.append(e.getMessage());
                    }
                    contadorIntentos++;
                }
		return error.toString();
	}

	@Override
	public MimeMultipart getArchivosAdjuntos(List<ArchivoEmailDTO> files, MimeMultipart multiPart) {
		logger.info("------------------- Archivos ----------------");
		try {
			
			for (ArchivoEmailDTO attach : files) {
				logger.info("nombre: "+attach.getNombre());
				logger.info("tipo: "+attach.getTipo());
				logger.info("contenido: "+attach.getContenido().length);
				BodyPart messageBodyPart = new MimeBodyPart();
				DataSource source = new ByteArrayDataSource(attach.getContenido(),attach.getTipo());
				messageBodyPart.setDataHandler(new DataHandler(source));
				messageBodyPart.setFileName(attach.getNombre());
				messageBodyPart.setDisposition(Part.ATTACHMENT);

				multiPart.addBodyPart(messageBodyPart);
			}
			
		} catch (MessagingException e) {
			logger.error("Error al ejecutar EnvioCorreos.getArchivosAdjuntos: " + e);
			logger.error("Error: " + e.getMessage() + " Cause by: " + e.getCause());
		}
		
		return multiPart;
	}
	
	
}
package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.APROBADO_POR;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.DOCUMENT_NAME;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.FECHA;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.FORMATOREPORTE;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.FORMATYY;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.PREAPARADO_POR;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.TITULO;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.VERSION;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.service.error.ErrorService;

public class ReporteOvitUtil {

	private static final String LABEL_PREPARADO= "Preparado por";
	private static final String LABEL_DOCUMENTO= "Documento";
	private static final String LABEL_APROBADO= "Aprobado por";
	private static final String LABEL_FECHA= "Fecha";
	private static final String LABEL_VERSION= "Versi�n";

	private static final String DATE_FORMAT_PLANTILLA="yyyy/MM/dd";
	private static final String PATH_PLANTILLA="/PlantillasITxv02.xlsx";
	private static final Logger LOGGER = LogManager.getLogger(ErrorService.class);

	
	public static String fechaReporte(){
		return new SimpleDateFormat(FORMATOREPORTE,Locale.ENGLISH).format(new Date()).toString();
	}
	
	public static String fechaYY(){
		return new SimpleDateFormat(FORMATYY,Locale.ENGLISH).format(new Date()).toString();
	}
	
	

	
	
}

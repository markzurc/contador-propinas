package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util;


@javax.xml.bind.annotation.XmlRootElement
public class CommonAction {

	
	private String nombreAction;

	
	public CommonAction() {
		
	}
	
	public CommonAction(String nombreAction) {
		super();
		this.nombreAction = nombreAction;
	}

     @javax.xml.bind.annotation.XmlElement(nillable=true)
	public String getNombreAction() {
		return nombreAction;
	}

	public void setNombreAction(String nombreAction) {
		this.nombreAction = nombreAction;
	}
	
	
	
}

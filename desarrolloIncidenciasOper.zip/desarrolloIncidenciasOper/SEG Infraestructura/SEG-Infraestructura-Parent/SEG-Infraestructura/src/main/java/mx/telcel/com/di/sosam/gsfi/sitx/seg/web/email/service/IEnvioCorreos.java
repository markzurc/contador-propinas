package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.email.service;

import java.util.List;
import java.util.Properties;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMultipart;

/**
  * 
  * Interface de servicio de env�o de correos electronicos 
  *
  */
public interface IEnvioCorreos {
	
	/**
	 * Servicio de envio de correos electronicos.
	 * 
	 * @author vi7xxix
	 * @param {@link InternetAddress}[] addressTo
	 * @param {@link InternetAddress}[] addressCC
	 * @param {@link InternetAddress}[] addressBCC
	 * @param {@link String} asunto
	 * @param {@link String} mensaje
	 * @param {@link Properties} mailPropiedades
	 * @param {@link ArchivoEmailDTO} imgFirma
	 * @return {@link String} 
	 */
	String enviaCorreo (InternetAddress[] addressTo, InternetAddress[] addressCC, InternetAddress[] addressBCC, 
					String asunto, String mensaje, Properties mailPropiedades, ArchivoEmailDTO imgFirma);
	
	/**
	 * Servicio de envio de correos electronicos.
	 * 
	 * @author vi7xxix
	 * @param {@link InternetAddress}[] addressTo
	 * @param {@link InternetAddress}[] addressCC
	 * @param {@link InternetAddress}[] addressBCC
	 * @param {@link String} asunto
	 * @param {@link String} mensaje
	 * @param {@link List}<{@link String}> attachedFiles
	 * @param {@link Properties} mailPropiedades
	 * @param {@link ArchivoEmailDTO} imgFirma
	 * @return {@link String} 
	 */
	String enviaCorreo (InternetAddress[] addressTo, InternetAddress[] addressCC, InternetAddress[] addressBCC, 
					String asunto, String mensaje, List<ArchivoEmailDTO> attachedFiles, Properties mailPropiedades, ArchivoEmailDTO imgFirma);
	
	/**
	 * Servicio que obtiene los archivos a adjuntar en el correo
	 * electronico.
	 * 
	 * <p>Recibe como parametros una lista con la ruta de los archivos
	 * a adjuntar y un objeto {@link MimeMultipart} en el cual se 
	 * almacenaran los archivos a enviarse.
	 * </p>
	 * 
	 * @author vi7xxix
	 * @param {@link List <{@link String}> files
	 * @param {@link MimeMultipart} multiPart
	 * @return {@link MimeMultipart}
	 */
	MimeMultipart getArchivosAdjuntos(List<ArchivoEmailDTO> files, MimeMultipart multiPart);
	
}
package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.OVITUtils;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ApplicationVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ComponentVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolAclVo;

import org.primefaces.component.tabview.Tab;
import org.primefaces.model.DefaultTreeNode;
import org.primefaces.model.TreeNode;

public class TabAplicacionAclUtil extends Tab implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5125949245009412542L;
	private TreeNode treeNode;
	private List<WrapperSelectUtil> listaComponentesWrap;
	private ApplicationVo aplicacion;
	private boolean showErrorSeleccionados;
          
	private boolean inView;
	
	
	
	public TabAplicacionAclUtil() {
		super();
	}
	
	public TabAplicacionAclUtil(ApplicationVo aplicacion) {
		this.aplicacion=aplicacion;
	}
	

	public boolean hasSeletedComponents() {
		for (WrapperSelectUtil wrapperSelect : listaComponentesWrap) {
			if (wrapperSelect.isSelected()) {
				showErrorSeleccionados = false;
				return true;
			}
		}
		return false;
	}

	public void showErrorSeleccionados() {
		showErrorSeleccionados = true;

	}

	public void generaTreeNodeAclsByApp(List<ComponentVo> listaComponentes) {
		listaComponentesWrap = wrapList(listaComponentes);
		TreeNode root = new DefaultTreeNode(null, null);
		for (WrapperSelectUtil wrapperSelect : listaComponentesWrap) {
			if (wrapperSelect.getComponente().getIdPadre() == null) {
				TreeNode sub = new DefaultTreeNode(wrapperSelect, root);
				sub.setExpanded(true);
				addChilds(sub, listaComponentesWrap,
						wrapperSelect.getComponente());
			}
		}
		treeNode = root;
	}

	private void addChilds(TreeNode treeNode,
			List<WrapperSelectUtil> listaComponentes,
			ComponentVo componenteParent) {
		List<WrapperSelectUtil> childs = getChilds(listaComponentes,
				componenteParent);
		for (WrapperSelectUtil child : childs) {
			TreeNode item = new DefaultTreeNode(child, treeNode);
			item.setExpanded(true);
			addChilds(item, listaComponentes, child.getComponente());
		}
	}

	private List<WrapperSelectUtil> getChilds(
			List<WrapperSelectUtil> listaComponentes, ComponentVo comp) {
		List<WrapperSelectUtil> childs = new ArrayList<WrapperSelectUtil>();
		for (WrapperSelectUtil componente : listaComponentes) {
			if (componente.getComponente().getIdPadre()!= null && componente.getComponente().getIdPadre().equals(comp
					.getIdComponente()))
				childs.add(componente);
		}
		return childs;

	}

	private List<WrapperSelectUtil> wrapList(List<ComponentVo> listaComponentes) {
		List<WrapperSelectUtil> listaBack = new ArrayList<WrapperSelectUtil>();
		if (!OVITUtils.isEmptyList(listaComponentes)) {
			for (ComponentVo componente : listaComponentes) {
				WrapperSelectUtil wrapperSelect = new WrapperSelectUtil(
						componente);
				listaBack.add(wrapperSelect);
			}
		}

		return listaBack;
	}

	public void selectLoadedbyRol(List<RolAclVo> listaCompontesAsig) {
		if (!OVITUtils.isEmptyList(listaCompontesAsig)) {
			for (RolAclVo rolAclVo : listaCompontesAsig) {
				for (WrapperSelectUtil wrapperSelect : listaComponentesWrap) {
					if (wrapperSelect.getComponente().getIdComponente().equals(rolAclVo
							.getIdComponente())) {
						wrapperSelect.setSelected(true);
						wrapperSelect.setPermisoChar(rolAclVo.getPermiso());
						wrapperSelect.setDisablePermiso(false);
					}
				}
			}
		}
	}

	public List<WrapperSelectUtil> getComponentsSelected() {
		List<WrapperSelectUtil> seleccionados = new ArrayList<WrapperSelectUtil>();

		for (WrapperSelectUtil wrapperSelect : listaComponentesWrap) {
			if (wrapperSelect.isSelected()){
				seleccionados.add(wrapperSelect);
			}
		}

		return seleccionados;

	}

	public TreeNode getTreeNode() {
		return treeNode;
	}

	public void setTreeNode(TreeNode treeNode) {
		this.treeNode = treeNode;
	}

	public ApplicationVo getAplicacion() {
		return aplicacion;
	}

	public void setAplicacion(ApplicationVo aplicacion) {
		this.aplicacion = aplicacion;
	}

	public boolean isShowErrorSeleccionados() {
		return showErrorSeleccionados;
	}

	public void setShowErrorSeleccionados(boolean showErrorSeleccionados) {
		this.showErrorSeleccionados = showErrorSeleccionados;
	}

	public boolean isInView() {
		return inView;
	}

	public void setInView(boolean inView) {
		this.inView = inView;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((aplicacion == null) ? 0 : aplicacion.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
			}
		if (obj == null){
			return false;
			}
		if (getClass() != obj.getClass()){
			return false;
			}
		TabAplicacionAclUtil other = (TabAplicacionAclUtil) obj;
		if (aplicacion == null) {
			if (other.aplicacion != null){
				return false;
				}
		} else if (!aplicacion.equals(other.aplicacion)){
			return false;
			}
		return true;
	}

	
	
}

															package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.validators;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

@FacesValidator("securityParamValidator")
public class SecurityParamValidator implements Validator {

	
	
	static final String LABEL="label";
	static final String REQUIRED="required";
	static final String ER="ER";
	static final String MESSAGE="message";
	private String cuurentMSJ="";
	private Integer tipoDato;
	static final String TYPE="type";
	private static final int INTEGER=1;
	private static final int FLOAT=2;
	private static final String MSG_ERROR_INTEGER="El valor de este parametro debe ser del tipo entero";
	private static final String MSG_ERROR_FLOAT="El valor de este parametro debe ser del tipo float";
	
	
	@Override
	public void validate(FacesContext arg0, UIComponent arg1, Object arg2)
			throws ValidatorException {
		    
		tipoDato = Integer.parseInt(String.valueOf(arg1.getAttributes().get(TYPE)));
		String value = arg2.toString().trim();
		boolean valido=true;
		
		
		//definir nuevos tipos de datos agragados al catalogo
		if(tipoDato== INTEGER){
			try{
				Integer.parseInt(value);
			}catch(NumberFormatException nfe){
				valido=false;
				cuurentMSJ=MSG_ERROR_INTEGER;
			}
		}else if(tipoDato== FLOAT){
			try{
				Float.parseFloat(value);
			}catch(NumberFormatException nfe){
				valido=false;
				cuurentMSJ=MSG_ERROR_FLOAT;
			}
		}
			
		if (!valido) {
			FacesMessage msg = new FacesMessage("Validacion fallida",
					cuurentMSJ);
			msg.setSeverity(FacesMessage.SEVERITY_ERROR);
			throw new ValidatorException(msg);
		}

	}


	
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.service.error;

import java.io.Serializable;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

@Service("errorService")
public class ErrorService implements Serializable {

	private static final long serialVersionUID = 8237284460940606976L;
	
	private Logger logger = LogManager.getLogger(ErrorService.class);

	public void getError() throws IllegalArgumentException, Exception{
		logger.info("entro a error");
	}
}

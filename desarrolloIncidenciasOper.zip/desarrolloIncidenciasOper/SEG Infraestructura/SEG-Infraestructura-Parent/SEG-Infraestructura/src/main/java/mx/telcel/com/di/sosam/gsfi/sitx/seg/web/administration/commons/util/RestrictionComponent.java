package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util;

import java.io.IOException;

import javax.faces.component.FacesComponent;
import javax.faces.component.UIComponentBase;
import javax.faces.context.FacesContext;
import javax.faces.view.facelets.FaceletContext;

import org.primefaces.component.outputlabel.OutputLabel;
import org.primefaces.component.panel.Panel;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ApplicationVo;


@FacesComponent(value = "restrictionComponent")
public class RestrictionComponent extends UIComponentBase {

	private ApplicationVo appAsociada;
	
	@Override
	public String getFamily() {
		return "OVIT";
	}
	
	
	@Override
	public void encodeBegin(FacesContext context) {
       
            FaceletContext faceletContext = (FaceletContext) context.getAttributes().get(FaceletContext.FACELET_CONTEXT_KEY);
            try {
				faceletContext.includeFacelet(this, "/WEB-INF/views/Administration/Restricciones/deafuslt.xhtml");
			} catch (IOException e) {
				this.getChildren().clear();
			  Panel panel= new Panel();
			  OutputLabel outputLabel= new OutputLabel();
			  outputLabel.setId(("D"+Math.random()).replace(".", "D"));
			  outputLabel.setValue("No se han implementado restricciones para esta aplicacion: " + e);
			  panel.getChildren().add(outputLabel);
			  panel.setId(("C"+Math.random()).replace(".", "C"));
			  this.getChildren().add(panel);
				
			}
           
    }

	public ApplicationVo getAppAsociada() {
		return appAsociada;
	}


	public void setAppAsociada(ApplicationVo appAsociada) {
		this.appAsociada = appAsociada;
	}

}

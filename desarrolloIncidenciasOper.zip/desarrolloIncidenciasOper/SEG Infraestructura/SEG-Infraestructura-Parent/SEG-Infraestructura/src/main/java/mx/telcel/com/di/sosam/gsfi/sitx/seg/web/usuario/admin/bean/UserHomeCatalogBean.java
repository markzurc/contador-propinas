  package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.usuario.admin.bean;

import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.FOLIO_VAL;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.MSJ_FOL_ALPHA;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.MSJ_FOL_REQ;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.SISTEMA_OVIT;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.STATUS_ACTIVO;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.STATUS_BAJA;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.STATUS_BLOQUEADO;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.STATUS_REINICIADO;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.SUCCESS;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.VALIDATION;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.VER_1;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.IBitacoraSoxBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.WrapperReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.user.service.UserCatalogService;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Controller;
import org.springframework.webflow.execution.RequestContext;

@Controller("userHomeCatalogBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class UserHomeCatalogBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9149583303043112578L;
	
	private static final Logger logger = LogManager.getLogger(UserHomeCatalogBean.class);
	
	/**
     * This static property stores the value of the action "DELETE", this indicates that the user selected will change
     * of status to "baja"    
	 */
	private static final String DELETE="DELETE";
	/**
     * This static property stores the value of the action "LOCK", this indicates that the user selected will change
     * of status to "BLOQUEADO"    
	 */
	private static final String LOCK="LOCK";
	/**
     * This static property stores the value of the action "UNLOCK", this indicates that the user selected will change
     * of status to "ACTIVO"    
	 */
	private static final String UNLOCK="UNLOCK";
	/**
     * This static property stores the value of the action "RESETPASS", this indicates that the user selected will change
     * of status to "REINICIADO"    
	 */
	private static final String RESET_PASS="RESETPASS";
	private static final Map<String,String> MESSAGES_MAP;
	private static final Map<String,String> MESSAGES_SUCCESS;
	private static final Map<String,String> MESSAGES_FAIL;
	
	
	static{
		MESSAGES_MAP= new HashMap<String,String>();
		MESSAGES_MAP.put(DELETE, "eliminar");
		MESSAGES_MAP.put(LOCK, "bloquear");
		MESSAGES_MAP.put(UNLOCK, "desbloquear");
		MESSAGES_MAP.put(RESET_PASS, "reinciar la contrase�a");
		
		MESSAGES_SUCCESS= new HashMap<String,String>();
		MESSAGES_SUCCESS.put(DELETE, "El Usuario se ha elminado");
		MESSAGES_SUCCESS.put(LOCK, "El 	Usuario se ha bloqueado");
		MESSAGES_SUCCESS.put(UNLOCK, "El Usuario se ha desbloqueado");
		MESSAGES_SUCCESS.put(RESET_PASS, "Se ha reiniciado la contrase�a ");
		
		MESSAGES_FAIL= new HashMap<String,String>();
		MESSAGES_FAIL.put(DELETE, "en la eliminaci�n");
		MESSAGES_FAIL.put(LOCK, "en el bloqueo");
		MESSAGES_FAIL.put(UNLOCK, "en el desbloqueo");
		MESSAGES_FAIL.put(RESET_PASS, "en el reinicio de la contre�a");
	}
	
	
	
	@Autowired
	@Qualifier("userCatalogService")
	private UserCatalogService userCatalogService;
	
	
	/**
     * This property stores the list of all users for visual representation in the datatable "usersTable" of the userHomecatalog view.   
	 */
	private List<WrapperReportUserVo> usersListAll;
	/**
     * This property stores the list of all internal users to fill the internalUsers table  of the userMerge view.    
	 */
	private List<ReportUserVo> usersListInternal;
	
	/**
     * This property stores the current user selected from the userHomecatalog view, this is uses for realize an action over him.
     * this value is passed through by f:setPropertyActionListener tag.  
	 */
	private ReportUserVo currentUser;
	
	private String mensajeErrorConfirm;
	private String currentFolio;
	
	
	
	/**
     * This property stores the value of the action that will performed at selected user object selected from 
	 * data table.    
	 */
	private String action="";
	/**
     * this property stores the value of the action confirmation dialog's label, this value will change depending on the 
     * value of action property.
     */
	private String messageConfirm;
	/**
     * this property stores the value of "folio" from the view userHomeCatalog.xhtml, this value is used to do an entry log by each one data change   
     */
	private String currentFolioAction;
	/**
     * this property stores the value of the success confirmation dialog's label, this value will change depending on the 
     * value of action property.
     */
	private String messageSucces;
	/**
     * this property stores the value of the fail confirmation dialog's label, this value will change depending on the 
     * value of action property.
     */
	private String messageFail;
	
	
	
	private List<ReportUserVo> listAll;
	
	/**
	 * Method that initializes values for the view userHomeCatalog.xhtml,
	 * this method is invoked by userHomeCatalog-flow.xml when the action userHomeCatalog
	 * is called 
	 * @param requestContext
	 * @throws TransactionalOVITException
	 */
	public void initHomeCatologHome(RequestContext ctx)
			throws TransactionalOVITException {
		listAll=userCatalogService.getAllUsers();
		//usersListAll=userCatalogService.wrapListUsers(excludeBajas(listAll));
		usersListInternal=userCatalogService.getAllInternalUsers(listAll);
		currentFolio="";
	}
	
	
	
	private List<ReportUserVo> excludeBajas(List<ReportUserVo> listAll){
		List<ReportUserVo> filtredlist=new ArrayList<ReportUserVo>();
		for(ReportUserVo reportUserVo:listAll){
			if(reportUserVo.getIdEstatus() != STATUS_BAJA){
				filtredlist.add(reportUserVo);
			}
		}
		return filtredlist;
	}
	
	
	
	public void soloBajas(){
		List<ReportUserVo> filtredlist=new ArrayList<ReportUserVo>();
		for(ReportUserVo reportUserVo:listAll){
			if(reportUserVo.getIdEstatus() == STATUS_BAJA){
				filtredlist.add(reportUserVo);
			}
		}
		//usersListAll=userCatalogService.wrapListUsers(filtredlist);
	}
	
    public void allUsers(){
    	//usersListAll=userCatalogService.wrapListUsers(excludeBajas(listAll));
    }
	
	
	
	/**
	 * Method that initializes the message on action confirmation dialog, depends of value of action it will search
	 * the corresponding value in the map MESSAGES_MAP, this method is invoked on action property of the actionLinks 
	 * in the user data table 
	 */
	public void initDialog(){
		messageConfirm=MESSAGES_MAP.get(action);
		mensajeErrorConfirm="";
		currentFolio="";
	}
	
	/**
	 * Method that initializes the message on success and fail confirmation dialog, depends of value of action it will search
	 * the corresponding value in the MESSAGES_SUCCESS and MESSAGES_FAIL after it calls the method of userCatalogService that 
	 * corresponding to the current action, this method is invoked on action property of the action confirmation dialog.  
	 * @throws TransactionalOVITException 
	 */
	public void doActionUser() throws TransactionalOVITException{
		
		org.primefaces.context.RequestContext context = org.primefaces.context.RequestContext.getCurrentInstance();
		boolean succes=false;
		boolean validation=false;
		messageSucces=MESSAGES_SUCCESS.get(action);
		messageFail=MESSAGES_FAIL.get(action);
		String objOldXML=userCatalogService.getXMLfromObject(currentUser);
		
		
		
		if (this.currentFolio.trim().isEmpty()) {
			mensajeErrorConfirm = MSJ_FOL_REQ;
			currentFolio="";
		} else if (!this.currentFolio.matches(FOLIO_VAL)) {
			mensajeErrorConfirm = MSJ_FOL_ALPHA;
			currentFolio="";
		}else{
			validation=true;
		} 
		
		if(DELETE.equals(action) && validation){
			 succes=updateStatus(currentUser,STATUS_BAJA,Boolean.FALSE);
		}
		if(LOCK.equals(action)  && validation){
			 succes=updateStatus(currentUser,STATUS_BLOQUEADO,Boolean.FALSE);
		}
		
		if(UNLOCK.equals(action) && validation){
			succes=updateStatus(currentUser,STATUS_ACTIVO,Boolean.FALSE);
		}
		
		if(RESET_PASS.equals(action) && validation){
				succes=updateStatus(currentUser,STATUS_REINICIADO,Boolean.TRUE);
		}
		
		
		if(succes){
			userCatalogService.registraEnBitacora(objOldXML, currentUser, currentFolio, IBitacoraSoxBusiness.UPDATE);
		}else{
			userCatalogService.registraEnBitacora(objOldXML, currentUser, currentFolio, IBitacoraSoxBusiness.ERROR_MODIFY);
		}
		
		context.addCallbackParam(SUCCESS, succes);
		context.addCallbackParam(VALIDATION, validation);
	}
	
	
	
	
	/**
	 * 
	 * 
	 * @param currentUser
	 * @param idEstatus
	 * @param reset
	 * @return
	 * @throws TransactionalOVITException
	 */
	public boolean updateStatus(ReportUserVo currentUser, Integer idEstatus,boolean reset) throws TransactionalOVITException{

		if(reset && userCatalogService.resetPassword(currentUser.getIdUsuario())){
			return userCatalogService.updateStatusUser(currentUser.getIdUsuario(), idEstatus);
		}else if(!reset){
			return userCatalogService.updateStatusUser(currentUser.getIdUsuario(), idEstatus);			
		} else{
			return false;
		}
		
	}

	

	
	public void getFile() {

       
    }
	
	
	
	
	
	
	
	/**
	 * @return the userCatalogService
	 */
	public UserCatalogService getUserCatalogService() {
		return userCatalogService;
	}

	/**
	 * @param userCatalogService the userCatalogService to set
	 */
	public void setUserCatalogService(UserCatalogService userCatalogService) {
		this.userCatalogService = userCatalogService;
	}

	
	public List<WrapperReportUserVo> getUsersListAll() {
		return usersListAll;
	}

	public void setUsersListAll(List<WrapperReportUserVo> usersListAll) {
		this.usersListAll = usersListAll;
	}

	/**
	 * @return the currentUser
	 */
	public ReportUserVo getCurrentUser() {
		return currentUser;
	}

	/**
	 * @param currentUser the currentUser to set
	 */
	public void setCurrentUser(ReportUserVo currentUser) {
		this.currentUser = currentUser;
	}

	
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * @return the messageConfirm
	 */
	public String getMessageConfirm() {
		return messageConfirm;
	}

	/**
	 * @param messageConfirm the messageConfirm to set
	 */
	public void setMessageConfirm(String messageConfirm) {
		this.messageConfirm = messageConfirm;
	}

	/**
	 * @return the currentFolioAction
	 */
	public String getCurrentFolioAction() {
		return currentFolioAction;
	}

	/**
	 * @param currentFolioAction the currentFolioAction to set
	 */
	public void setCurrentFolioAction(String currentFolioAction) {
		this.currentFolioAction = currentFolioAction;
	}

	/**
	 * @return the messageSucces
	 */
	public String getMessageSucces() {
		return messageSucces;
	}

	/**
	 * @param messageSucces the messageSucces to set
	 */
	public void setMessageSucces(String messageSucces) {
		this.messageSucces = messageSucces;
	}

	/**
	 * @return the messageFail
	 */
	public String getMessageFail() {
		return messageFail;
	}

	/**
	 * @param messageFail the messageFail to set
	 */
	public void setMessageFail(String messageFail) {
		this.messageFail = messageFail;
	}

	public List<ReportUserVo> getUsersListInternal() {
		return usersListInternal;
	}

	public void setUsersListInternal(List<ReportUserVo> usersListInternal) {
		this.usersListInternal = usersListInternal;
	}

	public String getMensajeErrorConfirm() {
		return mensajeErrorConfirm;
	}

	public void setMensajeErrorConfirm(String mensajeErrorConfirm) {
		this.mensajeErrorConfirm = mensajeErrorConfirm;
	}

	public String getCurrentFolio() {
		return currentFolio;
	}

	public void setCurrentFolio(String currentFolio) {
		this.currentFolio = currentFolio;
	}

	
	
	
	
	
}

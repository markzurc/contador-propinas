package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.obra.bean;

import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.primefaces.model.DefaultStreamedContent;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.elementosPantalla.IElementosPantallaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.obra.IGestionObraCivilService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ElementosPantallaDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto.EstadoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto.MunicipioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto.ObraCivilDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto.ObraCivilVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.FiltroSitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.obra.service.ObraCivilService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.mapper.MapperCustomFactory;

@Controller("gestionObraCivilBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class GestionObraCivilBean extends MapperCustomFactory implements Serializable {
	
	@Autowired
	private IGestionObraCivilService gestionObraCivilServiceImpl;
	
	@Autowired
	private ObraCivilService obraCivilService;
	
	@Autowired
	private IElementosPantallaService elementosPantalla;
	
	private List<ObraCivilDto> listaObra;
	private List<ObraCivilVo> listaObraFilter;
	private static final long serialVersionUID = -2226579370912559241L;
	private static final Logger LOGGER = LogManager.getLogger(GestionObraCivilBean.class);
	private DefaultStreamedContent archivoDescarga;
	
	private List<FiltroSitioDto> filtros;
	private List<String> filtroRegion;
	private List<EstadoDto> filtroEstado;
	private List<MunicipioDto> filtroMunicipio;
	
	private String selectFiltroRegion;
	private String selectFiltroEstado;
	private String selectFiltroMunicipio;
	private List<ElementosPantallaDTO> listaElementosPantalla;

	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		try{
			listaElementosPantalla = new ArrayList<>();
			limpiaCombos();
			FiltroSitioDto filtro = new FiltroSitioDto();
			filtro.setRegion(selectFiltroRegion);
			filtro.setEstado(selectFiltroEstado);
			filtro.setMunicipio(selectFiltroMunicipio);
			filtroRegion = gestionObraCivilServiceImpl.getListaRegion();
			listaObra = gestionObraCivilServiceImpl.getListaObraCivil(filtro);
			listaObraFilter = getMapper().mapAsList(listaObra, ObraCivilVo.class);
			String nombreEstadoVista = rc.getCurrentState().getId();
			UserDetailsVo userDetailsVo = (UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			listaElementosPantalla = elementosPantalla.getElementosPermitidosPantalla(nombreEstadoVista, userDetailsVo.getIdRol(), new HashMap<String,Integer>() );
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al cargar los datos de Sitios");
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","Ocurri� un error al cargar la Consulta de Sitios"));
		}
	}
	
	public void limpiaCombos(){
		filtroEstado = new ArrayList<>();
		filtroMunicipio = new ArrayList<>();;
		
	    selectFiltroRegion = "null";
		selectFiltroEstado = "null";
		selectFiltroMunicipio = "null";
	}
	
	public void cargaFiltroRegion() {
		filtroRegion = new ArrayList<>();
		for (FiltroSitioDto filtro : filtros) {
			if (!filtroRegion.contains(filtro.getRegion())) {
				filtroRegion.add(filtro.getRegion());
			}
		}
		
	}

	public void cargaFiltroEstado() {
		FacesContext context = FacesContext.getCurrentInstance();
		try {
			filtroEstado = new ArrayList<>();
			filtroMunicipio = new ArrayList<>();
			filtroEstado = gestionObraCivilServiceImpl.getListaEstado(selectFiltroRegion);
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al cargar el combo de estados");
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","Ocurri� un error al cargar el combo de estados"));
		}	
	}
	
	public void cargaFiltroMunicipio() {
		FacesContext context = FacesContext.getCurrentInstance();
		try {
			filtroMunicipio = new ArrayList<>();
			filtroMunicipio = gestionObraCivilServiceImpl.getListaMunicipio(selectFiltroRegion, selectFiltroEstado);
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al cargar el combo de municipios");
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","Ocurri� un error al cargar el combo de municipios"));
		}
		
	}
	
	public void consultaObras(){
		FacesContext context = FacesContext.getCurrentInstance();
		String mensaje = validaFiltros();
		if(mensaje.isEmpty()){
			FiltroSitioDto filtro = new FiltroSitioDto();
			filtro.setRegion(selectFiltroRegion);
			filtro.setEstado(selectFiltroEstado);
			filtro.setMunicipio(selectFiltroMunicipio);
			listaObra = gestionObraCivilServiceImpl.getListaObraCivil(filtro);
			listaObraFilter = getMapper().mapAsList(listaObra, ObraCivilVo.class);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('tblObra').clearFilters();");
		} else {
			context.addMessage("mensajes", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error de validaci�n!", mensaje)); 
		}
	}

	private String validaFiltros() {
		String mensaje = "";
		if(selectFiltroRegion.equals("null") 
				&& selectFiltroEstado.equals("null") 
					&& selectFiltroMunicipio.equals("null")){
			mensaje = "Se debe seleccionar al menos un filtro para la B�squeda";
		}
		return mensaje;
	}
	
	public void getReporte() {
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Reporte Nueva Obra Civil");
        obraCivilService.toExcel(workbook,this.listaObraFilter);
		FacesContext facesContext = FacesContext.getCurrentInstance();
	    ExternalContext externalContext = facesContext.getExternalContext();
	    externalContext.setResponseContentType("application/vnd.ms-excel");
	    externalContext.setResponseHeader("Content-Disposition", "attachment; filename=\"Reporte SEG Nueva Obra Civil " + fechaReporte()+" v01.xlsx\"");
 
	    try {
			workbook.write(externalContext.getResponseOutputStream());
		} catch (IOException e) {
			LOGGER.error("Error al generar el archivo: " + e);
		}
	    facesContext.responseComplete();
	}
	
	public static String fechaReporte(){
		return new SimpleDateFormat(Constants.FORMATOREPORTE, Locale.ENGLISH).format(new Date()).toString();
	}

	public boolean getVisible(String nombreComponente) {
		boolean visible = false;
		for (ElementosPantallaDTO elemento : listaElementosPantalla) {
			if (elemento.getIdElemento().equals(nombreComponente)) {
				visible = elemento.isVisible();
			}
		}
		return visible;
	}
	
	/**
	 * @return the filtros
	 */
	public List<FiltroSitioDto> getFiltros() {
		return filtros;
	}

	/**
	 * @param filtros the filtros to set
	 */
	public void setFiltros(List<FiltroSitioDto> filtros) {
		this.filtros = filtros;
	}

	/**
	 * @return the filtroRegion
	 */
	public List<String> getFiltroRegion() {
		return filtroRegion;
	}

	/**
	 * @param filtroRegion the filtroRegion to set
	 */
	public void setFiltroRegion(List<String> filtroRegion) {
		this.filtroRegion = filtroRegion;
	}

	/**
	 * @return the filtroEstado
	 */
	public List<EstadoDto> getFiltroEstado() {
		return filtroEstado;
	}

	/**
	 * @param filtroEstado the filtroEstado to set
	 */
	public void setFiltroEstado(List<EstadoDto> filtroEstado) {
		this.filtroEstado = filtroEstado;
	}

	/**
	 * @return the filtroMunicipio
	 */
	public List<MunicipioDto> getFiltroMunicipio() {
		return filtroMunicipio;
	}

	/**
	 * @param filtroMunicipio the filtroMunicipio to set
	 */
	public void setFiltroMunicipio(List<MunicipioDto> filtroMunicipio) {
		this.filtroMunicipio = filtroMunicipio;
	}

	/**
	 * @return the selectFiltroRegion
	 */
	public String getSelectFiltroRegion() {
		return selectFiltroRegion;
	}

	/**
	 * @param selectFiltroRegion the selectFiltroRegion to set
	 */
	public void setSelectFiltroRegion(String selectFiltroRegion) {
		this.selectFiltroRegion = selectFiltroRegion;
	}

	/**
	 * @return the selectFiltroEstado
	 */
	public String getSelectFiltroEstado() {
		return selectFiltroEstado;
	}

	/**
	 * @param selectFiltroEstado the selectFiltroEstado to set
	 */
	public void setSelectFiltroEstado(String selectFiltroEstado) {
		this.selectFiltroEstado = selectFiltroEstado;
	}

	/**
	 * @return the selectFiltroMunicipio
	 */
	public String getSelectFiltroMunicipio() {
		return selectFiltroMunicipio;
	}

	/**
	 * @param selectFiltroMunicipio the selectFiltroMunicipio to set
	 */
	public void setSelectFiltroMunicipio(String selectFiltroMunicipio) {
		this.selectFiltroMunicipio = selectFiltroMunicipio;
	}

	/**
	 * @return the archivoDescarga
	 */
	public DefaultStreamedContent getArchivoDescarga() {
		return archivoDescarga;
	}
	
	/**
	 * @param archivoDescarga the archivoDescarga to set
	 */
	public void setArchivoDescarga(DefaultStreamedContent archivoDescarga) {
		this.archivoDescarga = archivoDescarga;
	}

	/**
	 * @return the listaObra
	 */
	public List<ObraCivilDto> getListaObra() {
		return listaObra;
	}

	/**
	 * @param listaObra the listaObra to set
	 */
	public void setListaObra(List<ObraCivilDto> listaObra) {
		this.listaObra = listaObra;
	}

	/**
	 * @return the listaObraFilter
	 */
	public List<ObraCivilVo> getListaObraFilter() {
		return listaObraFilter;
	}

	/**
	 * @param listaObraFilter the listaObraFilter to set
	 */
	public void setListaObraFilter(List<ObraCivilVo> listaObraFilter) {
		this.listaObraFilter = listaObraFilter;
	}
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.exception;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.webflow.engine.ActionList;
import org.springframework.webflow.engine.FlowExecutionExceptionHandler;
import org.springframework.webflow.engine.RequestControlContext;
import org.springframework.webflow.engine.Transition;
import org.springframework.webflow.engine.support.DefaultTargetStateResolver;
import org.springframework.webflow.execution.FlowExecutionException;

@Component
public class CustomExceptionHandler implements FlowExecutionExceptionHandler {

	private static final Logger logger = LogManager.getLogger(CustomExceptionHandler.class);
	private String errorTransition = "error";
	private ActionList actionList = new ActionList();

	@Override
	public boolean canHandle(FlowExecutionException exception) {
		return true;
	}

	@Override
	public void handle(FlowExecutionException exception, RequestControlContext context) {
		logger.info("Handling exception mesa: ".concat(exception.getMessage()));
		logger.error(exception.getMessage());
		if (context == null) {
			return;
		}
		
		this.actionList.execute(context);
		
		context.execute(new Transition(new DefaultTargetStateResolver(this.errorTransition)));
		
	}

	/**
	 * @return the errorTransition
	 */
	public String getErrorTransition() {
		return errorTransition;
	}

	/**
	 * @param errorTransition the errorTransition to set
	 */
	public void setErrorTransition(String errorTransition) {
		this.errorTransition = errorTransition;
	}

	/**
	 * @return the actionList
	 */
	public ActionList getActionList() {
		return actionList;
	}

	/**
	 * @param actionList the actionList to set
	 */
	public void setActionList(ActionList actionList) {
		this.actionList = actionList;
	}

	
	
}

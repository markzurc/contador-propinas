package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.visitaTecnica.bean;
import static javax.faces.application.FacesMessage.SEVERITY_ERROR;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;


import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.elementosPantalla.IElementosPantallaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.IColocacionService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum.TipoArchivo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.visitaTecnica.IVisitaTecnicaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ElementosPantallaDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegcHerrVistTecn;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegcPersVistTecn;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegdSoliArch;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3segoVisiTecnSoli;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SoliArchDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SolicitudDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.ValidacionUtil;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.sitios.bean.DetalleSolicitudBean;

@Controller("visitaTecnicaBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class VisitaTecnicaBean {

	private static final Logger LOGGER = LogManager.getLogger(VisitaTecnicaBean.class);

	@Autowired
	private IVisitaTecnicaService visitaService;

	@Autowired
	private IElementosPantallaService elementosPantallaService;

	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;
	
    @Autowired
    private IColocacionService colocacionService;

	@Autowired
	private DetalleSolicitudBean detalleSolicitudBean;

	private T3SegcPersVistTecn personalVisita;

	private T3SegcPersVistTecn personalVisitaOriginal;

	private T3SegcHerrVistTecn herramientaVisita;

	private T3SegcHerrVistTecn herramientaVisitaOriginal;

	private List<T3SegcPersVistTecn> listPersonalVisita;

	private List<T3SegcHerrVistTecn> listHerramientaVisita;

	private List<SoliArchDto> listArchivosAdjuntos;

	private List<UploadedFile> filesArchivoAdjunto;

	private List<ElementosPantallaDTO> elementosPantalla;

	private T3segoVisiTecnSoli visitaTecnica;

	private SolicitudDto solicitudDto;

	private SoliArchDto archivoDTO;

	private UserDetailsVo userDetailsVo;

	private T3segoVisiTecnSoli solicitudVisitaTecnica;

	private List<T3SegcPersVistTecn> listPersonalVisitaEliminado;

	private List<T3SegcHerrVistTecn> listHerramientaVisitaEliminado;

	private List<SoliArchDto> listArchivosEliminadoS;



	private List<String> listaTipoHerramienta;

	private StreamedContent file;

	private boolean edicion;
	
	private boolean  editable;
	
	private String valorTransicion;
	private boolean tabVisitaTecnica;
	private String fechaV;

	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		userDetailsVo = (UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		this.edicion = false;
		limpiarRegistro();
		this.elementosPantalla = new ArrayList<>();
		listaTipoHerramienta = new ArrayList<>();
		this.filesArchivoAdjunto = new ArrayList<>();
		this.listPersonalVisitaEliminado = new ArrayList<>();
		this.listHerramientaVisitaEliminado = new ArrayList<>();
		this.listArchivosEliminadoS = new ArrayList<>();
		this.listPersonalVisita = new ArrayList<>();
		this.listHerramientaVisita = new ArrayList<>();
		this.listArchivosAdjuntos = new ArrayList<>();
		tabVisitaTecnica = false;
		this.fechaV = "";
		
		try {
			if (solicitudDto != null) {

				Integer estadoSolicitud=Integer.parseInt(solicitudDto.getIdEstado());
				
				// Obtener informaci�n relacionada con la visita
			
				this.listPersonalVisita = visitaService.getPersonal(solicitudDto.getFolio(),
						solicitudDto.getGrupoOperador());

				this.listHerramientaVisita = visitaService.getHerramientas(solicitudDto.getFolio(),
						solicitudDto.getGrupoOperador());

				// Obtener archivos asociados

				this.listArchivosAdjuntos = visitaService.getArchivos(solicitudDto.getFolio(),
						TipoArchivo.ARCHIVO_ADJUNTO_VISITA_TECNICA.getSeccion(),
						TipoArchivo.ARCHIVO_ADJUNTO_VISITA_TECNICA.getDescripcion());

				// Validar permisos y obtener elementos permitidos para la pantalla
				HashMap<String, Integer> validar = new HashMap<>();
				validar.put("idEstatusOrden", estadoSolicitud);
				validar.put("idRolUsuario", userDetailsVo.getIdRol());
				String estatus_rol_visita_tecnica = solicitudDto.getIdEstado() + userDetailsVo.getIdRol();
				validar.put("estatus_rol_visita_tecnica", Integer.parseInt(estatus_rol_visita_tecnica));
				elementosPantalla = elementosPantallaService.getElementosPermitidosPantalla("visitaTecnica",
						userDetailsVo.getIdRol(), validar);

				listaTipoHerramienta = visitaService.getTipoHerramientas();
				
				this.editable=permiso("pnlVisitaTecnica", "editable");
				this.solicitudVisitaTecnica = visitaService.getSolicitudVisita(solicitudDto.getFolio());
				int countBitacora = colocacionService.consultaEstadoBitacora(solicitudDto.getFolio(),
						"SOLICITUD DE FACTIBILIDAD AUTORIZADA");
				
				if(solicitudVisitaTecnica != null) {
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
					this.fechaV = solicitudVisitaTecnica.getFechaVisita() != null ? sdf.format(this.solicitudVisitaTecnica.getFechaVisita()) : "";
				}
				
				if(solicitudVisitaTecnica != null || (countBitacora > 0 && userDetailsVo.getIdRol() == 13)) {
					tabVisitaTecnica = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Ocurrio un error al cargar la p�gina visita tecncia");
			context.addMessage("mensajes",
					new FacesMessage(SEVERITY_ERROR, "Error", "Ocurri� un error al cargar la pagina visita tecnica"));
		}
	}

	public void solicitudVisitaTecnica(String valorTransicion, Integer accion) {
	
		try {
			
		// validacion de campos vacios
		if (isListEmpty(this.listPersonalVisita, "Personal") || isListEmpty(this.listHerramientaVisita, "Herramientas")
				|| isListEmpty(this.listArchivosAdjuntos, "Archivos adjuntos")) {
			return;
		}

		ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness
				.getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_ADJUNTOS_VISITA_TECNICA);
		String ruta = configurationUtilsVo.getValor();
		if (ruta == null) {
			detalleSolicitudBean.mensajeError("Visita tecnica ","No se encontr� la ruta para guardar el archivo.");
			return;
		}

		String rutaCompleta = ruta + solicitudDto.getFolio() + "/" + valorTransicion + "/" + "actuales" + "/";
		// Subir archivos adjuntos
		List<T3SegdSoliArch> listArchivos = uploadArchivos(filesArchivoAdjunto, rutaCompleta,
				TipoArchivo.ARCHIVO_ADJUNTO_VISITA_TECNICA.getSeccion(),
				TipoArchivo.ARCHIVO_ADJUNTO_VISITA_TECNICA.getDescripcion());

		T3segoVisiTecnSoli visitaTecnica = new T3segoVisiTecnSoli();
		visitaTecnica.setIdFolio(solicitudDto.getFolio());
		visitaTecnica.setFechaCreacion(new Date());
		visitaTecnica.setUsuarioCreacion(userDetailsVo.getIdUsuario());

		boolean exito = visitaService.solicitarVisitaTecnica(visitaTecnica, valorTransicion, listPersonalVisita,
				listHerramientaVisita, listArchivos, accion, listPersonalVisitaEliminado,
				listHerramientaVisitaEliminado, listArchivosEliminadoS

		);

		if (exito) {
			eliminarArchivoServidor(listArchivosEliminadoS);
			
			String mensaje= "Solicitud visita t�cnica generada.";
			detalleSolicitudBean.insertarBitacora("");
			if (accion.equals(ConfigOvitIdentifierEnum.TipoAccionVisitaTecnica.CORRECCION.getTipoAccion())) {
				mensaje= "Correci�n de visita tecnica realizada. ";
			}
			detalleSolicitudBean.mensajeExito("Visita tecnica", mensaje);
		} else {
			detalleSolicitudBean.mensajeError("Visita tecnica ","Ocurrio un error general en guardar la visita t�cnica.");
		}

		} catch (Exception e) {
			detalleSolicitudBean.mensajeError("Visita tecnica ","Ocurrio un error general en solicitar la visita t�cnica.");
		}
	}

	public boolean getEditable(String nombreComponente) {
		boolean editable = false;
		for (ElementosPantallaDTO elemento : elementosPantalla) {
			if (elemento.getIdElemento().equals(nombreComponente)) {
				editable = elemento.isEditable();
			}
		}

		return editable;
	}

	
	private boolean isListEmpty(Collection<?> list, String name) {
		if (list.isEmpty()) {
			detalleSolicitudBean.mensajeWarning("Solicitud visita t�cnica", "Favor de ingresar  " + name + " para la visita t�cnica." );
			return true;
		}
		return false;
	}

	
	public void aprobarVisitaTecnica(String valorTransicion)  {
		try {
			if (fechaV.equals("")) {
				detalleSolicitudBean.mensajeWarning("Aprobar", "La fecha debe cumplir con el siguiente formato dd/MM/yyyy.");
				return;
			} else {
				if (fechaV.matches("^([0-2][0-9]|3[0-1])(\\/)(0[1-9]|1[0-2])\\2(\\d{4})$")) {
					try {
						String[] fh = fechaV.split("/");
						Integer dia = Integer.parseInt(fh[0]);
						Integer mes = Integer.parseInt(fh[1]);
						Integer anio = Integer.parseInt(fh[2]);
						LocalDate fechaD = LocalDate.of(anio, mes, dia);
					} catch (DateTimeException e) {
						detalleSolicitudBean.mensajeWarning("Aprobar", "La fecha debe cumplir con el siguiente formato dd/MM/yyyy.");
						return;
					}
				} else {
					detalleSolicitudBean.mensajeWarning("Aprobar", "La fecha debe cumplir con el siguiente formato dd/MM/yyyy.");
					return;
				}
			}
			SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy");
			Date fechaVisita = null;
			try {
				fechaVisita = date.parse(fechaV);
			} catch (Exception e) {
				detalleSolicitudBean.mensajeWarning("Aprobar", "La fecha debe cumplir con el siguiente formato dd/MM/yyyy.");
				return;
			}
			
			Date fV = new Date();
			if (fV.after(fechaVisita)) {
				detalleSolicitudBean.mensajeWarning("Aprobar", "La fecha de Visita Tecnica debe ser mayor al dia actual");
				return;
			}
			
			if (ValidacionUtil.isEmpty(this.solicitudVisitaTecnica.getHoraVisita())
					|| this.solicitudVisitaTecnica.getHoraVisita().replace("__:__", "").trim().isEmpty()) {
				detalleSolicitudBean.mensajeWarning("Aprobar", ValidacionUtil.MENSAJE_CAMPO_VACIO+" el campo fecha y hora .");
				return;
			}
			
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			Date parsed =  dateFormat.parse(fechaV);
			this.solicitudVisitaTecnica.setFechaVisita(parsed);
	
			boolean exito = visitaService.avanzarSolicitudVisita(this.solicitudVisitaTecnica, valorTransicion,userDetailsVo.getIdUsuario());
			if (exito) {
				detalleSolicitudBean.insertarBitacora("");
				detalleSolicitudBean.mensajeExito("Aprobaci�n", "Solicitud de visita t�cnica aprobada.");
				
			} else {
				detalleSolicitudBean.mensajeError("Visita tecnica ","Ocurri� un error general en aprobar la visita t�cnica.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			detalleSolicitudBean.mensajeError("Visita tecnica ","error al aprobar visita tecnica");
		}
	}
	
	public void autorizarVisitaTecnica(String valorTransicion) {
		try {
			limpiarAutorizacion();
			this.valorTransicion=valorTransicion;
			RequestContext.getCurrentInstance().execute("PF('dlgAprobarSolicitudVT').show();");
		} catch (Exception e) {
			detalleSolicitudBean.mensajeError("Visita tecnica ","Ocurri� un error  general al arbrir la pantalla  de la solicitud.");
		}
	}

	public void realizarAutorizacionVT() {
		String motivo = this.solicitudVisitaTecnica.getMotivoAprobacion();
		if (ValidacionUtil.isEmpty(motivo)) {
			detalleSolicitudBean.mensajeWarning("Aprobaci�n",
					ValidacionUtil.MENSAJE_CAMPO_VACIO + "el campo autorizaci�n.");
			return;
		}
		if (!ValidacionUtil.validarCaracteres(motivo)) {
			detalleSolicitudBean.mensajeWarning("Aprobaci�n",
					ValidacionUtil.MENSAJE_CARACTER_INVALIDO + "el campo autorizaci�n.");
			return;
		}
		if (!ValidacionUtil.validaLongitud(motivo, 250)) {
			detalleSolicitudBean.mensajeWarning("Aprobaci�n", ValidacionUtil.mensajeLongitudInvalida(250));
			return;
		}
		aprobarVisitaTecnica(this.valorTransicion);
	}
	
	public void limpiarAutorizacion() {
		this.solicitudVisitaTecnica.setMotivoAprobacion("");
	}

	public void rechazarVisitaTecnica(String valorTransicion)  {
		try {
			this.valorTransicion=valorTransicion;
			RequestContext.getCurrentInstance().execute("PF('dialogRechazarSolicitudVisitaTecnica').show();");
		} catch (Exception e) {
			detalleSolicitudBean.mensajeError("Visita tecnica ","Ocurri� un error  general  arbrir la pantalla  de la solicitud.");
		}
	}

	public void realizarRechazoVisitaTecnica()  {
		try {
		 	String motivo = this.solicitudVisitaTecnica.getMotivoRechazo();
		 	if (ValidacionUtil.isEmpty(motivo)) {
		 		detalleSolicitudBean.mensajeWarning( "Rechazar", ValidacionUtil.MENSAJE_CAMPO_VACIO + "el campo rechazo.");
		        return;
		    }

		    if (!ValidacionUtil.validarCaracteres(motivo)) {
		    	detalleSolicitudBean.mensajeWarning( "Rechazar", ValidacionUtil.MENSAJE_CARACTER_INVALIDO + "el campo rechazo.");
		        return;
		    }

		    if (!ValidacionUtil.validaLongitud(motivo, 250)) {
		    	detalleSolicitudBean.mensajeWarning( "Rechazar", ValidacionUtil.mensajeLongitudInvalida(250));
		        return;
		    }
	
			boolean exito = visitaService.avanzarSolicitudVisita(this.solicitudVisitaTecnica, this.valorTransicion,this.userDetailsVo.getIdUsuario());
			if (exito) {
				detalleSolicitudBean.insertarBitacora(this.solicitudVisitaTecnica.getMotivoRechazo());
				detalleSolicitudBean.mensajeExito("Rechazar", "Visita t�cnica rechazada.");
			} else {
				detalleSolicitudBean.mensajeError("Visita tecnica ","Ocurri� un error al rechazar la visita tecncia");
			}
		} catch (Exception e) {
			detalleSolicitudBean.mensajeError("Visita tecnica ","Ocurri� un error al intentar rechazar  la solicitud.");
		}
	}
		
	
	public void guardarPersonalVisita() {
		try {
			// valida los campos personales
			if ( !campoValido(this.personalVisita.getNombre(), "Nombre",50) ||
				 !campoValido(this.personalVisita.getApellidoPaterno(), "Apellido paterno",50) ||
				 !campoValido(this.personalVisita.getApellidoMaterno(), "Apellido materno",50)
				) {
				    return;
				}

			// valida que no se agregen personal repetido
			if (existePersonal(this.personalVisita)) {
				if (edicion==false) {
					detalleSolicitudBean.mensajeWarning("Agregar personal", "El personal ya se encuentra agregado en la visita t�cnica.");
				}
				RequestContext.getCurrentInstance().execute("PF('wvdialogPersonalVisita').hide();");
				limpiarRegistro();
				return;
			}

			// agrega el personal a la lista
			if (edicion) {
				this.personalVisitaOriginal.setNombre(ValidacionUtil.capitalizarPrimeraLetra(personalVisita.getNombre()));
				this.personalVisitaOriginal.setApellidoPaterno(ValidacionUtil.capitalizarPrimeraLetra(personalVisita.getApellidoPaterno()));
				this.personalVisitaOriginal.setApellidoMaterno(ValidacionUtil.capitalizarPrimeraLetra(personalVisita.getApellidoMaterno()));
			} else {
				this.personalVisita.setGrupoOperador(solicitudDto.getGrupoOperador());
				this.personalVisita.setIdFolio(solicitudDto.getFolio());
				
				this.personalVisita.setNombre(ValidacionUtil.capitalizarPrimeraLetra(personalVisita.getNombre()));
				this.personalVisita.setApellidoPaterno(ValidacionUtil.capitalizarPrimeraLetra(personalVisita.getApellidoPaterno()));
				this.personalVisita.setApellidoMaterno( ValidacionUtil.capitalizarPrimeraLetra(personalVisita.getApellidoMaterno()));
				this.listPersonalVisita.add(personalVisita);
			}

			limpiarRegistro();
			RequestContext.getCurrentInstance().execute("PF('wvdialogPersonalVisita').hide();");
		} catch (Exception e) {
		
			detalleSolicitudBean.mensajeError("Visita tecnica ","Ocurri� un error al agregar el personal.");
			e.printStackTrace();

		}
	}



	public boolean existePersonal(T3SegcPersVistTecn personal) {
		for (T3SegcPersVistTecn p : this.listPersonalVisita) {
			String nombre=p.getNombre().replace(" ", "");
			String aPaterno= p.getApellidoPaterno().replace(" ", "");
			String aMaterno=p.getApellidoMaterno().replace(" ", "");
			
			if (nombre.equalsIgnoreCase(personal.getNombre().replace(" ", "")) &&
				aPaterno.equalsIgnoreCase(personal.getApellidoPaterno().replace(" ", ""))&&
				aMaterno.equalsIgnoreCase(personal.getApellidoMaterno().replace(" ", ""))
				) 
			{
				return true;
			}
		}
		return false;

	}

	// setea el personal de la visita tecnica para usar el mismo formulario de
	// registro
	public void prepararEdicionPersonal(T3SegcPersVistTecn personalVisitaEdit) {
		this.personalVisitaOriginal = personalVisitaEdit;
		this.personalVisita = new T3SegcPersVistTecn(personalVisitaEdit);
		this.edicion = true;
	}

	public void prepararEliminarPersonal(T3SegcPersVistTecn personalVisitaEdit) {
		this.personalVisita=personalVisitaEdit;
	}
	
	public void eliminarPersonalVisita() {
		try {
			this.listPersonalVisita.remove(personalVisita);
			if (personalVisita.getIdPersonalVisita()!= null) {
				this.listPersonalVisitaEliminado.add(personalVisita);
			}
			limpiarRegistro();
			
		} catch (Exception e) {
			e.printStackTrace();
			detalleSolicitudBean.mensajeError("Visita tecnica ","Ocurrio un error al eliminar el personal.");
		}
	}

	public void guardarHerramienta() {
		try {

			if (ValidacionUtil.isEmpty(this.herramientaVisita.getTipo())) {
				detalleSolicitudBean.mensajeWarning("Agregar herramienta.", ValidacionUtil.MENSAJE_CAMPO_VACIO+" el campo tipo.");
				return;
			}
			
			if (ValidacionUtil.isEmpty(this.herramientaVisita.getDescripcion())) {
				detalleSolicitudBean.mensajeWarning("Aregar herramienta.", ValidacionUtil.MENSAJE_CAMPO_VACIO+" el campo descripcion.");
				return;
			}
			
			if (!ValidacionUtil.validarCaracteres(this.herramientaVisita.getDescripcion())) {
				detalleSolicitudBean.mensajeWarning("Agregar herramienta.",ValidacionUtil.MENSAJE_CARACTER_INVALIDO +" el campo descripcion.");
				return;
			}

			if (!ValidacionUtil.validaLongitud(this.herramientaVisita.getDescripcion(),250)) {
				detalleSolicitudBean.mensajeWarning("Agregar herramienta.", "Solo se permiten 250 caracteres en: el campo descripcion");
				return;
			}
			// agrega herramienta a la lista
			if (edicion) {
				this.herramientaVisitaOriginal.setTipo(herramientaVisita.getTipo());
				this.herramientaVisitaOriginal.setDescripcion(herramientaVisita.getDescripcion());
			
			} else {
				this.herramientaVisita.setGrupoOperador(solicitudDto.getGrupoOperador());
				this.herramientaVisita.setIdFolio(solicitudDto.getFolio());
				this.listHerramientaVisita.add(herramientaVisita);
			}
			limpiarRegistro();
			RequestContext.getCurrentInstance().execute("PF('wvdialogHerramientaVisita').hide();");

		} catch (Exception e) {
			e.printStackTrace();
			limpiarRegistro();
			detalleSolicitudBean.mensajeError("Visita tecnica ","Ocurri� un error al agregar la herramienta. ");

		}
	}

	// setea la herramienta de la visita tecnica para usar el mismo formulario de
	// registro
	public void prepararEdicionHerramienta(T3SegcHerrVistTecn herramientaVisita) {
		this.herramientaVisitaOriginal = herramientaVisita;
		this.herramientaVisita = new T3SegcHerrVistTecn(herramientaVisita);
		this.edicion = true;
	}

	
	public void prepararEliminarHerramiente(T3SegcHerrVistTecn herramientaVisitat) {
		this.herramientaVisita=herramientaVisitat;
	}
	public void eliminarHerramienta() {
		try {
			this.listHerramientaVisita.remove(herramientaVisita);
			if (herramientaVisita.getIdHerramientaVisitaTecnica() != null) {
				this.listHerramientaVisitaEliminado.add(herramientaVisita);
			}
			this.herramientaVisita = new T3SegcHerrVistTecn();
			limpiarRegistro();
		} catch (Exception e) {
			e.printStackTrace();
			detalleSolicitudBean.mensajeError("Visita tecnica ","Ocurri� un error al eliminar la herramienta.");

		}

	}

	

	// reinicia los objetos de persona y herramientas
	public void limpiarRegistro() {
		this.personalVisita = new T3SegcPersVistTecn();
		this.herramientaVisita = new T3SegcHerrVistTecn();
		this.personalVisitaOriginal = null;
		this.herramientaVisitaOriginal = null;
		this.edicion=false;
	}
	
	public void limpiarMotivoRechazo() {
		this.solicitudVisitaTecnica.setMotivoRechazo("");
	}


	public void uploadArchivo(FileUploadEvent event) {
		try {
			UploadedFile file = event.getFile();
			if(!ValidacionUtil.validaLongitud(file.getFileName(),100)) {
				detalleSolicitudBean.mensajeWarning("Carga de archivo.", "Longitud del nombre del archivo debe ser menor a 100 caracteres.");
				return;
			}
			SoliArchDto archivo = new SoliArchDto();

			archivo.setNombreArch(file.getFileName());

			archivo.setNombreUsu(userDetailsVo.getNombre() + " " + userDetailsVo.getApellidoPaterno() + " "
					+ userDetailsVo.getApellidoMaterno());

			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");
			archivo.setFechaCarga(sdf.format(new Date()));

			archivo.setTamanio(file.getSize() / 1024 + " kb");
			if (existeArchivoPorNombre(filesArchivoAdjunto, file.getFileName())) {
					return;
			}
			
			archivo.setIdSeccion(TipoArchivo.ARCHIVO_ADJUNTO_VISITA_TECNICA.getSeccion());
			archivo.setDescripcion(TipoArchivo.ARCHIVO_ADJUNTO_VISITA_TECNICA.getDescripcion());
			this.listArchivosAdjuntos.add(archivo);
			this.filesArchivoAdjunto.add(file);
			
		} catch (Exception e) {
			e.printStackTrace();
			detalleSolicitudBean.mensajeError("Visita tecnica ","Ocurri� un error en upload del archv�");

		}
	}

	public void prepararEliminarArchivo(SoliArchDto archivo) {
		this.archivoDTO = new SoliArchDto();
		this.archivoDTO = archivo;
	}

	public void eliminarArchivo() {
		if (this.archivoDTO.getIdSeccion()
				.equals(ConfigOvitIdentifierEnum.TipoArchivo.ARCHIVO_ADJUNTO_VISITA_TECNICA.getSeccion())) {
			this.listArchivosAdjuntos.remove(archivoDTO);
			this.eliminarArchivoPorNombre(this.filesArchivoAdjunto, archivoDTO.getNombreArch());

		}

		if (archivoDTO.getIdArchivo() != null) {
			listArchivosEliminadoS.add(archivoDTO);
		}

	}

	public List<T3SegdSoliArch> uploadArchivos(List<UploadedFile> files, String rutaDestino, Integer seccion,
			String descripcion) {

		List<T3SegdSoliArch> archivosAgregados = new ArrayList<T3SegdSoliArch>();
		try {

			for (UploadedFile file : files) {
				String nombreArchivo = file.getFileName();
				File fileDestino = new File(rutaDestino + nombreArchivo);
				fileDestino.getParentFile().mkdirs();
				try (InputStream input = file.getInputstream();
						OutputStream output = new FileOutputStream(fileDestino)) {
					byte[] buffer = new byte[1024];
					int bytesRead;
					while ((bytesRead = input.read(buffer)) != -1) {
						output.write(buffer, 0, bytesRead);
					}
				}
				T3SegdSoliArch archivo = new T3SegdSoliArch();
				archivo.setIdFolio(solicitudDto.getFolio());
				archivo.setDescripcion(descripcion);
				archivo.setIdSeccion(seccion);
				archivo.setNombreArchivo(nombreArchivo);
				archivo.setRuta(rutaDestino);
				archivo.setRevision("1");
				archivo.setFechaCarga(new Date());
				archivo.setTamanio(file.getSize() / 1024 + " kb");
				archivo.setUsuario(userDetailsVo.getIdUsuario());
				archivosAgregados.add(archivo);

			}
			return archivosAgregados;

		} catch (Exception e) {
			e.printStackTrace();
			detalleSolicitudBean.mensajeError("Visita tecnica ","Ocurri� un error al subir los archivos en el servidor.");

			return new ArrayList<T3SegdSoliArch>();

		}

	}

	public void prepararDescarga(SoliArchDto archivo) {
		try {
			InputStream inputStream;
			String nombreArchivo;

			if (archivo.getIdArchivo() == null) {
				UploadedFile fileEncontrado = buscarArchivo(archivo.getIdSeccion(), archivo.getNombreArch());
				if (fileEncontrado != null) {
					inputStream = fileEncontrado.getInputstream();
					nombreArchivo = fileEncontrado.getFileName();
				} else {
					detalleSolicitudBean.mensajeError("Visita tecnica ","No se encontr� el archivo cargado.");
					file = null;
					return;
				}
			} else {
				File fileReal = new File(archivo.getRuta() + archivo.getNombreArch());
				if (!fileReal.exists()) {
					detalleSolicitudBean.mensajeError("Visita tecnica ","No se encontr� la ruta del archivo.");
					file = null;
					return;
				}
				inputStream = new FileInputStream(fileReal);
				nombreArchivo = fileReal.getName();
			}

			file = new DefaultStreamedContent(inputStream, "application/octet-stream", nombreArchivo);
			RequestContext.getCurrentInstance().execute("PF('wvmodalDescarga').show();");
		} catch (Exception e) {
			e.printStackTrace();
			file = null;
			detalleSolicitudBean.mensajeError("Visita tecnica ","Ocurri� un error al preparar la descarga del archivo.");
		}
	}

	public void eliminarArchivoServidor(List<SoliArchDto> listArchivos) {
		try {
			for (SoliArchDto archivo : listArchivos) {
				File fileDestino = new File(archivo.getRuta() + archivo.getNombreArch());
				if (fileDestino.exists()) {
					fileDestino.delete();
				}
			}

		} catch (Exception e) {
			detalleSolicitudBean.mensajeError("Visita tecnica ","Ocurri� un error al eliminar el archivo del servidor.");
			e.printStackTrace();
		}

	}

	public boolean permiso(String nombreComponente, String permiso) {

		for (ElementosPantallaDTO elemento : this.elementosPantalla) {
			if (elemento.getIdElemento().equals(nombreComponente)) {
				switch (permiso) {
				case "visible":
					return elemento.isVisible();
				case "editable":
					return elemento.isEditable();
				}
			}
		}
		return false;
	}

	

	
	
	
	public boolean existeArchivoPorNombre(List<UploadedFile> lista, String nombreArchivo) {
		for (UploadedFile archivo : lista) {
			if (archivo.getFileName().equals(nombreArchivo)) {
			 String mensaje = "El archivo " + nombreArchivo + " ya fue agregado.";
				String header = "Archivo existente.";
				detalleSolicitudBean.mensajeWarning(header, mensaje);
				return true;
			}
		}
		return false;
	}

	
	public UploadedFile buscarArchivo(Integer seccion, String nombreArchivo) {
		List<UploadedFile> archivos = null;
		UploadedFile archivo = null;

		if (seccion.equals(TipoArchivo.ARCHIVO_ADJUNTO_VISITA_TECNICA.getSeccion())) {
			archivos = this.filesArchivoAdjunto;
		}

		for (UploadedFile a : archivos) {
			if (a.getFileName().equals(nombreArchivo)) {
				archivo = a;
				break;
			}
		}
		return archivo;
	}

	
	public void eliminarArchivoPorNombre(List<UploadedFile> lista, String nombreArchivo) {
		Iterator<UploadedFile> iterator = lista.iterator();
		while (iterator.hasNext()) {
			UploadedFile archivo = iterator.next();
			if (archivo.getFileName().equals(nombreArchivo)) {
				iterator.remove(); // Elimina el archivo de la lista
				break; // Elimina solo el primero que coincide
			}
		}
	}

	private boolean  campoValido(String value, String nombreCampo,int longitud) {
		if (ValidacionUtil.isEmpty(value)) {
			detalleSolicitudBean.mensajeWarning("Agregar personal", ValidacionUtil.MENSAJE_CAMPO_VACIO + " el campo " +nombreCampo + ".");
			return false;
		}
		
		if (!ValidacionUtil.validarSoloLetras(value)){
			detalleSolicitudBean.mensajeWarning("Agregar personal", "Solo se permiten letras en  el registro del personal.");
			return false;
		}
		
		if (!ValidacionUtil.validaLongitud(value, longitud)){
			detalleSolicitudBean.mensajeWarning("Agregar personal", "Solo se permiten "+ longitud+" caracteres en: el campo "+longitud );
			return false;
		}
		return true;
	}

	
	public List<T3SegcPersVistTecn> getListPersonalVisita() {
		return listPersonalVisita;
	}

	public void setListPersonalVisita(List<T3SegcPersVistTecn> listPersonalVisita) {
		this.listPersonalVisita = listPersonalVisita;
	}

	public T3SegcPersVistTecn getPersonalVisita() {
		return personalVisita;
	}

	public void setPersonalVisita(T3SegcPersVistTecn personalVisita) {
		this.personalVisita = personalVisita;
	}

	public SolicitudDto getSolicitudDto() {
		return solicitudDto;
	}

	public void setSolicitudDto(SolicitudDto solicitudDto) {
		this.solicitudDto = solicitudDto;
	}

	public IVisitaTecnicaService getVisitaService() {
		return visitaService;
	}

	public void setVisitaService(IVisitaTecnicaService visitaService) {
		this.visitaService = visitaService;
	}

	public T3SegcHerrVistTecn getHerramientaVisita() {
		return herramientaVisita;
	}

	public void setHerramientaVisita(T3SegcHerrVistTecn herramientaVisita) {
		this.herramientaVisita = herramientaVisita;
	}

	public List<T3SegcHerrVistTecn> getListHerramientaVisita() {
		return listHerramientaVisita;
	}

	public void setListHerramientaVisita(List<T3SegcHerrVistTecn> listHerramientaVisita) {
		this.listHerramientaVisita = listHerramientaVisita;
	}

	public UserDetailsVo getUserDetailsVo() {
		return userDetailsVo;
	}

	public void setUserDetailsVo(UserDetailsVo userDetailsVo) {
		this.userDetailsVo = userDetailsVo;
	}

	public List<SoliArchDto> getListArchivosAdjuntos() {
		return listArchivosAdjuntos;
	}

	public void setListArchivosAdjuntos(List<SoliArchDto> listArchivosAdjuntos) {
		this.listArchivosAdjuntos = listArchivosAdjuntos;
	}

	public SoliArchDto getArchivoDTO() {
		return archivoDTO;
	}

	public void setArchivoDTO(SoliArchDto archivoDTO) {
		this.archivoDTO = archivoDTO;
	}

	public T3segoVisiTecnSoli getVisitaTecnica() {
		return visitaTecnica;
	}

	public void setVisitaTecnica(T3segoVisiTecnSoli visitaTecnica) {
		this.visitaTecnica = visitaTecnica;
	}

	
	public T3segoVisiTecnSoli getSolicitudVisitaTecnica() {
		return solicitudVisitaTecnica;
	}

	public void setSolicitudVisitaTecnica(T3segoVisiTecnSoli solicitudVisitaTecnica) {
		this.solicitudVisitaTecnica = solicitudVisitaTecnica;
	}



	public List<UploadedFile> getFilesArchivoAdjunto() {
		return filesArchivoAdjunto;
	}

	public void setFilesArchivoAdjunto(List<UploadedFile> filesArchivoAdjunto) {
		this.filesArchivoAdjunto = filesArchivoAdjunto;
	}

	public List<String> getListaTipoHerramienta() {
		return listaTipoHerramienta;
	}

	public void setListaTipoHerramienta(List<String> listaTipoHerramienta) {
		this.listaTipoHerramienta = listaTipoHerramienta;
	}

	public StreamedContent getFile() {
		return file;
	}

	public void setFile(StreamedContent file) {
		this.file = file;
	}

	public boolean getEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}

	public boolean isTabVisitaTecnica() {
		return tabVisitaTecnica;
	}

	public void setTabVisitaTecnica(boolean tabVisitaTecnica) {
		this.tabVisitaTecnica = tabVisitaTecnica;
	}

	public String getFechaV() {
		return fechaV;
	}

	public void setFechaV(String fechaV) {
		this.fechaV = fechaV;
	}
	
}

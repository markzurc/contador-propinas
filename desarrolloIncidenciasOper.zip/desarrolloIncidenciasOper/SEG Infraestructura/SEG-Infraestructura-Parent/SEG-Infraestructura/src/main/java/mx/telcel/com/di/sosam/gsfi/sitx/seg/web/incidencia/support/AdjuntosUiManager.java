package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.incidencia.support;

import java.io.Serializable;
import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.IIncidenciaService.AdjuntoUi;

public class AdjuntosUiManager implements Serializable {

	private static final long serialVersionUID = 1L;

	public UploadOutcome validarYCrearAdjunto(String nombreArchivo,
			long sizeBytes,
			byte[] contenido,
			List<AdjuntoUi> adjuntosActuales,
			long maxTotalBytes) {

		if (nombreArchivo == null || nombreArchivo.trim().isEmpty()) {
			return UploadOutcome.error("Archivo inv�lido", "No se recibi� el archivo.");
		}

		String nombre = nombreArchivo.trim();
		String nombreLower = nombre.toLowerCase();

		// Regla actual: s�lo PDF por extensi�n
		if (!nombreLower.endsWith(".pdf")) {
			return UploadOutcome.error("Validaci�n de archivo", "Solo se permiten archivos PDF.");
		}

		if (sizeBytes <= 0L) {
			return UploadOutcome.error("Validaci�n de archivo", "Archivo vac�o o inv�lido.");
		}

		// Regla actual: si un archivo individual excede el total permitido, se rechaza
		if (sizeBytes > maxTotalBytes) {
			return UploadOutcome.error("Validaci�n de archivo",
					"El archivo excede el tama�o m�ximo permitido (10 MB).");
		}

		// Regla actual: duplicado = mismo nombre y mismo tama�o => OK silencioso (no se agrega)
		if (esDuplicado(nombre, sizeBytes, adjuntosActuales)) {
			return UploadOutcome.okSinAgregar();
		}

		long totalActual = sumarBytes(adjuntosActuales);
		long totalNuevo = totalActual + sizeBytes;

		// Regla actual: l�mite acumulado
		if (totalNuevo > maxTotalBytes) {
			long disponible = maxTotalBytes - totalActual;

			String msg = "El tama�o total permitido es 10 MB. Disponible: "
					+ bytesToMbStr(disponible) + " MB. Archivo: "
					+ bytesToMbStr(sizeBytes) + " MB.";

			return UploadOutcome.error("L�mite total de evidencias", msg);
		}

		try {
			AdjuntoUi adjunto = new AdjuntoUi(nombre, sizeBytes, contenido);
			return UploadOutcome.okConAdjunto(adjunto);
		} catch (Exception ex) {
			return UploadOutcome.error("Error", "No fue posible procesar el archivo.");
		}
	}

	public void removerAdjunto(AdjuntoUi adjunto, List<AdjuntoUi> adjuntosActuales) {
		if (adjunto == null || adjuntosActuales == null) {
			return;
		}
		adjuntosActuales.remove(adjunto);
	}

	public long sumarBytes(List<AdjuntoUi> adjuntosActuales) {
		long total = 0L;
		if (adjuntosActuales == null) {
			return 0L;
		}
		for (AdjuntoUi adj : adjuntosActuales) {
			if (adj != null) {
				total += adj.getTamanio();
			}
		}
		return total;
	}

	public String bytesToMbStr(long bytes) {
		double mb = bytes / (1024d * 1024d);
		double red = Math.round(mb * 100.0) / 100.0;
		return String.valueOf(red);
	}

	private boolean esDuplicado(String nombre, long sizeBytes, List<AdjuntoUi> adjuntosActuales) {
		if (adjuntosActuales == null || adjuntosActuales.isEmpty()) {
			return false;
		}
		for (AdjuntoUi yaSubido : adjuntosActuales) {
			if (yaSubido == null) {
				continue;
			}
			if (nombre.equals(yaSubido.getNombre()) && sizeBytes == yaSubido.getTamanio()) {
				return true;
			}
		}
		return false;
	}

	public static class UploadOutcome implements Serializable {

		private static final long serialVersionUID = 1L;

		private final boolean ok;
		private final AdjuntoUi adjunto;
		private final String title;
		private final String message;

		private UploadOutcome(boolean ok, AdjuntoUi adjunto, String title, String message) {
			this.ok = ok;
			this.adjunto = adjunto;
			this.title = title;
			this.message = message;
		}

		public static UploadOutcome okConAdjunto(AdjuntoUi adjunto) {
			return new UploadOutcome(true, adjunto, null, null);
		}

		public static UploadOutcome okSinAgregar() {
			return new UploadOutcome(true, null, null, null);
		}

		public static UploadOutcome error(String title, String message) {
			return new UploadOutcome(false, null, title, message);
		}

		public boolean isOk() {
			return ok;
		}

		public AdjuntoUi getAdjunto() {
			return adjunto;
		}

		public String getTitle() {
			return title;
		}

		public String getMessage() {
			return message;
		}
	}
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util;


import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.FORMATOREPORTE;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.FORMATYY;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.APROBADO_POR;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.DOCUMENT_NAME;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.FECHA;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.FORMATOREPORTE;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.FORMATYY;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.PREAPARADO_POR;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.TITULO;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.VERSION;
 
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

 
import java.io.IOException;
import java.io.InputStream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFShape;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFSimpleShape;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.service.error.ErrorService;

public class ReporteSegUtil {
	
	private static final String LABEL_PREPARADO= "Preparado por";
	private static final String LABEL_DOCUMENTO= "Documento";
	private static final String LABEL_APROBADO= "Aprobado por";
	private static final String LABEL_FECHA= "Fecha";
	private static final String LABEL_VERSION= "Versi�n";
 
	private static final String DATE_FORMAT_PLANTILLA="yyyy/MM/dd";
	private static final String PATH_PLANTILLA="/PlantillasITxv02.xlsx";
	private static final Logger LOGGER = LogManager.getLogger(ErrorService.class);
 
	
	public static XSSFWorkbook  cargaPlantilla(String preparadoPor,String documento,String aprobadoPor,Date fecha,
			String Titulo,String version){
		InputStream fis = ReporteOvitUtil.class.getResourceAsStream(PATH_PLANTILLA);
		XSSFWorkbook  workbook=null;
		try {
			workbook = (XSSFWorkbook) WorkbookFactory.create(fis);
			 XSSFSheet sheet = workbook.getSheetAt(0);
			 sheet.addMergedRegion(new CellRangeAddress(0,7,0,10));
		   	 XSSFDrawing draw = sheet.createDrawingPatriarch();
			 List<XSSFShape> shapes = draw.getShapes();
			 Iterator<XSSFShape> it = shapes.iterator();
 
				while(it.hasNext()) {           
				    XSSFShape shape = it.next();
				    if (shape instanceof XSSFSimpleShape){
				    	XSSFSimpleShape textbox = (XSSFSimpleShape) shape;
				        if(!textbox.getCTShape().xmlText().isEmpty()){
				        	 if(textbox.getCTShape().xmlText().contains(PREAPARADO_POR)){
				        	    textbox.setText( replaceText(LABEL_PREPARADO,preparadoPor,workbook));
				        	   }
				        	 if(textbox.getCTShape().xmlText().contains(DOCUMENT_NAME)){
					        	    textbox.setText( replaceText(LABEL_DOCUMENTO,documento,workbook));
					        	   }
				        	 if(textbox.getCTShape().xmlText().contains(APROBADO_POR)){
					        	    textbox.setText( replaceText(LABEL_APROBADO,aprobadoPor,workbook));
					        	   }
				        	 if(textbox.getCTShape().xmlText().contains(FECHA)){
					        	    textbox.setText( replaceText(LABEL_FECHA,new SimpleDateFormat(DATE_FORMAT_PLANTILLA).format(fecha),workbook));
					        	   }
				        	 if(textbox.getCTShape().xmlText().contains(VERSION)){
					        	    textbox.setText( replaceText(LABEL_VERSION,version,workbook));
					        	   }
				        	 if(textbox.getCTShape().xmlText().contains(TITULO)){
					        	    textbox.setText( replaceText(Titulo,"",workbook));
					        	   }
				        }
				    }
				}
		} catch (InvalidFormatException e) {
			LOGGER.error("Error en formato " + e);
		} catch (IOException e) {
			LOGGER.error("Error al generar el archivo excel " + e);
		}
		return workbook;
	}

	private static XSSFRichTextString replaceText(String label, String nuevoValor, XSSFWorkbook  workbook){
		XSSFRichTextString richText = new XSSFRichTextString("");
		richText.applyFont(Constants.getFontReportes(workbook) );
		richText.append(label+" \n",Constants.getFontReportesBold(workbook));
		richText.append(nuevoValor,Constants.getFontReportes(workbook));
	    return richText;
	}

	public static String fechaReporte(){
		return new SimpleDateFormat(FORMATOREPORTE,Locale.ENGLISH).format(new Date()).toString();
	}
	public static String fechaYY(){
		return new SimpleDateFormat(FORMATYY,Locale.ENGLISH).format(new Date()).toString();
	}

}

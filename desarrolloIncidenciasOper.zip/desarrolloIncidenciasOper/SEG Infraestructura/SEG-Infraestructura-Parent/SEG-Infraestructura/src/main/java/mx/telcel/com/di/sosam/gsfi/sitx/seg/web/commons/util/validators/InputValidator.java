package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.validators;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

@FacesValidator("inputCommonValidator")
public class InputValidator implements Validator {

	private static final  String MSG_ERROR_VACIO="El campo $label$ es requerido";
	private static final  String MSG_ERROR_ALPHA="El campo $label$ no debe contener caracteres especiales.";
	static final String LABEL="label";
	static final String REQUIRED="required";
	static final String ER="ER";
	static final String MESSAGE="message";
	private String er;
	private String message;
	
	private static final String ALPHA_PATTERN = "^[_A-Za-z0-9������.,\\s]+";
	private String currentER="";
	private String cuurentMSJ="";
	
	
	@Override
	public void validate(FacesContext arg0, UIComponent arg1, Object arg2)
			throws ValidatorException {
		
		 er = (String) arg1.getAttributes().get(ER);
		 message= (String) arg1.getAttributes().get(MESSAGE);
		
		if(er!= null){
			currentER=er;
			 arg1.getAttributes().remove(ER);
		}else{
			currentER=ALPHA_PATTERN;
		}
		
		if(message!= null){
			cuurentMSJ=message;
			arg1.getAttributes().remove(MESSAGE);
		}else{
			cuurentMSJ=MSG_ERROR_ALPHA;
		}
		
		
		
		String messageError = "";
		String labelComponent="";
		Boolean required=false;
		boolean error = false;
		String value = arg2.toString().trim();
		if(arg1.getAttributes().get(LABEL)!=null){
		 labelComponent = arg1.getAttributes().get(LABEL).toString();
		 }
		
		if(arg1.getAttributes().get(REQUIRED)!=null){
			required = (Boolean) arg1.getAttributes().get(REQUIRED);
			}
		
		if (value.isEmpty() && required) {
			messageError = MSG_ERROR_VACIO.replace("$label$", labelComponent);
			error = true;
		}else if (!value.matches(currentER) && !value.isEmpty()) {
			messageError = cuurentMSJ.replace("$label$", labelComponent);
			error = true;
		}
		
		
		

		if (error) {
			FacesMessage msg = new FacesMessage("Validacion fallida",
					messageError);
			msg.setSeverity(FacesMessage.SEVERITY_ERROR);
			throw new ValidatorException(msg);
		}

	}


	
	
}

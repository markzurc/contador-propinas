package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.solicitud.bean;
import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.elementosPantalla.IElementosPantallaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.solicitudes.ISolicitudesService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ElementosPantallaDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.CInfoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SoliArchDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SolicitudDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.ValidacionUtil;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.sitios.bean.DetalleSolicitudBean;

@Controller("solicitudInformacionBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class SolicitudInformacionBean implements Serializable {
	
	@Autowired
	private IElementosPantallaService elementosPantalla;
	
	@Autowired
	private ISolicitudesService consultaServiciosServiceImpl;
	
	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;
	
	@Autowired
	private DetalleSolicitudBean detalleSolicitudBean;
	
	private static final long serialVersionUID = 1973527406249170172L;
	private static final Logger LOGGER = LogManager.getLogger(SolicitudInformacionBean.class);
	
	private static final String ACCION_SOLICITAR_INFORMACION = "1";
	private static final String ESTADO_SOLICITAR_INFORMACION = "1";
	
	
	private SitioDto parametroSitio; //OBJETO QUE TRAE TODA LA INFO DE LA SOLI
	private String servicioSelect; // TRAE EL VALOR DEL SERVICIO SELECCIONADO (INFORMACION REQUERIDA/FACTI)
    private String tipoInfReqSelec; //RECIBE EL VALOR SELECCIONADO DEL COMBO DE SELECCION PARA LA SOLICITUD 
    private List<String> lstIdInfoSelecc; //LISTA QUE SE CONSTRUYE A PARTIR DE LA SELECCION DEL COMBO DE LOS ARCHIVOS A REQUERIR
    private List<CInfoDto> lstInfReq; //LISTA QUE SETEA LOS REGISTROS PARA LLENAR EL COMBO DE SELECCION DE LOS ARCHIVOS A REQUERIR
    private Map<String, String> mapaServicios;
    private List<SoliArchDto> lstArchFinal;
    private String fromPantalla;
    private String nombreEstadoVista;
    private List<SoliArchDto> lstArchSoli;
    private String cpoInfEntregada;
    private List<String> listaErroresCargaArch;
    File verificaSiExiste ;
    File directorioTemp;
    private List<FileUploadEvent> listaArchCarga;
    private String archivoSeleccionCarga;
    UserDetailsVo userDetailsVo;
	private String headerDialogo;
	private String mensajeDialogo;
	private String banderaIng;
	private List<String> tipoDocumentos;

	private DefaultStreamedContent archivoDescarga;

    
	private List<ElementosPantallaDTO> listElemPantalla;
	Map<String, Integer> map =	new HashMap<String,Integer>();
	SolicitudDto sitioConSolicitud = new SolicitudDto();
	
	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		userDetailsVo = (UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		lstIdInfoSelecc = new ArrayList<>(); //LISTA QUE SE CONSTRUYE A PARTIR DE LA SELECCION DEL COMBO DE LOS ARCHIVOS A REQUERIR
		LOGGER.info("Entro a metodo cargaInicial() del solicitudInformacionBean"); 		
		lstArchFinal = new ArrayList<SoliArchDto>();
		lstArchSoli = new ArrayList<SoliArchDto>();
		listaArchCarga = new ArrayList<>();
		tipoDocumentos = new ArrayList<>();
		try{
			cpoInfEntregada = "";
	        tipoInfReqSelec = null; 
	        directorioTemp = null;
	        verificaSiExiste = null;
			nombreEstadoVista = "solicitudInformacionConsulta";
			lstInfReq = new ArrayList<CInfoDto>(); //LISTA QUE SETEA LOS REGISTROS PARA LLENAR EL COMBO DE SELECCION DE LOS ARCHIVOS A REQUERIR
			lstInfReq = consultaServiciosServiceImpl.getInfoReq();
			for (CInfoDto doc : lstInfReq) {
				tipoDocumentos.add(doc.getDescripcion());
			}
			if (fromPantalla.equals("Crea")) {
				map.put("idEstatusOrden", 0); //Se  le asigna 0 por default, no hay solicitud generada para este sitio
				String estatus_rol_servicio_info =  userDetailsVo.getIdRol() + parametroSitio.getIdEstado() + servicioSelect;
				map.put("estatus_rol_info", Integer.parseInt(estatus_rol_servicio_info));
				map.put("pnlInformacionCons", 1);
			}else if (fromPantalla.equals("Consulta")) {
				sitioConSolicitud = consultaServiciosServiceImpl.getSitioConSolicitudConsulta(parametroSitio);//se consulta para saber el estatus de la solicitud en caso de que exista			
				cpoInfEntregada = consultaServiciosServiceImpl.getInfoConSolicitudConsulta(parametroSitio).getInformacionEntregada();
				lstArchSoli = consultaServiciosServiceImpl.getLstArchSoli(parametroSitio, tipoDocumentos);
				map.put("idEstatusOrden", Integer.valueOf(sitioConSolicitud.getIdEstado()));
				String estatus_rol_info = userDetailsVo.getIdRol() + parametroSitio.getIdEstado();
				map.put("estatus_rol_info", Integer.parseInt(estatus_rol_info));
				
				int existeSolInfo = consultaServiciosServiceImpl.getCountSolicitudInf(parametroSitio.getFolio());
				map.put("pnlInformacionCons", existeSolInfo);
				if (lstArchSoli != null) {
					for (SoliArchDto soliArchDTO : lstArchSoli) {
						lstIdInfoSelecc.add(soliArchDTO.getDescripcion());
						lstArchFinal.add(soliArchDTO);
					}
				}
			}

			map.put("idRolUsuario", userDetailsVo.getIdRol());
			map.put("btnCrearSolicitudInfo", Integer.parseInt(parametroSitio.getIdEstado()));
			map.put("panelInformacionEntregada", Integer.parseInt(userDetailsVo.getIdRol()+parametroSitio.getIdEstado()));
			map.put("panelArchivosAdjuntos", Integer.parseInt(userDetailsVo.getIdRol()+parametroSitio.getIdEstado()));
			listElemPantalla = elementosPantalla.getElementosPermitidosPantalla(nombreEstadoVista, userDetailsVo.getIdRol(), map);
			
			mapaServicios = new HashMap<>();
			for (CInfoDto infoReq : lstInfReq) {
			    mapaServicios.put(infoReq.getIdTipoInfo(), infoReq.getDescripcion());
			}			
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al cargar la p�gina");
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","Ocurri� un error al cargar la p�gina"));
		}
	}
	
	public void generaSolicitud() {
		SolicitudDto generaSoliDto = new SolicitudDto();
		generaSoliDto.setSitio(parametroSitio.getSitio());
		generaSoliDto.setUsuario(userDetailsVo.getIdUsuario().toString());
		try {			
	        switch (Integer.parseInt(servicioSelect)) {
            case 1:
                System.out.println("Genera Solicitud de Informacion");
                generaSoliDto.setEstatus("1");
                break;
            case 2:
                System.out.println("Genera Solicitud de Servicio de factibilidad");
                generaSoliDto.setEstatus("3");
                break;
            default:
                System.out.println("Opci�n no v�lida");
                break;
        }
	        
	        //busca grupo operador por usuario
	        generaSoliDto.setGrupoOperador(consultaServiciosServiceImpl.getGpoOperUsuById(generaSoliDto.getUsuario()));
	        
	        //genera la solicitud
	        generaSoliDto = consultaServiciosServiceImpl.generaSolicitud(generaSoliDto);

	        if (generaSoliDto.getFolio() != null) { //Solicitud generada con exito
		        //genera info solicitud
		        consultaServiciosServiceImpl.generaSolicitudInfo(generaSoliDto);
		        
		        
		        
		        for (String descripcion : lstIdInfoSelecc) {
		        	
		            lstArchFinal.add(new SoliArchDto(null ,null, descripcion, null, null, null,null, null,
		            						1 , generaSoliDto.getFolio(), null));
		        }
		        
		        if (!lstArchFinal.isEmpty()) {
			        consultaServiciosServiceImpl.generaSolicitudArch(lstArchFinal);
				}else {
					headerDialogo = "Creaci�n Solicitud Informaci�n";
			        mensajeDialogo = "Error al procesar la solicitud, falta informacion";
			        org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
				}
			}
	        detalleSolicitudBean.setHeaderDialogo("Solicitud Informaci�n: Crear");
	        detalleSolicitudBean.setMensajeDialogo("Solicitud de Infraestructura generada");
	        //headerDialogo = "Creaci�n Solicitud Informaci�n";
	        //mensajeDialogo = "Solicitud de informaci�n generada con exito.";
	        detalleSolicitudBean.setIdAccionBitacora(ACCION_SOLICITAR_INFORMACION);
			detalleSolicitudBean.setIdEstatusBitacora(ESTADO_SOLICITAR_INFORMACION);
			detalleSolicitudBean.setIdGrupoOperadorBitacora(consultaServiciosServiceImpl.getGpoOperUsuById(userDetailsVo.getIdUsuario().toString()));
			detalleSolicitudBean.setIdSolicitudBitacora(generaSoliDto.getFolio());
	        detalleSolicitudBean.insertarBitacora("");
	        org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli').show();");
		} catch (Exception e) {
			LOGGER.error("Ocurri� un error al generar la solicitud, causa: " + e);
			//headerDialogo = "Creaci�n Solicitud Informaci�n";
			//mensajeDialogo = "Ocurri� un error al generar la solicitud.";
	        detalleSolicitudBean.setHeaderDialogo("Solicitud Informaci�n: Crear");
	        detalleSolicitudBean.setMensajeDialogo("Ocurrio un error al crear la Solicitud de Infraestructura");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	public void prepararArchivoCarga(String	archivoCarga) {
	    this.archivoSeleccionCarga = archivoCarga;
	}
	
	public void cargaArchivos(FileUploadEvent event) {
		SimpleDateFormat dateFormatTime = new SimpleDateFormat("dd/MM/yyyy hh:mm aa");
		String fileName = FilenameUtils.getName(event.getFile().getFileName());
		boolean nombreRepetido = false;
		try {

			ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness
					.getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_INF);
			String rutaBase = String.valueOf(configurationUtilsVo.getValor());
			String ruta = rutaBase + parametroSitio.getFolio() + File.separator
					+ parametroSitio.getIdEstado();
			UploadedFile archivo = event.getFile();
			directorioTemp = new File(ruta);

			for (int i = 0; i < lstArchFinal.size(); i++) {
				if (fileName.equalsIgnoreCase(lstArchFinal.get(i).getNombreArch())) {
					nombreRepetido = true;
					break;
				}
			}

			if (!directorioTemp.exists()) {
				directorioTemp.mkdirs();
			}

			if (!nombreRepetido) {
				for (SoliArchDto archivoCargar : lstArchFinal) {
					if (archivoCargar.getDescripcion() != null
							&& archivoCargar.getDescripcion().equals(archivoSeleccionCarga)) {
						listaArchCarga.add(event);
						archivoCargar.setRuta(ruta);
						archivoCargar.setNombreArch(archivo.getFileName());
						archivoCargar.setTamanio(archivo.getSize()/1024+ " kb");
						archivoCargar.setFechaCarga(dateFormatTime.format(new Date()));
						archivoCargar.setRevision("1");// Implementar una consulta para validar si existe un archivo de
														// este tipo y hacer un selec max para continuar con el numero
														// de revision
						archivoCargar.setUsuario(userDetailsVo.getIdUsuario().toString());
						archivoCargar
								.setNombreUsu(consultaServiciosServiceImpl.getNombreUsu(userDetailsVo.getIdUsuario()));
					}
				}
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgUpload').hide();");
				//headerDialogo = "Carga de Documento";
				//mensajeDialogo = "Se cargo el documento: " + fileName +" de forma exitosa.";
		        detalleSolicitudBean.setHeaderDialogo("Carga de Archivo");
		        detalleSolicitudBean.setMensajeDialogo("Se cargo el archivo: " + fileName +" de forma exitosa");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli2').show();");
			} else {
				//headerDialogo = "Carga de Documento";
				//mensajeDialogo = "No se puede cargar un archivo con el mismo nombre " + fileName;
		        detalleSolicitudBean.setHeaderDialogo("Carga de Archivo");
		        detalleSolicitudBean.setMensajeDialogo("No se puede cargar un archivo con el mismo nombre " + fileName);
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			}

		} catch (Exception e) {
			LOGGER.error("Ocurri� un error al cargar los documentos: " + e);
		}
	}
	
	public void avanzarEstatus(String trancision) {
	    boolean cpoInfCompleto = cpoInfEntregada != null && !cpoInfEntregada.trim().isEmpty();
	    boolean lstArchCompleta = true;
	    boolean updateCorrecto = false;
	    try {

	        for (SoliArchDto soliArchDto : lstArchFinal) {
	            if (soliArchDto.getNombreArch() == null || soliArchDto.getTamanio() == null) {
	                lstArchCompleta = false;
	                break;
	            }
	        }

	        if (!cpoInfCompleto || !lstArchCompleta) {
	            if (cpoInfCompleto && ! ValidacionUtil.validarCaracteres(cpoInfEntregada)) {
	                //mostrarMensaje("No es posible ingresar caracteres especiales en el �rea de Telcel Informaci�n Entregada.");
	        	    //headerDialogo = "Avance Estatus";
	        		//mensajeDialogo = "No es posible ingresar caracteres especiales en el �rea de Telcel Informaci�n Entregada.";
	        		detalleSolicitudBean.setHeaderDialogo("Solicitud Informaci�n");
			        detalleSolicitudBean.setMensajeDialogo("No es posible ingresar caracteres especiales en el �rea de Telcel Informaci�n Entregada");
	        		org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
	            } else {
	                //mostrarMensaje("No es posible avanzar la solicitud debido a que la informaci�n no se ha completado.");
	        	    //headerDialogo = "Avance Estatus";
	                //mensajeDialogo = "No es posible avanzar la solicitud debido a que la informaci�n no se ha completado.";
	                detalleSolicitudBean.setHeaderDialogo("Solicitud Informaci�n");
	                detalleSolicitudBean.setMensajeDialogo("No es posible avanzar la solicitud debido a que la informaci�n no se ha completado");
	        		org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
	            }
	            return;
	        }

	        if (!ValidacionUtil.validarCaracteres(cpoInfEntregada)) {
	        	//headerDialogo = "Avance Estatus";
	            //mensajeDialogo = "No es posible ingresar caracteres especiales en el �rea de Telcel Informaci�n Entregada.";
	            detalleSolicitudBean.setHeaderDialogo("Solicitud Informaci�n");
                detalleSolicitudBean.setMensajeDialogo("No es posible ingresar caracteres especiales en el �rea de Telcel Informaci�n Entregada");
	            org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
	            return;
	        }

	        // Procesamiento cuando todo es v�lido
	        updateCorrecto = consultaServiciosServiceImpl.updateSolicitud(parametroSitio, trancision);
	        updateCorrecto &= consultaServiciosServiceImpl.updateSolicitudInfo(parametroSitio, cpoInfEntregada);

	        for (FileUploadEvent event : listaArchCarga) {
	            String fileName = FilenameUtils.getName(event.getFile().getFileName());
	            String rutaA = directorioTemp.getPath() + File.separator + fileName;
	            verificaSiExiste = new File(rutaA);
	            InputStream inputStream = event.getFile().getInputstream();
	            subirArchivo(inputStream, verificaSiExiste);
	        }

	        updateCorrecto &= consultaServiciosServiceImpl.updateSolicitudArch(lstArchFinal, parametroSitio);
			//headerDialogo = "Avance Estatus";
			//mensajeDialogo = "Se avanz� el estatus de la solicitud con �xito";
			detalleSolicitudBean.setHeaderDialogo("Solicitud Informaci�n");
            detalleSolicitudBean.setMensajeDialogo("Se avanz� el estatus de la solicitud de Infraestructura con �xito");
			detalleSolicitudBean.insertarBitacora("");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli').show();");

	    } catch (Exception e) {
	    	//headerDialogo = "Avance Estatus";
            //mensajeDialogo = "Error al intentar avanzar estatus a la solicitud desde SolicitudInformacionBean";
            detalleSolicitudBean.setHeaderDialogo("Solicitud Informaci�n");
            detalleSolicitudBean.setMensajeDialogo("Error al intentar avanzar el estatus de la solicitud de Infraestructura");
            org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
	    }
	}

	public void verArchivoPrevio(SoliArchDto archivo) {	
		try {
			archivoDescarga = getArchivoFileById(archivo);
		} catch(Exception error){
			LOGGER.error("Ocurri� un error al intentar descargar el archivo: " + error);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvmodalDescargaInfo').hide();");
			detalleSolicitudBean.setHeaderDialogo("Descarga Archivo");
            detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al intentar descargar el archivo seleccionado");
            org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	public DefaultStreamedContent getArchivoFileById(SoliArchDto archivo) {
		ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();		
		File file = new File(archivo.getRuta() + File.separator + archivo.getNombreArch());
		InputStream targetStream = null;
		try {
			byte[] decodedBytes = Files.readAllBytes(file.toPath());
			targetStream = new ByteArrayInputStream(decodedBytes);	
		} catch(Exception e) {
			LOGGER.error("Ocurri� un error al intentar descargar el archivo: " + e);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvmodalDescargaInfo').hide();");
			detalleSolicitudBean.setHeaderDialogo("Descarga Archivo");
            detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al intentar descargar el archivo seleccionado");
            org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
		return new DefaultStreamedContent(targetStream, externalContext.getMimeType(archivo.getNombreArch()),
				archivo.getNombreArch());
	}
	
	public void setLstInfoSelecc() {
		if (tipoInfReqSelec.trim().length() > 0) {
			if (tipoInfReqSelec != null && !lstIdInfoSelecc.contains(tipoInfReqSelec)) {
				lstIdInfoSelecc.add(tipoInfReqSelec);
				tipoInfReqSelec = null;
			} else {
				detalleSolicitudBean.setHeaderDialogo("Selecci�n de Documentos");
	            detalleSolicitudBean.setMensajeDialogo("No es posible agregar la opci�n seleccionada porque ya se encuentra en la solicitud");
	            org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			}
		} else {
			//headerDialogo = "Documentos Informaci�n";
			//mensajeDialogo = "Favor de agregar una opci�n v�lida.";
			detalleSolicitudBean.setHeaderDialogo("Selecci�n de Documentos");
            detalleSolicitudBean.setMensajeDialogo("Favor de agregar una opci�n v�lida");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
		}
	}

    public void eliminarOpcion(String id) {
        lstIdInfoSelecc.remove(id);
    }
	
	public boolean getVisible(String nombreComponente) {
		boolean visible = false;
		for (ElementosPantallaDTO elemento : listElemPantalla) {
			if (elemento.getIdElemento().equals(nombreComponente)) {
				visible = elemento.isVisible();
			}
		}
		return visible;
	}

	public boolean getEditable(String nombreComponente) {
		boolean visible = false;
		for (ElementosPantallaDTO elemento : listElemPantalla) {
			if (elemento.getIdElemento().equals(nombreComponente)) {
				visible = elemento.isEditable();
			}
		}
		return visible;
	}
	
	public static boolean subirArchivo(InputStream origen, File destino) {
		OutputStream out = null;
		try {
			InputStream in = origen;
			out = new FileOutputStream(destino);

			byte[] buf = new byte[1024];
			int len;

			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			in.close();
			out.close();
		} catch (IOException e) {
			return false;

		} finally {
			close(out);
		}
		return true;
	}
	
	private static void close(Closeable closable) {
		try {
			if (closable != null) {
				closable.close();
			}
		} catch (IOException e) {
			System.out.println("Error al cerrar OutputStream ");
		}
	}

	public SitioDto getParametroSitio() {
		return parametroSitio;
	}

	public void setParametroSitio(SitioDto parametroSitio) {
		this.parametroSitio = parametroSitio;
	}
	
	public String getServicioSelect() {
		return servicioSelect;
	}

	public void setServicioSelect(String servicioSelect) {
		this.servicioSelect = servicioSelect;
	}

	public String getTipoInfReqSelec() {
		return tipoInfReqSelec;
	}

	public void setTipoInfReqSelec(String tipoInfReqSelec) {
		this.tipoInfReqSelec = tipoInfReqSelec;
	}

	public List<CInfoDto> getLstInfReq() {
		return lstInfReq;
	}

	public void setLstInfReq(List<CInfoDto> lstInfReq) {
		this.lstInfReq = lstInfReq;
	}

	public List<String> getLstIdInfoSelecc() {
		return lstIdInfoSelecc;
	}

	public void setLstIdInfoSelecc(List<String> lstIdInfoSelecc) {
		this.lstIdInfoSelecc = lstIdInfoSelecc;
	}

	public String getHeaderDialogo() {
		return headerDialogo;
	}

	public void setHeaderDialogo(String headerDialogo) {
		this.headerDialogo = headerDialogo;
	}

	public String getMensajeDialogo() {
		return mensajeDialogo;
	}

	public void setMensajeDialogo(String mensajeDialogo) {
		this.mensajeDialogo = mensajeDialogo;
	}
	
	public String getFromPantalla() {
		return fromPantalla;
	}

	public void setFromPantalla(String fromPantalla) {
		this.fromPantalla = fromPantalla;
	}

	public List<SoliArchDto> getLstArchFinal() {
		return lstArchFinal;
	}

	public void setLstArchFinal(List<SoliArchDto> lstArchFinal) {
		this.lstArchFinal = lstArchFinal;
	}

	public String getCpoInfEntregada() {
		return cpoInfEntregada;
	}

	public void setCpoInfEntregada(String cpoInfEntregada) {
		this.cpoInfEntregada = cpoInfEntregada;
	}

	public List<String> getListaErroresCargaArch() {
		return listaErroresCargaArch;
	}

	public void setListaErroresCargaArch(List<String> listaErroresCargaArch) {
		this.listaErroresCargaArch = listaErroresCargaArch;
	}
	
	public DefaultStreamedContent getArchivoDescarga() {
		return archivoDescarga;
	}

	public void setArchivoDescarga(DefaultStreamedContent archivoDescarga) {
		this.archivoDescarga = archivoDescarga;
	}

	public String getBanderaIng() {
		return banderaIng;
	}

	public void setBanderaIng(String banderaIng) {
		this.banderaIng = banderaIng;
	}	
	
}

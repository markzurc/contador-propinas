package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util;

import java.io.Serializable;
import java.util.Date;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.IBitacoraSoxBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.vo.BitacoraSoxVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;

import java.util.logging.Level;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

@Controller("bitacoraSeguridadUtil")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class BitacoraSeguridadUtil implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8942281629252575597L;
	@Autowired
	@Qualifier("bitacoraSox")
	private IBitacoraSoxBusiness bitacoraSoxBusiness;
	private static final Logger logger = LogManager.getLogger(BitacoraSeguridadUtil.class);
	
	
	public void registraEntradaBitacora(String oldObj, Object newObject, String folio,int operationType){
		UserDetailsVo userDetailsVo =(UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		BitacoraSoxVo bitacoraSoxVo = new BitacoraSoxVo();
		bitacoraSoxVo.setObjetoFinal(bitacoraSoxBusiness.objectToXML(newObject));
		bitacoraSoxVo.setObjetoInicial(oldObj);
		bitacoraSoxVo.setFechaOperacion(new Date());
		bitacoraSoxVo.setFolioSua(folio);
		//IBitacoraSoxBusiness.CREATE
		bitacoraSoxVo.setIdAccion(operationType);
		bitacoraSoxVo.setIdUsuario(userDetailsVo.getIdUsuario());
		bitacoraSoxVo.setNumeroEmpleado(userDetailsVo.getNumeroEmpleado());
		
		try {
			bitacoraSoxBusiness.createBitacoraSox(bitacoraSoxVo);
		} catch (TransactionalOVITException e) {
			logger.error("No se guardo la entrada a la bitacora del obj: "+oldObj+" to: "+newObject, e);
		}
	}
	
	public String getActualStateXML(Object obj){
		return bitacoraSoxBusiness.objectToXML(obj);
		
	}

	public void registraAccionBitacora(String oldObj, String newObj, String folio, int operationType) {
		UserDetailsVo userDetailsVo =(UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		BitacoraSoxVo bitacoraSoxVo = new BitacoraSoxVo();
		bitacoraSoxVo.setObjetoFinal(newObj);
		bitacoraSoxVo.setObjetoInicial(oldObj);
		bitacoraSoxVo.setFechaOperacion(new Date());
		bitacoraSoxVo.setFolioSua(folio);
		bitacoraSoxVo.setIdAccion(operationType);
		bitacoraSoxVo.setIdUsuario(userDetailsVo.getIdUsuario());
		bitacoraSoxVo.setNumeroEmpleado(userDetailsVo.getNumeroEmpleado());
		
		try {
			bitacoraSoxBusiness.createBitacoraSox(bitacoraSoxVo);
		} catch (TransactionalOVITException e) {
			logger.error("No se guardo la entrada a la bitacora del obj: "+oldObj+" to: "+newObj, e);
		}
	}
	
	
}

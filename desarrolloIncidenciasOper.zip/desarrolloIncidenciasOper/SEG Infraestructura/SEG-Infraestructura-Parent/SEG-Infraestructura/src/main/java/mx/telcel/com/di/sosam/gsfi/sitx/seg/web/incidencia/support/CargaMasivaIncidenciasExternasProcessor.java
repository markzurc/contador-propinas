package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.incidencia.support;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.IIncidenciaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;

public class CargaMasivaIncidenciasExternasProcessor {

    private final IIncidenciaService incidenciaService;
    private final IncidenciasExcelExporter excelExporter;

    public CargaMasivaIncidenciasExternasProcessor(IIncidenciaService incidenciaService,
                                                   IncidenciasExcelExporter excelExporter) {
        this.incidenciaService = incidenciaService;
        this.excelExporter = excelExporter;
    }

    public ResultadoCargaMasiva procesar(byte[] excelBytes, Map<String, String> mapaConcesionarios) throws Exception {

        ResultadoCargaMasiva resultado = new ResultadoCargaMasiva();

        DataFormatter formatter = new DataFormatter();

        Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(excelBytes));
        try {
            org.apache.poi.ss.usermodel.Sheet sheet = workbook.getSheet("Incidencias");
            if (sheet == null) {
                sheet = workbook.getSheetAt(0);
            }

            List<?> sitios = incidenciaService.listarSitiosEnOperacionVisibles();
            List<String> tipos = incidenciaService.catalogoTiposIncidencia();

            List<Map<String, String>> errores = new ArrayList<>();
            List<Map<String, String>> capturados = new ArrayList<>();

            int renglonIncidencia = 0;

            for (int r = 1; r <= sheet.getLastRowNum(); r++) {
                org.apache.poi.ss.usermodel.Row row = sheet.getRow(r);
                if (row == null) {
                    continue;
                }

                String idSitio = formatter.formatCellValue(row.getCell(0)).trim();
                String tipo = formatter.formatCellValue(row.getCell(1)).trim();
                String desc = formatter.formatCellValue(row.getCell(2)).trim();
                String nombreRep = formatter.formatCellValue(row.getCell(3)).trim();
                String correo = formatter.formatCellValue(row.getCell(4)).trim();
                String conces = formatter.formatCellValue(row.getCell(5)).trim();
                String estatusExcel = formatter.formatCellValue(row.getCell(6)).trim();

                boolean filaVacia = idSitio.isEmpty() && tipo.isEmpty() && desc.isEmpty() && nombreRep.isEmpty()
                        && correo.isEmpty() && conces.isEmpty() && estatusExcel.isEmpty();

                if (filaVacia) {
                    continue;
                }

                renglonIncidencia++;
                resultado.totalLeidas++;

                Map<String, String> err = new HashMap<>();
                Map<String, String> cap = new HashMap<>();
                cap.put("renglon", String.valueOf(renglonIncidencia));
                cap.put("idSitio", idSitio);
                cap.put("tipo", tipo);
                cap.put("desc", desc);
                cap.put("nombre", nombreRep);
                cap.put("correo", correo);
                cap.put("conces", conces);
                cap.put("estatus", estatusExcel);

                if (idSitio.isEmpty()) {
                    err.put("idSitio", "ID de sitio faltante (campo obligatorio).");
                } else if (!existeSitioEnCatalogo(idSitio, sitios)) {
                    err.put("idSitio", "ID de sitio inexistente en el cat�logo de sitios.");
                }

                if (tipo.isEmpty()) {
                    err.put("tipo", "Tipo de incidencia faltante (campo obligatorio).");
                } else if (!existeTipoEnCatalogo(tipo, tipos)) {
                    err.put("tipo", "Tipo de incidencia inexistente en el cat�logo.");
                }

                if (desc.isEmpty()) {
                    err.put("desc", "Descripci�n detallada faltante (campo obligatorio).");
                }

                if (nombreRep.isEmpty()) {
                    err.put("nombre", "Nombre de quien reporta faltante (campo obligatorio).");
                }

                if (correo.isEmpty()) {
                    err.put("correo", "No se agreg� correo de quien reporta.");
                } else if (!correoValidoBasico(correo)) {
                    err.put("correo", "Correo de quien reporta con formato inv�lido.");
                }

                if (conces.isEmpty()) {
                    err.put("conces", "Concesionario faltante (campo obligatorio).");
                } else if (!existeConcesionarioEnCatalogo(conces, mapaConcesionarios)) {
                    err.put("conces", "Concesionario inexistente en el cat�logo.");
                }

                String estatusCanon = normalizarEstatusExcel(estatusExcel);
                if (estatusExcel.isEmpty()) {
                    err.put("estatus", "Estatus faltante (campo obligatorio).");
                } else if (estatusCanon == null) {
                    err.put("estatus", "Estatus inv�lido. Permitidos: CREADA, EN ATENCI�N, RECHAZADA, FINALIZADA.");
                }

                if (!err.isEmpty()) {
                    errores.add(err);
                    capturados.add(cap);
                    resultado.totalErrores++;
                    continue;
                }

                try {
                    incidenciaService.crearIncidenciaExternaCargaMasiva(
                            idSitio,
                            normalizarTipo(tipo, tipos),
                            desc,
                            nombreRep,
                            correo,
                            conces,
                            estatusCanon
                    );
                    resultado.totalCreadas++;
                } catch (Exception ex) {
                    err.put("desc", "Error al crear incidencia en el sistema: " + ex.getMessage());
                    errores.add(err);
                    capturados.add(cap);
                    resultado.totalErrores++;
                }
            }

            if (resultado.totalErrores > 0) {
                resultado.catalogoErroresBytes = excelExporter.exportarCatalogoErroresCargaMasiva(errores, capturados);
            }

            return resultado;

        } finally {
            try { workbook.close(); } catch (Exception ignore) {}
        }
    }

    private boolean existeSitioEnCatalogo(String idSitio, List<?> sitios) {
        if (sitios == null) {
            return false;
        }
        for (Object o : sitios) {
            if (o instanceof SitioDto) {
                SitioDto s = (SitioDto) o;
                if (s.getSitio() != null && s.getSitio().trim().equalsIgnoreCase(idSitio.trim())) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean existeTipoEnCatalogo(String tipo, List<String> tipos) {
        if (tipos == null) {
            return false;
        }
        for (String t : tipos) {
            if (t != null && t.trim().equalsIgnoreCase(tipo.trim())) {
                return true;
            }
        }
        return false;
    }

    private String normalizarTipo(String tipo, List<String> tipos) {
        if (tipos != null) {
            for (String t : tipos) {
                if (t != null && t.trim().equalsIgnoreCase(tipo.trim())) {
                    return t.trim();
                }
            }
        }
        return tipo.trim();
    }

    private boolean correoValidoBasico(String correo) {
        String c = correo.trim();
        return c.contains("@") && c.indexOf('@') > 0 && c.indexOf('@') < c.length() - 3;
    }

    private boolean existeConcesionarioEnCatalogo(String cap, Map<String, String> mapaConcesionarios) {
        if (mapaConcesionarios == null || mapaConcesionarios.isEmpty()) {
            return true;
        }
        String v = cap.trim();
        if (mapaConcesionarios.containsKey(v)) {
            return true;
        }
        for (String desc : mapaConcesionarios.values()) {
            if (desc != null && desc.trim().equalsIgnoreCase(v)) {
                return true;
            }
        }
        return false;
    }

    private String normalizarEstatusExcel(String s) {
        if (s == null) {
            return null;
        }
        String v = s.trim().toUpperCase();

        if (v.contains("RECHAZ")) {
            return "RECHAZADA";
        }
        if (v.contains("FINAL")) {
            return "FINALIZADA";
        }
        if (v.contains("ATEN")) {
            return "EN ATENCI�N";
        }
        if (v.contains("CREA")) {
            return "CREADA";
        }

        return null;
    }

    public static class ResultadoCargaMasiva {
        private int totalLeidas;
        private int totalCreadas;
        private int totalErrores;
        private byte[] catalogoErroresBytes;

        public int getTotalLeidas() { return totalLeidas; }
        public int getTotalCreadas() { return totalCreadas; }
        public int getTotalErrores() { return totalErrores; }
        public byte[] getCatalogoErroresBytes() { return catalogoErroresBytes; }
    }
}

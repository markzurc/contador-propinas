package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util;


import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.*;

import java.io.Serializable;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ReportUserVo;

public class WrapperReportUserVo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3227064215400146341L;
	private ReportUserVo reportUserVo;
	private boolean renderEdicion;
	private boolean renderDelete;
	private boolean renderLock;
	private boolean renderUnlock;
	private boolean renderResetPass;
	
	
	public WrapperReportUserVo(){
		this.reportUserVo = new ReportUserVo();
	}

	public WrapperReportUserVo(ReportUserVo reportUserVo) {
		this.reportUserVo = reportUserVo;
//		determineRenderActions();
	}


	public ReportUserVo getReportUserVo() {
		return reportUserVo;
	}

	public void setReportUserVo(ReportUserVo reportUserVo) {
		this.reportUserVo = reportUserVo;
	}

	
	
	private void determineRenderActions(){
		if(reportUserVo.getIdEstatus()!=STATUS_BAJA){
		   renderEdicion=true;
			if(reportUserVo.getIdTipoUsuario().equals(USER_EXTENRO_TYPE)){
				renderDelete=true;
				renderResetPass=true;
				if(reportUserVo.getIdEstatus()==STATUS_BLOQUEADO){
					renderUnlock=true;
				}else{
					renderLock=true;
				}
			  }
		}
	}



	public boolean isRenderEdicion() {
		return renderEdicion;
	}




	public void setRenderEdicion(boolean renderEdicion) {
		this.renderEdicion = renderEdicion;
	}




	public boolean isRenderDelete() {
		return renderDelete;
	}




	public void setRenderDelete(boolean renderDelete) {
		this.renderDelete = renderDelete;
	}




	public boolean isRenderLock() {
		return renderLock;
	}




	public void setRenderLock(boolean renderLock) {
		this.renderLock = renderLock;
	}




	public boolean isRenderUnlock() {
		return renderUnlock;
	}




	public void setRenderUnlock(boolean renderUnlock) {
		this.renderUnlock = renderUnlock;
	}




	public boolean isRenderResetPass() {
		return renderResetPass;
	}




	public void setRenderResetPass(boolean renderResetPass) {
		this.renderResetPass = renderResetPass;
	}
	
	
	
}

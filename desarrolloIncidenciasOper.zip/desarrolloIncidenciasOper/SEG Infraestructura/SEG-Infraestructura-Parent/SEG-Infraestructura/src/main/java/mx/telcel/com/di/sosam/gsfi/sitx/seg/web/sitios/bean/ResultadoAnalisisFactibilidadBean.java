package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.sitios.bean;

import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.elementosPantalla.IElementosPantallaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.IFactibilidadService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.solicitudes.IConsultaSolicitudesService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ElementosPantallaDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.FactibilidadDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.ValidacionUtil;



@Controller("resultadoAnalisisFactibilidadBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class ResultadoAnalisisFactibilidadBean implements Serializable {

	private static final long serialVersionUID = -8715496866982916388L;
	private static final Logger LOGGER = LogManager.getLogger(ResultadoAnalisisFactibilidadBean.class.getName());
	private String valor = "";
	
	@Autowired
	private IFactibilidadService factibilidadService;
	
	@Autowired
	private IConsultaSolicitudesService iSolicitudesService;
	
	@Autowired
	private IElementosPantallaService elementosPantalla;
	
	@Autowired
	private DetalleSolicitudBean detalleSolicitudBean;

	private List<FactibilidadDto> factibilidad;
	
	private List<ElementosPantallaDTO> list;
	
	private String seleccionadoTorre;
	private String seleccionadoRecuperacionE;
	private String seleccionadoAdecuacion;
	private String seleccionadoFactibilidadTorre;
	private String seleccionadoEspacioAdicionalPiso;
	private String seleccionadoLicenciasPermisos;
	
	private List<String> listaAvance;
	private List<String> listaTorre;
	private List<String> listaRecuperacionEspacio;
	private List<String> listaRequiereA;
	private List<String> listaFactibilidadTorre;
	private List<String> listaEspacioAdicionalPiso;
	private List<String> listaLicenciasPermisos;
	private List<String> listaErrores;
	
	private String alturaTotalTorre;
	private String idNivelR;
	private String idAreaD;
	private String idObservaciones;
	private String detalleLicenciasPermisos;
	private String idFechaInicio;
	private String idFechaTermino;
	private String idRentaPA;
	private String idRentaPC;
	private String idRentaTO;
	private String idRH;
	private String observaciones2;
	private String seleccionadoFactibilidadE;
	private String seleccionadoLineaS;
	private String idObs;
	private String seleccionadoFactibilidadEA;
	private String seleccionadoFactibilidadEE;
	private String idObs2;
	private String idFactibilidad;
	
	private String headerDialogo;
	private String mensajeDialogo;
	
	private SitioDto parametroSitio;

	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		llenarListas();
		try {
			limpiarCampos();
			
			String nombreEstadoVista = "solicitudFactibilidad";
			UserDetailsVo userDetailsVo =(UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			Map<String, Integer> mapa = new HashMap<String, Integer>();
			if (parametroSitio.getIdEstado()==null) {
				parametroSitio.setIdEstado("0");
			}
			mapa.put("Estados no validos para formulario Resultado Factibilidad", Integer.parseInt(parametroSitio.getIdEstado()));
			list=elementosPantalla.getElementosPermitidosPantalla(nombreEstadoVista, userDetailsVo.getIdRol(), mapa );
			
			if (parametroSitio.getFolio() != null) {
				idFactibilidad = factibilidadService.getFactiPorFolio(parametroSitio.getFolio());
			} else {
				idFactibilidad = null;
			}
			
			if (idFactibilidad !=null) {
				factibilidad = factibilidadService.getFacti(idFactibilidad);
				if (factibilidad.size()>0) {
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
					
					seleccionadoTorre = factibilidad.get(0).getIdTipoTorre();
					if (seleccionadoTorre!=null) {
						String torreD = factibilidadService.getTorrePorId(seleccionadoTorre);
						seleccionadoTorre = seleccionadoTorre + ":" + torreD;
					}
					alturaTotalTorre =(factibilidad.get(0).getAlturaTotal()!=null) ? factibilidad.get(0).getAlturaTotal().toString() : "";
					idNivelR = factibilidad.get(0).getNivelCentroRadiacionDisponible();
					idAreaD = (factibilidad.get(0).getAreaDisponiblePiso()!=null) ? factibilidad.get(0).getAreaDisponiblePiso().toString() : "";
					seleccionadoRecuperacionE = factibilidad.get(0).getRecuperacionEspacio();
					seleccionadoAdecuacion = factibilidad.get(0).getAdecuacion();
					seleccionadoFactibilidadTorre = factibilidad.get(0).getFactibilidadIncrementoTorre();
					seleccionadoEspacioAdicionalPiso = factibilidad.get(0).getEspacioAdicionalPiso();
					idObservaciones = factibilidad.get(0).getObservacionesInfraestructura();
					seleccionadoLicenciasPermisos = factibilidad.get(0).getLicencias();
					detalleLicenciasPermisos = factibilidad.get(0).getDetalleLicencias();
					idFechaInicio = (factibilidad.get(0).getFechaInicio()!=null) ? sdf.format(factibilidad.get(0).getFechaInicio()) : "";
					idFechaTermino = (factibilidad.get(0).getFechaTermino()!=null) ? sdf.format(factibilidad.get(0).getFechaTermino()) : "";
					idRentaPA = factibilidad.get(0).getRentaPisoActualizada();
					idRentaPC = factibilidad.get(0).getRentaPisoConcesionario();
					idRentaTO = factibilidad.get(0).getRentaTorre();
					idRH = factibilidad.get(0).getAcceso();
					observaciones2 = factibilidad.get(0).getObservacionesOcupacion();
					seleccionadoFactibilidadE = factibilidad.get(0).getFactiLineaSuministro();
					seleccionadoLineaS = factibilidad.get(0).getFactiLineaSuministroElectrica();
					idObs = factibilidad.get(0).getObservacionesEnergiaElectrica();
					seleccionadoFactibilidadEA = factibilidad.get(0).getFactiAire();
					seleccionadoFactibilidadEE = factibilidad.get(0).getFactiElementosAuxiliares();
					idObs2 = factibilidad.get(0).getObservacionesOtrosElementos();
				}
			}
				
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al cargar la p�gina");
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","Ocurri� un error al cargar la p�gina"));
		}
	}
	
	public boolean getEditable(String nombreComponente) {
		boolean editable=false;
		for(ElementosPantallaDTO elemento:list) {
			if(elemento.getIdElemento().equals(nombreComponente)) {
				editable=elemento.isEditable();
			}
		}
		
		return editable;
	}
	
	public void limpiarCampos() {
		alturaTotalTorre = "";
		idNivelR = "";
		idAreaD = "";
		idObservaciones = "";
		detalleLicenciasPermisos = "";
		idFechaInicio = "";
		idFechaTermino = "";
		idRentaPA = "";
		idRentaPC = "";
		idRentaTO = "";
		idRH = "";
		seleccionadoFactibilidadE = "";
		seleccionadoLineaS = "Si";
		idObs = "";
		seleccionadoFactibilidadEA = "";
		seleccionadoFactibilidadEE = "";
		idObs2 = "";
		
		seleccionadoTorre = "";
		seleccionadoRecuperacionE = "";
		seleccionadoAdecuacion = "";
		seleccionadoFactibilidadTorre = "";
		seleccionadoEspacioAdicionalPiso = "";
		seleccionadoLicenciasPermisos = "Si";
	}
	
	public void llenarListas() {
		listaAvance = new ArrayList<>();
		listaTorre = new ArrayList<>();
		listaRecuperacionEspacio = new ArrayList<>();
		listaRequiereA = new ArrayList<>();
		listaFactibilidadTorre = new ArrayList<>();
		listaEspacioAdicionalPiso = new ArrayList<>();
		listaLicenciasPermisos = new ArrayList<>();
		
		listaTorre = factibilidadService.getTorres();
		
		listaRecuperacionEspacio.add("Si");
		listaRecuperacionEspacio.add("No");
		
		listaRequiereA.add("Si");
		listaRequiereA.add("No");
		
		listaFactibilidadTorre.add("Si");
		listaFactibilidadTorre.add("No");
		
		listaEspacioAdicionalPiso.add("Si");
		listaEspacioAdicionalPiso.add("No");
		
		listaLicenciasPermisos.add("Si");
		listaLicenciasPermisos.add("No");
		
		listaAvance.add("Aprobar Solicitud");
		listaAvance.add("Factibilidad Negativa");
	}
	
	public boolean getVisible(String nombreComponente) {
		boolean visible=false;
		for(ElementosPantallaDTO elemento:list) {
			if(elemento.getIdElemento().equals(nombreComponente)) {
				visible=elemento.isVisible();
			}
		}
		return visible;
	}
	
	public void valueChanged(ValueChangeEvent event) {
	    System.out.println("prueba" + event.toString());
	}
	
	public void rechazarResulFacti(String trancision) throws ParseException {
		try {
			String[] parts = seleccionadoTorre.split(":");
			String idTorre = ""+parts[0];
			boolean resultado = false;
			boolean sitio = false;
			if (validaciones()) {
				SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
				Date fechaI = formato.parse(idFechaInicio);
				Date fechaT = (idFechaTermino.equals("") ? null : formato.parse(idFechaTermino));
				FactibilidadDto factibilidadDto = new FactibilidadDto();
				factibilidadDto.setIdFactibilidad(Integer.parseInt(idFactibilidad));
				factibilidadDto.setIdTipoTorre(idTorre);
				factibilidadDto.setAlturaTotal(alturaTotalTorre);
				factibilidadDto.setNivelCentroRadiacionDisponible(idNivelR);
				factibilidadDto.setAreaDisponiblePiso(idAreaD);
				factibilidadDto.setRecuperacionEspacio(seleccionadoRecuperacionE);
				factibilidadDto.setAdecuacion(seleccionadoAdecuacion);
				factibilidadDto.setFactibilidadIncrementoTorre(seleccionadoFactibilidadTorre);
				factibilidadDto.setEspacioAdicionalPiso(seleccionadoEspacioAdicionalPiso);
				factibilidadDto.setObservacionesInfraestructura(idObservaciones);
				factibilidadDto.setLicencias(seleccionadoLicenciasPermisos);
				factibilidadDto.setDetalleLicencias(detalleLicenciasPermisos);
				factibilidadDto.setFechaInicio(fechaI);
				factibilidadDto.setFechaTermino(fechaT);
				factibilidadDto.setRentaPisoActualizada(idRentaPA);
				factibilidadDto.setRentaPisoConcesionario(idRentaPC);
				factibilidadDto.setRentaTorre(idRentaTO);
				factibilidadDto.setAcceso(idRH);
				factibilidadDto.setObservacionesOcupacion(observaciones2);
				factibilidadDto.setFactiLineaSuministro(seleccionadoFactibilidadE);
				factibilidadDto.setFactiLineaSuministroElectrica(seleccionadoLineaS);
				factibilidadDto.setObservacionesEnergiaElectrica(idObs);
				factibilidadDto.setFactiAire(seleccionadoFactibilidadEA);
				factibilidadDto.setFactiElementosAuxiliares(seleccionadoFactibilidadEE);
				factibilidadDto.setObservacionesOtrosElementos(idObs2);
				
				resultado = factibilidadService.crearResultado(factibilidadDto);
				sitio = factibilidadService.modificarSitioEstado(parametroSitio.getFolio(), trancision);
				
				if(resultado && sitio){
					detalleSolicitudBean.insertarBitacora("");
					detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad: Rechazar");
					detalleSolicitudBean.setMensajeDialogo("Solicitud de Factibilidad rechazada con exito.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli').show();");
				} else {
					detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad: Rechazar");
					detalleSolicitudBean.setMensajeDialogo("Solicitud de Factibilidad no rechazada con exito.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
				}
			} else {
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvdlgValidacionesResultadoFacti').show();");
			}
		} catch (Exception e) {
			detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
			detalleSolicitudBean.setMensajeDialogo("Ocurrio un error al rechazar la Solicitud de Factibilidad.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	public void autorizarResulFacti(String trancision) throws ParseException {
		try {
			String[] parts = seleccionadoTorre.split(":");
			String idTorre = ""+parts[0];
			boolean resultado = false;
			boolean sitio = false;
			if (validaciones()) {
				if (seleccionadoRecuperacionE.equals("Si") || seleccionadoAdecuacion.equals("Si")) {
					detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
					detalleSolicitudBean.setMensajeDialogo("Para proceder a Factibilidad Autorizada se debe tener adecuacion y recuperacion en NO.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
					return;
				}
				
				SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
				Date fechaI = formato.parse(idFechaInicio);
				Date fechaT = (idFechaTermino.equals("") ? null : formato.parse(idFechaTermino)) ;
				FactibilidadDto factibilidadDto = new FactibilidadDto();
				factibilidadDto.setIdFactibilidad(Integer.parseInt(idFactibilidad));
				factibilidadDto.setIdTipoTorre(idTorre);
				factibilidadDto.setAlturaTotal(alturaTotalTorre);
				factibilidadDto.setNivelCentroRadiacionDisponible(idNivelR);
				factibilidadDto.setAreaDisponiblePiso(idAreaD);
				factibilidadDto.setRecuperacionEspacio(seleccionadoRecuperacionE);
				factibilidadDto.setAdecuacion(seleccionadoAdecuacion);
				factibilidadDto.setFactibilidadIncrementoTorre(seleccionadoFactibilidadTorre);
				factibilidadDto.setEspacioAdicionalPiso(seleccionadoEspacioAdicionalPiso);
				factibilidadDto.setObservacionesInfraestructura(idObservaciones);
				factibilidadDto.setLicencias(seleccionadoLicenciasPermisos);
				factibilidadDto.setDetalleLicencias(detalleLicenciasPermisos);
				factibilidadDto.setFechaInicio(fechaI);
				factibilidadDto.setFechaTermino(fechaT);
				factibilidadDto.setRentaPisoActualizada(idRentaPA);
				factibilidadDto.setRentaPisoConcesionario(idRentaPC);
				factibilidadDto.setRentaTorre(idRentaTO);
				factibilidadDto.setAcceso(idRH);
				factibilidadDto.setObservacionesOcupacion(observaciones2);
				factibilidadDto.setFactiLineaSuministro(seleccionadoFactibilidadE);
				factibilidadDto.setFactiLineaSuministroElectrica(seleccionadoLineaS);
				factibilidadDto.setObservacionesEnergiaElectrica(idObs);
				factibilidadDto.setFactiAire(seleccionadoFactibilidadEA);
				factibilidadDto.setFactiElementosAuxiliares(seleccionadoFactibilidadEE);
				factibilidadDto.setObservacionesOtrosElementos(idObs2);
				
				resultado = factibilidadService.crearResultado(factibilidadDto);
				sitio = factibilidadService.modificarSitioEstado(parametroSitio.getFolio(), trancision);
				
				if(resultado && sitio){
					detalleSolicitudBean.insertarBitacora("");
					detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad: Autorizar");
					detalleSolicitudBean.setMensajeDialogo("Solicitud de Factibilidad autorizada con exito.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli').show();");
				} else {
					detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad: Autorizar");
					detalleSolicitudBean.setMensajeDialogo("Solicitud de Factibilidad no autorizada con exito.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
				}
			} else {
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvdlgValidacionesResultadoFacti').show();");
			}
		} catch (Exception e) {
			detalleSolicitudBean.setHeaderDialogo("Solicitud de Factibilidad");
			detalleSolicitudBean.setMensajeDialogo("Ocurrio un error al autorizar la Solicitud de Factibilidad.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}	

	public boolean validaciones() {
		listaErrores = new ArrayList<>();
		seleccionadoLicenciasPermisos = "Si";
		seleccionadoLineaS = "Si";
		boolean resp = true;
		try {
			if (seleccionadoTorre.equals("")) {
				listaErrores.add("Se debe especificar un valor para tipo torre.");
				resp = false;
			}
			if (seleccionadoRecuperacionE.equals("")) {
				listaErrores.add("Se debe especificar un valor para recuperaci�n espacio.");
				resp = false;
			}
			if (seleccionadoAdecuacion.equals("")) {
				listaErrores.add("Se debe especificar un valor para adecuaci�n.");
				resp = false;
			}
			if (seleccionadoFactibilidadTorre.equals("")) {
				listaErrores.add("Se debe especificar un valor para factibilidad torre.");
				resp = false;
			}
			if (seleccionadoEspacioAdicionalPiso.equals("")) {
				listaErrores.add("Se debe especificar un valor para espacio adicional piso.");
				resp = false;
			}
			if (seleccionadoLicenciasPermisos.equals("")) {
				listaErrores.add("Se debe especificar un valor para licencias y permisos.");
				resp = false;
			}
			if (alturaTotalTorre.equals("")) {
				listaErrores.add("Se debe especificar un valor para altura total de la torre.");
				resp = false;
			} else if (Double.parseDouble(alturaTotalTorre) <= 0) {
				listaErrores.add("Se espera un valor mayor a cero en el campo Altura total.");
				resp = false;
			}
			if (idNivelR.equals("")) {
				listaErrores.add("Se debe especificar un valor para Nivel Centro de radiaci�n de antenas disponible.");
				resp = false;
			} else if (Double.parseDouble(idNivelR) <= 0) {
				listaErrores.add("Se espera un valor mayor a cero en el campo Nivel Centro de radiaci�n de antenas disponible.");
				resp = false;
			}
			if (idAreaD.equals("")) {
				listaErrores.add("Se debe especificar un valor para Area disponible en piso.");
				resp = false;
			} else if (Double.parseDouble(idAreaD) <= 0) {
				listaErrores.add("Se espera un valor mayor a cero en el campo Area disponible en piso.");
				resp = false;
			}
			if (idObservaciones.trim().equals("")) {
				listaErrores.add("Se debe especificar un valor para Observaciones de informaci�n de infraestructura pasiva.");
				resp = false;
			} else if (!ValidacionUtil.validarCaracteres(idObservaciones)) {
				listaErrores.add("No se permiten caracteres especiales en Observaciones de informaci�n de infraestructura pasiva.");
				resp = false;
			} else if (!ValidacionUtil.validaLongitud(idObservaciones, 250)) {
				listaErrores.add("Solo se permiten 250 caracteres en informaci�n de infraestructura pasiva");
				resp = false;
			}
			if (idFechaInicio.equals("")) {
				listaErrores.add("Se debe especificar un valor para fecha Inicio.");
				resp = false;
			} else {
				if (idFechaInicio.matches("^([0-2][0-9]|3[0-1])(\\/)(0[1-9]|1[0-2])\\2(\\d{4})$")) {
					try {
						String[] fh = idFechaInicio.split("/");
						Integer dia = Integer.parseInt(fh[0]);
						Integer mes = Integer.parseInt(fh[1]);
						Integer anio = Integer.parseInt(fh[2]);
						LocalDate fechaD = LocalDate.of(anio, mes, dia);
					} catch (DateTimeException e) {
						listaErrores.add("La fecha inicio debe cumplir con el siguiente formato dd/MM/yyyy.");
						resp = false;
					}
				} else {
					listaErrores.add("La fecha inicio debe cumplir con el siguiente formato dd/MM/yyyy.");
					resp = false;
				}
			}
			if (idFechaTermino.equals("")) {
				resp = true;
			} else {
				if (idFechaTermino.matches("^([0-2][0-9]|3[0-1])(\\/)(0[1-9]|1[0-2])\\2(\\d{4})$")) {
					try {
						String[] fh = idFechaTermino.split("/");
						Integer dia = Integer.parseInt(fh[0]);
						Integer mes = Integer.parseInt(fh[1]);
						Integer anio = Integer.parseInt(fh[2]);
						LocalDate fechaD = LocalDate.of(anio, mes, dia);
					} catch (DateTimeException e) {
						listaErrores.add("La fecha termino debe cumplir con el siguiente formato dd/MM/yyyy.");
						resp = false;
					}
				} else {
					listaErrores.add("La fecha termino debe cumplir con el siguiente formato dd/MM/yyyy.");
					resp = false;
				}
			}
			if (!idFechaInicio.equals("") && !idFechaTermino.equals("")) {
				SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy");
				Date fechaInicioDate = date.parse(idFechaInicio);
				Date fechaFinDate = date.parse(idFechaTermino);
				if (fechaInicioDate.after(fechaFinDate)) {
					listaErrores.add("Fecha inicio no debe ser mayor a fecha fin.");
					resp = false;
				}
			}
			if (idRentaPA.trim().equals("")) {
				listaErrores.add("Se debe especificar un valor para Renta en piso actualizada.");
				resp = false;
			} else if (!ValidacionUtil.validarCaracteres(idRentaPA)) {
				listaErrores.add("No se permiten caracteres especiales en Renta en piso actualizada.");
				resp = false;
			} else if (!ValidacionUtil.validaLongitud(idRentaPA, 50)) {
				listaErrores.add("Solo se permiten 50 caracteres en Renta en piso actualizada.");
				resp = false;
			}
			if (idRentaPC.trim().equals("")) {
				listaErrores.add("Se debe especificar un valor para Renta de piso por Concesionario.");
				resp = false;
			} else if (!ValidacionUtil.validarCaracteres(idRentaPC)) {
				listaErrores.add("No se permiten caracteres especiales en Renta de piso por Concesionario.");
				resp = false;
			} else if (!ValidacionUtil.validaLongitud(idRentaPC, 50)) {
				listaErrores.add("Solo se permiten 50 caracteres en Renta de piso por Concesionario.");
				resp = false;
			}
			if (idRentaTO.trim().equals("")) {
				listaErrores.add("Se debe especificar un valor para Renta en torre.");
				resp = false;
			} else if (!ValidacionUtil.validarCaracteres(idRentaTO)) {
				listaErrores.add("No se permiten caracteres especiales en Renta en torre.");
				resp = false;
			} else if (!ValidacionUtil.validaLongitud(idRentaTO, 50)) {
				listaErrores.add("Solo se permiten 50 caracteres en Renta en torre.");
				resp = false;
			}
			if (idRH.trim().equals("")) {
				listaErrores.add("Se debe especificar un valor para Acceso.");
				resp = false;
			} else if (!ValidacionUtil.validarCaracteres(idRH)) {
				listaErrores.add("No se permiten caracteres especiales en Acceso.");
				resp = false;
			} else if (!ValidacionUtil.validaLongitud(idRH, 50)) {
				listaErrores.add("Solo se permiten 50 caracteres en Acceso.");
				resp = false;
			}
			if (observaciones2.trim().equals("")) {
				listaErrores.add("Se debe especificar un valor para Observaciones de informaci�n del t�tulo de ocupaci�n.");
				resp = false;
			} else if (!ValidacionUtil.validarCaracteres(observaciones2)) {
				listaErrores.add("No se permiten caracteres especiales en Observaciones de informaci�n del t�tulo de ocupaci�n.");
				resp = false;
			} else if (!ValidacionUtil.validaLongitud(observaciones2, 250)) {
				listaErrores.add("Solo se permiten 50 caracteres en Observaciones de informaci�n del t�tulo de ocupaci�n.");
				resp = false;
			}
			if (seleccionadoFactibilidadE.equals("")) {
				listaErrores.add("Se debe especificar un valor para Factibilidad de existencia de l�nea del suministro de energ�a.");
				resp = false;
			}
			if (seleccionadoLineaS.equals("")) {
				listaErrores.add("Se debe especificar un valor para Factibilidad de existencia de l�nea del suministro de energ�a el�ctrica.");
				resp = false;
			}
			if (idObs.trim().equals("")) {
				listaErrores.add("Se debe especificar un valor para observaciones de Informaci�n de Energ�a El�ctrica.");
				resp = false;
			} else if (!ValidacionUtil.validarCaracteres(idObs)) {
				listaErrores.add("No se permiten caracteres especiales en Observaciones de Informaci�n de Energ�a El�ctrica.");
				resp = false;
			} else if (!ValidacionUtil.validaLongitud(idObs, 250)) {
				listaErrores.add("Solo se permiten 250 caracteres en Informaci�n de Energ�a El�ctrica.");
				resp = false;
			}
			if (seleccionadoFactibilidadEA.equals("")) {
				listaErrores.add("Se debe especificar un valor para Factibilidad de existencia de aire acondicionado.");
				resp = false;
			}
			if (seleccionadoFactibilidadEE.equals("")) {
				listaErrores.add("Se debe especificar un valor para Factibilidad de existencia de elementos auxiliares.");
				resp = false;
			}
			if (idObs2.trim().equals("")) {
				listaErrores.add("Se debe especificar un valor para observaciones de Informaci�n de otros elementos.");
				resp = false;
			} else if (!ValidacionUtil.validarCaracteres(idObs2)) {
				listaErrores.add("No se permiten caracteres especiales en observaciones de Informaci�n de otros elementos.");
				resp = false;
			} else if (!ValidacionUtil.validaLongitud(idObs2, 250)) {
				listaErrores.add("Solo se permiten 250 caracteres en Informaci�n de otros elementos.");
				resp = false;
			}
		} catch (Exception e) {
			listaErrores.add("Favor de validar");
			resp = false;
		}
		return resp;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}


	public IFactibilidadService getFactibilidadService() {
		return factibilidadService;
	}


	public void setFactibilidadService(IFactibilidadService factibilidadService) {
		this.factibilidadService = factibilidadService;
	}


	public List<FactibilidadDto> getFactibilidad() {
		return factibilidad;
	}


	public void setFactibilidad(List<FactibilidadDto> factibilidad) {
		this.factibilidad = factibilidad;
	}


	public List<String> getListaAvance() {
		return listaAvance;
	}

	public void setListaAvance(List<String> listaAvance) {
		this.listaAvance = listaAvance;
	}

	public String getAlturaTotalTorre() {
		return alturaTotalTorre;
	}

	public void setAlturaTotalTorre(String alturaTotalTorre) {
		this.alturaTotalTorre = alturaTotalTorre;
	}

	public IConsultaSolicitudesService getiSolicitudesService() {
		return iSolicitudesService;
	}

	public void setiSolicitudesService(IConsultaSolicitudesService iSolicitudesService) {
		this.iSolicitudesService = iSolicitudesService;
	}

	public IElementosPantallaService getElementosPantalla() {
		return elementosPantalla;
	}

	public void setElementosPantalla(IElementosPantallaService elementosPantalla) {
		this.elementosPantalla = elementosPantalla;
	}

	public List<ElementosPantallaDTO> getList() {
		return list;
	}

	public void setList(List<ElementosPantallaDTO> list) {
		this.list = list;
	}

	public String getSeleccionadoTorre() {
		return seleccionadoTorre;
	}

	public void setSeleccionadoTorre(String seleccionadoTorre) {
		this.seleccionadoTorre = seleccionadoTorre;
	}

	public String getSeleccionadoRecuperacionE() {
		return seleccionadoRecuperacionE;
	}

	public void setSeleccionadoRecuperacionE(String seleccionadoRecuperacionE) {
		this.seleccionadoRecuperacionE = seleccionadoRecuperacionE;
	}

	public String getSeleccionadoAdecuacion() {
		return seleccionadoAdecuacion;
	}

	public void setSeleccionadoAdecuacion(String seleccionadoAdecuacion) {
		this.seleccionadoAdecuacion = seleccionadoAdecuacion;
	}

	public String getSeleccionadoFactibilidadTorre() {
		return seleccionadoFactibilidadTorre;
	}

	public void setSeleccionadoFactibilidadTorre(String seleccionadoFactibilidadTorre) {
		this.seleccionadoFactibilidadTorre = seleccionadoFactibilidadTorre;
	}

	public String getSeleccionadoEspacioAdicionalPiso() {
		return seleccionadoEspacioAdicionalPiso;
	}

	public void setSeleccionadoEspacioAdicionalPiso(String seleccionadoEspacioAdicionalPiso) {
		this.seleccionadoEspacioAdicionalPiso = seleccionadoEspacioAdicionalPiso;
	}

	public String getSeleccionadoLicenciasPermisos() {
		return seleccionadoLicenciasPermisos;
	}

	public void setSeleccionadoLicenciasPermisos(String seleccionadoLicenciasPermisos) {
		this.seleccionadoLicenciasPermisos = seleccionadoLicenciasPermisos;
	}

	public List<String> getListaTorre() {
		return listaTorre;
	}

	public void setListaTorre(List<String> listaTorre) {
		this.listaTorre = listaTorre;
	}

	public List<String> getListaRecuperacionEspacio() {
		return listaRecuperacionEspacio;
	}

	public void setListaRecuperacionEspacio(List<String> listaRecuperacionEspacio) {
		this.listaRecuperacionEspacio = listaRecuperacionEspacio;
	}

	public List<String> getListaRequiereA() {
		return listaRequiereA;
	}

	public void setListaRequiereA(List<String> listaRequiereA) {
		this.listaRequiereA = listaRequiereA;
	}

	public List<String> getListaFactibilidadTorre() {
		return listaFactibilidadTorre;
	}

	public void setListaFactibilidadTorre(List<String> listaFactibilidadTorre) {
		this.listaFactibilidadTorre = listaFactibilidadTorre;
	}

	public List<String> getListaEspacioAdicionalPiso() {
		return listaEspacioAdicionalPiso;
	}

	public void setListaEspacioAdicionalPiso(List<String> listaEspacioAdicionalPiso) {
		this.listaEspacioAdicionalPiso = listaEspacioAdicionalPiso;
	}

	public List<String> getListaLicenciasPermisos() {
		return listaLicenciasPermisos;
	}

	public void setListaLicenciasPermisos(List<String> listaLicenciasPermisos) {
		this.listaLicenciasPermisos = listaLicenciasPermisos;
	}

	public String getIdNivelR() {
		return idNivelR;
	}

	public void setIdNivelR(String idNivelR) {
		this.idNivelR = idNivelR;
	}

	public String getIdAreaD() {
		return idAreaD;
	}

	public void setIdAreaD(String idAreaD) {
		this.idAreaD = idAreaD;
	}

	public String getIdObservaciones() {
		return idObservaciones;
	}

	public void setIdObservaciones(String idObservaciones) {
		this.idObservaciones = idObservaciones;
	}

	public String getDetalleLicenciasPermisos() {
		return detalleLicenciasPermisos;
	}

	public void setDetalleLicenciasPermisos(String detalleLicenciasPermisos) {
		this.detalleLicenciasPermisos = detalleLicenciasPermisos;
	}

	public String getIdFechaInicio() {
		return idFechaInicio;
	}

	public void setIdFechaInicio(String idFechaInicio) {
		this.idFechaInicio = idFechaInicio;
	}

	public String getIdFechaTermino() {
		return idFechaTermino;
	}

	public void setIdFechaTermino(String idFechaTermino) {
		this.idFechaTermino = idFechaTermino;
	}

	public String getIdRentaPA() {
		return idRentaPA;
	}

	public void setIdRentaPA(String idRentaPA) {
		this.idRentaPA = idRentaPA;
	}

	public String getIdRentaPC() {
		return idRentaPC;
	}

	public void setIdRentaPC(String idRentaPC) {
		this.idRentaPC = idRentaPC;
	}

	public String getIdRentaTO() {
		return idRentaTO;
	}

	public void setIdRentaTO(String idRentaTO) {
		this.idRentaTO = idRentaTO;
	}

	public String getIdRH() {
		return idRH;
	}

	public void setIdRH(String idRH) {
		this.idRH = idRH;
	}

	public String getObservaciones2() {
		return observaciones2;
	}

	public void setObservaciones2(String observaciones2) {
		this.observaciones2 = observaciones2;
	}

	public String getIdObs() {
		return idObs;
	}

	public void setIdObs(String idObs) {
		this.idObs = idObs;
	}

	public String getIdObs2() {
		return idObs2;
	}

	public void setIdObs2(String idObs2) {
		this.idObs2 = idObs2;
	}

	public SitioDto getParametroSitio() {
		return parametroSitio;
	}

	public void setParametroSitio(SitioDto parametroSitio) {
		this.parametroSitio = parametroSitio;
	}

	public List<String> getListaErrores() {
		return listaErrores;
	}

	public void setListaErrores(List<String> listaErrores) {
		this.listaErrores = listaErrores;
	}

	public String getHeaderDialogo() {
		return headerDialogo;
	}

	public void setHeaderDialogo(String headerDialogo) {
		this.headerDialogo = headerDialogo;
	}

	public String getMensajeDialogo() {
		return mensajeDialogo;
	}

	public void setMensajeDialogo(String mensajeDialogo) {
		this.mensajeDialogo = mensajeDialogo;
	}
	
	public String getSeleccionadoFactibilidadE() {
		return seleccionadoFactibilidadE;
	}

	public void setSeleccionadoFactibilidadE(String seleccionadoFactibilidadE) {
		this.seleccionadoFactibilidadE = seleccionadoFactibilidadE;
	}

	public String getSeleccionadoLineaS() {
		return seleccionadoLineaS;
	}

	public void setSeleccionadoLineaS(String seleccionadoLineaS) {
		this.seleccionadoLineaS = seleccionadoLineaS;
	}

	public String getSeleccionadoFactibilidadEA() {
		return seleccionadoFactibilidadEA;
	}

	public void setSeleccionadoFactibilidadEA(String seleccionadoFactibilidadEA) {
		this.seleccionadoFactibilidadEA = seleccionadoFactibilidadEA;
	}

	public String getSeleccionadoFactibilidadEE() {
		return seleccionadoFactibilidadEE;
	}

	public void setSeleccionadoFactibilidadEE(String seleccionadoFactibilidadEE) {
		this.seleccionadoFactibilidadEE = seleccionadoFactibilidadEE;
	}

}

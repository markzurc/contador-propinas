package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.usuario.admin.bean;

import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX0;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX1;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX2;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX3;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX4;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX5;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX6;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.WrapperReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants;

@Service("adminUsuariosService")
public class AdminUsuariosService{

	private int index = 0;
	private static final Logger logger = LogManager.getLogger(AdminUsuariosService.class);
	private static String[] columNamesUsuario={"Usuario","Apellido Paterno","Apellido Materno","Correo Electronico","Concesionario","Tipo Usuario", "Estado" };
	
	XSSFCellStyle styleDerecho = null;
	
	public void toExcelAdminUsuarios(XSSFWorkbook hssfWorkbook,List<WrapperReportUserVo> listBitacora) {		  
		XSSFSheet sheet = hssfWorkbook.createSheet("Reporte Usuarios Administrador"); 
		sheet.setDisplayGridlines(false);
		sheet.setPrintGridlines(false);
		XSSFCellStyle headerStyle = Constants.getLevelStyle(hssfWorkbook,INDEX1);
		headerStyle.setAlignment(HorizontalAlignment.CENTER);
		
		XSSFCellStyle campoStyle = Constants.getLevelStyle(hssfWorkbook,INDEX5);
		campoStyle.setBorderBottom(CellStyle.BORDER_THIN);
		campoStyle.setBorderLeft(CellStyle.BORDER_THIN);
		campoStyle.setBorderRight(CellStyle.BORDER_THIN);
		campoStyle.setBorderTop(CellStyle.BORDER_THIN);
		
		//Estilo para el borde derecho
		styleDerecho = Constants.getLevelStyle(hssfWorkbook,Constants.INDEX2);
		styleDerecho.setBorderRight(CellStyle.BORDER_THIN);
		styleDerecho.setRightBorderColor(IndexedColors.BLACK.getIndex());
		styleDerecho.setBorderTop(CellStyle.BORDER_THIN);
		styleDerecho.setTopBorderColor(IndexedColors.WHITE.getIndex());
		
		//APPs
		insertaCell(sheet,INDEX0,INDEX0,"Reporte Usuarios Administrador",headerStyle);
		sheet.addMergedRegion(new CellRangeAddress(INDEX0,INDEX0,0,6));

		index=1; 		
		addColumnsNames(sheet, index++,Constants.getLevelStyle(hssfWorkbook,INDEX2),columNamesUsuario);
				
		for(WrapperReportUserVo reporUsuarioDto: listBitacora){
			
			insertaCell(sheet, index,INDEX0,reporUsuarioDto.getReportUserVo().getNombre(),campoStyle);
			insertaCell(sheet, index,INDEX1,reporUsuarioDto.getReportUserVo().getApellidoPaterno(),campoStyle);			
			insertaCell(sheet, index,INDEX2,reporUsuarioDto.getReportUserVo().getApellidoMaterno(),campoStyle);
			insertaCell(sheet, index,INDEX3,reporUsuarioDto.getReportUserVo().getCorreo(),campoStyle);
			insertaCell(sheet, index,INDEX4,reporUsuarioDto.getReportUserVo().getEmpresa(),campoStyle);	
			insertaCell(sheet, index,INDEX5,reporUsuarioDto.getReportUserVo().getTipoUsuarioNombre(),campoStyle);	
			insertaCell(sheet, index,INDEX6,reporUsuarioDto.getReportUserVo().getEstatusNombre(),campoStyle);

			index++;
		}
		
		ajustarTodasColumnas(sheet, 7, index);
	}
	
	//common
	private void insertaCell(XSSFSheet sheet, int rowIndex, int column, String value, XSSFCellStyle style) {
		XSSFRow commonRow = sheet.getRow(rowIndex);
		
		if (commonRow == null) {
			commonRow = sheet.createRow(rowIndex);
		}
		
		XSSFCell nombre = commonRow.createCell(column);
		nombre.setCellValue(value);
		nombre.setCellStyle(style);
		
	}
	
	private void addColumnsNames(XSSFSheet sheet, int position, XSSFCellStyle style, String[] titles) {
		int column = INDEX0;
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setRightBorderColor(IndexedColors.WHITE.getIndex());
		style.setBorderTop(CellStyle.BORDER_THIN);
		style.setTopBorderColor(IndexedColors.WHITE.getIndex());
		for (String titleColumn : titles) {
			if (column == 6) {
				insertaCell(sheet, position, column, titleColumn, styleDerecho);
			}else {
				insertaCell(sheet, position, column, titleColumn, style);
			}
			column += 1;
						
		}
 
	}
	private void ajustarTodasColumnas(XSSFSheet sheet, int numColumnas, int numFilas) {
	    for (int col = 0; col < numColumnas; col++) {
	        int anchoMax = 0;
	        String textoMayus = "";
	        for (int fila = 1; fila < numFilas; fila++) {
	            XSSFRow row = sheet.getRow(fila);
	            if (row != null) {
	                XSSFCell cell = row.getCell(col);
	                if (cell != null && !cell.getStringCellValue().isEmpty()) {	                    
	                	String texto = cell.getStringCellValue();
	                	if (texto.length() > anchoMax) {
	                		anchoMax  = texto.length();	
	                		textoMayus = texto;
						}
	                }
	            }
	        }
	        if (textoMayus.matches("^[A-Z\\s]+$")) {
	        	sheet.setColumnWidth(col, (anchoMax + 3) * 300);
				
			}else {
				sheet.setColumnWidth(col, (anchoMax + 3) * 256);
			}
	    }
	}
	
}
package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.usuario.admin.bean;

import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.event.FileUploadEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Controller;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.external.authentication.IAuthenticationExternal;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dao.IUserDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.DocumentoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.OperadorDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.ReportUserDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.user.service.UserCatalogService;

@Controller("editarUsuarioConcesionarioBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class EditarUsuarioConcesionarioBean implements Serializable {
	
	private static final long serialVersionUID = 4582624686881827949L;
	private static final Logger LOGGER = LogManager.getLogger(EditarUsuarioAdministradorBean.class);

	@Autowired
	@Qualifier("userCatalogService")
	private UserCatalogService userCatalogService;
	
	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;
	
	@Autowired
	@Qualifier("userDao")
	private IUserDao userDao;
	
	@Autowired
    @Qualifier("externalAuth")
    private IAuthenticationExternal authExternal;
	
	private File targetFolder;
	
	private ReportUserVo reportUserVo;
	
	private List<String> listaTipoUsuario;
	private List<String> listaEstado;
	private List<OperadorDto> listaConcesionario;
	private List<DocumentoDto> listaDocumentos;
	
	private String tipoUsuario;
	private String estado;
	
	private String seleccionadoTipoUsuario;
	private String seleccionadoEstado;
	private String seleccionadoConcesionario;
	private String nombre;
	private String apellidoP;
	private String apellidoM;
	private String correo;
	private String pass;
	private String concesionario;
	private Integer concesionarioId;
	private List<String> listaErrores;
	
	private String renderedConcesionario;
	
	private String leyenda;
	private String operacion;
	private String contraAnterior;
	private String estadoAnterior;
	
	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		try {
			listaEstado = new ArrayList<>();
			listaTipoUsuario = new ArrayList<>();
			listaConcesionario = new ArrayList<>();
			listaDocumentos = new ArrayList<>();
			tipoUsuario = "";
			estado = "";
			nombre = "";
			cargaListas();
			cargaUsuario();
			listaDocumentos = userCatalogService.obtenerDocumentos(reportUserVo.getIdUsuario());
			validaTipoUsuario();
			contraAnterior = userCatalogService.getPassUser(reportUserVo.getIdUsuario());
			estadoAnterior = userCatalogService.getEstadoUser(reportUserVo.getIdUsuario());
		} catch (Exception e) {
			LOGGER.info("Ocurrio un error al cargar la pagina: " + e);
			context.addMessage("mensajes",
					new FacesMessage(SEVERITY_ERROR, "Error", "Ocurri� un error al cargar la p�gina"));
		}
	}
	
	public boolean validaciones() {
		listaErrores = new ArrayList<>();
		boolean resp = true;
		FacesContext context = FacesContext.getCurrentInstance();
		try {
			List<ReportUserVo> user=userCatalogService.getUsersConcesionario();
			for (ReportUserVo reportUserVo : user) {
				if (reportUserVo.getCorreo().equals(correo)) {
					if (!reportUserVo.getIdUsuario().equals(this.reportUserVo.getIdUsuario())) {
						listaErrores.add("No se puede registrar otro usuario con el mismo correo.");
						resp = false;
					}
					
				}
			}
			List<ReportUserVo> user2=userCatalogService.getAllUsers();
			for (ReportUserVo reportUserVo : user2) {
				if (reportUserVo.getCorreo().equals(correo)) {
					listaErrores.add("No se puede registrar otro usuario con el mismo correo.");
					resp = false;
				}
			}
			
			int usuarios = userCatalogService.getCountUsersConcesionarioByOp(reportUserVo.getEmpresaId().toString());
			if (reportUserVo.getEstatusNombre().equals("Bloqueado") || reportUserVo.getEstatusNombre().equals("Activo")) {
				usuarios = usuarios -1;
			}
			ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness.
					getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.NUM_MAX_CONCESIONARIO);
			int numUsuarios = Integer.parseInt(configurationUtilsVo.getValor());
			if(usuarios >= numUsuarios){
				if (!seleccionadoEstado.equals("Baja")) {
					listaErrores.add("El n�mero m�ximo de usuarios por Concesionario es "+numUsuarios);
					resp = false;
				}
			}
			
			String strPasswordCrypt = authExternal.encriptarAcceso(pass);
			
			if (nombre.equals("")) {
				listaErrores.add("El campo nombre es obligatorio.");
				resp = false;
			} else if (nombre.length() >= 250) {
				listaErrores.add("El campo nombre no puede ser mayor a 250 caracteres.");
				resp = false;
			}
			
			if (!nombre.matches("[a-zA-Z ]*")) {
				listaErrores.add("Solo se pueden agregar letras en el campo nombre.");
				resp = false;
			}
			
			if (apellidoP.equals("")) {
				listaErrores.add("El campo apellido paterno es obligatorio.");
				resp = false;
			} else if (apellidoP.length() >= 250) {
				listaErrores.add("El campo apellido paterno no puede ser mayor a 250 caracteres.");
				resp = false;
			}
			
			if (!apellidoP.matches("[a-zA-Z ]*")) {
				listaErrores.add("Solo se pueden agregar letras en el campo apellido paterno.");
				resp = false;
			}
			
			if (apellidoM.equals("")) {
				listaErrores.add("El campo apellido materno es obligatorio.");
				resp = false;
			} else if (apellidoM.length() >= 250) {
				listaErrores.add("El campo apellido materno no puede ser mayor a 250 caracteres.");
				resp = false;
			}
			if (!apellidoM.matches("[a-zA-Z ]*")) {
				listaErrores.add("Solo se pueden agregar letras en el campo apellido materno.");
				resp = false;
			}
			
			if (correo.equals("")) {
				listaErrores.add("El campo correo electr�nico es obligatorio.");
				resp = false;
			} else if (!correo.matches("^[a-z0-9_+&*-]+(?:\\.[a-z0-9_+&*-]+)*@(?:[a-z0-9-]+\\.)+[a-z]{2,7}$")) {
				listaErrores.add("El correo electr�nico no cumple con el formato requerido.");
				resp = false;
			} else if (correo.length() >= 250) {
				listaErrores.add("El campo corre� no puede ser mayor a 250 caracteres.");
				resp = false;
			}
		
			if (pass.equals("")) {
				listaErrores.add("El campo contrase�a es obligatorio.");
				resp = false;
			} else if (pass.length() > 30 || pass.length() < 8) {
				listaErrores.add("La contrase�a debe tener de 8 a 30 caracteres.");
				resp = false;
			} else if (!contrasenaSegura(pass)) {
				listaErrores.add("La contrase�a debe tener m�nimo 1 n�mero, 1 s�mbolo, 1 car�cter especial, 1 letra may�scula y min�sculas.");
				resp = false;
			}  else if (seleccionadoEstado.equals("Activo") && estadoAnterior.equals("2")) {
				if (strPasswordCrypt.equals(contraAnterior)) {
					listaErrores.add("La contrase�a debe ser diferente a la anterior ya que se cambio el estado de Baja a Activo .");
					resp = false;
				}
			}
			
			if (seleccionadoEstado.equals("null") || seleccionadoEstado.equals("")) {
				listaErrores.add("El campo estado es obligatorio.");
				resp = false;
			} else if (seleccionadoEstado.equals("Bloqueado")) {
				if(!reportUserVo.getEstatusNombre().equals("Bloqueado")){
					listaErrores.add("No se puede bloquear el usuario.");
					resp = false;
				}
			}
			
		} catch (Exception e) {
			LOGGER.info("Ocurrio un error al realizar las validaciones: " + e);
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","Ocurri� un error al realizar las validaciones"));
		}
		return resp;
	}
	
	public static boolean contrasenaSegura(String contrasena) {

		boolean mayuscula = false;
		boolean minuscula = false;
        boolean numero = false;
        boolean especial = false;
               
        //Define caracteres especiales
        Pattern special = Pattern.compile("[<>{}\"/|;:.,!?@#$%=&*\\]\\\\()\\[��_+]");
        Matcher hasSpecial = special.matcher(contrasena);

        int i;
        char l;

        for (i = 0; i < contrasena.length(); i++) {
            l = contrasena.charAt(i);

            if (Character.isDigit(l)) {//m�nimo un n�mero. 
                numero = true;
            }
            
            if (Character.isUpperCase(l)) { // m�nimo una letra may�scula 
                mayuscula = true;
            }
            
            if (Character.isLowerCase(l)) { // m�nimo una letra may�scula 
                minuscula = true;
            }
            
            if (hasSpecial.find()) { //Valida "caracteres especiales".       
                especial = true;
            }
        }

        if (numero == true && mayuscula == true && minuscula == true && especial == true) {
            return true;
        } else {
            return false;
        }
	}
	
	public void editarUsuario() {
		boolean valid = validaciones();
		if (valid) {
			String strPasswordCrypt = authExternal.encriptarAcceso(pass);
			ReportUserDto reportUserDto = new ReportUserDto();
			reportUserDto.setApellidoMaterno(capitalizarPrimeraLetra(apellidoM.toLowerCase()));
			reportUserDto.setIdUsuario(reportUserVo.getIdUsuario());
			reportUserDto.setNombre(capitalizarPrimeraLetra(nombre.toLowerCase()));
			reportUserDto.setApellidoPaterno(capitalizarPrimeraLetra(apellidoP.toLowerCase()));
			reportUserDto.setCorreo(correo);
			if (seleccionadoEstado.equals("Activo")) {
				reportUserDto.setIdEstatus(0);
			} else if (seleccionadoEstado.equals("Bloqueado")) {
				reportUserDto.setIdEstatus(1);
			}else {
				reportUserDto.setIdEstatus(2);
			}
			
			if (estadoAnterior.equals("2") && seleccionadoEstado.equals("Activo")) {
				reportUserDto.setIdEstatus(3);
			}
			
			if (seleccionadoEstado.equals("Activo")) {
				if (strPasswordCrypt.equals(contraAnterior)) {
					reportUserDto.setIdEstatus(0);
				} else {
					reportUserDto.setIdEstatus(3);
				}
			}
			
			boolean resp = userCatalogService.actualizarUsuarioAdmin(reportUserDto, strPasswordCrypt);
			if (resp) {
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMensaje').show();");
			} else {
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMensajeError').show();");
			}
		} else {
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgValidaciones').show();");
		}
	}
	
	public String capitalizarPrimeraLetra(String str) {
		String nombreR="";
		String[] parts = str.split(" ");
		for (String string : parts) {
			if(string.trim().length() > 0){
				String nombre = string;
				String resultado = nombre.toUpperCase().charAt(0) + nombre.substring(1, nombre.length()).toLowerCase();
				nombreR = nombreR + resultado + " ";
			}
		}
		String nombreF = nombreR.substring(0, nombreR.length() - 1);
		return nombreF;
	}
	
	public void validaTipoUsuario() {
		if (reportUserVo.getTipoUsuarioNombre().equals("IFT")) {
			renderedConcesionario = "false";
		} else {
			renderedConcesionario = "true";
		}
	}
	
	public void eliminarDoc(DocumentoDto doc) {
		boolean resp = userCatalogService.eliminarDoc(doc.getIdDocumento());
		if (resp) {
			listaDocumentos = userCatalogService.obtenerDocumentos(reportUserVo.getIdUsuario());
		}
	}
	
	public void cargaArchivos(FileUploadEvent event) throws IOException {
		String fileName = null;
		InputStream inputStream =null;	
		try {
			fileName = FilenameUtils.getName(event.getFile().getFileName());
			String ruta ="C:\\Users\\Hitss\\Documents\\Docs";
			File directorioTemp = new File(ruta);
			if (!directorioTemp.exists()) {
				directorioTemp.mkdirs();
			}
			inputStream = event.getFile().getInputstream();
			
			
			String rutaA = directorioTemp.getPath() + File.separator + fileName;
			File verificaSiExiste = new File(rutaA);
			System.out.println("sdd");
			
			subirArchivo(inputStream, verificaSiExiste);
			guardarArchivo(directorioTemp.getPath(), fileName);
			
		} catch (Exception e) {
			System.out.println("error");
		}
		finally {
			listaDocumentos = userCatalogService.obtenerDocumentos(reportUserVo.getIdUsuario());
		}
	}
	
	public void guardarArchivo(String ruta, String name) {
		userCatalogService.guardarDocumento(ruta, name, reportUserVo.getIdUsuario());
	}
	
	public static boolean subirArchivo(InputStream origen, File destino) {
		OutputStream out = null;
		try {
			InputStream in = origen;
			out = new FileOutputStream(destino);

			byte[] buf = new byte[1024];
			int len;

			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}

			in.close();
			out.close();
		} catch (IOException e) {
			return false;

		} finally {
			close(out);
		}

		return true;
	}
	
	private static void close(Closeable closable){
        try {
            if( closable != null ){
            	closable.close();
            }
        } catch (IOException e) {
        	System.out.println("Error al cerrar OutputStream ");
        }
    }
	
	private void cargaUsuario() {
		this.setEstado("Seleccione un estado");
		this.setTipoUsuario("Seleccione un tipo usuario");
		this.setConcesionario(reportUserVo.getEmpresa());
		
		this.setSeleccionadoTipoUsuario(reportUserVo.getTipoUsuarioNombre());
		if (reportUserVo.getEstatusNombre().equals("Nuevo")) 
			this.setSeleccionadoEstado("Activo");
		else 
			this.setSeleccionadoEstado(reportUserVo.getEstatusNombre());
		this.setNombre(reportUserVo.getNombre());
		this.setApellidoM(reportUserVo.getApellidoMaterno());
		this.setApellidoP(reportUserVo.getApellidoPaterno());
		this.setCorreo(reportUserVo.getCorreo());
		
		String strPasswordCrypt = authExternal.desencriptarAcceso(reportUserVo.getPass());
		this.setPass(strPasswordCrypt);
	}
	
	
	private void cargaListas() {
		listaEstado.add("Activo");
		listaEstado.add("Bloqueado");
		listaEstado.add("Baja");
//		listaEstado.add("Nuevo");
//		listaEstado.add("Reiniciado");
//		listaEstado.add("Mantenimiento");
//		listaEstado.add("Expirado");
		
		listaTipoUsuario.add("Administrador Concesionario");
		listaTipoUsuario.add("IFT");
		
		this.setListaConcesionario(userCatalogService.obtenerEmpresas());
		
	}
	
	public void handleFileUpload(FileUploadEvent event) {
		FacesMessage msg = new FacesMessage("Succesful", event.getFile().getFileName() + " is uploaded.");
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}
	
	public void lecturaArchivo(FileUploadEvent event) {
		System.out.println("LECTURA DE ARCHIVO EXCEL");
	}

	public File getTargetFolder() {
		return targetFolder;
	}

	public void setTargetFolder(File targetFolder) {
		this.targetFolder = targetFolder;
	}

	public ReportUserVo getReportUserVo() {
		return reportUserVo;
	}

	public void setReportUserVo(ReportUserVo reportUserVo) {
		this.reportUserVo = reportUserVo;
	}

	public List<String> getListaTipoUsuario() {
		return listaTipoUsuario;
	}

	public void setListaTipoUsuario(List<String> listaTipoUsuario) {
		this.listaTipoUsuario = listaTipoUsuario;
	}

	public List<String> getListaEstado() {
		return listaEstado;
	}

	public void setListaEstado(List<String> listaEstado) {
		this.listaEstado = listaEstado;
	}

	public String getTipoUsuario() {
		return tipoUsuario;
	}

	public void setTipoUsuario(String tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getSeleccionadoTipoUsuario() {
		return seleccionadoTipoUsuario;
	}

	public void setSeleccionadoTipoUsuario(String seleccionadoTipoUsuario) {
		this.seleccionadoTipoUsuario = seleccionadoTipoUsuario;
	}

	public String getSeleccionadoEstado() {
		return seleccionadoEstado;
	}

	public void setSeleccionadoEstado(String seleccionadoEstado) {
		this.seleccionadoEstado = seleccionadoEstado;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidoP() {
		return apellidoP;
	}

	public void setApellidoP(String apellidoP) {
		this.apellidoP = apellidoP;
	}

	public String getApellidoM() {
		return apellidoM;
	}

	public void setApellidoM(String apellidoM) {
		this.apellidoM = apellidoM;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getSeleccionadoConcesionario() {
		return seleccionadoConcesionario;
	}

	public void setSeleccionadoConcesionario(String seleccionadoConcesionario) {
		this.seleccionadoConcesionario = seleccionadoConcesionario;
	}

	public String getConcesionario() {
		return concesionario;
	}

	public void setConcesionario(String concesionario) {
		this.concesionario = concesionario;
	}

	public List<OperadorDto> getListaConcesionario() {
		return listaConcesionario;
	}

	public void setListaConcesionario(List<OperadorDto> listaConcesionario) {
		this.listaConcesionario = listaConcesionario;
	}

	public List<DocumentoDto> getListaDocumentos() {
		return listaDocumentos;
	}

	public void setListaDocumentos(List<DocumentoDto> listaDocumentos) {
		this.listaDocumentos = listaDocumentos;
	}

	public Integer getConcesionarioId() {
		return concesionarioId;
	}

	public void setConcesionarioId(Integer concesionarioId) {
		this.concesionarioId = concesionarioId;
	}
	
	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getRenderedConcesionario() {
		return renderedConcesionario;
	}

	public void setRenderedConcesionario(String renderedConcesionario) {
		this.renderedConcesionario = renderedConcesionario;
	}

	public List<String> getListaErrores() {
		return listaErrores;
	}

	public void setListaErrores(List<String> listaErrores) {
		this.listaErrores = listaErrores;
	}

	public String getLeyenda() {
		return leyenda;
	}

	public void setLeyenda(String leyenda) {
		this.leyenda = leyenda;
	}

	public String getOperacion() {
		return operacion;
	}

	public void setOperacion(String operacion) {
		this.operacion = operacion;
	}
	
}

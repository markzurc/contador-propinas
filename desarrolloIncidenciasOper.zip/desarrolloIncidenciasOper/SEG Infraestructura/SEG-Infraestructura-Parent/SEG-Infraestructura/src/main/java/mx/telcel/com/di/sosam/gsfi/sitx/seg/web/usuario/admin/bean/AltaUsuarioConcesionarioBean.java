package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.usuario.admin.bean;

import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;


import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.external.authentication.IAuthenticationExternal;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.OperadorDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.ReportUserDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.user.service.UserCatalogService;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Controller("altaUsuarioConcesionarioBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class AltaUsuarioConcesionarioBean implements Serializable {
	
	private static final Logger LOGGER = LogManager.getLogger(AltaUsuarioConcesionarioBean.class);

	private static final long serialVersionUID = 4582624686881827949L;
	

	@Autowired
	@Qualifier("userCatalogService")
	private UserCatalogService userCatalogService;
	
	@Autowired
    @Qualifier("externalAuth")
    private IAuthenticationExternal authExternal;
	
	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;

	private File targetFolder;

	private ReportUserVo reportUserVo;

	private List<String> listaTipoUsuario;
	private List<OperadorDto> listaConcesionario;
	private List<String> listaArchivos;

	private String tipoUsuario;

	private String seleccionadoTipoUsuario;
	private String seleccionadoEstado;
	private String seleccionadoConcesionario;
	private String nombre;
	private String apellidoP;
	private String apellidoM;
	private String correo;
	private String pass;
	private String concesionario;
	private Integer concesionarioId;
	private String operadorUsuario;
	
	private String renderedConcesionario;
	
	private UserDetailsVo userDetailsVo;
	
	private String mensajeError;
	private List<String> listaErrores;

	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		try {

			userDetailsVo = (UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			listaTipoUsuario = new ArrayList<>();
			listaConcesionario = new ArrayList<>();
			listaArchivos = new ArrayList<>();
			listaErrores = new ArrayList<>();
			tipoUsuario = "";
			concesionario = "";
			nombre = "";
			apellidoM = "";
			apellidoP = "";
			correo = "";
			pass = "";
			operadorUsuario = "";
			mensajeError = "";
			cargaListas();
		} catch (Exception e) {
			LOGGER.info("Ocurrio un error al cargar la pagina: " + e);
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","Ocurri� un error al cargar la p�gina"));
		}
	}
	
	public boolean validaciones() {
		listaErrores = new ArrayList<>();
		boolean resp = true;
		FacesContext context = FacesContext.getCurrentInstance();
		try {
			List<ReportUserVo> user=userCatalogService.getUsersConcesionario();
			for (ReportUserVo reportUserVo : user) {
				if (reportUserVo.getCorreo().equals(correo)) {
					listaErrores.add("No se puede registrar otro usuario con el mismo correo.");
					resp = false;
				}
			}
			List<ReportUserVo> user2=userCatalogService.getAllUsers();
			for (ReportUserVo reportUserVo : user2) {
				if (reportUserVo.getCorreo().equals(correo)) {
					listaErrores.add("No se puede registrar otro usuario con el mismo correo.");
					resp = false;
				}
			}
			int usuarios = userCatalogService.getCountUsersConcesionarioByOp(seleccionadoConcesionario);
			ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness.
					getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.NUM_MAX_CONCESIONARIO);
			int numUsuarios = Integer.parseInt(configurationUtilsVo.getValor());
			if(usuarios >= numUsuarios){
				listaErrores.add("El n�mero m�ximo de usuarios por Concesionario es "+numUsuarios);
				resp = false;
			}
			
			if (nombre.equals("")) {
				listaErrores.add("El campo nombre es obligatorio.");
				resp = false;
			} else if (nombre.length() >= 250) {
				listaErrores.add("El campo nombre no puede ser mayor a 250 caracteres.");
				resp = false;
			}
			
			if (!nombre.matches("[a-zA-Z ]*")) {
				listaErrores.add("Solo se pueden agregar letras en el campo nombre.");
				resp = false;
			}
			
			if (apellidoP.equals("")) {
				listaErrores.add("El campo apellido paterno es obligatorio.");
				resp = false;
			} else if (apellidoP.length() >= 250) {
				listaErrores.add("El campo apellido paterno no puede ser mayor a 250 caracteres.");
				resp = false;
			}
			
			if (!apellidoP.matches("[a-zA-Z ]*")) {
				listaErrores.add("Solo se pueden agregar letras en el campo apellido paterno.");
				resp = false;
			}
			
			if (apellidoM.equals("")) {
				listaErrores.add("El campo apellido materno es obligatorio.");
				resp = false;
			} else if (apellidoM.length() >= 250) {
				listaErrores.add("El campo apellido materno no puede ser mayor a 250 caracteres.");
				resp = false;
			}
			if (!apellidoM.matches("[a-zA-Z ]*")) {
				listaErrores.add("Solo se pueden agregar letras en el campo apellido materno.");
				resp = false;
			}
			
			if (correo.equals("")) {
				listaErrores.add("El campo correo electr�nico es obligatorio.");
				resp = false;
			} else if (!correo.matches("^[a-z0-9_+&*-]+(?:\\.[a-z0-9_+&*-]+)*@(?:[a-z0-9-]+\\.)+[a-z]{2,7}$")) {
				listaErrores.add("El correo electr�nico no cumple con el formato requerido.");
				resp = false;
			} else if (correo.length() >= 250) {
				listaErrores.add("El campo corre� no puede ser mayor a 250 caracteres.");
				resp = false;
			}
		
			if (pass.equals("")) {
				listaErrores.add("El campo contrase�a es obligatorio.");
				resp = false;
			} else if (pass.length() > 30 || pass.length() < 8) {
				listaErrores.add("La contrase�a debe tener de 8 a 30 caracteres.");
				resp = false;
			} else if (!contrasenaSegura(pass)) {
				listaErrores.add("La contrase�a debe tener minimo 1 n�mero, 1 s�mbolo, 1 car�cter especial, 1 letra may�scula y min�sculas.");
				resp = false;
			}
			
		} catch (Exception e) {
			LOGGER.info("Ocurrio un error al realizar las validaciones: " + e);
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","Ocurri� un error al realizar las validaciones"));
		}
		return resp;
	}
	
	public static boolean contrasenaSegura(String contrasena) {

		boolean mayuscula = false;
		boolean minuscula = false;
        boolean numero = false;
        boolean especial = false;
               
        //Define caracteres especiales
        Pattern special = Pattern.compile("[<>{}\"/|;:.,!?@#$%=&*\\]\\\\()\\[��_+]");
        Matcher hasSpecial = special.matcher(contrasena);

        int i;
        char l;

        for (i = 0; i < contrasena.length(); i++) {
            l = contrasena.charAt(i);

            if (Character.isDigit(l)) {//m�nimo un n�mero. 
                numero = true;
            }
            
            if (Character.isUpperCase(l)) { // m�nimo una letra may�scula 
                mayuscula = true;
            }
            
            if (Character.isLowerCase(l)) { // m�nimo una letra may�scula 
                minuscula = true;
            }
            
            if (hasSpecial.find()) { //Valida "caracteres especiales".       
                especial = true;
            }
        }

        if (numero == true && mayuscula == true && minuscula == true && especial == true) {
            return true;
        } else {
            return false;
        }
	}

	public void altaUsuario() {
		boolean valid = validaciones();
		if (valid) {
			ReportUserDto reportUserDto = new ReportUserDto();
			reportUserDto.setNombre(capitalizarPrimeraLetra(nombre.toLowerCase()));
			reportUserDto.setApellidoPaterno(capitalizarPrimeraLetra(apellidoP.toLowerCase()));
			reportUserDto.setApellidoMaterno(capitalizarPrimeraLetra(apellidoM.toLowerCase()));
			reportUserDto.setCorreo(correo);
			String password = pass;
			String strPasswordCrypt = authExternal.encriptarAcceso(password);
			
			reportUserDto.setEmpresa(seleccionadoConcesionario);
			reportUserDto.setIdTipoUsuario(2);
			reportUserDto.setIdRol(13);
			
			boolean resp = userCatalogService.altaUsuarioAdministrador(reportUserDto, strPasswordCrypt);
			reportUserDto.setPass(strPasswordCrypt);
			boolean resp2 = userCatalogService.altaPass(reportUserDto);
			boolean resp3 = userCatalogService.altaRolUsuario(reportUserDto);
			
			if (resp && resp2 && resp3) {
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMensaje').show();");
			} else {
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMensajeError').show();");
			}
		} else {
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgValidaciones').show();");
		}
		
	}
	
	public String capitalizarPrimeraLetra(String str) {
		String nombreR="";
		String[] parts = str.split(" ");
		for (String string : parts) {
			if(string.trim().length() > 0){
				String nombre = string;
				String resultado = nombre.toUpperCase().charAt(0) + nombre.substring(1, nombre.length()).toLowerCase();
				nombreR = nombreR + resultado + " ";
			}
		}
		String nombreF = nombreR.substring(0, nombreR.length() - 1);
		return nombreF;
	}

	private void cargaListas() {
		this.setConcesionario("Seleccione un concesionario");
		this.setListaConcesionario(userCatalogService.obtenerEmpresas());
		
		this.setOperadorUsuario(userCatalogService.obtenerOperadorUsuario(userDetailsVo.getIdUsuario()));
		String string = this.getOperadorUsuario();
		String[] parts = string.split(":");
		String part1 = parts[0];
		String part2 = parts[1];
		this.setConcesionario(part2);
		this.setSeleccionadoConcesionario(part1);

	}

	public File getTargetFolder() {
		return targetFolder;
	}

	public void setTargetFolder(File targetFolder) {
		this.targetFolder = targetFolder;
	}

	public ReportUserVo getReportUserVo() {
		return reportUserVo;
	}

	public void setReportUserVo(ReportUserVo reportUserVo) {
		this.reportUserVo = reportUserVo;
	}

	public List<String> getListaTipoUsuario() {
		return listaTipoUsuario;
	}

	public void setListaTipoUsuario(List<String> listaTipoUsuario) {
		this.listaTipoUsuario = listaTipoUsuario;
	}

	public String getTipoUsuario() {
		return tipoUsuario;
	}

	public void setTipoUsuario(String tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}

	public String getSeleccionadoTipoUsuario() {
		return seleccionadoTipoUsuario;
	}

	public void setSeleccionadoTipoUsuario(String seleccionadoTipoUsuario) {
		this.seleccionadoTipoUsuario = seleccionadoTipoUsuario;
	}

	public String getSeleccionadoEstado() {
		return seleccionadoEstado;
	}

	public void setSeleccionadoEstado(String seleccionadoEstado) {
		this.seleccionadoEstado = seleccionadoEstado;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidoP() {
		return apellidoP;
	}

	public void setApellidoP(String apellidoP) {
		this.apellidoP = apellidoP;
	}

	public String getApellidoM() {
		return apellidoM;
	}

	public void setApellidoM(String apellidoM) {
		this.apellidoM = apellidoM;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getSeleccionadoConcesionario() {
		return seleccionadoConcesionario;
	}

	public void setSeleccionadoConcesionario(String seleccionadoConcesionario) {
		this.seleccionadoConcesionario = seleccionadoConcesionario;
	}

	public String getConcesionario() {
		return concesionario;
	}

	public void setConcesionario(String concesionario) {
		this.concesionario = concesionario;
	}

	public List<OperadorDto> getListaConcesionario() {
		return listaConcesionario;
	}

	public void setListaConcesionario(List<OperadorDto> listaConcesionario) {
		this.listaConcesionario = listaConcesionario;
	}

	public Integer getConcesionarioId() {
		return concesionarioId;
	}

	public void setConcesionarioId(Integer concesionarioId) {
		this.concesionarioId = concesionarioId;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public List<String> getListaArchivos() {
		return listaArchivos;
	}

	public void setListaArchivos(List<String> listaArchivos) {
		this.listaArchivos = listaArchivos;
	}

	public String getRenderedConcesionario() {
		return renderedConcesionario;
	}

	public void setRenderedConcesionario(String renderedConcesionario) {
		this.renderedConcesionario = renderedConcesionario;
	}

	public String getOperadorUsuario() {
		return operadorUsuario;
	}

	public void setOperadorUsuario(String operadorUsuario) {
		this.operadorUsuario = operadorUsuario;
	}

	public String getMensajeError() {
		return mensajeError;
	}

	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}

	public List<String> getListaErrores() {
		return listaErrores;
	}

	public void setListaErrores(List<String> listaErrores) {
		this.listaErrores = listaErrores;
	}

	public UserDetailsVo getUserDetailsVo() {
		return userDetailsVo;
	}

	public void setUserDetailsVo(UserDetailsVo userDetailsVo) {
		this.userDetailsVo = userDetailsVo;
	}
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.objetos;

import java.util.Date;

/**
 *
 */
public class TablaProgramaColocacionSortDTO {
	private String semana;
	private String actividad;
	private Date inicioProgramado;
	private Date finalProgramado;

	public String getSemana() {
		return semana;
	}

	public void setSemana(String semana) {
		this.semana = semana;
	}

	public String getActividad() {
		return actividad;
	}

	public void setActividad(String actividad) {
		this.actividad = actividad;
	}

	public Date getInicioProgramado() {
		return inicioProgramado;
	}

	public void setInicioProgramado(Date inicioProgramado) {
		this.inicioProgramado = inicioProgramado;
	}

	public Date getFinalProgramado() {
		return finalProgramado;
	}

	public void setFinalProgramado(Date finalProgramado) {
		this.finalProgramado = finalProgramado;
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.rol.bean;

import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.rol.service.RolCatalogService.STEP_ACLS;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.rol.service.RolCatalogService.STEP_CONFIMR;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.FOLIO_VAL;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.MSJ_FOL_ALPHA;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.MSJ_FOL_REQ;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.TYPE_ROL_AS_STRING;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ApplicationVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolAclVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.SnapshotRolAcls;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.TabAplicacionAclUtil;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.WrapperSelectUtil;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.rol.service.RolCatalogService;

import org.primefaces.event.FlowEvent;
import org.primefaces.model.DefaultTreeNode;
import org.primefaces.model.TreeNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Controller;
import org.springframework.webflow.execution.RequestContext;



@Controller("mergeCatalogoRol")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class RolMergeCatalogoBean implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -9162996807803658418L;
	public static final String ALTA="Alta";
	public static final String CREATE="creado";
	public static final String CREACION="creacion";
	private static final String ERROR_NAME_EXIST="El nombre del rol $NAME ya existe.";
	private static final String MACRO="$NAME";
	private static final String ID_FIELD_NAME="form:idNombre";
	private static final String MSJ_ACLS="Seleccionar al menos un ACL para las aplicaciones: ";
	
	
	@Autowired
	@Qualifier("rolCatalogService")
	private RolCatalogService catalogoRolServcice;
	
	private List<ApplicationVo> aplicaciones;
	private List<ApplicationVo> selectedApps= new ArrayList<ApplicationVo>();
	private List<TabAplicacionAclUtil> tabsAclsApps= new ArrayList<TabAplicacionAclUtil>();
	private RolVo currentRol;
	private String tipoDeOperacion="";
	private String currentFolio;
	private String mensajeErrorAlta;
	private String titlePantalla;
	private String msgDialog;
	private String msgDialog2;
	@SuppressWarnings("unused")
	private String currentTypeRol;
	private WrapperSelectUtil currentRowSelected;
	private String oldNameEdit;
	private String oldSnapshotRolXML;
	private String msjErrorValidacion;
	
	
	
	public void initMerge( RequestContext ctx) throws TransactionalOVITException{
		aplicaciones=catalogoRolServcice.getAllApp();
		selectedApps= new ArrayList<ApplicationVo>();
		tabsAclsApps= new ArrayList<TabAplicacionAclUtil>();
		currentFolio="";
		currentTypeRol=ALTA;
		mensajeErrorAlta="";
		if(tipoDeOperacion.equals(ALTA)){
			initAlta();
		}else{
			initEdicion();
		}
		
	}
	
	
	
	private void initAlta() throws TransactionalOVITException{
		currentRol= new RolVo();
		oldSnapshotRolXML="";
		titlePantalla=ALTA;
		msgDialog=CREATE;
		msgDialog2=CREACION;
		currentFolio="";
	}

	private void initEdicion() throws TransactionalOVITException{
		selectedApps=catalogoRolServcice.getApliacionesByRol(currentRol);
		 List<RolAclVo> intialAclsAsigned= catalogoRolServcice.fillTabsAcls(selectedApps,currentRol,tabsAclsApps);	
		oldSnapshotRolXML=catalogoRolServcice.getXMLfromObject(new SnapshotRolAcls(currentRol, intialAclsAsigned));
		titlePantalla="Edici�n";
		msgDialog="editado";
		msgDialog2="edicion";
		oldNameEdit=currentRol.getNombre();
		currentFolio="";
	}
	
	
	
	
	public String onFlowProcess(FlowEvent event) throws TransactionalOVITException{
		String evento=event.getNewStep();
		msjErrorValidacion=MSJ_ACLS;
		if(STEP_ACLS.equals(evento)){
			
			if(hasChanges(currentRol.getNombre()) &&  catalogoRolServcice.existRolName(currentRol.getNombre()) ){
				evento=event.getOldStep();
				FacesContext.getCurrentInstance().addMessage(ID_FIELD_NAME, new FacesMessage(FacesMessage.SEVERITY_ERROR,"",ERROR_NAME_EXIST.replace(MACRO, currentRol.getNombre())));
				
			}else{
					catalogoRolServcice.fillTabsAcls(selectedApps,currentRol,tabsAclsApps);
					org.primefaces.context.RequestContext.getCurrentInstance().update(":form:wizardRol");
				}
			}	
		if(STEP_CONFIMR.equals(evento) && !catalogoRolServcice.validaAcls(tabsAclsApps).equals("success")){
				evento=event.getOldStep();
				msjErrorValidacion +=  catalogoRolServcice.validaAcls(tabsAclsApps);
				org.primefaces.context.RequestContext.getCurrentInstance().update(":form:messageSucces:labelConfirmOvit");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('errorAcls').show()");
				
			}
			
	   return evento;
    }
	
	
	
	private boolean hasChanges(String newName){
		if(!tipoDeOperacion.equals(ALTA) && newName.equals(oldNameEdit)){
			return false;
		}
		return true;
	}
	
	
	
	public void merge(ActionEvent event){
		org.primefaces.context.RequestContext context = org.primefaces.context.RequestContext.getCurrentInstance();
		boolean validation = false;
		boolean succes = false;

		if (this.currentFolio.trim().isEmpty()) {
			mensajeErrorAlta = MSJ_FOL_REQ;
		} else if (!this.currentFolio.matches(FOLIO_VAL)) {
			mensajeErrorAlta = MSJ_FOL_ALPHA;
		} else {
			validation = true;
			succes = catalogoRolServcice.merge(currentRol, selectedApps,tabsAclsApps,oldSnapshotRolXML,currentFolio);
		}

		context.addCallbackParam("succes", succes);
		context.addCallbackParam("validation", validation);
	}
	
	
	
	public void checkDefault(WrapperSelectUtil wrapperSelectUtil,DefaultTreeNode defaultTree){
		
		catalogoRolServcice.validaAcls(tabsAclsApps);
		
		if(wrapperSelectUtil.isSelected()){
			wrapperSelectUtil.setPermiso(true);
			wrapperSelectUtil.setDisablePermiso(false);
		}else{
			wrapperSelectUtil.setPermiso(false);
			wrapperSelectUtil.setDisablePermiso(true);
		}
		
		
	}
	
	
	@SuppressWarnings("unused")
	private void markChilds(TreeNode node,WrapperSelectUtil wrapperSelectUtil){
		
		if(node.getChildCount() > 0){
			for(TreeNode nodeChild: node.getChildren()){
				markChilds(nodeChild,wrapperSelectUtil);
			}
		}else{
			WrapperSelectUtil tempDataNode= (WrapperSelectUtil)node.getData();
			if(wrapperSelectUtil.getComponente().getIdComponente().equals(tempDataNode.getComponente().getIdComponente())){
				mark(wrapperSelectUtil);
			}
		}
		
	}
	
	
	private void mark(WrapperSelectUtil wrapperSelectUtil){
		if(wrapperSelectUtil.isSelected()){
			wrapperSelectUtil.setPermiso(true);
			wrapperSelectUtil.setDisablePermiso(false);
		}else{
			wrapperSelectUtil.setDisablePermiso(true);
		}
		
	}
	
	
	
	public WrapperSelectUtil getCurrentRowSelected() {
		return currentRowSelected;
	}



	public void setCurrentRowSelected(WrapperSelectUtil currentRowSelected) {
		this.currentRowSelected = currentRowSelected;
	}



	public void initDialog(){
		currentFolio="";
		mensajeErrorAlta="";
		
	}

	public List<ApplicationVo> getAplicaciones() {
		return aplicaciones;
	}


	public void setAplicaciones(List<ApplicationVo> aplicaciones) {
		this.aplicaciones = aplicaciones;
	}


	public List<ApplicationVo> getSelectedApps() {
		return selectedApps;
	}


	public void setSelectedApps(List<ApplicationVo> selectedApps) {
		this.selectedApps = selectedApps;
	}


	public List<TabAplicacionAclUtil> getTabsAclsApps() {
		return tabsAclsApps;
	}


	public void setTabsAclsApps(List<TabAplicacionAclUtil> tabsAclsApps) {
		this.tabsAclsApps = tabsAclsApps;
	}


	public RolVo getCurrentRol() {
		return currentRol;
	}


	public void setCurrentRol(RolVo currentRol) {
		this.currentRol = currentRol;
	}


	public String getTipoDeOperacion() {
		return tipoDeOperacion;
	}


	public void setTipoDeOperacion(String tipoDeOperacion) {
		this.tipoDeOperacion = tipoDeOperacion;
	}

	public String getCurrentFolio() {
		return currentFolio;
	}

	public void setCurrentFolio(String currentFolio) {
		this.currentFolio = currentFolio;
	}

	public String getMensajeErrorAlta() {
		return mensajeErrorAlta;
	}

	public void setMensajeErrorAlta(String mensajeErrorAlta) {
		this.mensajeErrorAlta = mensajeErrorAlta;
	}

	public String getTitlePantalla() {
		return titlePantalla;
	}

	public void setTitlePantalla(String titlePantalla) {
		this.titlePantalla = titlePantalla;
	}

	public String getMsgDialog() {
		return msgDialog;
	}

	public void setMsgDialog(String msgDialog) {
		this.msgDialog = msgDialog;
	}

	public String getCurrentTypeRol() {
		return TYPE_ROL_AS_STRING.get(this.getCurrentRol().getIdTipoRol());
	}

	public void setCurrentTypeRol(String currentTypeRol) {
		this.currentTypeRol = currentTypeRol;
	}

	public String getMsgDialog2() {
		return msgDialog2;
	}

	public void setMsgDialog2(String msgDialog2) {
		this.msgDialog2 = msgDialog2;
	}



	public String getMsjErrorValidacion() {
		return msjErrorValidacion;
	}



	public void setMsjErrorValidacion(String msjErrorValidacion) {
		this.msjErrorValidacion = msjErrorValidacion;
	}
	
	
}

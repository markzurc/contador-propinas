
package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.orbi.admin.fact.service;

import java.io.IOException;
import java.io.InputStream;

import javax.mail.Session;


public class SFTPConnector {
	 /**
     * Sesion SFTP establecida.
     */
    private Session session;
 
    /**
     * Establece una conexion SFTP.
     *
     * @param username Nombre de usuario.
     * @param password Contrasena.
     * @param host     Host a conectar.
     * @param port     Puerto del Host.
     *
     * @throws JSchException          Cualquier error al establecer
     *                                conexi�n SFTP.
     * @throws IllegalAccessException Indica que ya existe una conexion
     *                                SFTP establecida.
     */

 
    
}
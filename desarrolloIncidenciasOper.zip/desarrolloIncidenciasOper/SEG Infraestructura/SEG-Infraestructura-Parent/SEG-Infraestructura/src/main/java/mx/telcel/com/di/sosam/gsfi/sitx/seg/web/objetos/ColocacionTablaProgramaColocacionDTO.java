package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.objetos;

/**
 *
 * @author Jair Javier
 */
public class ColocacionTablaProgramaColocacionDTO {
    private String semana;
    private String actividad;
    private String inicioProgramado;
    private String finalProgramado;
    private String inicioReal;
    private String finalReal;

    public String getSemana() {
        return semana;
    }

    public void setSemana(String semana) {
        this.semana = semana;
    }

    public String getActividad() {
        return actividad;
    }

    public void setActividad(String actividad) {
        this.actividad = actividad;
    }

    public String getInicioProgramado() {
        return inicioProgramado;
    }

    public void setInicioProgramado(String inicioProgramado) {
        this.inicioProgramado = inicioProgramado;
    }

    public String getFinalProgramado() {
        return finalProgramado;
    }

    public void setFinalProgramado(String finalProgramado) {
        this.finalProgramado = finalProgramado;
    }

    public String getInicioReal() {
        return inicioReal;
    }

    public void setInicioReal(String inicioReal) {
        this.inicioReal = inicioReal;
    }

    public String getFinalReal() {
        return finalReal;
    }

    public void setFinalReal(String finalReal) {
        this.finalReal = finalReal;
    }
}

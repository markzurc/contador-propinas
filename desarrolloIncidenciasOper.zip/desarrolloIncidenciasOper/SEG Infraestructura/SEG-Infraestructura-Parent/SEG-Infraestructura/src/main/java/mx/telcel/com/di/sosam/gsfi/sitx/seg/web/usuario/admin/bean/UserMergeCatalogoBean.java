package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.usuario.admin.bean;

import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.FOLIO_VAL;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.MSJ_FOL_ALPHA;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.MSJ_FOL_REQ;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.STATUS_NUEVO;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.SUCCESS;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.USER_EXTENRO_TYPE;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.USER_EXTENRO_TYPE_STRING;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.USER_INETRNO_TYPE_STRING;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.USER_INTERNO_TYPE;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.VALIDATION;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.IBitacoraSoxBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.exception.SendingMailOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.OVITUtils;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.application.thirdparty.request.ApplicationGenericRequest;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ApplicationVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ExternalDataVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ExternalUserFindVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ExternalUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.InternalUserFindVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.InternalUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.UserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.RestrictionComponent;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.TabAplicacionAclUtil;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.rol.bean.RolViewDetailBean;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.user.service.UserCatalogService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.JsfUtil;

import org.primefaces.component.wizard.Wizard;
import org.primefaces.event.FlowEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.webflow.execution.RequestContext;

@Controller("userMergeCatalogoBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class UserMergeCatalogoBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2203082727753862026L;
	private static final int NUM_TABS_FIJAS = 2;
	private static final int INDEX_START_DYNTABS = 1;
	private static final String ID_TAB_CONFIRM = "confirm";
	private static final String ALTA = "Alta";
	
	
	private static final String CREATE="creado";
	private static final String CREACION="creaci�n";
	
	private static final String EDITAR="editado";
	private static final String EDICION="edici�n";
	
	private static final String ERROR_NAME_EXIST="El n�mero de empleado: $NAME ya existe.";
	private static final String MACRO="$NAME";
	private static final String ID_FIELD_NAME="form:idNumEmpl";
	private static final String ID_FIELD_USER_RESP="form:usrResp";
	private static final String MSJ_ERROR_USER_RESPONSIBLE="Debe seleccionar un usuario responsable";
	
	

	@Autowired
	@Qualifier("userCatalogService")
	private UserCatalogService catalogoUserServcice;

	@Autowired
	private ApplicationContext appContext;

	private ReportUserVo userFromHome;
	private UserVo currentUser;
	private String tipoDeOperacion;
	private RolVo currentRol;
	private List<RolVo> listRoles;
	private List<ApplicationVo> selectedApps = new ArrayList<ApplicationVo>();
	private List<ApplicationVo> aplicaciones = new ArrayList<ApplicationVo>();
	private List<TabAplicacionAclUtil> tabsAclsApps = new ArrayList<TabAplicacionAclUtil>();
	private Date fechaOperacion;
	private String userType;
	private ReportUserVo userSelectedFromDlg;
	private InternalUserFindVo currentResponsibleUser;
	private InternalUserFindVo currentInternalUser;
	private ExternalUserFindVo currentExternalUser;
	
	
	private String mailExternalUser;
	private String currentFolio;
	private String mensajeErrorAlta;
	private String msgCodErr;
	private String msgDialog;
	private String msgDialog2;
	private boolean internalUser;
	
	private String oldExternalUserVoXML;
	private String oldInternalUserVoXML;
	private String numeroEmpleado;
	private String numeroEmpleadoOld;
	private boolean readCampoUsuario;
	
	

	public void initMerge(RequestContext ctx) throws TransactionalOVITException {
		
		currentFolio="";
		numeroEmpleado="";
		internalUser=false;
		mensajeErrorAlta="";
		aplicaciones = catalogoUserServcice.getAllApp();
		if (tipoDeOperacion.equals(ALTA)) {
			initAlta();
		}else {
			initEdition();
		}

		listRoles = catalogoUserServcice.getRoles(currentUser.getIdTipoUsuario());

	}

	public void function()
			throws TransactionalOVITException {
		
		RolViewDetailBean rolViewDetailBean = (RolViewDetailBean) appContext
				.getBean("viewDetailRol");
		//rolViewDetailBean.setCurrentRol(currentRol);
		//rolViewDetailBean.initDetailRol(null);
		
		
		
		if (currentRol != null && currentRol.getIdRol()!= null) {
			selectedApps = catalogoUserServcice.getApliacionesByRol(currentRol);
		} else {
			selectedApps = new ArrayList<ApplicationVo>();
		}

		UIViewRoot root = FacesContext.getCurrentInstance().getViewRoot();
		UIComponent component = JsfUtil.findComponent(root, "wizardUser");
		Wizard wizard = (Wizard) component;
		clearDynamicTabs(wizard);

		int index = INDEX_START_DYNTABS;
		if(!OVITUtils.isEmptyList(selectedApps)){
		for (ApplicationVo app : selectedApps) {
			if (!isLoadTabApp(app)) {
				TabAplicacionAclUtil tabApp = new TabAplicacionAclUtil(app);
				tabApp.setId(app.getNombre().replace(" ", "_"));
				tabApp.setTitle(app.getNombre());
				tabApp.getChildren().clear();
				RestrictionComponent restrictionComponent = new RestrictionComponent();
				restrictionComponent.setId(("A"+Math.random()).replace(".", "A"));
				tabApp.getChildren().add(restrictionComponent);
				wizard.getChildren().add(index++, tabApp);
				tabsAclsApps.add(tabApp);
			} else {
				TabAplicacionAclUtil tabApp = getTabLoaded(app);
				wizard.getChildren().add(index++, tabApp);
			}

		}
		}
		 
	}
	
	
	private String getFristTabApp(){
		UIViewRoot root = FacesContext.getCurrentInstance().getViewRoot();
		UIComponent component = JsfUtil.findComponent(root, "wizardUser");
		Wizard wizard = (Wizard) component;
		return wizard.getChildren().get(INDEX_START_DYNTABS).getId();
		
	}
	
	public String onFlowProcess(FlowEvent event) throws TransactionalOVITException{
		String evento=event.getNewStep();
		String evento2=event.getOldStep();
		
		
		if(evento2.equals("datosUser")){
			
			if(hasChanges(numeroEmpleado) &&  catalogoUserServcice.existUser(numeroEmpleado) ){
				evento=evento2;
				FacesContext.getCurrentInstance().addMessage(ID_FIELD_NAME, new FacesMessage(FacesMessage.SEVERITY_ERROR,"",ERROR_NAME_EXIST.replace(MACRO, numeroEmpleado)));
			}
			
			if(currentResponsibleUser.getUserVo() ==null && !this.internalUser){
				evento=evento2;
				FacesContext.getCurrentInstance().addMessage(ID_FIELD_USER_RESP, new FacesMessage(FacesMessage.SEVERITY_ERROR,"",MSJ_ERROR_USER_RESPONSIBLE));
			}else{
				function();
				org.primefaces.context.RequestContext.getCurrentInstance().execute("onload()");
				evento=getFristTabApp();
			}
		
		}
			
	   return evento;
    }
	
	
	
	private boolean hasChanges(String newName){
		if(!tipoDeOperacion.equals(ALTA) && newName.equals(numeroEmpleadoOld)){
			return false;
		}
		return true;
	}
	
	
	
	public void selectUserFromDialog() throws TransactionalOVITException {
		currentResponsibleUser= catalogoUserServcice.loadUserInternal(userSelectedFromDlg.getIdUsuario());
				
	}
	
	

	private void clearDynamicTabs(Wizard wizard) {
		int childCount = wizard.getChildren().size();
		if (childCount > NUM_TABS_FIJAS) {
			UIComponent tempTabConfirm = getConfirmTab(wizard);
			for (int index = INDEX_START_DYNTABS; index < childCount; index++) {
				wizard.getChildren().remove(INDEX_START_DYNTABS);
			}
			wizard.getChildren().add(INDEX_START_DYNTABS, tempTabConfirm);
		}

	}

	private UIComponent getConfirmTab(Wizard wizard) {
		UIComponent uiComponent = null;
		for (UIComponent componet : wizard.getChildren()) {
			if (componet.getId().equals(ID_TAB_CONFIRM)){
				uiComponent = componet;
				}
		}
		return uiComponent;
	}

	private boolean isLoadTabApp(ApplicationVo app) {
		return tabsAclsApps.contains(new TabAplicacionAclUtil(app));
	}

	private TabAplicacionAclUtil getTabLoaded(ApplicationVo app) {
		for (TabAplicacionAclUtil tabAplicacionAclUtil : tabsAclsApps) {
			if (tabAplicacionAclUtil.getAplicacion().equals(app)) {
				return tabAplicacionAclUtil;
			}
		}
		return null;
	}

	
	public void merge() throws TransactionalOVITException, SendingMailOVITException{
		
		if (tipoDeOperacion.equals(ALTA)) {
			alta();
		}else {
			edition();
		}

		
	}
	
	
	public void edition() throws TransactionalOVITException {
		org.primefaces.context.RequestContext context = org.primefaces.context.RequestContext.getCurrentInstance();
		boolean validation = false;
		boolean succes = false;
		UserDetailsVo userDetailsVo =(UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		if (this.currentFolio.trim().isEmpty()) {
			mensajeErrorAlta = MSJ_FOL_REQ;
		} else if (!this.currentFolio.matches(FOLIO_VAL)) {
			mensajeErrorAlta = MSJ_FOL_ALPHA;
		} else {
			currentFolio="";
			mensajeErrorAlta="";
			validation = true;
			if(userFromHome.getIdTipoUsuario().equals(USER_EXTENRO_TYPE)){
				ExternalUserVo externalUserVo = new ExternalUserVo();
				externalUserVo.setUserVo(currentExternalUser.getUserVo());
				externalUserVo.getUserVo().setIdRol(this.currentRol.getIdRol());
				currentExternalUser.getExternalDataUser().setCorreo(mailExternalUser);
				currentExternalUser.getUserVo().setFechaModificacion(new Date());
				currentExternalUser.getUserVo().setUsuarioModificacion(userDetailsVo.getNumeroEmpleado());
				externalUserVo.setExternalDataVo(currentExternalUser.getExternalDataUser());
				externalUserVo.getExternalDataVo().setIdResponsable(currentResponsibleUser.getUserVo().getIdUsuario());
				
				succes = catalogoUserServcice.updateUser(externalUserVo,null);
				
				if(succes){
					catalogoUserServcice.registraEnBitacora(oldExternalUserVoXML, externalUserVo, currentFolio, IBitacoraSoxBusiness.UPDATE);
				}else{
					catalogoUserServcice.registraEnBitacora(oldExternalUserVoXML, externalUserVo, currentFolio, IBitacoraSoxBusiness.ERROR_MODIFY);
				}
				
			}
			else{
				InternalUserVo internalUserVo = new InternalUserVo();
				currentInternalUser.getUserVo().setFechaModificacion(new Date());
				currentInternalUser.getUserVo().setUsuarioModificacion(userDetailsVo.getNumeroEmpleado());
				internalUserVo.setUserVo(currentInternalUser.getUserVo());
				internalUserVo.setInternalDataVo(currentInternalUser.getInternalDataVo());
				internalUserVo.getUserVo().setIdRol(this.currentRol.getIdRol());
				succes = catalogoUserServcice.updateUser(null,null);
				
				if(succes){
					catalogoUserServcice.registraEnBitacora(oldInternalUserVoXML, internalUserVo, currentFolio, IBitacoraSoxBusiness.UPDATE);
				}else{
					catalogoUserServcice.registraEnBitacora(oldInternalUserVoXML, internalUserVo, currentFolio, IBitacoraSoxBusiness.ERROR_MODIFY);
				}
				
				}
		}

		context.addCallbackParam(SUCCESS, succes);
		context.addCallbackParam(VALIDATION, validation);
		
	}
	
	
	public void alta() throws TransactionalOVITException, SendingMailOVITException {

		UserDetailsVo userDetailsVo =(UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		
		
		
		ExternalUserVo externalUserVo = new ExternalUserVo();
	    ExternalDataVo externalDataVo = new ExternalDataVo(currentResponsibleUser.getUserVo().getIdUsuario(),mailExternalUser);
	    currentUser.setFechaLogueo(new Date());
	    currentUser.setIdRol(currentRol.getIdRol());
	    currentUser.setIdEstatus(STATUS_NUEVO);
	    currentUser.setFechaModificacion(new Date());
	    currentUser.setUsuarioModificacion(userDetailsVo.getNumeroEmpleado());
	    currentUser.setFechaCreacion(new Date());
	    currentUser.setUsuarioCreacion(userDetailsVo.getNumeroEmpleado());
	    externalUserVo.setUserVo(currentUser);
	    externalDataVo.setNumeroEmpleado(numeroEmpleado);
		externalUserVo.setExternalDataVo(externalDataVo);
		List<ApplicationGenericRequest> listRequest = new ArrayList<ApplicationGenericRequest>();
		
		
		org.primefaces.context.RequestContext context = org.primefaces.context.RequestContext.getCurrentInstance();
		boolean validation = false;
		boolean succes = false;

		if (this.currentFolio.trim().isEmpty()) {
			mensajeErrorAlta = MSJ_FOL_REQ;
		} else if (!this.currentFolio.matches(FOLIO_VAL)) {
			mensajeErrorAlta = MSJ_FOL_ALPHA;
		} else {
			currentFolio="";
			mensajeErrorAlta="";
			validation = true;
			String resp = catalogoUserServcice.createUser(externalUserVo, listRequest);
			if(resp.equals("success")){
				succes=true;
			}else if(resp.equals("error_mail")){
				succes=false;
				msgCodErr= "Favor de validar si el correo es correcto.";
			}
		}
		
		if(succes){
			catalogoUserServcice.registraEnBitacora("", externalUserVo, currentFolio, IBitacoraSoxBusiness.CREATE);
		}else{
			catalogoUserServcice.registraEnBitacora("", externalUserVo, currentFolio, IBitacoraSoxBusiness.ERROR_CREATE);
		}

		context.addCallbackParam(SUCCESS, succes);
		context.addCallbackParam(VALIDATION, validation);
				
	}

	private void initAlta() throws TransactionalOVITException {
		readCampoUsuario=false;
		currentUser = new UserVo();
		currentUser.setIdTipoUsuario(USER_EXTENRO_TYPE);
		fechaOperacion = new Date();
		userType=USER_EXTENRO_TYPE_STRING;
		userSelectedFromDlg= new ReportUserVo();
		currentResponsibleUser= new InternalUserFindVo();
		currentRol= new RolVo();
		
		mailExternalUser="";
		msgDialog=CREATE;
		msgDialog2=CREACION;
		msgCodErr="";
	}

	private void initEdition() throws TransactionalOVITException {
		readCampoUsuario=true;
		numeroEmpleadoOld=userFromHome.getNumeroEmpleado();
		msgCodErr="";
		if(userFromHome.getIdTipoUsuario().equals(USER_EXTENRO_TYPE)){
			
			fechaOperacion = new Date();
			currentExternalUser=catalogoUserServcice.loadUserExternal(userFromHome.getIdUsuario());
			currentUser=currentExternalUser.getUserVo();
			numeroEmpleado=currentExternalUser.getExternalDataUser().getNumeroEmpleado();
			currentRol=catalogoUserServcice.loadRolbyId(currentUser.getIdRol());
			userType=USER_EXTENRO_TYPE_STRING;
			currentResponsibleUser=new InternalUserFindVo();
			currentResponsibleUser.setInternalDataVo(currentExternalUser.getResponsibleUser().getInternalDataVo());
			currentResponsibleUser.setUserVo(currentExternalUser.getResponsibleUser().getUserVo());
			userSelectedFromDlg= new ReportUserVo();
			userSelectedFromDlg.setIdUsuario(currentResponsibleUser.getUserVo().getIdUsuario());
			userSelectedFromDlg.setNumeroEmpleado(currentResponsibleUser.getInternalDataVo().getNumeroEmpleado());
			this.internalUser=false;
			
			
			mailExternalUser=currentExternalUser.getExternalDataUser().getCorreo();
			
			ExternalUserVo oldExternalUserVo = new ExternalUserVo();
			oldExternalUserVo.setUserVo(currentExternalUser.getUserVo());
			oldExternalUserVo.getUserVo().setIdRol(this.currentRol.getIdRol());
			oldExternalUserVo.setExternalDataVo(currentExternalUser.getExternalDataUser());
			oldExternalUserVoXML=catalogoUserServcice.getXMLfromObject(oldExternalUserVo);
			
		}else if(userFromHome.getIdTipoUsuario().equals(USER_INTERNO_TYPE)){
			
			
			
			userSelectedFromDlg= new ReportUserVo();
			currentInternalUser= catalogoUserServcice.loadUserInternal(userFromHome.getIdUsuario());
			currentUser=currentInternalUser.getUserVo();
			numeroEmpleado=currentInternalUser.getInternalDataVo().getNumeroEmpleado();
			currentRol=catalogoUserServcice.loadRolbyId(currentUser.getIdRol());
			userType=USER_INETRNO_TYPE_STRING;
			currentResponsibleUser=new InternalUserFindVo();
			this.internalUser=true;
			mailExternalUser=currentInternalUser.getInternalDataVo().getCorreo();
			
			
			//guaradando una copia del objeto a guardar
			InternalUserVo oldInternalUserVo = new InternalUserVo();
			oldInternalUserVo.setUserVo(currentInternalUser.getUserVo());
			oldInternalUserVo.setInternalDataVo(currentInternalUser.getInternalDataVo());
			oldInternalUserVo.getUserVo().setIdRol(this.currentRol.getIdRol());
			oldExternalUserVoXML=catalogoUserServcice.getXMLfromObject(oldInternalUserVo);
			
		}
		
		msgDialog=EDITAR;
		msgDialog2=EDICION;
		
		
	}

	
	
	
	public ReportUserVo getUserFromHome() {
		return userFromHome;
	}

	public void setUserFromHome(ReportUserVo userFromHome) {
		this.userFromHome = userFromHome;
	}

	public UserVo getCurrentUser() {
		return currentUser;
	}

	public void setCurrentUser(UserVo currentUser) {
		this.currentUser = currentUser;
	}

	public String getTipoDeOperacion() {
		return tipoDeOperacion;
	}

	public void setTipoDeOperacion(String tipoDeOperacion) {
		this.tipoDeOperacion = tipoDeOperacion;
	}

	public List<ApplicationVo> getSelectedApps() {
		return selectedApps;
	}

	public void setSelectedApps(List<ApplicationVo> selectedApps) {
		this.selectedApps = selectedApps;
	}

	public List<ApplicationVo> getAplicaciones() {
		return aplicaciones;
	}

	public void setAplicaciones(List<ApplicationVo> aplicaciones) {
		this.aplicaciones = aplicaciones;
	}

	public List<TabAplicacionAclUtil> getTabsAclsApps() {
		return tabsAclsApps;
	}

	public void setTabsAclsApps(List<TabAplicacionAclUtil> tabsAclsApps) {
		this.tabsAclsApps = tabsAclsApps;
	}



	public Date getFechaOperacion() {
		return fechaOperacion;
	}

	public void setFechaOperacion(Date fechaOperacion) {
		this.fechaOperacion = fechaOperacion;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public RolVo getCurrentRol() {
		return currentRol;
	}

	public void setCurrentRol(RolVo currentRol) {
		this.currentRol = currentRol;
	}

	public List<RolVo> getListRoles() {
		return listRoles;
	}

	public void setListRoles(List<RolVo> listRoles) {
		this.listRoles = listRoles;
	}

	

	
	public InternalUserFindVo getCurrentResponsibleUser() {
		return currentResponsibleUser;
	}

	public void setCurrentResponsibleUser(InternalUserFindVo currentResponsibleUser) {
		this.currentResponsibleUser = currentResponsibleUser;
	}

	public ReportUserVo getUserSelectedFromDlg() {
		return userSelectedFromDlg;
	}

	public void setUserSelectedFromDlg(ReportUserVo userSelectedFromDlg) {
		this.userSelectedFromDlg = userSelectedFromDlg;
	}

	

	public String getMailExternalUser() {
		return mailExternalUser;
	}

	public void setMailExternalUser(String mailExternalUser) {
		this.mailExternalUser = mailExternalUser;
	}

	public String getCurrentFolio() {
		return currentFolio;
	}

	public void setCurrentFolio(String currentFolio) {
		this.currentFolio = currentFolio;
	}

	public String getMensajeErrorAlta() {
		return mensajeErrorAlta;
	}

	public void setMensajeErrorAlta(String mensajeErrorAlta) {
		this.mensajeErrorAlta = mensajeErrorAlta;
	}

	public void initDialog(){
		currentFolio="";
		mensajeErrorAlta="";
		
	}

	public String getMsgDialog() {
		return msgDialog;
	}

	public void setMsgDialog(String msgDialog) {
		this.msgDialog = msgDialog;
	}

	public String getMsgDialog2() {
		return msgDialog2;
	}

	public void setMsgDialog2(String msgDialog2) {
		this.msgDialog2 = msgDialog2;
	}

	public boolean isInternalUser() {
		return internalUser;
	}

	public void setInternalUser(boolean internalUser) {
		this.internalUser = internalUser;
	}

	public InternalUserFindVo getCurrentInternalUser() {
		return currentInternalUser;
	}

	public void setCurrentInternalUser(InternalUserFindVo currentInternalUser) {
		this.currentInternalUser = currentInternalUser;
	}

	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}

	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	public String getMsgCodErr() {
		return msgCodErr;
	}

	public void setMsgCodErr(String msgCodErr) {
		this.msgCodErr = msgCodErr;
	}

	public boolean isReadCampoUsuario() {
		return readCampoUsuario;
	}

	public void setReadCampoUsuario(boolean readCampoUsuario) {
		this.readCampoUsuario = readCampoUsuario;
	}

	
	
	
	
}

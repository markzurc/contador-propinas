package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.sitios.bean;

import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.IBitacoraService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.elementosPantalla.IElementosPantallaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.solicitudes.ISolicitudesService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dto.BitacoraDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ElementosPantallaDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SolicitudDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dto.AccionAvanceDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dto.GraficaDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dto.TranEstaInfDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.ReporteSegUtil;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.proyecto.bean.SolicitudProyectoPresupuestoBean;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.reportes.service.BitacoraService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.solicitud.bean.SolicitudInformacionBean;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.visitaTecnica.bean.VisitaTecnicaBean;

@Controller("detalleSolicitudBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class DetalleSolicitudBean implements Serializable {

	private static final long serialVersionUID = 4529164763930375519L;
	private static final Logger LOGGER = LogManager.getLogger(DetalleSolicitudBean.class);
	private String styles;
	private SitioDto parametroSitio;
	private SolicitudDto parametroSolicitud;
	private String servicioSelect;
    private String tipoInfReqSelec;
    private List<GraficaDto> listaGrafica;
    private int valorGrafica;
    private int valorTab;
    private List<TranEstaInfDto> listaTranEstaInf;
    private String seleccionTransicion; 
    private UserDetailsVo userDetailsVo;
    
    private String fromPantalla;
    private String accionAvanceSelect;
    
	private List<ElementosPantallaDTO> listElemPantalla;
	Map<String, Integer> map =	new HashMap<String,Integer>();
	SolicitudDto sitioConSolicitud = new SolicitudDto();
	private String headerDialogo;
	private String mensajeDialogo;
	private String idEstatusBitacora;
	private String idAccionBitacora;
	private String idSolicitudBitacora;
	private String idGrupoOperadorBitacora;
	private String estatus;
	
	private List<BitacoraDto> listaAccionesBitacora;

	@Autowired
	private ISolicitudesService consultaServiciosServiceImpl;
	
	@Autowired
	private IElementosPantallaService elementosPantalla;
	
	@Autowired
	private SolicitudProyectoPresupuestoBean solicitudProyectoPresupuestoBean;
	
	@Autowired
	private SolicitudAnalisisFactibilidadBean solicitudAnalisisFactibilidadBean;
	
	@Autowired
	private ResultadoAnalisisFactibilidadBean resultadoAnalisisFactibilidadBean;
	
	@Autowired
	private SolicitudInformacionBean solicitudInformacionBean;
	
	@Autowired
	private VisitaTecnicaBean visitaTecnica;
	
	@Autowired
	private IBitacoraService bitacoraServiceImpl;
        
    @Autowired
    private ColocacionBean colocacionBean;
    
    @Autowired
    @Qualifier("bitacoraService")
    private BitacoraService bitacoraService;
	
	
	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		String nombreEstadoVista = rc.getCurrentState().getId() + fromPantalla;
		userDetailsVo = (UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		
		if (parametroSolicitud != null) {
			listaAccionesBitacora = bitacoraServiceImpl.obtenerAcciones(parametroSolicitud.getFolio());
		}  else {
			listaAccionesBitacora = new ArrayList<>();
		}
		
		try {
			seleccionTransicion = "";
			
			if (fromPantalla.equals("Crea")) {
				sitioConSolicitud = consultaServiciosServiceImpl.getSitioConSolicitudCrea(parametroSitio, consultaServiciosServiceImpl.getGpoOperUsuById(userDetailsVo.getIdUsuario().toString()));			
			}else if (fromPantalla.equals("Consulta")) {
				sitioConSolicitud = consultaServiciosServiceImpl.getSitioConSolicitudConsulta(parametroSitio);//se consulta para saber el estatus de la solicitud en caso de que exista			
				//listaAccionesAvance = consultaServiciosServiceImpl.getListaAcciones();			
			}

			
			map.put("idRolUsuario", userDetailsVo.getIdRol());
			if (sitioConSolicitud != null) {
				map.put("idEstatusOrden", Integer.valueOf(sitioConSolicitud.getIdEstado()));
			}else {
				map.put("idEstatusOrden", 0); //Se  le asigna 0 por default, no hay solicitud generada para este sitio
			}
			
			listElemPantalla = elementosPantalla.getElementosPermitidosPantalla(nombreEstadoVista, userDetailsVo.getIdRol(), map);
					
			if(servicioSelect == null) {
				servicioSelect = "";
			}
			if(servicioSelect.equals("")) {
				listaGrafica = consultaServiciosServiceImpl.getDatosGrafica(parametroSolicitud.getIdEstado());
				valorGrafica = listaGrafica.get(0).getValorGrafica();
				valorTab = listaGrafica.get(0).getValorTab();
				styles = this.darEstilo(listaGrafica.get(0).getColor());
				listaTranEstaInf = consultaServiciosServiceImpl.getDatosTransicion(parametroSolicitud.getIdEstado(), userDetailsVo.getIdRol());
			} else if(servicioSelect.equals("1")) {
				valorGrafica = 0;
				valorTab = 0;
				styles = this.darEstilo("#FFC000");
				listaTranEstaInf = consultaServiciosServiceImpl.getDatosTransicion("0", userDetailsVo.getIdRol());
			} else if(servicioSelect.equals("2")) {
				valorGrafica = 1;
				valorTab = 1;
				styles = this.darEstilo("#FFC000");
				listaTranEstaInf = consultaServiciosServiceImpl.getDatosTransicion("0", userDetailsVo.getIdRol());
			}
			servicioSelect = "";
			
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al cargar la p�gina");
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","Ocurrio un error al cargar la p�gina"));
		}
	}

    public void avanzarEstatus() {
        try {
            SolicitudDto solicitudAux = consultaServiciosServiceImpl.getSitioConSolicitudConsulta(parametroSitio);
			String estatusActual = solicitudAux.getIdEstado();
			if (parametroSolicitud.getIdEstado().equals(estatusActual)) {
                String[] valoresTransicion = seleccionTransicion.split("\\|");
                idEstatusBitacora = valoresTransicion[0];
                idAccionBitacora = valoresTransicion[2];
                idSolicitudBitacora = parametroSolicitud.getFolio();
                idGrupoOperadorBitacora = parametroSolicitud.getGrupoOperador();
                switch (valoresTransicion[1]) {
                    case "solicitudInformacionBean":
                        solicitudInformacionBean.avanzarEstatus(valoresTransicion[0]);
                        break;
                    case "solicitudAnalisisFactibilidadBean":
                        solicitudAnalisisFactibilidadBean.avanzarSoliFacti(valoresTransicion[0]);
                        break;
                    case "autorizarResultadoAnalisisFactibilidadBean":
    					resultadoAnalisisFactibilidadBean.autorizarResulFacti(valoresTransicion[0]);
    					break;
    				case "rechazarResultadoAnalisisFactibilidadBean":
    					resultadoAnalisisFactibilidadBean.rechazarResulFacti(valoresTransicion[0]);
    					break;
                    case "solicitudProyectoPresupuesto":
                        solicitudProyectoPresupuestoBean.crearSolicitudPp(valoresTransicion[0]);
                        break;
                    case "atenderProyectoPresupuesto":
                        solicitudProyectoPresupuestoBean.atenderSolicitudPp(valoresTransicion[0]);
                        break;
                    case "rechazarProyectoPresupuesto":
                        solicitudProyectoPresupuestoBean.limpiarMotivoRechazo();
                        org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgRechazarSolicitudPp').show();");
                        break;
                    case "rechazarConcesionarioProyectoPresupuesto":
                        solicitudProyectoPresupuestoBean.rechazarConcesionarioSolicitudPp(valoresTransicion[0]);
                        break;
                    case "corregirProyectoPresupuesto":
                        solicitudProyectoPresupuestoBean.corregirSolicitudPp(valoresTransicion[0]);
                        break;
                    case "solicitarPagoProyectoPresupuesto":
                        solicitudProyectoPresupuestoBean.solicitarPagoPp(valoresTransicion[0]);
                        break;
                    case "finalizarSolicitudProyectoPresupuesto":
                        solicitudProyectoPresupuestoBean.solicitarPagoPp(valoresTransicion[0]);
                        break;
                    case "solicitarAdecuacionRecuperacionProyectoPresupuesto":
                        solicitudProyectoPresupuestoBean.solicitarRecuperacionAdecuacionPp(valoresTransicion[0]);
                        break;
                    case "solicitarAcuerdoSitioProyectoPresupuesto":
                        solicitudProyectoPresupuestoBean.solicitarAcuerdoSitioPp(valoresTransicion[0]);
                        break;
                    case "cancelacion":
                        cancelarSolicitud(valoresTransicion[0]);
                        break;
                    case "solicitudVisitaTecnica":
                        visitaTecnica.solicitudVisitaTecnica(valoresTransicion[0], ConfigOvitIdentifierEnum.TipoAccionVisitaTecnica.SOLICITUD.getTipoAccion());
                        break;
                    case "aprobarVisitaTecnica":
                        visitaTecnica.autorizarVisitaTecnica(valoresTransicion[0]);
                        break;
                    case "rechazarVisitaTecnica":
                        visitaTecnica.rechazarVisitaTecnica(valoresTransicion[0]);
                        break;
                    case "corregirVisitaTecnica":
                        visitaTecnica.solicitudVisitaTecnica(valoresTransicion[0], ConfigOvitIdentifierEnum.TipoAccionVisitaTecnica.CORRECCION.getTipoAccion());
                        break;
                    case "cancelarMotivoRechazo":
                    	solicitudAnalisisFactibilidadBean.limpiarMotivoRechazo();
                        org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgRechazarSolicitud').show();");
                        break;
                    case "colocacionBean":
                    	colocacionBean.limpiarMotivoRechazoSoliColo();
                        colocacionBean.avanzarEstatusColocacion(valoresTransicion, parametroSolicitud);
                        break;
                    case "generarProgramaColocacion":
                        colocacionBean.generaProgramaColocacion(valoresTransicion, parametroSolicitud);
                        break;
                    case "completarProgramaColocacion":
                        colocacionBean.completarColocacion(valoresTransicion);
                        break;
                    case "solicitarVerificacionColocacion":
                        colocacionBean.solicitarVerificacionColocacion(valoresTransicion[0]);
                        break;
                    case "finalizarSolicitudColocacion":
                        colocacionBean.finalizarSolicitudColocacion(valoresTransicion[0]);
                        break;
                    case "rechazarVerificacionColocacion":
                        colocacionBean.limpiarMotivoRechazo();
                        //colocacionBean.rechazarVerificacionColocacion(valoresTransicion[0]);
                        org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgRechazarSolicitudVc').show();");
                        break;
                    case "corregirVerificacionColocacion":
                        colocacionBean.corregirVerificacionColocacion(valoresTransicion[0]);
                        break;
                    case "facturacionColocacionGenerada":
                        colocacionBean.facturacionColocacionGenerada(valoresTransicion[0]);
                        break;
                    default:
                        break;
                }
            } else {
				headerDialogo = "Actualizar Estatus";
				mensajeDialogo = "Error, el estado de la solicitud ha sido modificado por otro usuario.";
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli2').show();");
			}
        } catch (Exception e) {
            LOGGER.info("Ocurrio un error al avanzar el estatus de la solicitud " + e);
            headerDialogo = "Actualizar Estatus";
            mensajeDialogo = "Ocurrio un error al avanzar el estatus de la solicitud.";
            org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
        }
    }
    
    public void confirmaAvance() {
		if (!seleccionTransicion.equals("")) {
			String[] valoresTransicion = seleccionTransicion.split("\\|");
			idAccionBitacora = valoresTransicion[2];
			headerDialogo = "Actualizar Estatus";
			estatus = valoresTransicion[3];
			mensajeDialogo = "�Esta seguro que desea avanzar el estado de la solicitud a "+ estatus +"?";
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjConfStatus').show();");
		} else {
			headerDialogo = "Actualizar Estatus";
			mensajeDialogo = "Debe seleccionar una opci�n de actualizaci�n.";
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
		}
	}
	
	public void insertarBitacora(String motivoRechazo) {
		Date todayDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String fechaActual = sdf.format(todayDate);
		BitacoraDto bitacoraDto = new BitacoraDto();
		bitacoraDto.setIdSolicitud(idSolicitudBitacora);
		bitacoraDto.setIdUsuario(userDetailsVo.getIdUsuario().toString());
		bitacoraDto.setIdEmpresa(idGrupoOperadorBitacora);
		bitacoraDto.setIdEstatusFlujo(idEstatusBitacora);
		bitacoraDto.setFechaMovimiento(fechaActual);
		bitacoraDto.setIdAccion(idAccionBitacora);
		bitacoraDto.setMotivoRechazo(motivoRechazo);
		
		bitacoraServiceImpl.insertaBitacora(bitacoraDto);
		
	}

	private void cancelarSolicitud(String estatus) {
		try {
			boolean solicitudCanc = consultaServiciosServiceImpl.updateSolicitud(parametroSitio, estatus);
			if (solicitudCanc) {
				insertarBitacora("");
				headerDialogo = "Cancelar Solicitud";
				mensajeDialogo = "Se cancelo la solicitud de forma exitosa.";
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli').show();");
			} else {
				headerDialogo = "Cancelar Solicitud";
				mensajeDialogo = "Ocurri� un error al cancelar la solicitud.";
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
			}
		} catch (Exception e) {
			LOGGER.info("Ocurrio un error al cancelar la solicitud: " + e);
			headerDialogo = "Cancelar Solicitud";
			mensajeDialogo = "Ocurri� un error al cancelar la solicitud.";
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}

	public boolean getVisible(String nombreComponente) {
		boolean visible=false;
		for(ElementosPantallaDTO elemento : listElemPantalla) {
			if(elemento.getIdElemento().equals(nombreComponente)) {
				visible=elemento.isVisible();
			}
		}
		return visible;
	}
	
	public boolean getEditable(String nombreComponente) {
		boolean visible=false;
		for(ElementosPantallaDTO elemento : listElemPantalla) {
			if(elemento.getIdElemento().equals(nombreComponente)) {
				visible=elemento.isEditable();
			}
		}
		return visible;
	}
	
	
	public void validaSeleccionAccion() {
	    if (accionAvanceSelect != null) {
	    	System.out.println("Estatus a avanzar: " +  accionAvanceSelect);
		}
	}

	public String getStyles() {
		return styles;
	}

	public void setStyles(String styles) {
		this.styles = styles;
	}

	private String darEstilo(String color) {
		 return new StringBuffer()
				
			        .append(".ui-steps.custom {\r\n"
			        		+ "    			margin-bottom: 30px;\r\n"
			        		+ "    		}")
			        .append(".ui-steps.custom .ui-steps-item .ui-menuitem-link {\r\n"
			        		+ "    			height: 10px;\r\n"
			        		+ "    			padding: 0 1em; \r\n"
			        		+ "    		}")
			        .append(".ui-steps.custom .ui-steps-item .ui-steps-number {\r\n"
			        		+ "    			background-color: #0081c2;\r\n"
			        		+ "    			color: #FFFFFF;\r\n"
			        		+ "    			display: inline-block;\r\n"
			        		+ "    			width: 30px;\r\n"
			        		+ "    			border-radius: 10px;\r\n"
			        		+ "    			margin-top: -10px;\r\n"
			        		+ "    			margin-bottom: 10px;\r\n"
			        		+ "    			margin-bottom: 10px;\r\n"
			        		+ "    		}")  
			        .append(".ui-widget-overlay {\r\n"
			        		+ "    			position: fixed;\r\n"
			        		+ "    		}")
			      
			        .append(".ui-state-highlight a, .ui-widget-content .ui-state-highlight a, .ui-widget-header .ui-state-highlight a{\r\n"
			        		+ "  					 	color: #000000;\r\n"
			        		+ "  					 	font-weight: bold;\r\n"
			        		+ "  						background-color:"+color+";\r\n"
			        		+ "  					  \r\n"
			        		+ "					}")
			        .toString();

	}
	
	public void mensajeExito(String headerMsj, String bodyMsj){
		headerDialogo = headerMsj;
		mensajeDialogo = bodyMsj;
		org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli').show();");
		
	}
	
	public void mensajeWarning(String headerMsj, String bodyMsj){
		headerDialogo = headerMsj;
		mensajeDialogo = bodyMsj;
		org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
		
	}
	
	public void mensajeError(String headerMsj, String bodyMsj){
		headerDialogo = headerMsj;
		mensajeDialogo = bodyMsj;
		org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		
	}
	
	public void mensajeConfirmacion(String headerMsj, String bodyMsj){
		headerDialogo = headerMsj;
		mensajeDialogo = bodyMsj;
		org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli2').show();");
		
	}
	
	public void getReporte() throws EncryptedDocumentException, InvalidFormatException, IOException {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		try {
			XSSFWorkbook workbook = new XSSFWorkbook();
			String fechaReporte = ReporteSegUtil.fechaReporte();
			bitacoraService.toExcelBitacora(workbook, listaAccionesBitacora);

			ExternalContext externalContext = facesContext.getExternalContext();
			externalContext.setResponseContentType("application/vnd.ms-excel");
			externalContext.setResponseHeader("Content-Disposition",
					"attachment; filename=\"Reporte SEG Bit�cora de Movimientos " + fechaReporte + " v01.xlsx\"");

			OutputStream out = externalContext.getResponseOutputStream();
			workbook.write(out);
		    out.flush();
		} catch (IOException e) {
			LOGGER.error("Error al crear el Reporte de Bitacora de Movimientos: " + e);
			headerDialogo = "Reporte Bit�cora de Movimientos";
			mensajeDialogo = "Error al crear el Reporte de Bitacora de Movimientos.";
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
		facesContext.responseComplete();		    
	}
	
	public SitioDto getParametroSitio() {
		return parametroSitio;
	}

	public void setParametroSitio(SitioDto parametroSitio) {
		this.parametroSitio = parametroSitio;
	}
	
	public String getServicioSelect() {
		return servicioSelect;
	}

	public void setServicioSelect(String servicioSelect) {
		this.servicioSelect = servicioSelect;
	}

	public String getTipoInfReqSelec() {
		return tipoInfReqSelec;
	}

	public void setTipoInfReqSelec(String tipoInfReqSelec) {
		this.tipoInfReqSelec = tipoInfReqSelec;
	}

	public SolicitudDto getParametroSolicitud() {
		return parametroSolicitud;
	}

	public void setParametroSolicitud(SolicitudDto parametroSolicitud) {
		this.parametroSolicitud = parametroSolicitud;
	}

	public int getValorGrafica() {
		return valorGrafica;
	}

	public void setValorGrafica(int valorGrafica) {
		this.valorGrafica = valorGrafica;
	}
	
	public int getValorTab() {
		return valorTab;
	}

	public void setValorTab(int valorTab) {
		this.valorTab = valorTab;
	}

	public List<TranEstaInfDto> getListaTranEstaInf() {
		return listaTranEstaInf;
	}

	public void setListaTranEstaInf(List<TranEstaInfDto> listaTranEstaInf) {
		this.listaTranEstaInf = listaTranEstaInf;
	}

	public String getSeleccionTransicion() {
		return seleccionTransicion;
	}

	public void setSeleccionTransicion(String seleccionTransicion) {
		this.seleccionTransicion = seleccionTransicion;
	}
	
	public String getFromPantalla() {
		return fromPantalla;
	}

	public void setFromPantalla(String fromPantalla) {
		this.fromPantalla = fromPantalla;
	}

	public String getAccionAvanceSelect() {
		return accionAvanceSelect;
	}

	public void setAccionAvanceSelect(String accionAvanceSelect) {
		this.accionAvanceSelect = accionAvanceSelect;
	}

	public String getHeaderDialogo() {
		return headerDialogo;
	}

	public void setHeaderDialogo(String headerDialogo) {
		this.headerDialogo = headerDialogo;
	}

	public String getMensajeDialogo() {
		return mensajeDialogo;
	}

	public void setMensajeDialogo(String mensajeDialogo) {
		this.mensajeDialogo = mensajeDialogo;
	}

	public List<BitacoraDto> getListaAccionesBitacora() {
		return listaAccionesBitacora;
	}

	public void setListaAccionesBitacora(List<BitacoraDto> listaAccionesBitacora) {
		this.listaAccionesBitacora = listaAccionesBitacora;
	}

	public String getIdEstatusBitacora() {
		return idEstatusBitacora;
	}

	public void setIdEstatusBitacora(String idEstatusBitacora) {
		this.idEstatusBitacora = idEstatusBitacora;
	}

	public String getIdAccionBitacora() {
		return idAccionBitacora;
	}

	public void setIdAccionBitacora(String idAccionBitacora) {
		this.idAccionBitacora = idAccionBitacora;
	}

	public String getIdSolicitudBitacora() {
		return idSolicitudBitacora;
	}

	public void setIdSolicitudBitacora(String idSolicitudBitacora) {
		this.idSolicitudBitacora = idSolicitudBitacora;
	}

	public String getIdGrupoOperadorBitacora() {
		return idGrupoOperadorBitacora;
	}

	public void setIdGrupoOperadorBitacora(String idGrupoOperadorBitacora) {
		this.idGrupoOperadorBitacora = idGrupoOperadorBitacora;
	}

	public String getEstatus() {
		return estatus;
	}

	public void setEstatus(String estatus) {
		this.estatus = estatus;
	}
	
}

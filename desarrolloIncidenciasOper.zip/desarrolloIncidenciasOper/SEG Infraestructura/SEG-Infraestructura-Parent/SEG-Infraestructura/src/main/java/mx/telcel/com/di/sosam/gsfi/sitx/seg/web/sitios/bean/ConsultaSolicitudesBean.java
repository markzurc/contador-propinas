package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.sitios.bean;

import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.ReporteOvitUtil;
import javax.faces.context.ExternalContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.util.Date;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.elementosPantalla.IElementosPantallaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.solicitudes.IConsultaSolicitudesService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ElementosPantallaDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ConsultaSolicitudesDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SolicitudDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.IRolBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.impl.RolBusinessImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolTypeVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.ReporteSegUtil;

@Controller("consultaSolicitudesBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class ConsultaSolicitudesBean implements Serializable {

	@Autowired
	private IConsultaSolicitudesService iSolicitudesService;

	@Autowired
	private IElementosPantallaService elementosPantalla;

	@Autowired
	@Qualifier("rolBusiness")
	private IRolBusiness rolBussines;

	private static final long serialVersionUID = 1973527406249170172L;
	private static final Logger LOGGER = LogManager.getLogger(ConsultaSolicitudesBean.class);

	private List<ElementosPantallaDTO> list;
	private List<SolicitudDto> listaSolicitudes;
	public boolean verDetalle;
	private String mensajeDialog;
	private String rolType;

	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		try {
			list = new ArrayList<>();
			this.mensajeDialog = null;
			String nombreEstadoVista = rc.getCurrentState().getId();
			UserDetailsVo userDetailsVo = (UserDetailsVo) SecurityContextHolder.getContext().getAuthentication()
					.getPrincipal();
			ConsultaSolicitudesDTO consulta = iSolicitudesService.getSolicitudes(userDetailsVo.getIdUsuario(),
					userDetailsVo.getIdTipoUsuario(), userDetailsVo.getIdRol());
			list = elementosPantalla.getElementosPermitidosPantalla(nombreEstadoVista, userDetailsVo.getIdRol(),
					new HashMap<String, Integer>());

			if (consulta.getMensajeError() == null) {
				listaSolicitudes = consulta.getListSolicitudes();
			} else {
				this.mensajeDialog = consulta.getMensajeError();
			}
			rolType = rolBussines.getRoltype(userDetailsVo.getIdRol());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Ocurrio un error al cargar los datos de Sitios");
			context.addMessage("mensajes",
					new FacesMessage(SEVERITY_ERROR, "Error", "Ocurri� un error al cargar la Consulta de servicios "));
		}
	}

	public boolean getVisible(String nombreComponente) {
		boolean visible = false;
		for (ElementosPantallaDTO elemento : list) {
			if (elemento.getIdElemento().equals(nombreComponente)) {
				visible = elemento.isVisible();
			}
		}
		return visible;
	}

	public SitioDto getSitioDTO(SolicitudDto solicitud) {
		SitioDto sitioDto = new SitioDto();
		sitioDto.setNombre(solicitud.getNombre());
		sitioDto.setSitio(solicitud.getSitio());
		sitioDto.setLatitud(solicitud.getLatitud());
		sitioDto.setLongitud(solicitud.getLongitud());
		sitioDto.setRegion(solicitud.getRegion());
		sitioDto.setEstado(solicitud.getEstatus());
		sitioDto.setIdEstado(solicitud.getIdEstado());
		sitioDto.setFolio(solicitud.getFolio());
		return sitioDto;
	}

	public String formatFolio(String folio) {
		return "SI-" + String.format("%06d", Integer.parseInt(folio));
	}

	public int numberFolio(String folio) {
		return Integer.parseInt(folio);
	}

	public String formatFecha(String fecha) {
		String[] fechaformat = fecha.split("\\-");
		return fechaformat[1];
	}

	public BigDecimal formatFechaInt(String fecha) {
		String[] fechaformat = fecha.split("\\-");
		return new BigDecimal(fechaformat[0]);
	}

	public void getFile() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		try {
			String fechaReporte = ReporteOvitUtil.fechaReporte();
			XSSFWorkbook workbook = new XSSFWorkbook();
			iSolicitudesService.toExcel(workbook, listaSolicitudes);
			ExternalContext externalContext = facesContext.getExternalContext();
			externalContext.setResponseContentType("application/vnd.ms-excel");
			externalContext.setResponseHeader("Content-Disposition",
					"attachment; filename=\"Reporte SEG Gestion de Servicios " + fechaReporte + " v01.xlsx\"");
			workbook.write(externalContext.getResponseOutputStream());
		} catch (IOException e) {
			LOGGER.error("Error al generar el archivo excel " + e);
		}
		facesContext.responseComplete();
	}

	public List<SolicitudDto> getListaSolicitudes() {
		return listaSolicitudes;
	}

	public void setListaSolicitudes(List<SolicitudDto> listaSolicitudes) {
		this.listaSolicitudes = listaSolicitudes;
	}

	public String getMensajeDialog() {
		return mensajeDialog;
	}

	public void setMensajeDialog(String mensajeDialog) {
		this.mensajeDialog = mensajeDialog;
	}

	public String getStylePendiente(String param) throws TransactionalOVITException {
		return rolType.equals(param) ? "background-color: #dce6f1;font-weight: bold;" : "";
	}

}

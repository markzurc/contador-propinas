package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.usuario.admin.bean;

import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.event.FileUploadEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Controller;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.external.authentication.IAuthenticationExternal;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.DocumentoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.OperadorDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.ReportUserDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.user.service.UserCatalogService;

@Controller("altaUsuarioAdministradorBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class AltaUsuarioAdministradorBean implements Serializable {
	
	private static final Logger LOGGER = LogManager.getLogger(AltaUsuarioAdministradorBean.class);

	private static final long serialVersionUID = 4582624686881827949L;
	

	@Autowired
	@Qualifier("userCatalogService")
	private UserCatalogService userCatalogService;
	
	@Autowired
    @Qualifier("externalAuth")
    private IAuthenticationExternal authExternal;
	
	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;

	private File targetFolder;

	private ReportUserVo reportUserVo;

	private List<String> listaTipoUsuario;
	private List<OperadorDto> listaConcesionario;
	private List<String> listaArchivos;

	private String tipoUsuario;

	private String seleccionadoTipoUsuario;
	private String seleccionadoEstado;
	private String seleccionadoConcesionario;
	private String nombre;
	private String apellidoP;
	private String apellidoM;
	private String correo;
	private String pass;
	private String concesionario;
	private Integer concesionarioId;
	private String mensajeTipoUsuario;
	
	private String renderedConcesionario;
	
	private List<String> listaErrores;
	
	private List<FileUploadEvent> listaArch;
	
	private List<DocumentoDto> listaDocumentos;
	
	private String msjBorrarArchivo;
	
	private Integer validaUsuarios;

	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		try {
			listaTipoUsuario = new ArrayList<>();
			listaConcesionario = new ArrayList<>();
			listaArchivos = new ArrayList<>();
			listaArch = new ArrayList<>();
			msjBorrarArchivo = "";
			tipoUsuario = "";
			nombre = "";
			apellidoM = "";
			apellidoP = "";
			correo = "";
			pass = "";
			concesionario = "";
			seleccionadoTipoUsuario = "";
			seleccionadoConcesionario = "";
			validaUsuarios = 0;
			listaErrores = new ArrayList<>();
			cargaListas();
			validaTipoUsuario();
			listaDocumentos = new ArrayList<>();
		} catch (Exception e) {
			LOGGER.info("Ocurrio un error al cargar la pagina: " + e);
			context.addMessage("mensajes",
					new FacesMessage(SEVERITY_ERROR, "Error", "Ocurri� un error al cargar la p�gina"));
		}

	}
	
	public boolean validaciones() {
		validaUsuarios = 0;
		listaErrores = new ArrayList<>();
		boolean resp = true;
		FacesContext context = FacesContext.getCurrentInstance();
		try {
			ConfigurationUtilsVo configurationUtilsVo2 = configurationUtilsBusiness.
					getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.MAX_ADMIN_CONCESIONARIO);
			Integer numeroConcesionarios = Integer.parseInt(configurationUtilsVo2.getValor());
			
			List<ReportUserVo> user=userCatalogService.getAllUsers();
			if (seleccionadoTipoUsuario.equals("Administrador Concesionario")) {
				if (listaDocumentos.size()==0) {
					listaErrores.add("Se deben agregar documentos.");
					resp = false;
				}
				if (seleccionadoConcesionario.equals("")) {
					listaErrores.add("El campo concesionario es obligatorio.");
					resp = false;
				}
				for (ReportUserVo reportUserVo : user) {
					if (!seleccionadoConcesionario.equals("")) {
						if (!reportUserVo.getTipoUsuarioNombre().equals("IFT")) {
							if (reportUserVo.getEmpresaId()==Integer.parseInt(seleccionadoConcesionario) && (reportUserVo.getEstatusNombre().equals("Activo") || reportUserVo.getEstatusNombre().equals("Bloqueado"))) {
								validaUsuarios++;
							}
						}
					}
					
				}
				if (validaUsuarios >= numeroConcesionarios) {
					listaErrores.add("No es posible registrar m�s usuarios para el Concesionario seleccionado.");
					resp = false;
				}
			} else {
				listaDocumentos = new ArrayList<>();
				String idUsuario = userCatalogService.idArchivosUsuario();
				ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness.
						getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_TMP);
				String ruta = String.valueOf(configurationUtilsVo.getValor() + File.separator + idUsuario);
				File archivo = new File(ruta);
			    if (archivo.delete()) {
			    	LOGGER.info("Archivo eliminado correctamente");
			    } else {
			    	LOGGER.info("No se pudo eliminar el archivo");
			    }
			}
			for (ReportUserVo reportUserVo : user) {
				if (reportUserVo.getCorreo().equals(correo)) {
					listaErrores.add("No se puede registrar otro usuario con el mismo correo.");
					resp = false;
				}
			}
			List<ReportUserVo> user2=userCatalogService.getUsersConcesionario();
			for (ReportUserVo reportUserVo : user2) {
				if (reportUserVo.getCorreo().equals(correo)) {
					listaErrores.add("No se puede registrar otro usuario con el mismo correo.");
					resp = false;
				}
			}
			if (nombre.equals("")) {
				listaErrores.add("El campo nombre es obligatorio.");
				resp = false;
			} else if (nombre.length()>=250) {
				listaErrores.add("El campo nombre no puede ser mayor a 250 caracteres.");
				resp = false;
			}
			if (!nombre.matches("[a-zA-Z ]*")) {
				listaErrores.add("Solo se pueden agregar letras en el campo nombre.");
				resp = false;
			}
			if (apellidoP.equals("")) {
				listaErrores.add("El campo apellido paterno es obligatorio.");
				resp = false;
			} else if (apellidoP.length()>=250) {
				listaErrores.add("El campo apellido paterno no puede ser mayor a 250 caracteres.");
				resp = false;
			}
			if (!apellidoP.matches("[a-zA-Z ]*")) {
				listaErrores.add("Solo se pueden agregar letras en el campo apellido paterno.");
				resp = false;
			}
			if (apellidoM.equals("")) {
				listaErrores.add("El campo apellido materno es obligatorio.");
				resp = false;
			} else if (apellidoM.length()>=250) {
				listaErrores.add("El campo apellido materno no puede ser mayor a 250 caracteres.");
				resp = false;
			}
			if (!apellidoM.matches("[a-zA-Z ]*")) {
				listaErrores.add("Solo se pueden agregar letras en el campo apellido materno.");
				resp = false;
			}
			if (correo.equals("")) {
				listaErrores.add("El campo correo electr�nico es obligatorio.");
				resp = false;
			} else if (!correo.matches("^[a-z0-9_+&*-]+(?:\\.[a-z0-9_+&*-]+)*@(?:[a-z0-9-]+\\.)+[a-z]{2,7}$")) {
				listaErrores.add("El correo electr�nico no cumple con el formato requerido.");
				resp = false;
			} else if (correo.length()>=250) {
				listaErrores.add("El campo corre� no puede ser mayor a 250 caracteres.");
				resp = false;
			}
			if (pass.equals("")) {
				listaErrores.add("El campo contrase�a es obligatorio.");
				resp = false;
			} else if (pass.length() > 30 || pass.length() < 8) {
				listaErrores.add("La contrase�a debe tener de 8 a 30 caracteres.");
				resp = false;
			} else if (!contrasenaSegura(pass)) {
				listaErrores.add("La contrase�a debe tener un m�nimo de 1 n�mero, 1 s�mbolo, 1 car�cter especial, 1 letra may�scula y min�sculas.");
				resp = false;
			}
			if (seleccionadoTipoUsuario.equals("")) {
				listaErrores.add("El campo tipo usuario es obligatorio.");
				resp = false;
			}
		} catch (Exception e) {
			LOGGER.info("Ocurrio un error al validar los datos: " + e);
			context.addMessage("mensajes",
					new FacesMessage(SEVERITY_ERROR, "Error", "Ocurri� un error al validar los datos."));
		}
		return resp;
	}
	
	public static boolean contrasenaSegura(String contrasena) {

		boolean mayuscula = false;
		boolean minuscula = false;
        boolean numero = false;
        boolean especial = false;
        
        //Define caracteres especiales
        Pattern special = Pattern.compile("[<>{}\"/|;:.,!?@#$%=&*\\]\\\\()\\[��_+]");
        Matcher hasSpecial = special.matcher(contrasena);

        int i;
        char l;

        for (i = 0; i < contrasena.length(); i++) {
            l = contrasena.charAt(i);

            if (Character.isDigit(l)) {//m�nimo un n�mero. 
                numero = true;
            }
            
            if (Character.isUpperCase(l)) { // m�nimo una letra may�scula 
                mayuscula = true;
            }
            
            if (Character.isLowerCase(l)) { // m�nimo una letra may�scula 
                minuscula = true;
            }
            
            if (hasSpecial.find()) { //Valida "caracteres especiales".       
                especial = true;
            }
        }

        if (numero == true && mayuscula == true && minuscula == true && especial == true) {
            return true;
        } else {
            return false;
        }
	}

	public void altaUsuario() {
		boolean valid = validaciones();
		if (valid) {
			try {
				ReportUserDto reportUserDto = new ReportUserDto();
				reportUserDto.setNombre(capitalizarPrimeraLetra(nombre.toLowerCase()));
				reportUserDto.setApellidoPaterno(capitalizarPrimeraLetra(apellidoP.toLowerCase()));
				reportUserDto.setApellidoMaterno(capitalizarPrimeraLetra(apellidoM.toLowerCase()));
				reportUserDto.setCorreo(correo);
				if (seleccionadoTipoUsuario.equals("IFT")) {
					reportUserDto.setEmpresa("");
				} else {
					reportUserDto.setEmpresa(seleccionadoConcesionario);
				}
				String password = pass;
				String strPasswordCrypt = authExternal.encriptarAcceso(password);
				
				if (seleccionadoTipoUsuario.equals("IFT")) {
					mensajeTipoUsuario = "IFT";
					reportUserDto.setIdTipoUsuario(3);
					reportUserDto.setIdRol(14);
				} else {
					mensajeTipoUsuario = "Administrador";
					reportUserDto.setIdTipoUsuario(1);
					reportUserDto.setIdRol(12);
				}
				
				boolean resp = userCatalogService.altaUsuarioAdministrador(reportUserDto, strPasswordCrypt);
				reportUserDto.setPass(strPasswordCrypt);
				boolean resp2 = userCatalogService.altaPass(reportUserDto);
				boolean resp3 = userCatalogService.altaRolUsuario(reportUserDto);
				
				String idUsuario = userCatalogService.idArchivosUsuario();
				Integer idUsuarioF= Integer.parseInt(idUsuario)-1;
				
				ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness.
						getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_USR);
				String ruta = String.valueOf(configurationUtilsVo.getValor()) + idUsuarioF;
				
				
				//Guardar Archivos
				for (FileUploadEvent fileUploadEvent : listaArch) {
					guardarArchivo2(ruta, fileUploadEvent.getFile().getFileName());
					String fileName = null;
					InputStream inputStream =null;	
					FacesContext context = FacesContext.getCurrentInstance();
					FacesMessage facesMessage = new FacesMessage();
					try {
						
						fileName = FilenameUtils.getName(fileUploadEvent.getFile().getFileName());
						File directorioTemp = new File(ruta);
						if (!directorioTemp.exists()) {
							directorioTemp.mkdirs();
						}
						inputStream = fileUploadEvent.getFile().getInputstream();
						
						String rutaA = directorioTemp.getPath() + File.separator + fileName;
						File verificaSiExiste = new File(rutaA);
						
						subirArchivo(inputStream, verificaSiExiste);
						listaArchivos.add(fileName);
						
						facesMessage.setDetail("Carga exitosa de documentos");
						facesMessage.setSummary("Listo!");
						facesMessage.setSeverity(FacesMessage.SEVERITY_INFO);
						
					} catch (Exception e) {
						LOGGER.error("Ocurri� un error al cargar los documentos: " + e);
						facesMessage.setDetail("Ocurri� un error al cargar los documentos: " + e.getMessage());
						facesMessage.setSummary("Error!");
						facesMessage.setSeverity(FacesMessage.SEVERITY_ERROR);
					}
					context.addMessage("msjArchivos", facesMessage);
				}
				
				if (resp && resp2 && resp3) {
					if (seleccionadoTipoUsuario.equals("IFT")) {
						org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMensajeIFT').show();");
					} else {
						org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMensaje').show();");
					}
				} else {
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMensajeError').show();");
				}
			} catch (Exception e) {
				
			}
		} else {
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgValidaciones').show();");
		}
	}
	
	public String capitalizarPrimeraLetra(String str) {
		String nombreR="";
		String[] parts = str.split(" ");
		for (String string : parts) {
			if(string.trim().length() > 0){
				String nombre = string;
				String resultado = nombre.toUpperCase().charAt(0) + nombre.substring(1, nombre.length()).toLowerCase();
				nombreR = nombreR + resultado + " ";
			}
		}
		String nombreF = nombreR.substring(0, nombreR.length() - 1);
		return nombreF;
	}
	
	public void validaTipoUsuario() {
		if (seleccionadoTipoUsuario.equals("IFT") || seleccionadoTipoUsuario.equals("")) {
			renderedConcesionario = "false";
		} else {
			renderedConcesionario = "true";
		}
	}
	

	public void cargaArchivos(FileUploadEvent event) throws IOException {
		listaErrores = new ArrayList<>();
		if (listaArchivos.size() > 1) {
			listaErrores.add("No puedes agregar m�s de dos archivos.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgValidaciones').show();");
		} else {
			listaArch.add(event);
			String fileName = null;
			InputStream inputStream =null;	
			FacesContext context = FacesContext.getCurrentInstance();
			FacesMessage facesMessage = new FacesMessage();
			try {
				String idUsuario = userCatalogService.idArchivosUsuario();
				//Integer idUsuarioF= Integer.parseInt(idUsuario)-1;
				ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness.
						getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_TMP);
				String ruta = String.valueOf(configurationUtilsVo.getValor());
				
				fileName = FilenameUtils.getName(event.getFile().getFileName());
				File directorioTemp = new File(ruta + File.separator+ idUsuario);
				if (!directorioTemp.exists()) {
					directorioTemp.mkdirs();
				}
				inputStream = event.getFile().getInputstream();
				
				String rutaA = directorioTemp.getPath() + File.separator + fileName;
				File verificaSiExiste = new File(rutaA);
				
				subirArchivo(inputStream, verificaSiExiste);
				listaArchivos.add(fileName);
				
				DocumentoDto doc = new DocumentoDto();
				doc.setDocumento(event.getFile().getFileName());
				listaDocumentos.add(doc);
				
				facesMessage.setDetail("Carga exitosa de documentos.");
				facesMessage.setSummary("Listo!");
				facesMessage.setSeverity(FacesMessage.SEVERITY_INFO);
				
			} catch (Exception e) {
				LOGGER.error("Ocurri� un error al cargar los documentos: " + e);
				facesMessage.setDetail("Ocurri� un error al cargar los documentos: " + e.getMessage());
				facesMessage.setSummary("Error!");
				facesMessage.setSeverity(FacesMessage.SEVERITY_ERROR);
			}
			context.addMessage("msjArchivos", facesMessage);
		}
		
	}
	
	public void eliminarDoc(DocumentoDto doc) {
		ConfigurationUtilsVo configurationUtilsVo;
		try {
			String idUsuario = userCatalogService.idArchivosUsuario();
			configurationUtilsVo = configurationUtilsBusiness.
					getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_TMP);
			String ruta = String.valueOf(configurationUtilsVo.getValor()) + File.separator + idUsuario + File.separator + doc.getDocumento();
			File archivo = new File(ruta);

		    if (archivo.delete()) {
		    	listaDocumentos.remove(doc);
		    	org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgArchivos').show();");
		    } else {
		    	org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgArchivosError').show();");
		    }
		    
		} catch (Exception e) {
			LOGGER.info("Ocurrio un error al eliminar los archivos " + e);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgArchivosError').show();");
		}
		
		
	}
	
	public void guardarArchivo2(String ruta, String name) {
		userCatalogService.altaDocumento(ruta, name, 1);
	}

	public static boolean subirArchivo(InputStream origen, File destino) {
		OutputStream out = null;
		try {
			InputStream in = origen;
			out = new FileOutputStream(destino);

			byte[] buf = new byte[1024];
			int len;

			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}

			in.close();
			out.close();
		} catch (IOException e) {
			return false;

		} finally {
			close(out);
		}

		return true;
	}

	private static void close(Closeable closable) {
		try {
			if (closable != null) {
				closable.close();
			}
		} catch (IOException e) {
			System.out.println("Error al cerrar OutputStream ");
		}
	}

	private void cargaListas() {
		listaTipoUsuario.add("Administrador Concesionario");
		listaTipoUsuario.add("IFT");
		
		this.setTipoUsuario("Seleccione un tipo usuario");
		this.setConcesionario("Seleccione un concesionario");
		
		this.setListaConcesionario(userCatalogService.obtenerEmpresas());

	}

	public File getTargetFolder() {
		return targetFolder;
	}

	public void setTargetFolder(File targetFolder) {
		this.targetFolder = targetFolder;
	}

	public ReportUserVo getReportUserVo() {
		return reportUserVo;
	}

	public void setReportUserVo(ReportUserVo reportUserVo) {
		this.reportUserVo = reportUserVo;
	}

	public List<String> getListaTipoUsuario() {
		return listaTipoUsuario;
	}

	public void setListaTipoUsuario(List<String> listaTipoUsuario) {
		this.listaTipoUsuario = listaTipoUsuario;
	}

	public String getTipoUsuario() {
		return tipoUsuario;
	}

	public void setTipoUsuario(String tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}

	public String getSeleccionadoTipoUsuario() {
		return seleccionadoTipoUsuario;
	}

	public void setSeleccionadoTipoUsuario(String seleccionadoTipoUsuario) {
		this.seleccionadoTipoUsuario = seleccionadoTipoUsuario;
	}

	public String getSeleccionadoEstado() {
		return seleccionadoEstado;
	}

	public void setSeleccionadoEstado(String seleccionadoEstado) {
		this.seleccionadoEstado = seleccionadoEstado;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidoP() {
		return apellidoP;
	}

	public void setApellidoP(String apellidoP) {
		this.apellidoP = apellidoP;
	}

	public String getApellidoM() {
		return apellidoM;
	}

	public void setApellidoM(String apellidoM) {
		this.apellidoM = apellidoM;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getSeleccionadoConcesionario() {
		return seleccionadoConcesionario;
	}

	public void setSeleccionadoConcesionario(String seleccionadoConcesionario) {
		this.seleccionadoConcesionario = seleccionadoConcesionario;
	}

	public String getConcesionario() {
		return concesionario;
	}

	public void setConcesionario(String concesionario) {
		this.concesionario = concesionario;
	}

	public List<OperadorDto> getListaConcesionario() {
		return listaConcesionario;
	}

	public void setListaConcesionario(List<OperadorDto> listaConcesionario) {
		this.listaConcesionario = listaConcesionario;
	}

	public Integer getConcesionarioId() {
		return concesionarioId;
	}

	public void setConcesionarioId(Integer concesionarioId) {
		this.concesionarioId = concesionarioId;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public List<String> getListaArchivos() {
		return listaArchivos;
	}

	public void setListaArchivos(List<String> listaArchivos) {
		this.listaArchivos = listaArchivos;
	}

	public String getRenderedConcesionario() {
		return renderedConcesionario;
	}

	public void setRenderedConcesionario(String renderedConcesionario) {
		this.renderedConcesionario = renderedConcesionario;
	}

	public List<String> getListaErrores() {
		return listaErrores;
	}

	public void setListaErrores(List<String> listaErrores) {
		this.listaErrores = listaErrores;
	}

	public List<DocumentoDto> getListaDocumentos() {
		return listaDocumentos;
	}

	public void setListaDocumentos(List<DocumentoDto> listaDocumentos) {
		this.listaDocumentos = listaDocumentos;
	}

	public String getMsjBorrarArchivo() {
		return msjBorrarArchivo;
	}

	public void setMsjBorrarArchivo(String msjBorrarArchivo) {
		this.msjBorrarArchivo = msjBorrarArchivo;
	}

	public String getMensajeTipoUsuario() {
		return mensajeTipoUsuario;
	}

	public void setMensajeTipoUsuario(String mensajeTipoUsuario) {
		this.mensajeTipoUsuario = mensajeTipoUsuario;
	}
	
}

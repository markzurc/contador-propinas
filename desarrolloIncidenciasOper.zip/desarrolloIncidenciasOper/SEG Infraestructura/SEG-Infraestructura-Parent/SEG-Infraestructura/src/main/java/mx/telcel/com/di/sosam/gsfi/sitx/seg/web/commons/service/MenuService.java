package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.faces.component.UIComponentBase;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.OVITUtils;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ApplicationVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.IRolBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolAclVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.rol.service.RolCatalogService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.JsfUtil;

import org.primefaces.component.menubar.Menubar;
import org.primefaces.component.menuitem.UIMenuItem;
import org.primefaces.component.submenu.UISubmenu;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Service;

@Service("menuService")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class MenuService implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3669528022968685826L;
	private static final int STATUS_MAINTENANCE = 5;
	private static final String ACTION_MAINTENANCE = "maintenance";
	private static final Integer TYPE_MENU = 0;
	private static final Integer TYPE_MENU_RIGHT = 2;
	private static final Integer TYPE_SUB_MENU = 1;

	@Autowired
	@Qualifier("rolBusiness")
	private IRolBusiness rolBussines;
	@Autowired
	@Qualifier("rolCatalogService")
	private RolCatalogService rolCatalogService;

	public void getMenuModelbyRol(int idRol, Menubar menuBar) throws TransactionalOVITException {
		RolVo rolVo = rolCatalogService.loadRolById(idRol);
		List<RolAclVo> aclsMenu = new ArrayList<RolAclVo>();
		if (rolVo != null) {
			List<ApplicationVo> listaAppByRol = rolCatalogService.getApliacionesByRol(rolVo);

			for (ApplicationVo applicationVo : listaAppByRol) {
				List<RolAclVo> listaRolAclVo = rolBussines.findByRolAcl(rolVo.getIdRol(),
						applicationVo.getIdAplicacion());
				if (!OVITUtils.isEmptyList(listaRolAclVo)) {
					filterByTypeMenu(listaRolAclVo);
					if (applicationVo.getIdEstatus() == STATUS_MAINTENANCE && rolVo.getIdTipoRol() != 2) {
						markComponentAsMaintenance(listaRolAclVo);
					}
					aclsMenu.addAll(listaRolAclVo);
				}
			}
			generaTreeNodeAclsByApp(aclsMenu, menuBar);
		}
	}

	public Menubar getMenuBinding(int idRol, int idUser, int idcuurentEstatus) throws TransactionalOVITException {

		Menubar menuBar = new Menubar();

		UIMenuItem coman3 = new UIMenuItem();
		coman3.setIcon("ui-icon-power");
		coman3.setActionExpression(JsfUtil.createMethodExpression("logout", String.class, new Class[] {}));
		coman3.setStyle("position: absolute; right: 2px;");
		menuBar.getChildren().add(coman3);

		UIMenuItem acercaDe = new UIMenuItem();
		acercaDe.setValue("Acerca");
		acercaDe.setOnclick("PF('acercaDe').show()");
		acercaDe.setStyle("position: absolute; right: 20px;");
		menuBar.getChildren().add(acercaDe);

		if (idcuurentEstatus == 0) {
			try {
				getMenuModelbyRol(idRol, menuBar);
			} catch (TransactionalOVITException e) {

			}
		}

		return menuBar;
	}

	private void markComponentAsMaintenance(List<RolAclVo> aclsByApp) {
		for (RolAclVo rolAclVo : aclsByApp) {
			rolAclVo.setFlujo(ACTION_MAINTENANCE);
		}

	}

	private void filterByTypeMenu(List<RolAclVo> listaToFilter) {
		List<RolAclVo> listaToEliminate = new ArrayList<RolAclVo>();
		if (!OVITUtils.isEmptyList(listaToFilter)) {
			for (RolAclVo rolAclVo : listaToFilter) {
				if (rolAclVo.getIdTipoComponente().equals(TYPE_MENU)
						|| rolAclVo.getIdTipoComponente().equals(TYPE_SUB_MENU)) {
					listaToEliminate.add(rolAclVo);
				}
			}
		}
		listaToFilter = listaToEliminate;
	}

	private List<RolAclVo> getMenuParentList(List<RolAclVo> listaComponentes) {
		List<RolAclVo> toReturn = new ArrayList<RolAclVo>();
		for (RolAclVo rolAclVo : listaComponentes) {
			if (rolAclVo.getIdPadre() == null && (rolAclVo.getIdTipoComponente().equals(TYPE_MENU)
					|| rolAclVo.getIdTipoComponente().equals(TYPE_MENU_RIGHT))) {
				toReturn.add(rolAclVo);
			}
		}

		Collections.sort(toReturn, new Comparator<RolAclVo>() {
			@Override
			public int compare(RolAclVo o1, RolAclVo o2) {
				return o1.getNivel().compareTo(o2.getNivel());
			}
		});

		return toReturn;
	}

	public void generaTreeNodeAclsByApp(List<RolAclVo> listaComponentes, Menubar menuBar) {

		List<RolAclVo> listaParents = getMenuParentList(listaComponentes);

		for (RolAclVo rolAclVo : listaParents) {

			if (rolAclVo.getIdPadre() == null && (rolAclVo.getIdTipoComponente().equals(TYPE_MENU)
					|| rolAclVo.getIdTipoComponente().equals(TYPE_MENU_RIGHT))) {
				UISubmenu sub = new UISubmenu();
				sub.setLabel(rolAclVo.getNombre());
				if (rolAclVo.getIdTipoComponente().equals(TYPE_MENU_RIGHT)) {
					sub.setStyle("position: absolute; right: 70px;");
				}
				if (rolAclVo.getFlujo() != null && rolAclVo.getFlujo().equals(ACTION_MAINTENANCE)) {
					sub.setIcon("ui-icon-wrench");
				}

				menuBar.getChildren().add(sub);
				addChilds(sub, rolAclVo, listaComponentes);
			}
		}
	}

	private void addChilds(UIComponentBase firstSubmenu, RolAclVo acl, List<RolAclVo> listaComponentes) {
		List<RolAclVo> acls = getChilds(listaComponentes, acl);

		Collections.sort(acls, new Comparator<RolAclVo>() {
			@Override
			public int compare(RolAclVo o1, RolAclVo o2) {
				return o1.getNivel().compareTo(o2.getNivel());
			}
		});

		for (RolAclVo child : acls) {
			if (child.getIdTipoComponente().equals(TYPE_SUB_MENU)) {

				UIMenuItem item = new UIMenuItem();
				item.setValue(child.getNombre());

				if (child.getFlujo() != null) {
					item.setActionExpression(
							JsfUtil.createMethodExpression(child.getFlujo(), String.class, new Class[] {}));
				}

				item.setOnclick("PF('statusDialog').show()");
				item.setAjax(false);
				if (child.getFlujo() != null && child.getFlujo().equals(ACTION_MAINTENANCE)) {
					item.setIcon("ui-icon-wrench");
				} else {
					firstSubmenu.getChildren().add(item);
				}
			} else {
				UISubmenu sub = new UISubmenu();
				sub.setLabel(child.getNombre());
				if (child.getFlujo() != null && child.getFlujo().equals(ACTION_MAINTENANCE)) {
					sub.setIcon("ui-icon-wrench");
				}
				addChilds(sub, child, listaComponentes);
				firstSubmenu.getChildren().add(sub);
			}
		}
	}

	private List<RolAclVo> getChilds(List<RolAclVo> listaComponentes, RolAclVo comp) {
		List<RolAclVo> childs = new ArrayList<RolAclVo>();
		for (RolAclVo rolAclVo : listaComponentes) {
			if (rolAclVo.getIdPadre() != null && rolAclVo.getIdPadre().equals(comp.getIdComponente())
					&& (rolAclVo.getIdTipoComponente().equals(TYPE_MENU)
							|| rolAclVo.getIdTipoComponente().equals(TYPE_MENU_RIGHT)
							|| rolAclVo.getIdTipoComponente().equals(TYPE_SUB_MENU))) {
				childs.add(rolAclVo);
			}
		}
		return childs;
	}

}

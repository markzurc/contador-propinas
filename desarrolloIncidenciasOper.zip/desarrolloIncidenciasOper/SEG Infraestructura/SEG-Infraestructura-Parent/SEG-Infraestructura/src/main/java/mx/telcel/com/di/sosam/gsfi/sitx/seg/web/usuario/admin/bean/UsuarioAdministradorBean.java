package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.usuario.admin.bean;

import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.elementosPantalla.IElementosPantallaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ElementosPantallaDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.WrapperReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.user.service.UserCatalogService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.ReporteSegUtil;

@Controller("usuarioAdministradorBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class UsuarioAdministradorBean implements Serializable {
	
	private static final long serialVersionUID = 4582624686881827949L;

	@Autowired
	@Qualifier("userCatalogService")
	private UserCatalogService userCatalogService;
	
	@Autowired
    @Qualifier("adminUsuariosService")
    private AdminUsuariosService adminUsuariosService;
	
	@Autowired
	private IElementosPantallaService elementosPantalla;
	
	private List<ReportUserVo> listAll;
	private UserDetailsVo userDetailsVo;
	private List<WrapperReportUserVo> usersListAll;
	private String banderaRolEditar;
	
	private List<String> filtroConcesionario;
	private List<String> filtroTipoUsuario;
	private List<String> filtroEstatus;
	
	private String selectFiltroConcesionario;
	private String selectFiltroTipoUsuario;
	private String selectFiltroEstatus;
	private List<ElementosPantallaDTO> listaElementosPantalla;
	
	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		try{
			listaElementosPantalla = new ArrayList<>();
			userDetailsVo = (UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			if (userDetailsVo.getIdRol()==5) {
				banderaRolEditar="true";
			} else {
				banderaRolEditar="false";
			}
			listAll=userCatalogService.getAllUsers();
			usersListAll=userCatalogService.wrapListUsers(listAll);
			filtroConcesionario = new ArrayList<String>();
			filtroTipoUsuario = new ArrayList<String>();
			filtroEstatus = new ArrayList<String>();
			selectFiltroConcesionario = "null";
			selectFiltroTipoUsuario = "null";
			selectFiltroEstatus = "null";
			cargaFiltrosUsuarios();
			String nombreEstadoVista = rc.getCurrentState().getId();
			UserDetailsVo userDetailsVo = (UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			listaElementosPantalla = elementosPantalla.getElementosPermitidosPantalla(nombreEstadoVista, userDetailsVo.getIdRol(), new HashMap<String,Integer>() );
		} catch (Exception e) {
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","Ocurri� un error al cargar la pagina"));
		}
	}

	private void cargaFiltrosUsuarios() {
		for (WrapperReportUserVo insumos : usersListAll) {
			if (!filtroConcesionario.contains(insumos.getReportUserVo().getEmpresa()) && insumos.getReportUserVo().getEmpresa() != null) {
				filtroConcesionario.add(insumos.getReportUserVo().getEmpresa());
			}
			
			if (!filtroTipoUsuario.contains(insumos.getReportUserVo().getTipoUsuarioNombre())) {
				filtroTipoUsuario.add(insumos.getReportUserVo().getTipoUsuarioNombre());
			}
			
			if (!filtroEstatus.contains(insumos.getReportUserVo().getEstatusNombre())) {
				filtroEstatus.add(insumos.getReportUserVo().getEstatusNombre());
			}
		}
		Collections.sort(filtroConcesionario);
		Collections.sort(filtroTipoUsuario);
		Collections.sort(filtroEstatus);
	}
	
	public void getReporte() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		try {
		XSSFWorkbook workbook = new XSSFWorkbook();
		String fechaReporte = ReporteSegUtil.fechaReporte();
		adminUsuariosService.toExcelAdminUsuarios(workbook, usersListAll);
 
		ExternalContext externalContext = facesContext.getExternalContext();
		externalContext.setResponseContentType("application/vnd.ms-excel");
		externalContext.setResponseHeader("Content-Disposition",
				"attachment; filename=\"Reporte SEG Usuarios Administrador " + fechaReporte + " v01.xlsx\"");
 
		OutputStream out = externalContext.getResponseOutputStream();
	    workbook.write(out);
	    out.flush();
		} catch (IOException e) {
			facesContext.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","Ocurri� un error al descargar el reporte de usuarios administrador"));
		}
		facesContext.responseComplete();
	}
	
	public boolean getVisible(String nombreComponente) {
		boolean visible = false;
		for (ElementosPantallaDTO elemento : listaElementosPantalla) {
			if (elemento.getIdElemento().equals(nombreComponente)) {
				visible = elemento.isVisible();
			}
		}
		return visible;
	}

	public List<ReportUserVo> getListAll() {
		return listAll;
	}

	public void setListAll(List<ReportUserVo> listAll) {
		this.listAll = listAll;
	}

	public List<WrapperReportUserVo> getUsersListAll() {
		return usersListAll;
	}

	public void setUsersListAll(List<WrapperReportUserVo> usersListAll) {
		this.usersListAll = usersListAll;
	}

	public UserDetailsVo getUserDetailsVo() {
		return userDetailsVo;
	}

	public void setUserDetailsVo(UserDetailsVo userDetailsVo) {
		this.userDetailsVo = userDetailsVo;
	}

	public String getBanderaRolEditar() {
		return banderaRolEditar;
	}

	public void setBanderaRolEditar(String banderaRolEditar) {
		this.banderaRolEditar = banderaRolEditar;
	}

	public List<String> getFiltroConcesionario() {
		return filtroConcesionario;
	}

	public void setFiltroConcesionario(List<String> filtroConcesionario) {
		this.filtroConcesionario = filtroConcesionario;
	}

	public List<String> getFiltroTipoUsuario() {
		return filtroTipoUsuario;
	}

	public void setFiltroTipoUsuario(List<String> filtroTipoUsuario) {
		this.filtroTipoUsuario = filtroTipoUsuario;
	}

	public List<String> getFiltroEstatus() {
		return filtroEstatus;
	}

	public void setFiltroEstatus(List<String> filtroEstatus) {
		this.filtroEstatus = filtroEstatus;
	}

	public String getSelectFiltroConcesionario() {
		return selectFiltroConcesionario;
	}

	public void setSelectFiltroConcesionario(String selectFiltroConcesionario) {
		this.selectFiltroConcesionario = selectFiltroConcesionario;
	}

	public String getSelectFiltroTipoUsuario() {
		return selectFiltroTipoUsuario;
	}

	public void setSelectFiltroTipoUsuario(String selectFiltroTipoUsuario) {
		this.selectFiltroTipoUsuario = selectFiltroTipoUsuario;
	}

	public String getSelectFiltroEstatus() {
		return selectFiltroEstatus;
	}

	public void setSelectFiltroEstatus(String selectFiltroEstatus) {
		this.selectFiltroEstatus = selectFiltroEstatus;
	}
	
}
package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.bean;

import java.io.Serializable;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.component.menubar.Menubar;
import org.primefaces.model.menu.MenuModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.user.service.UserCatalogService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.service.MenuService;

@Controller("menuBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class MenuBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1093465214952827045L;
	private static Logger logger = LogManager.getLogger(MenuBean.class);
	private static final String UNKNOW="unknown";
	private MenuModel model;
	
	private Menubar menubar;
	private int paramWarningSession;
	private int timeOutSession;
	private String paramVersion;
	private String fechaVersion;
	private String ipUsuario;
	private String usuario;
	private String empresa;
	private String empresaL;
	private String mostrarEmpresa;
	private String acercaDe1;
	private String acercaDe2;
	
	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;
	
	@Autowired
	@Qualifier("menuService")
	private MenuService menuService;
	
	@Autowired
	@Qualifier("userCatalogService")
	private UserCatalogService userCatalogService;
	
	
	public void init() throws TransactionalOVITException {

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		ipUsuario = getClientIpAddr(request);
		fechaVersion=FacesContext.getCurrentInstance().getExternalContext().getInitParameterMap().get("mesDiaOvitVersion").toString();
		fechaVersion+="-"+FacesContext.getCurrentInstance().getExternalContext().getInitParameterMap().get("anioOvitVersion").toString();
		
				
		UserDetailsVo userDetailsVo =(UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		usuario=userDetailsVo.getNombre()+" "+userDetailsVo.getApellidoPaterno()+" "+userDetailsVo.getApellidoMaterno();
		
		if (userDetailsVo.getIdTipoUsuario() == 1 || userDetailsVo.getIdTipoUsuario() == 2) {
			String[] datoEmpresa = userCatalogService.obtenerOperadorUsuario(userDetailsVo.getIdUsuario()).split(":");
			empresa = datoEmpresa[1];
			empresaL = "Empresa";
			mostrarEmpresa = "true";
		} else if(userDetailsVo.getIdTipoUsuario() == 3){
			empresa = "IFT";
			empresaL = "Perfil";
			mostrarEmpresa = "true";
		} else {
			mostrarEmpresa = "false";
		}
		
		ConfigurationUtilsVo configurationUtilsVo=configurationUtilsBusiness.getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.MIN_WRN_SESS_EXP);
		try{
			paramWarningSession= toSeconds(Integer.parseInt(configurationUtilsVo.getValor()));
		}catch(NumberFormatException nfe){
			paramWarningSession=toSeconds(2);
		}
		
		
		configurationUtilsVo=configurationUtilsBusiness.getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.SESSION_TIME);
		
		try{
			timeOutSession= toSeconds(Integer.parseInt(configurationUtilsVo.getValor()));
		}catch(NumberFormatException nfe){
			timeOutSession=toSeconds(30);
		}
		
		configurationUtilsVo=configurationUtilsBusiness.getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.ACERCA_1);
		try{
			acercaDe1 = configurationUtilsVo.getValor();
		}catch(Exception e){
				acercaDe1 = "SEG Infraestructura ver. 1.0.0 03-01-2025";
		}
		
		configurationUtilsVo=configurationUtilsBusiness.getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.ACERCA_2);
		try{
			acercaDe2 = configurationUtilsVo.getValor();
		}catch(Exception e){
				acercaDe1 = "Copyright � 2025 , Radiomovil Dipsa, S.A. de C.V. Todos los Derechos Reservados";
		}
		
		paramVersion= FacesContext.getCurrentInstance().getExternalContext().getInitParameterMap().get("ovitVersion").toString();
		menubar=menuService.getMenuBinding(userDetailsVo.getIdRol(),userDetailsVo.getIdUsuario(),userDetailsVo.getIdEstatus());
					
	}
	
	
	public static String getClientIpAddr(HttpServletRequest request) {
			 
		 String ip = request.getHeader("client_ip");
		 
        if (ip == null || ip.length() == 0 || UNKNOW.equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }

	
	
	public void stillAlive(){
		try{
			HttpServletRequest request = 
			(HttpServletRequest)FacesContext
				.getCurrentInstance()
					.getExternalContext()
						.getRequest();
			
			request.getSession().setMaxInactiveInterval(1);
			
		}catch(Exception e){
			logger.error("Error al revisar el estado de la sesion " + e);
		}
	}
	
     //125000  
	private int toSeconds(int value){
		return value * 60;
	}
	
	public MenuModel getModel() {
		return model;
	}


	public void setModel(MenuModel model) {
		this.model = model;
	}


	public String getMsjTest() {
		return "msjTest";
	}


	


	public Menubar getMenubar() {
		return menubar;
	}


	public void setMenubar(Menubar menubar) {
		this.menubar = menubar;
	}


	public MenuService getMenuService() {
		return menuService;
	}


	public void setMenuService(MenuService menuService) {
		this.menuService = menuService;
	}

	public int getParamWarningSession() {
		return paramWarningSession;
	}

	public void setParamWarningSession(int paramWarningSession) {
		this.paramWarningSession = paramWarningSession;
	}

	public String getParamVersion() {
		return paramVersion;
	}

	public void setParamVersion(String paramVersion) {
		this.paramVersion = paramVersion;
	}

	public String getIpUsuario() {
		return ipUsuario;
	}

	public void setIpUsuario(String ipUsuario) {
		this.ipUsuario = ipUsuario;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}


	public String getFechaVersion() {
		return fechaVersion;
	}


	public void setFechaVersion(String fechaVersion) {
		this.fechaVersion = fechaVersion;
	}


	public int getTimeOutSession() {
		return timeOutSession;
	}


	public void setTimeOutSession(int timeOutSession) {
		this.timeOutSession = timeOutSession;
	}


	public String getEmpresa() {
		return empresa;
	}


	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}


	public String getMostrarEmpresa() {
		return mostrarEmpresa;
	}


	public void setMostrarEmpresa(String mostrarEmpresa) {
		this.mostrarEmpresa = mostrarEmpresa;
	}


	public String getEmpresaL() {
		return empresaL;
	}


	public void setEmpresaL(String empresaL) {
		this.empresaL = empresaL;
	}
	
	public String getAcercaDe1() {
		return acercaDe1;
	}
 
	
	public void setAcercaDe1(String acercaDe1) {
		this.acercaDe1 = acercaDe1;
	}
 
	
	public String getAcercaDe2() {
		return acercaDe2;
	}
 
	
	public void setAcercaDe2(String acercaDe2) {
		this.acercaDe2 = acercaDe2;
	}
	
}

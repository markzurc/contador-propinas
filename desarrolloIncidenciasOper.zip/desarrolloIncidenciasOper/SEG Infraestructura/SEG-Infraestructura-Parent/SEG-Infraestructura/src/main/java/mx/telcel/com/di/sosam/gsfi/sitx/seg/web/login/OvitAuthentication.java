package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.login;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.error.ErrorSEGWeb;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.IUserBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.external.authentication.IAuthenticationExternal;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.ldap.ILdapService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.spring.custom.CustomUrlRequestMatcher;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

/**
 * Custom authentication manager class for ovit web
 *
 * @author hhernanm
 * @author Jair Javier
 * @version 1.0
 * @since January 26, 2015
 */
public class OvitAuthentication implements AuthenticationManager {

    private final Logger logger = LogManager.getLogger(OvitAuthentication.class);
    @Autowired
    private CustomUrlRequestMatcher custom;

    @Autowired
    private HttpServletRequest request;

    @Autowired
    @Qualifier("externalAuth")
    private IAuthenticationExternal authExternal;

    @Autowired
    @Qualifier("ldapService")
    private ILdapService ldapService;

    @Autowired
    @Qualifier("userBusiness")
    private IUserBusiness userBusiness;

    @Value("${login.message.locked}")
    private String messageLocked;

    @Value("${login.message.drop}")
    private String messageDrop;

    @Value("${login.message.wrong}")
    private String messageWrong;

    @Value("${login.message.error}")
    private String messageError;

    @Override
    public Authentication authenticate(Authentication credentials) throws AuthenticationException {
        logger.info("Ejecutando OvitAuthentication.authenticate");

        UsernamePasswordAuthenticationToken authenticationToken;
        String parametroRedireccion = custom.invocaRespuestaIndicadorParametro();
        logger.info("User: ".concat(credentials.getName()));
        int tipoUsuario = authExternal.consultaExistenciaUsuarioExterno(credentials.getName());

        try {
            UserDetailsVo userDetailsVo = userBusiness.validateLogIn(credentials.getName(), credentials.getCredentials().toString());
            if (userDetailsVo.getEstatusLogin() == IUserBusiness.USER_EXTERNAL_WRONG_PASS
                    || userDetailsVo.getEstatusLogin() == IUserBusiness.USER_NOT_FOUND) {
                throw new BadCredentialsException(messageWrong);
            }

            if (userDetailsVo.getEstatusLogin() == IUserBusiness.USER_LOCKED) {
                throw new BadCredentialsException(messageLocked);
            }

            if (userDetailsVo.getEstatusLogin() == IUserBusiness.USER_DROP) {
                throw new BadCredentialsException(messageDrop);
            }
            if (tipoUsuario == 0) {
                if (userDetailsVo.getEstatusLogin() == IUserBusiness.USER_INTERNAL) {
                    if (userDetailsVo.getIdRolInterno().equals(userDetailsVo.getIdRol())) {
                        String ldapAuth = ldapService.authenticationAppLdap(credentials.getName(), credentials.getCredentials().toString());
                        if (ldapAuth.startsWith("1:")) {
                            logger.info("Los detalles del usuario son correctos y est\u00E1n listos para acceder a la aplicaci\u00F3n OVIT Web");
                            if (parametroRedireccion != null && !parametroRedireccion.isEmpty() && parametroRedireccion.contains("idSolicitud")) {
                                logger.info("La sesi\u00F3n sera redireccionada.");
                                userDetailsVo.setVistaRedireccion(parametroRedireccion);
                                custom.reestableceRespuestaIndicadorParametro();
                            } else {
                                userDetailsVo.setVistaRedireccion("falso");
                            }
                            logger.info("User details are good and ready access to the OVIT Web Aplication");
                            Collection<GrantedAuthority> authorities = getAuthorities(userDetailsVo);
                            authenticationToken = new UsernamePasswordAuthenticationToken(userDetailsVo,
                            		credentials.getCredentials().toString(), authorities);
                            authenticationToken.setDetails(request.getRemoteAddr());
                            userBusiness.updateLoginDate(userDetailsVo.getIdUsuario());
                            return authenticationToken;
                        } else {
                            logger.info(ldapAuth);
                            logger.info("User details are not good and ready access to the OVIT Web Aplication");
                            throw new BadCredentialsException(ldapAuth);
                        }
                    } else {
                        throw new BadCredentialsException(ErrorSEGWeb.E06_ERROR_USUARIO_ROL.getMessageError());
                    }
                }
                logger.info("User details are good and ready access to the OVIT Web Aplication");
                Collection<GrantedAuthority> authorities = getAuthorities(userDetailsVo);
                authenticationToken = new UsernamePasswordAuthenticationToken(userDetailsVo,
                		credentials.getCredentials().toString(), authorities);
                authenticationToken.setDetails(request.getRemoteAddr());
                return authenticationToken;

            } else {
                String usuario = authExternal.validacionAcceso(credentials.getName(), credentials.getCredentials().toString());
                if (usuario.equals("")) {
                    userDetailsVo.setVistaRedireccion("");
                    Collection<GrantedAuthority> authorities = getAuthorities(userDetailsVo);
                    authenticationToken = new UsernamePasswordAuthenticationToken(userDetailsVo,
                    		credentials.getCredentials().toString(), authorities);
                    authenticationToken.setDetails(request.getRemoteAddr());
                    return authenticationToken;
                } else {
                    throw new BadCredentialsException(usuario);
                }
            }

        } catch (TransactionalOVITException e) {
            logger.error("Error al ejecutar OvitAuthenticationauthenticate: " + e);
            throw new BadCredentialsException(e.getMessageError());
        }
    }

    /**
     * Method that generates the {@link GrantedAuthority} of Ovit users}
     *
     * @param userDetailsVo {@link UserDetailsVo}
     * @return {@link Collection}<{@link GrantedAuthority}>
     */
    private Collection<GrantedAuthority> getAuthorities(UserDetailsVo userDetailsVo) {
        List<GrantedAuthority> authList = new ArrayList<>(1);
        authList.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
        authList.add(new SimpleGrantedAuthority(userDetailsVo.getRolNombre()));
        return authList;
    }
}

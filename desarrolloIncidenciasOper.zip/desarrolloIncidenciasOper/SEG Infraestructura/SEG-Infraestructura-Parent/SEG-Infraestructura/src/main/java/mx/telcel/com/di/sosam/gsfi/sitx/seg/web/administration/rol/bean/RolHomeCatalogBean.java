package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.rol.bean;

import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.rol.service.RolCatalogService.SUCCES;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ApplicationVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolAclVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.TabAplicacionAclUtil;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.rol.service.RolCatalogService;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Controller;
import org.springframework.webflow.execution.RequestContext;

@Controller("homeCatalogoRol")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class RolHomeCatalogBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4839486445458141063L;


	public static final String MSJ_FOL_ASIG="El rol no puede ser eliminado por que esta asignado a un usuario.";
	
	
	@Autowired
	@Qualifier("rolCatalogService")
	private RolCatalogService catalogoRolServcice;
	private List<RolVo> rolesOvit;
	private RolVo currentRol;
	private String currentFolioBaja;
	private String mensajeErrorDelete;
	private List<TabAplicacionAclUtil> tabsAclsApps= new ArrayList<TabAplicacionAclUtil>();
	private String messageError="Ha ocurrido un error en la eliminaci�n del rol.";
	private static final Logger logger = LogManager.getLogger(RolHomeCatalogBean.class);

	public void initHomeCatologHome(RequestContext ctx)
			throws TransactionalOVITException {	
		rolesOvit = catalogoRolServcice.getAllRoles();
		mensajeErrorDelete = "";
		currentFolioBaja="";
	}

	public void delete() throws TransactionalOVITException {
		try{
		org.primefaces.context.RequestContext context = org.primefaces.context.RequestContext.getCurrentInstance();
		boolean validation = false;
		boolean succes = false;
		String msgValidacion = catalogoRolServcice.validaFolio(currentFolioBaja);
		
		if (SUCCES.equals(msgValidacion)) {
			validation = true;
			if(!catalogoRolServcice.isAsigned(currentRol.getIdRol())){
				List<ApplicationVo> listaApps = catalogoRolServcice.getApliacionesByRol(currentRol);
				List<RolAclVo> intialAclsAsigned= catalogoRolServcice.fillTabsAcls(listaApps,currentRol,tabsAclsApps);
				currentRol.setListIdAplicacion(catalogoRolServcice.toIntegerList(listaApps));
				currentRol.setIdEstatus(2);
				succes = catalogoRolServcice.updateRol(currentRol, intialAclsAsigned,currentFolioBaja);
			}else{
				succes= false;
				messageError=MSJ_FOL_ASIG;
			}

		}else {
			mensajeErrorDelete = msgValidacion;

		}
		
		currentFolioBaja="";
		context.addCallbackParam("succes", succes);
		context.addCallbackParam("validation", validation);
		}catch(Exception e){
			logger.error("Error al ejecutar RolHomeCatalogBean.delete " + e);
		}

	}

	public void initDialog() {
		currentFolioBaja="";
		mensajeErrorDelete = "";

	}

	public List<RolVo> getRolesOvit() {
		return rolesOvit;
	}

	public void setRolesOvit(List<RolVo> rolesOvit) {
		this.rolesOvit = rolesOvit;
	}

	public RolVo getCurrentRol() {
		return currentRol;
	}

	public void setCurrentRol(RolVo currentRol) {
		this.currentRol = currentRol;
	}

	public String getCurrentFolioBaja() {
		return currentFolioBaja;
	}

	public void setCurrentFolioBaja(String currentFolioBaja) {
		this.currentFolioBaja = currentFolioBaja;
	}

	public String getMensajeErrorDelete() {
		return mensajeErrorDelete;
	}

	public void setMensajeErrorDelete(String mensajeErrorDelete) {
		this.mensajeErrorDelete = mensajeErrorDelete;
	}

	public String getMessageError() {
		return messageError;
	}

	public void setMessageError(String messageError) {
		this.messageError = messageError;
	}
	
	

}

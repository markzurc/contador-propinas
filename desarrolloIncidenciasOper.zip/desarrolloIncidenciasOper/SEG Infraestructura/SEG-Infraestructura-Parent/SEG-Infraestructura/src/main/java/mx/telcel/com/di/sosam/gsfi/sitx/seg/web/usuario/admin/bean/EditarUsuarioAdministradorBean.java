package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.usuario.admin.bean;

import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.external.authentication.IAuthenticationExternal;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dao.IUserDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.DocumentoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.EstatusDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.OperadorDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.ReportUserDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.user.service.UserCatalogService;

@Controller("editarUsuarioAdministradorBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class EditarUsuarioAdministradorBean implements Serializable {
	
	private static final Logger LOGGER = LogManager.getLogger(EditarUsuarioAdministradorBean.class);
	
	private static final long serialVersionUID = 4582624686881827949L;

	@Autowired
	@Qualifier("userCatalogService")
	private UserCatalogService userCatalogService;
	
	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;
	
	@Autowired
	@Qualifier("userDao")
	private IUserDao userDao;
	
	@Autowired
    @Qualifier("externalAuth")
    private IAuthenticationExternal authExternal;
	
	private File targetFolder;
	
	private ReportUserVo reportUserVo;
	
	private UserDetailsVo userDetailsVo;
	
	private List<String> listaTipoUsuario;
	private List<String> listaEstado;
	private List<OperadorDto> listaConcesionario;
	private List<EstatusDto> listaEstatus;
	private List<DocumentoDto> listaDocumentos;
	
	private String tipoUsuario;
	private String estado;
	
	private String seleccionadoTipoUsuario;
	private String seleccionadoEstatus;
	private String seleccionadoConcesionario;
	private String nombre;
	private String apellidoP;
	private String apellidoM;
	private String correo;
	private String pass;
	private String concesionario;
	private Integer concesionarioId;
	private String estatus;
	private Integer estatusId;
	private String mensajeTipoUsuario;
	
	private String renderedConcesionario;
	private String renderedTipoUsuario;
	private List<String> listaErrores;
	private Integer validaUsuarios;
	
	private DefaultStreamedContent archivoDescarga;
	
	private String leyenda;
	private String operacion;
	private String contraAnterior;
	private String estadoAnterior;
	
	
	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		try {
			userDetailsVo = (UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			listaEstado = new ArrayList<>();
			listaTipoUsuario = new ArrayList<>();
			listaConcesionario = new ArrayList<>();
			listaEstatus = new ArrayList<>();
			listaDocumentos = new ArrayList<>();
			tipoUsuario = "";
			estado = "";
			nombre = "";
			validaUsuarios = 0;
			cargaListas();
			cargaUsuario();
			listaDocumentos = userCatalogService.obtenerDocumentos(reportUserVo.getIdUsuario());
			validaTipoUsuario();
			validaTipoUsuarioLogueado();
			contraAnterior = userCatalogService.getPassUser(reportUserVo.getIdUsuario());
			estadoAnterior = userCatalogService.getEstadoUser(reportUserVo.getIdUsuario());
		} catch (Exception e) {
			LOGGER.info("Ocurrio un error al cargar la pagina: " + e);
			context.addMessage("mensajes",
					new FacesMessage(SEVERITY_ERROR, "Error", "Ocurri� un error al cargar la p�gina"));
		}
	}
	
	private void validaTipoUsuarioLogueado() {
		if(userDetailsVo.getIdTipoUsuario() == 3 || reportUserVo.getTipoUsuarioNombre().equals("IFT")){
			renderedTipoUsuario = "false";
		} else {
			renderedTipoUsuario = "true";
		}
	}

	public boolean validaciones() {
		validaUsuarios = 0;
		listaErrores = new ArrayList<>();
		boolean resp = true;
		try {
			ConfigurationUtilsVo configurationUtilsVo2 = configurationUtilsBusiness.
					getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.MAX_ADMIN_CONCESIONARIO);
			Integer numeroConcesionarios = Integer.parseInt(configurationUtilsVo2.getValor());
			
			List<ReportUserVo> user=userCatalogService.getAllUsers();
			if (seleccionadoTipoUsuario.equals("Administrador Concesionario")) {
				if (listaDocumentos.size()==0) {
					listaErrores.add("Se deben agregar documentos.");
					resp = false;
				}
				
				for (ReportUserVo reportUserVo : user) {
					if (!reportUserVo.getTipoUsuarioNombre().equals("IFT")) {
						if (!reportUserVo.getIdUsuario().equals(this.reportUserVo.getIdUsuario()) && (reportUserVo.getEstatusNombre().equals("Activo") || reportUserVo.getEstatusNombre().equals("Bloqueado"))) {
							if (reportUserVo.getEmpresa().equals(concesionario)) {
								validaUsuarios++;
							}
						}
					}
					
				}
				if (seleccionadoEstatus.equals("Activo") || seleccionadoEstatus.equals("Bloqueado")) {
					if (validaUsuarios >= numeroConcesionarios) {
						listaErrores.add("No es posible registrar m�s usuarios para el Concesionario seleccionado.");
						resp = false;
					}
				}
				
			}
			for (ReportUserVo reportUserVo : user) {
				if (reportUserVo.getCorreo().equals(correo)) {
					if (!reportUserVo.getIdUsuario().equals(this.reportUserVo.getIdUsuario())) {
						listaErrores.add("No se puede registrar otro usuario con el mismo correo.");
						resp = false;
					}
					
				}
			}
			List<ReportUserVo> user2=userCatalogService.getUsersConcesionario();
			for (ReportUserVo reportUserVo : user2) {
				if (reportUserVo.getCorreo().equals(correo)) {
					listaErrores.add("No se puede registrar otro usuario con el mismo correo.");
					resp = false;
				}
			}
			
			String strPasswordCrypt = authExternal.encriptarAcceso(pass);
			
			if (nombre.equals("")) {
				listaErrores.add("El campo nombre es obligatorio.");
				resp = false;
			}  else if (nombre.length()>=250) {
				listaErrores.add("El campo nombre no puede ser mayor a 250 caracteres.");
				resp = false;
			}
			if (!nombre.matches("[a-zA-Z ]*")) {
				listaErrores.add("Solo se pueden agregar letras en el campo nombre.");
				resp = false;
			}
			if (apellidoP.equals("")) {
				listaErrores.add("El campo apellido paterno es obligatorio.");
				resp = false;
			} else if (apellidoP.length()>=250) {
				listaErrores.add("El campo apellido paterno no puede ser mayor a 250 caracteres.");
				resp = false;
			}
			if (!apellidoP.matches("[a-zA-Z ]*")) {
				listaErrores.add("Solo se pueden agregar letras en el campo apellido paterno.");
				resp = false;
			}
			if (apellidoM.equals("")) {
				listaErrores.add("El campo apellido materno es obligatorio.");
				resp = false;
			} else if (apellidoM.length()>=250) {
				listaErrores.add("El campo apellido materno no puede ser mayor a 250 caracteres.");
				resp = false;
			}
			if (!apellidoM.matches("[a-zA-Z ]*")) {
				listaErrores.add("Solo se pueden agregar letras en el campo apellido materno.");
				resp = false;
			}
			if (correo.equals("")) {
				listaErrores.add("El campo correo electr�nico es obligatorio.");
				resp = false;
			} else if (!correo.toLowerCase().matches("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$")) {
				listaErrores.add("El correo electr�nico no cumple con el formato requerido.");
				resp = false;
			}
			
			if (pass.equals("")) {
				listaErrores.add("El campo contrase�a es obligatorio.");
				resp = false;
			} else if (pass.length() > 30 || pass.length() < 8) {
				listaErrores.add("La contrase�a debe tener de 8 a 30 caracteres.");
				resp = false;
			} else if (!contrasenaSegura(pass)) {
				listaErrores.add("La contrase�a debe tener m�nimo 1 numero, 1 s�mbolo, 1 car�cter especial, 1 letra may�scula y min�sculas.");
				resp = false;
			} else if (seleccionadoEstatus.equals("Activo") && estadoAnterior.equals("2")) {
				if (strPasswordCrypt.equals(contraAnterior)) {
					listaErrores.add("La contrase�a debe ser diferente a la anterior ya que se cambio el estado de Baja a Activo .");
					resp = false;
				}
			}
			if (seleccionadoEstatus.equals("null") || seleccionadoEstatus.equals("")) {
				listaErrores.add("El campo estado es obligatorio.");
				resp = false;
			} else if (seleccionadoEstatus.equals("Bloqueado")) {
				if(!reportUserVo.getEstatusNombre().equals("Bloqueado")){
					listaErrores.add("No se puede bloquear el usuario.");
					resp = false;
				}
			}
		} catch (TransactionalOVITException e) {
			e.printStackTrace();
		}
		return resp;
	}
	
	public static boolean contrasenaSegura(String contrasena) {

		boolean mayuscula = false;
		boolean minuscula = false;
        boolean numero = false;
        boolean especial = false;
               
        //Define caracteres especiales
        Pattern special = Pattern.compile("[<>{}\"/|;:.,!?@#$%=&*\\]\\\\()\\[��_+]");
        Matcher hasSpecial = special.matcher(contrasena);

        int i;
        char l;

        for (i = 0; i < contrasena.length(); i++) {
            l = contrasena.charAt(i);

            if (Character.isDigit(l)) {//m�nimo un n�mero. 
                numero = true;
            }
            
            if (Character.isUpperCase(l)) { // m�nimo una letra may�scula 
                mayuscula = true;
            }
            
            if (Character.isLowerCase(l)) { // m�nimo una letra may�scula 
                minuscula = true;
            }
            
            if (hasSpecial.find()) { //Valida "caracteres especiales".       
                especial = true;
            }
        }

        if (numero == true && mayuscula == true && minuscula == true && especial == true) {
            return true;
        } else {
            return false;
        }
	}

	public void editarUsuario() {
		boolean valid = validaciones();
		if (valid) {
			String strPasswordCrypt = authExternal.encriptarAcceso(pass);
			ReportUserDto reportUserDto = new ReportUserDto();
			reportUserDto.setNombre(capitalizarPrimeraLetra(nombre.toLowerCase()));
			reportUserDto.setApellidoPaterno(capitalizarPrimeraLetra(apellidoP.toLowerCase()));
			reportUserDto.setApellidoMaterno(capitalizarPrimeraLetra(apellidoM.toLowerCase()));
			reportUserDto.setIdUsuario(reportUserVo.getIdUsuario());
			reportUserDto.setCorreo(correo);
			
			if (seleccionadoEstatus.equals("Activo")) {
				reportUserDto.setIdEstatus(0);
			} else if (seleccionadoEstatus.equals("Bloqueado")) {
				reportUserDto.setIdEstatus(1);
			}else {
				reportUserDto.setIdEstatus(2);
			}
			
			if (estadoAnterior.equals("2") && seleccionadoEstatus.equals("Activo")) {
				reportUserDto.setIdEstatus(3);
			}
			
			if (seleccionadoEstatus.equals("Activo")) {
				if (strPasswordCrypt.equals(contraAnterior)) {
					reportUserDto.setIdEstatus(0);
				} else {
					reportUserDto.setIdEstatus(3);
				}
			}
			
			boolean resp = userCatalogService.actualizarUsuarioAdmin(reportUserDto, strPasswordCrypt);
			if (resp) {
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMensaje').show();");
			} else {
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMensajeError').show();");
			}
		} else {
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgValidaciones').show();");
		}
		
	}
	
	public String capitalizarPrimeraLetra(String str) {
		String nombreR="";
		String[] parts = str.split(" ");
		for (String string : parts) {
			if(string.trim().length() > 0){
				String nombre = string;
				String resultado = nombre.toUpperCase().charAt(0) + nombre.substring(1, nombre.length()).toLowerCase();
				nombreR = nombreR + resultado + " ";
			}
		}
		String nombreF = nombreR.substring(0, nombreR.length() - 1);
		return nombreF;
	}
	
	public void validaTipoUsuario() {
		if (reportUserVo.getTipoUsuarioNombre().equals("IFT")) {
			mensajeTipoUsuario = "IFT";
			renderedConcesionario = "false";
		} else {
			mensajeTipoUsuario = "Administrador";
			renderedConcesionario = "true";
		}
	}
	
	public void eliminarDoc(DocumentoDto doc) {
		//boolean resp = userCatalogService.eliminarDoc(doc.getIdDocumento());
		ConfigurationUtilsVo configurationUtilsVo;
		try {
			configurationUtilsVo = configurationUtilsBusiness.
					getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_USR);
			String ruta = String.valueOf(configurationUtilsVo.getValor())  + reportUserVo.getIdUsuario() + File.separator + doc.getDocumento();
			File archivo = new File(ruta);

		    if (archivo.delete()) {
		    	LOGGER.info("Se elimin� de manera correcta el archivo.");
		    } else {
		    	LOGGER.info("Ocurri� un error al eliminar el archivo.");
		    }
		    
		} catch (TransactionalOVITException e) {
			e.printStackTrace();
		}
		listaDocumentos = userCatalogService.obtenerDocumentos(reportUserVo.getIdUsuario());
		
	}
	
	public void cargaArchivos(FileUploadEvent event) throws IOException {
		listaErrores = new ArrayList<>();
		if (listaDocumentos.size()>1) {
			listaErrores.add("No puedes agregar m�s de dos archivos.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgValidaciones').show();");
		} else {
			String fileName = null;
			InputStream inputStream =null;	
			try {
				ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness.
						getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_USR);
				String ruta = String.valueOf(configurationUtilsVo.getValor());
				fileName = FilenameUtils.getName(event.getFile().getFileName());
				File directorioTemp = new File(ruta + File.separator+ reportUserVo.getIdUsuario());
				if (!directorioTemp.exists()) {
					directorioTemp.mkdirs();
				}
				inputStream = event.getFile().getInputstream();
				
				String rutaA = directorioTemp.getPath() + File.separator + fileName;
				File verificaSiExiste = new File(rutaA);
				
				subirArchivo(inputStream, verificaSiExiste);
				guardarArchivo(directorioTemp.getPath(), fileName);
				
			} catch (Exception e) {
				System.out.println("error");
			}
			finally {
				listaDocumentos = userCatalogService.obtenerDocumentos(reportUserVo.getIdUsuario());
			}
		}
	}
	
	public void verArchivoPrevio(DocumentoDto archivo) {
		FacesContext context = FacesContext.getCurrentInstance();
		LOGGER.info("Este es el id para buscar el archivo: " + archivo.getIdDocumento());
		try {
			archivoDescarga = getArchivoFileById(archivo);
		} catch(Exception error){
			LOGGER.error("Ocurri� un error al intentar descargar el archivo: " + error);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('modalDescarga').hide();");
			context.addMessage("mensajes", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error Descarga",
					"Ocurri� un error al intentar descargar el archivo; favor de intentarlo de nuevo."));
		}
	}
	
	public DefaultStreamedContent getArchivoFileById(DocumentoDto archivo) {
		FacesContext context = FacesContext.getCurrentInstance();
		ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();		
		File file = new File(archivo.getRuta() + File.separator + archivo.getDocumento());
		InputStream targetStream = null;
		try {
			byte[] decodedBytes = Files.readAllBytes(file.toPath());
			targetStream = new ByteArrayInputStream(decodedBytes);	
		} catch(Exception e) {
			LOGGER.error("Ocurri� un error al intentar descargar el archivo: " + e);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('modalDescarga').hide();");
			context.addMessage("mensajes", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error Descarga",
					"Ocurri� un error al intentar descargar el archivo; favor de intentarlo de nuevo."));
		}
		return new DefaultStreamedContent(targetStream, externalContext.getMimeType(archivo.getDocumento()),
				archivo.getDocumento());
	}
	
	public void guardarArchivo(String ruta, String name) {
		userCatalogService.guardarDocumento(ruta, name, reportUserVo.getIdUsuario());
	}
	
	public static boolean subirArchivo(InputStream origen, File destino) {
		OutputStream out = null;
		try {
			InputStream in = origen;
			out = new FileOutputStream(destino);

			byte[] buf = new byte[1024];
			int len;

			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}

			in.close();
			out.close();
		} catch (IOException e) {
			return false;

		} finally {
			close(out);
		}

		return true;
	}
	
	private static void close(Closeable closable){
        try {
            if( closable != null ){
            	closable.close();
            }
        } catch (IOException e) {
        	System.out.println("Error al cerrar OutputStream ");
        }
    }
	
	private void cargaUsuario() {
		
		this.setTipoUsuario("Seleccione un tipo usuario");
		this.setConcesionario(reportUserVo.getEmpresa());
		
		this.setSeleccionadoTipoUsuario(reportUserVo.getTipoUsuarioNombre());
		
		this.setEstatus("Seleccione un estado");
		if (reportUserVo.getEstatusNombre().equals("Nuevo")) 
			this.setSeleccionadoEstatus("Activo");
		else 
			this.setSeleccionadoEstatus(reportUserVo.getEstatusNombre());
		
		
		this.setNombre(reportUserVo.getNombre());
		this.setApellidoM(reportUserVo.getApellidoMaterno());
		this.setApellidoP(reportUserVo.getApellidoPaterno());
		this.setCorreo(reportUserVo.getCorreo());
		
		String strPasswordCrypt = authExternal.desencriptarAcceso(reportUserVo.getPass());
		this.setPass(strPasswordCrypt);
	}
	
	private void cargaListas() {
		listaEstado.add("Activo");
		listaEstado.add("Bloqueado");
		listaEstado.add("Baja");
//		listaEstado.add("Nuevo");
//		listaEstado.add("Reiniciado");
//		listaEstado.add("Mantenimiento");
//		listaEstado.add("Expirado");
		
		listaTipoUsuario.add("Administrador Concesionario");
		listaTipoUsuario.add("IFT");
		
		this.setListaConcesionario(userCatalogService.obtenerEmpresas());
		this.setListaEstatus(userCatalogService.obtenerEstatus());
		
	}

	public File getTargetFolder() {
		return targetFolder;
	}

	public void setTargetFolder(File targetFolder) {
		this.targetFolder = targetFolder;
	}

	public ReportUserVo getReportUserVo() {
		return reportUserVo;
	}

	public void setReportUserVo(ReportUserVo reportUserVo) {
		this.reportUserVo = reportUserVo;
	}

	public List<String> getListaTipoUsuario() {
		return listaTipoUsuario;
	}

	public void setListaTipoUsuario(List<String> listaTipoUsuario) {
		this.listaTipoUsuario = listaTipoUsuario;
	}

	public List<String> getListaEstado() {
		return listaEstado;
	}

	public void setListaEstado(List<String> listaEstado) {
		this.listaEstado = listaEstado;
	}

	public String getTipoUsuario() {
		return tipoUsuario;
	}

	public void setTipoUsuario(String tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getSeleccionadoTipoUsuario() {
		return seleccionadoTipoUsuario;
	}

	public void setSeleccionadoTipoUsuario(String seleccionadoTipoUsuario) {
		this.seleccionadoTipoUsuario = seleccionadoTipoUsuario;
	}

	public String getSeleccionadoEstatus() {
		return seleccionadoEstatus;
	}

	public void setSeleccionadoEstatus(String seleccionadoEstatus) {
		this.seleccionadoEstatus = seleccionadoEstatus;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidoP() {
		return apellidoP;
	}

	public void setApellidoP(String apellidoP) {
		this.apellidoP = apellidoP;
	}

	public String getApellidoM() {
		return apellidoM;
	}

	public void setApellidoM(String apellidoM) {
		this.apellidoM = apellidoM;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getSeleccionadoConcesionario() {
		return seleccionadoConcesionario;
	}

	public void setSeleccionadoConcesionario(String seleccionadoConcesionario) {
		this.seleccionadoConcesionario = seleccionadoConcesionario;
	}

	public String getConcesionario() {
		return concesionario;
	}

	public void setConcesionario(String concesionario) {
		this.concesionario = concesionario;
	}

	public List<OperadorDto> getListaConcesionario() {
		return listaConcesionario;
	}

	public void setListaConcesionario(List<OperadorDto> listaConcesionario) {
		this.listaConcesionario = listaConcesionario;
	}

	public List<DocumentoDto> getListaDocumentos() {
		return listaDocumentos;
	}

	public void setListaDocumentos(List<DocumentoDto> listaDocumentos) {
		this.listaDocumentos = listaDocumentos;
	}

	public Integer getConcesionarioId() {
		return concesionarioId;
	}

	public void setConcesionarioId(Integer concesionarioId) {
		this.concesionarioId = concesionarioId;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getRenderedConcesionario() {
		return renderedConcesionario;
	}

	public void setRenderedConcesionario(String renderedConcesionario) {
		this.renderedConcesionario = renderedConcesionario;
	}
	
	public String getRenderedTipoUsuario() {
		return renderedTipoUsuario;
	}

	public void setRenderedTipoUsuario(String renderedTipoUsuario) {
		this.renderedTipoUsuario = renderedTipoUsuario;
	}

	public List<EstatusDto> getListaEstatus() {
		return listaEstatus;
	}

	public void setListaEstatus(List<EstatusDto> listaEstatus) {
		this.listaEstatus = listaEstatus;
	}

	public String getEstatus() {
		return estatus;
	}

	public void setEstatus(String estatus) {
		this.estatus = estatus;
	}

	public Integer getEstatusId() {
		return estatusId;
	}

	public void setEstatusId(Integer estatusId) {
		this.estatusId = estatusId;
	}

	public List<String> getListaErrores() {
		return listaErrores;
	}

	public void setListaErrores(List<String> listaErrores) {
		this.listaErrores = listaErrores;
	}

	public DefaultStreamedContent getArchivoDescarga() {
		return archivoDescarga;
	}

	public void setArchivoDescarga(DefaultStreamedContent archivoDescarga) {
		this.archivoDescarga = archivoDescarga;
	}

	public String getLeyenda() {
		return leyenda;
	}

	public void setLeyenda(String leyenda) {
		this.leyenda = leyenda;
	}

	public String getOperacion() {
		return operacion;
	}

	public void setOperacion(String operacion) {
		this.operacion = operacion;
	}

	public String getMensajeTipoUsuario() {
		return mensajeTipoUsuario;
	}

	public void setMensajeTipoUsuario(String mensajeTipoUsuario) {
		this.mensajeTipoUsuario = mensajeTipoUsuario;
	}
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.user.service;

import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX0;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX1;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX2;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX3;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX4;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX5;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX6;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX7;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX8;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX9;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.STATUS_BAJA;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.STATUS_REINICIADO;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.USER_EXTENRO_TYPE;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.USER_EXTENRO_TYPE_STRING;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.USER_INETRNO_TYPE_STRING;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.USER_INTERNO_TYPE;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.exception.SendingMailOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.application.thirdparty.request.ApplicationGenericRequest;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.IApplicationBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ApplicationVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.email.vo.CorreoNotiVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.email.vo.CorreoPropVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.IRolBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolApplicationVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rolaccion.vo.RolAccionVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.IUserBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ExternalUserFindVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ExternalUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.InternalUserFindVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.UserContraVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.DocumentoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.EstatusDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.OperadorDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.ReportUserDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.BitacoraSeguridadUtil;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.WrapperReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.primefaces.model.TreeNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service("userCatalogService")
public class UserCatalogService implements Serializable{

	private static final long serialVersionUID = 6787145618586555818L;
	public static final String STEP_ACLS="aclsRol";
	public static final String STEP_CONFIMR="confirm";
	
	@Autowired
	@Qualifier("bitacoraSeguridadUtil")
	private BitacoraSeguridadUtil bitacoraSeguridadUtil;

	@Autowired
	@Qualifier("rolBusiness")
	private IRolBusiness rolBussines;

	@Autowired
	@Qualifier("userBusiness")
	private IUserBusiness userBusinessImpl;

	@Autowired
	@Qualifier("aplicacionBusiness")
	private IApplicationBusiness aplicacionBussinesImpl;
	private int index=0;
	public static final int INDEX0=0;
	public static final int INDEX1=1;
	public static final int INDEX2=2;
	public static final int INDEX3=3;
	public static final int INDEX4=4;
	public static final int INDEX5=5;
	public static final int INDEX6=6;
	public static final int INDEX7=7;
	public static final int INDEX8=8;
	public static final int INDEX9=9;
	public static final int INDEX10=10;
	public static final int INDEX11=11;
	public static final String FONT_EXCELL="Century Gothic";
	public static final short FONT_SIZE=10;
	public static final short FONT_SIZE_8=8;
	static XSSFColor level1 =new XSSFColor(new java.awt.Color(15,36,62));
    static XSSFColor level2 =new XSSFColor(new java.awt.Color(33,89,103));
    static XSSFColor level3 =new XSSFColor(new java.awt.Color(49,134,155));
    static XSSFColor level4 =new XSSFColor(new java.awt.Color(146,205,220));
    static XSSFColor level5 =new XSSFColor(new java.awt.Color(255,255,255));
    XSSFCellStyle styleDerecho = null;
	public static final Map<Integer,XSSFColor> STYLE_LEVELS= new HashMap<Integer,XSSFColor>();
	static{
		STYLE_LEVELS.put(INDEX1,level1);
		STYLE_LEVELS.put(INDEX2,level2);
		STYLE_LEVELS.put(INDEX3,level3);
		STYLE_LEVELS.put(INDEX4,level4);
		STYLE_LEVELS.put(INDEX0,level5);
	}
	private static String[] columNamesUserExcel = {"Nombre","Apellido paterno","Apellido materno","Correo electr�nico","Concecionario","Estado"};

	private static final Logger logger = LogManager.getLogger(UserCatalogService.class);



	public UserContraVo getDataSoxDatePass(Integer idUsuario) throws TransactionalOVITException{

		UserContraVo  userPasswordVo=	userBusinessImpl.obtainUserPasswordInfo(idUsuario);

		return  userPasswordVo; 
	}

	public ReportUserVo loadReportUserById(int idUser) throws TransactionalOVITException{
		List<ReportUserVo> lista= getAllUsers();
		for(ReportUserVo reportUserVo:lista){
			if(reportUserVo.getIdUsuario()== idUser){
				return reportUserVo;
			}
		}
		return null;	
	}


	public boolean resetPassword(Integer idUsuario){
		try {
			userBusinessImpl.resetPassword(idUsuario);
			return true;
		} catch (TransactionalOVITException e) {
			logger.error("Error al ejecutar UserCatalogService.resetPassword: " + e);
			return false;		} 
		catch (SendingMailOVITException e) {
			logger.error("Error al ejecutar UserCatalogService.resetPassword: " + e);
			return false;	
		}
	}


	public boolean existUser(String user) throws TransactionalOVITException{
		List<ReportUserVo> lista= getAllUsers();
		for(ReportUserVo reportUserVo:lista){
			if(reportUserVo.getNumeroEmpleado().equals(user)){
				return true;
			}
		}
		return false;
	}


	public InternalUserFindVo loadUserInternal(Integer idUsuario) throws TransactionalOVITException{
		return userBusinessImpl.findInternalUserById(idUsuario);
	}

	public ExternalUserFindVo loadUserExternal(Integer idUsuario) throws TransactionalOVITException{
		return userBusinessImpl.findExternalUserById(idUsuario);
	}


	public String createUser(ExternalUserVo userTypeVo,List<? super ApplicationGenericRequest> listRequest) {
		String msj="success";

		try{
			userBusinessImpl.createUser(userTypeVo, listRequest);

		}catch(SendingMailOVITException sme){
			logger.error("Error al ejecutar UserCatalogService.createUser: " + sme);
			msj="error_mail";
		}catch(TransactionalOVITException toe){
			logger.error("Error al ejecutar UserCatalogService.createUser: " + toe);
			msj="error_bd";
		}

		return msj;  

	}



	public void registraEnBitacora(String oldObj,Object newObj,String folio,int operationType){
		bitacoraSeguridadUtil.registraEntradaBitacora(oldObj, newObj, folio, operationType);
	}

	public String getXMLfromObject(Object obj){
		return bitacoraSeguridadUtil.getActualStateXML(obj);
	}


	public boolean updateUser(ExternalUserVo userTypeVo,List<? super ApplicationGenericRequest> listRequest) {
		try{  
			if(listRequest!=null){
				userBusinessImpl.updateUserApplicationList(listRequest);
			}
			if(userTypeVo!=null){
				userBusinessImpl.updateUser(userTypeVo);
			}
			return true;
		}catch(TransactionalOVITException toe){
			logger.error("Error al ejecutar UserCatalogService.updateUser: " + toe);
			return false;
		}
	}


	public boolean updateStatusUser(int idUser,int idStatus) {
		try{  
			userBusinessImpl.updateStatus(idUser, idStatus);
			return true;
		}catch(TransactionalOVITException toe){
			logger.error("Error al ejecutar UserCatalogService.updateStatusUser: " + toe);
			return false;
		}
	}


	public boolean changePass(String password, int idUsuario){
		try{  
			userBusinessImpl.updatePassword(idUsuario, password,STATUS_REINICIADO);
			return true;
		}catch(TransactionalOVITException toe){
			logger.error("Error al ejecutar UserCatalogService.changePass: " + toe);
			return false;
		}
	}


	public  List<ReportUserVo> getAllInternalUsers(List<ReportUserVo> listAllUser){
		List<ReportUserVo> filteredList= new ArrayList<ReportUserVo>(); 

		for(ReportUserVo reportUserVo:listAllUser){
			if(reportUserVo.getIdTipoUsuario()==USER_INTERNO_TYPE){
				filteredList.add(reportUserVo);
			}
		}
		return filteredList; 
	}


	public List<ApplicationVo> getApliacionesByRol(RolVo rol) throws TransactionalOVITException{
		RolApplicationVo rolApplicationVo= rolBussines.findByWithApplications(rol);
		return rolApplicationVo.getRolAplicacion().get(rol);
	}



	public List<RolVo> getRoles(int tipoUsuario) throws TransactionalOVITException{
		logger.info("Cargando roles del sistema ");
		List<RolVo> listaRoles=rolBussines.findByWithoutApplications (new RolVo());
		filtraRolbyUserType(listaRoles,tipoUsuario);

		return listaRoles;
	}


	public RolVo loadRolbyId(int idRol) throws TransactionalOVITException{
		RolVo rolVo=new RolVo();
		rolVo.setIdRol(idRol);
		List<RolVo> listaRoles=rolBussines.findByWithoutApplications (rolVo);

		for(RolVo rol: listaRoles){
			if(rol.getIdRol()==idRol){
				return rol;
			}
		}


		return null;
	}

	private void filtraRolbyUserType(List<RolVo> listaRoles,int tipoUser){
		List<RolVo> listResult= new ArrayList<RolVo>();

		for(RolVo rol:listaRoles){
			if(rol.getIdTipoRol() == tipoUser &&  rol.getIdEstatus() != STATUS_BAJA){
				listResult.add(rol);
			}
		}

		listaRoles.clear();
		listaRoles.addAll(listResult);
	}




	public List<ApplicationVo> getAllApp() throws TransactionalOVITException{
		logger.info("Cargando Apps del sistema ");
		return aplicacionBussinesImpl.findByExample(new ApplicationVo());
	}


	private int getLevel(TreeNode node){
		int count=INDEX0;
		while(node.getParent()!=null){
			node=node.getParent();
			count++;
		}
		return count;
	} 


	private String concatTab(int number){
		StringBuffer cadena=new StringBuffer();
		for(int x=INDEX0;x<number;x++){
			cadena.append("   ");
		}
		cadena.append("-");
		return cadena.toString();
	}
	
	public List<WrapperReportUserVo> wrapListUsers(List<ReportUserVo> usuarios){
		List<WrapperReportUserVo> listaBack=new ArrayList<WrapperReportUserVo>();
		for(ReportUserVo reportUserVo:usuarios){
			WrapperReportUserVo wrapperReportUserVo=new WrapperReportUserVo(reportUserVo);
			listaBack.add(wrapperReportUserVo);
		}

		return listaBack;
	}

	private static String[] columNamesUser={"Numero de empleado","Nombre","Apellido Paterno","Apellido Materno","Rol","Tipo usuario","Estatus"};

	public void registraAccionBitacora(String oldObj, String newObj, String folio, int operationType) {
		bitacoraSeguridadUtil.registraAccionBitacora(oldObj, newObj, folio, operationType);
	}

	public List<RolAccionVo> getRolAccionByRol(Integer rol) throws TransactionalOVITException {
		return userBusinessImpl.findRolAccionByRol(rol);
	}

	public List<CorreoNotiVo> getCorreoNotiByProd(Long producto) throws TransactionalOVITException{
		return userBusinessImpl.findAllCorrNotiByProd(producto);
	}

	public List<CorreoPropVo> getAllCorreoProp() throws TransactionalOVITException{
		return userBusinessImpl.findAllCorrProp();
	}
	
	public List<String> getAllCorreoAuto(Long rolAutorizador) throws TransactionalOVITException{
		return userBusinessImpl.findAllCorrAuto(rolAutorizador);
	}

	public List<String> getAllCorreoGrupoRol(List<Integer> grupoRol) {
		return userBusinessImpl.getAllCorreoGrupoRol(grupoRol);
	}

////////////////////////////////////////////////////////////////////////////////77

	public boolean actualizarUsuarioAdmin(ReportUserDto reportUserDto, String pass) {
		return userBusinessImpl.actualizarUsuarioAdmin(reportUserDto, pass);
	}

	public boolean guardarDocumento(String ruta, String name, Integer idUsuario) {
		return userBusinessImpl.guardarDocumento(ruta, name, idUsuario);
	}

	public boolean altaDocumento(String ruta, String name, Integer idUsuario) {
		return userBusinessImpl.altaDocumento(ruta, name, idUsuario);
	}

	public List<DocumentoDto> obtenerDocumentos(Integer idUsuario) {
		return userBusinessImpl.obtenerDocumentos(idUsuario);
	}

	public boolean eliminarDoc(Integer idDoc) {
		return userBusinessImpl.eliminarDoc(idDoc);
	}

	public boolean altaUsuarioAdministrador(ReportUserDto reportUserDto, String pass) {
		return userBusinessImpl.altaUsuarioAdmin(reportUserDto, pass);
	}
	
	public boolean requiereCambioPass(String rol) {
		return userBusinessImpl.requiereCambioPass(rol);
	}

	public boolean altaPass(ReportUserDto reportUserDto) {
		return userBusinessImpl.altaPass(reportUserDto);
	}

	public boolean altaRolUsuario(ReportUserDto reportUserDto) {
		return userBusinessImpl.altaRolUsuario(reportUserDto);
	}

	public List<OperadorDto> obtenerEmpresas() {
		return userBusinessImpl.obtenerEmpresas();
	}

	public String obtenerOperadorUsuario(Integer idUsuario) {
		return userBusinessImpl.obtenerOperadorUsuario(idUsuario);
	}

	public List<EstatusDto> obtenerEstatus() {
		return userBusinessImpl.obtenerEstatus();
	}
	
	public List<ReportUserVo> getUsersConcesionario() throws TransactionalOVITException{
		return 	userBusinessImpl.findReportUsersConcesionario();
	}
	
	public List<ReportUserVo> getAllUsers() throws TransactionalOVITException{
		return 	userBusinessImpl.findAllReportUsers();
	}

	public String idArchivosUsuario() {
		return userBusinessImpl.idArchivosUsuario();
	}
	
	public List<ReportUserVo> getUsersConcesionarioByOp(String operadorUsuario) throws TransactionalOVITException {
		return userBusinessImpl.getUsersConcesionarioByOp(operadorUsuario);
	}
 
	public int getCountUsersConcesionarioByOp(String seleccionadoConcesionario) {
		return userBusinessImpl.getCountUsersConcesionarioByOp(seleccionadoConcesionario);
	}
	
	public String getPassUser(int idUsuario) {
		return userBusinessImpl.getPassUser(idUsuario);
	}
	
	public String getEstadoUser(int idUsuario) {
		return userBusinessImpl.getEstadoUser(idUsuario);
	}
	
	public void toExcel(XSSFWorkbook hssfWorkbook, List<WrapperReportUserVo> userList) {
		XSSFSheet sheet = hssfWorkbook.createSheet("Reporte Usuarios Concesionario"); 
		sheet.setDisplayGridlines(false);
		sheet.setPrintGridlines(false);
		XSSFCellStyle headerStyle = getLevelStyle(hssfWorkbook,INDEX1);
		headerStyle.setAlignment(HorizontalAlignment.CENTER);
		XSSFCellStyle campoStyle = getLevelStyle(hssfWorkbook,INDEX5);
		campoStyle.setBorderBottom(CellStyle.BORDER_THIN);
		campoStyle.setBorderLeft(CellStyle.BORDER_THIN);
		campoStyle.setBorderRight(CellStyle.BORDER_THIN);
		campoStyle.setBorderTop(CellStyle.BORDER_THIN);
		//Estilo para el borde derecho
		styleDerecho = Constants.getLevelStyle(hssfWorkbook,Constants.INDEX2);
		styleDerecho.setBorderRight(CellStyle.BORDER_THIN);
		styleDerecho.setRightBorderColor(IndexedColors.BLACK.getIndex());
		styleDerecho.setBorderTop(CellStyle.BORDER_THIN);
		styleDerecho.setTopBorderColor(IndexedColors.WHITE.getIndex());
		//APPs
		insertaCell(sheet,INDEX0,INDEX0,"Reporte Usuarios Concesionario",headerStyle);
		sheet.addMergedRegion(new CellRangeAddress(INDEX0,INDEX0,0,5));
 
		index=1;
		addColumnsNames(sheet, index++, getLevelStyle(hssfWorkbook,INDEX2), columNamesUserExcel);
		for(WrapperReportUserVo reportUserVo: userList){
			insertaCell(sheet, index,INDEX0,reportUserVo.getReportUserVo().getNombre(),campoStyle);
			insertaCell(sheet, index,INDEX1,reportUserVo.getReportUserVo().getApellidoPaterno(),campoStyle);
			insertaCell(sheet, index,INDEX2,reportUserVo.getReportUserVo().getApellidoMaterno(),campoStyle);
			insertaCell(sheet, index,INDEX3,reportUserVo.getReportUserVo().getCorreo(),campoStyle);
			insertaCell(sheet, index,INDEX4,reportUserVo.getReportUserVo().getEmpresa(),campoStyle);
			insertaCell(sheet, index,INDEX5,reportUserVo.getReportUserVo().getEstatusNombre(),campoStyle);
			index++;
		}
		ajustarTodasColumnas(sheet, 6, index);
	}

	// common
	private void insertaCell(XSSFSheet sheet, int rowIndex, int column, String value, XSSFCellStyle style) {
		XSSFRow commonRow = sheet.getRow(rowIndex);
		if (commonRow == null) {
			commonRow = sheet.createRow(rowIndex);
		}
 
		XSSFCell nombre = commonRow.createCell(column);
		nombre.setCellValue(value);
		sheet.autoSizeColumn(column);
		nombre.setCellStyle(style);

	}

	// common
	private void addColumnsNames(XSSFSheet sheet, int position, XSSFCellStyle style, String[] titles) {
		int column = INDEX0;
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setRightBorderColor(IndexedColors.WHITE.getIndex());
		style.setBorderTop(CellStyle.BORDER_THIN);
		style.setTopBorderColor(IndexedColors.WHITE.getIndex());
		for (String titleColumn : titles) {
			if (column == 5) {
				insertaCell(sheet, position, column, titleColumn, styleDerecho);
			}else {
				insertaCell(sheet, position, column, titleColumn, style);
			}
			column += 1;
						
		}
	}
	
	public static XSSFCellStyle getLevelStyle(XSSFWorkbook hssfWorkbook,int level){
		XSSFCellStyle style = hssfWorkbook.createCellStyle();
		XSSFFont fontH = hssfWorkbook.createFont();
		fontH.setFontName(FONT_EXCELL); 
		fontH.setFontHeightInPoints(FONT_SIZE);
		if(STYLE_LEVELS.containsKey(level)){
			style.setFillForegroundColor(STYLE_LEVELS.get(level));
			fontH.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			fontH.setColor(IndexedColors.WHITE.getIndex());
		}else{
			style.setFillForegroundColor(STYLE_LEVELS.get(INDEX0));
			fontH.setColor(IndexedColors.BLACK.getIndex());
		}
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style.setFont(fontH);
 
		return style;
	}
	
	private void ajustarTodasColumnas(XSSFSheet sheet, int numColumnas, int numFilas) {
	    for (int col = 0; col < numColumnas; col++) {
	        int anchoMax = 0;
	        String textoMayus = "";
	        for (int fila = 1; fila < numFilas; fila++) {
	            XSSFRow row = sheet.getRow(fila);
	            if (row != null) {
	                XSSFCell cell = row.getCell(col);
	                if (cell != null && !cell.getStringCellValue().isEmpty()) {	                    
	                	String texto = cell.getStringCellValue();
	                	if (texto.length() > anchoMax) {
	                		anchoMax  = texto.length();	
	                		textoMayus = texto;
						}
	                }
	            }
	        }
	        if (textoMayus.matches("^[A-Z\\s]+$")) {
	        	sheet.setColumnWidth(col, (anchoMax + 3) * 300);
				
			}else {
				sheet.setColumnWidth(col, (anchoMax + 3) * 256);
			}
	    }
	}
	
}

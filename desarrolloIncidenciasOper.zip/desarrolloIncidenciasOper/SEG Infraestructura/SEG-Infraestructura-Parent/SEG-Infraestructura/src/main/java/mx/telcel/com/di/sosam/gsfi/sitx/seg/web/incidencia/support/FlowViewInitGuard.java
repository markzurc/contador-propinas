package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.incidencia.support;

import java.io.Serializable;
import java.util.Map;

import javax.faces.context.FacesContext;

import org.springframework.webflow.execution.RequestContext;

public class FlowViewInitGuard implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String KEY_BITACORA_CONC = "INC_BITACORA_CONC_INIT_ONCE";
	public static final String KEY_BITACORA_MANT = "INC_BITACORA_MANT_INIT_ONCE";

	public boolean shouldRun(RequestContext ctx, String key) {
		if (ctx == null || key == null) {
			return true;
		}

		Object yaEjecuto = ctx.getRequestScope().get(key);
		if (yaEjecuto != null) {
			return false;
		}

		ctx.getRequestScope().put(key, Boolean.TRUE);
		return true;
	}

	public boolean shouldRun(FacesContext fc, String key) {
		if (fc == null || key == null) {
			return true;
		}

		Map<String, Object> requestMap = fc.getExternalContext().getRequestMap();
		if (requestMap.containsKey(key)) {
			return false;
		}

		requestMap.put(key, Boolean.TRUE);
		return true;
	}
}

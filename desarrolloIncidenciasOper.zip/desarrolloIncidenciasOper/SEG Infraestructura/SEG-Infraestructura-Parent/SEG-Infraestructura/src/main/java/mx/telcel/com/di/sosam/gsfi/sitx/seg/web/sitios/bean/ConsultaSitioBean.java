package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.sitios.bean;

import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;


import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.security.core.context.SecurityContextHolder;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.ReporteSegUtil;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.reportes.service.SitiosService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.primefaces.model.DefaultStreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Controller;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.elementosPantalla.IElementosPantallaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.IConsultaSitiosService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ElementosPantallaDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ConsultaSolicitudesDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.FiltroSitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;

@Controller("consultaSitioBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class ConsultaSitioBean implements Serializable {
	
	@Autowired
	private IConsultaSitiosService consultaSitiosServiceImpl;
	
	@Autowired
	private SitiosService sitiosService;
	
	@Autowired
	private IElementosPantallaService elementosPantalla;
	
	private List<SitioDto> listaSitios;
	private static final long serialVersionUID = -2226579370912559241L;
	private final Logger LOGGER = LogManager.getLogger(ConsultaSitioBean.class);
	private DefaultStreamedContent archivoDescarga;
	
	private List<FiltroSitioDto> filtros;
	private List<String> filtroRegion;
	private List<String> filtroEstado;
	private List<String> filtroMunicipio;
	
	private String selectFiltroRegion;
	private String selectFiltroEstado;
	private String selectFiltroMunicipio;
	private List<ElementosPantallaDTO> listaElementosPantalla;

	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		try{
			listaElementosPantalla = new ArrayList<>();
			filtros = consultaSitiosServiceImpl.getDatosFiltro();
			limpiaCombos();
			cargaFiltroRegion();
			listaSitios = consultaSitiosServiceImpl.getListaSitios();
			String nombreEstadoVista = rc.getCurrentState().getId();
			UserDetailsVo userDetailsVo = (UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			listaElementosPantalla = elementosPantalla.getElementosPermitidosPantalla(nombreEstadoVista, userDetailsVo.getIdRol(), new HashMap<String,Integer>() );
			
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al cargar los datos de Sitios");
			context.addMessage("mensajes", new FacesMessage(SEVERITY_ERROR, "Error","Ocurri� un error al cargar la Consulta de Sitios"));
		}
	}
	
	public void limpiaCombos(){
		filtroEstado = new ArrayList<>();
		filtroMunicipio = new ArrayList<>();;
		
	    selectFiltroRegion = "null";
		selectFiltroEstado = "null";
		selectFiltroMunicipio = "null";
	}
	
	public void cargaFiltroRegion() {
		filtroRegion = new ArrayList<>();
		for (FiltroSitioDto filtro : filtros) {
			if (!filtroRegion.contains(filtro.getRegion())) {
				filtroRegion.add(filtro.getRegion());
			}
		}
		
	}

	public void cargaFiltroEstado() {
		filtroEstado = new ArrayList<>();
		for (FiltroSitioDto filtro : filtros) {
			if (filtro.getRegion().equals(selectFiltroRegion)) {
				if(!filtroEstado.contains(filtro.getEstado())) {
					filtroEstado.add(filtro.getEstado());
				}
			}
		}	
	}
	
	public void cargaFiltroMunicipio() {
		filtroMunicipio = new ArrayList<>();
		for (FiltroSitioDto filtro : filtros) {
			if (filtro.getEstado().equals(selectFiltroEstado)) {
				if(!filtroMunicipio.contains(filtro.getMunicipio())) {
					filtroMunicipio.add(filtro.getMunicipio());
				}
			}
		}
		
	}
	
	public void consultaSitios(){
		FacesContext context = FacesContext.getCurrentInstance();
		String mensaje = validaFiltros();
		if(mensaje.isEmpty()){
			FiltroSitioDto filtro = new FiltroSitioDto();
			filtro.setRegion(selectFiltroRegion);
			filtro.setEstado(selectFiltroEstado);
			filtro.setMunicipio(selectFiltroMunicipio);
			listaSitios = consultaSitiosServiceImpl.getListaSitiosFiltros(filtro);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('tblSitios').clearFilters();");
		} else {
			context.addMessage("mensajes", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error de validaci�n!", mensaje)); 
		}
	}

	private String validaFiltros() {
		String mensaje = "";
		if(selectFiltroRegion.equals("null") 
				&& selectFiltroEstado.equals("null") 
					&& selectFiltroMunicipio.equals("null")){
			mensaje = "Se debe seleccionar al menos un filtro para la B�squeda";
		}
		return mensaje;
	}

	public void getReporte() {
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Reporte Sitios");
        sitiosService.toExcel(workbook,this.listaSitios);
		FacesContext facesContext = FacesContext.getCurrentInstance();
	    ExternalContext externalContext = facesContext.getExternalContext();
	    externalContext.setResponseContentType("application/vnd.ms-excel");
	    externalContext.setResponseHeader("Content-Disposition", "attachment; filename=\"Reporte SEG Sitios " + fechaReporte()+" v01.xlsx\"");
 
	    try {
			workbook.write(externalContext.getResponseOutputStream());
		} catch (IOException e) {
			LOGGER.error("Error al generar el archivo: " + e);
		}
	    facesContext.responseComplete();
	}
	
	public static String fechaReporte(){
		return new SimpleDateFormat(Constants.FORMATOREPORTE, Locale.ENGLISH).format(new Date()).toString();
	}
	
	public boolean getVisible(String nombreComponente) {
		boolean visible = false;
		for (ElementosPantallaDTO elemento : listaElementosPantalla) {
			if (elemento.getIdElemento().equals(nombreComponente)) {
				visible = elemento.isVisible();
			}
		}
		return visible;
	}
 

	/**
	 * @return the filtros
	 */
	public List<FiltroSitioDto> getFiltros() {
		return filtros;
	}

	/**
	 * @param filtros the filtros to set
	 */
	public void setFiltros(List<FiltroSitioDto> filtros) {
		this.filtros = filtros;
	}

	/**
	 * @return the filtroRegion
	 */
	public List<String> getFiltroRegion() {
		return filtroRegion;
	}

	/**
	 * @param filtroRegion the filtroRegion to set
	 */
	public void setFiltroRegion(List<String> filtroRegion) {
		this.filtroRegion = filtroRegion;
	}

	/**
	 * @return the filtroEstado
	 */
	public List<String> getFiltroEstado() {
		return filtroEstado;
	}

	/**
	 * @param filtroEstado the filtroEstado to set
	 */
	public void setFiltroEstado(List<String> filtroEstado) {
		this.filtroEstado = filtroEstado;
	}

	/**
	 * @return the filtroMunicipio
	 */
	public List<String> getFiltroMunicipio() {
		return filtroMunicipio;
	}

	/**
	 * @param filtroMunicipio the filtroMunicipio to set
	 */
	public void setFiltroMunicipio(List<String> filtroMunicipio) {
		this.filtroMunicipio = filtroMunicipio;
	}

	/**
	 * @return the selectFiltroRegion
	 */
	public String getSelectFiltroRegion() {
		return selectFiltroRegion;
	}

	/**
	 * @param selectFiltroRegion the selectFiltroRegion to set
	 */
	public void setSelectFiltroRegion(String selectFiltroRegion) {
		this.selectFiltroRegion = selectFiltroRegion;
	}

	/**
	 * @return the selectFiltroEstado
	 */
	public String getSelectFiltroEstado() {
		return selectFiltroEstado;
	}

	/**
	 * @param selectFiltroEstado the selectFiltroEstado to set
	 */
	public void setSelectFiltroEstado(String selectFiltroEstado) {
		this.selectFiltroEstado = selectFiltroEstado;
	}

	/**
	 * @return the selectFiltroMunicipio
	 */
	public String getSelectFiltroMunicipio() {
		return selectFiltroMunicipio;
	}

	/**
	 * @param selectFiltroMunicipio the selectFiltroMunicipio to set
	 */
	public void setSelectFiltroMunicipio(String selectFiltroMunicipio) {
		this.selectFiltroMunicipio = selectFiltroMunicipio;
	}

	/**
	 * @return the archivoDescarga
	 */
	public DefaultStreamedContent getArchivoDescarga() {
		return archivoDescarga;
	}
	
	/**
	 * @param archivoDescarga the archivoDescarga to set
	 */
	public void setArchivoDescarga(DefaultStreamedContent archivoDescarga) {
		this.archivoDescarga = archivoDescarga;
	}

	/**
	 * @return the listaSitios
	 */
	public List<SitioDto> getListaSitios() {
		return listaSitios;
	}

	/**
	 * @param listaSitios the listaSitios to set
	 */
	public void setListaSitios(List<SitioDto> listaSitios) {
		this.listaSitios = listaSitios;
	}

}

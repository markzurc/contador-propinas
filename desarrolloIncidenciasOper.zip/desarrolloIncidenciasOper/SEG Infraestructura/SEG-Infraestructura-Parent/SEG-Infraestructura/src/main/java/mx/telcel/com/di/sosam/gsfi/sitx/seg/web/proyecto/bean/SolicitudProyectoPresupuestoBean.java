package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.proyecto.bean;

import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletResponse;



import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.elementosPantalla.IElementosPantallaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.proyecto.IProyectoPresupuestoService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.IColocacionService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ElementosPantallaDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegdSoliArch;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.proyecto.dto.ProyectoPresupuestoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.proyecto.dto.TipoSolicitudDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SoliArchDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SolicitudDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.ValidacionUtil;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.sitios.bean.DetalleSolicitudBean;


@Controller("solicitudProyectoPresupuestoBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class SolicitudProyectoPresupuestoBean implements Serializable {

	private static final long serialVersionUID = -8715496866982916388L;
	private static final Logger LOGGER = LogManager.getLogger(SolicitudProyectoPresupuestoBean.class.getName());
	
	@Autowired
	private IElementosPantallaService elementosPantalla;
	
	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;
	
	@Autowired
	private IProyectoPresupuestoService proyectoService;
	
	@Autowired
	private DetalleSolicitudBean detalleSolicitudBean;
	
	@Autowired
	private IColocacionService colocacionService;
	
	private List<ElementosPantallaDTO> list;
	private List<SoliArchDto> listaArchivosPpSoli;
	private List<SoliArchDto> listaArchivosPpSoliTmp;
	private List<SoliArchDto> listaArchivosPpAten;
	private List<SoliArchDto> listaArchivosPpFact;
	private List<SoliArchDto> listaArchivosPpAcuerdo; 
	private List<FileUploadEvent> listaArchSoli;
	private List<FileUploadEvent> listaArchAten;
	private List<FileUploadEvent> listaArchFact;
	private List<FileUploadEvent> listaArchAcuerdo;
	private List<ProyectoPresupuestoDto> listaProyecto;
	private List<TipoSolicitudDto> listaTipoSolicitud;
	private String observacionesSolicitud;
	private String observacionesAtencion;
	private String motivoRechazo;
	private String motivoR;
	private SolicitudDto solicitudDto;
	private UserDetailsVo userDetailsVo ;
	private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
	private SimpleDateFormat dateFormatTime = new SimpleDateFormat("dd/MM/yyyy hh:mm aa");
	private SoliArchDto archivoSoli;
	private SoliArchDto archivoAten;
	private SoliArchDto archivoFact;
	private SoliArchDto archivoAcuerdo;
	private String solicitudSelect;
	private String observacionesRecuperacion;
	private String observacionesAdecuacion;
	private String headerDialogo;
	private String mensajeDialogo;
	private boolean muestraRecuperacion;
	private boolean muestraAdecuacion;
	private DefaultStreamedContent archivoDescarga;
	private boolean tabProyecto;
	
	
	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		observacionesSolicitud = "";
		observacionesAtencion = "";
		observacionesAdecuacion = "";
		observacionesRecuperacion = "";
		solicitudSelect = "null";
		muestraRecuperacion = false;
		muestraAdecuacion = false;
		tabProyecto = false;
		listaArchivosPpSoliTmp = new ArrayList<>();
		listaArchSoli = new ArrayList<>();
		listaArchAten = new ArrayList<>();
		listaArchFact = new ArrayList<>();
		listaArchAcuerdo = new ArrayList<>();
		motivoR = "";
		listaArchivosPpSoli = new ArrayList<>();
		listaArchivosPpAten = new ArrayList<>();
		listaArchivosPpFact = new ArrayList<>();
		listaArchivosPpAcuerdo = new ArrayList<>();
		listaProyecto = new ArrayList<>();
		listaTipoSolicitud = new ArrayList<>();

		try {
			userDetailsVo = (UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			if (solicitudDto != null) {
				listaArchivosPpSoli = proyectoService.getArchivos(solicitudDto.getFolio(),
						"Solicitud Elaboracion de Proyecto y Presupuesto");
				listaArchivosPpAten = proyectoService.getArchivos(solicitudDto.getFolio(), 
						"Proyecto y Presupuesto");
				listaArchivosPpFact = proyectoService.getArchivos(solicitudDto.getFolio(),
						"Facturacion Proyecto y Presupuesto");
				listaArchivosPpAcuerdo = proyectoService.getArchivos(solicitudDto.getFolio(),
						"Acuerdo de Sitio");
				listaProyecto = proyectoService.getDatosProyectoPorFolio(solicitudDto.getFolio());
				listaTipoSolicitud = proyectoService.getDatosTipoSolicitud();
				int countBitacora = colocacionService.consultaEstadoBitacora(solicitudDto.getFolio(),
						"SOLICITUD DE FACTIBILIDAD RECHAZADA");
				if(listaProyecto.size() > 0 || (countBitacora > 0 && userDetailsVo.getIdRol() == 13)) {
					tabProyecto = true;
				}
			}

			if (!listaProyecto.isEmpty()) {
				observacionesSolicitud = listaProyecto.get(0).getObservacionesSolicitud() != null 
						? listaProyecto.get(0).getObservacionesSolicitud() : "";
				observacionesAtencion = listaProyecto.get(0).getObservacionesAtencion() != null
						? listaProyecto.get(0).getObservacionesAtencion() : "";
				motivoRechazo = listaProyecto.get(0).getMotivoRechazo() != null
						? listaProyecto.get(0).getMotivoRechazo() : "";
				observacionesRecuperacion = listaProyecto.get(0).getObservacionesRecuperacion() != null
						? listaProyecto.get(0).getObservacionesRecuperacion() : "";
				observacionesAdecuacion = listaProyecto.get(0).getObservacionesAdecuacion() != null
						? listaProyecto.get(0).getObservacionesAdecuacion() : "";
				solicitudSelect = listaProyecto.get(0).getIdTipoSolicitud() != null
						? listaProyecto.get(0).getIdTipoSolicitud() : "null";
						cargaTipoSolicitud(solicitudSelect);
			}
			
			Map<String, Integer> mapa = new HashMap<String, Integer>();
			String nombreEstadoVista = "proyectoPresupuesto";
			String rolEstado = "";
			String rolEstadoTipo = "";
			if (solicitudDto == null) {
				rolEstado = userDetailsVo.getIdRol() + "0";
				rolEstadoTipo = userDetailsVo.getIdRol() + "00";
			} else {
				rolEstado = userDetailsVo.getIdRol() + solicitudDto.getIdEstado();
				if(solicitudSelect.equals("null"))
					rolEstadoTipo = userDetailsVo.getIdRol() + solicitudDto.getIdEstado() + "0";
				else 
					rolEstadoTipo = userDetailsVo.getIdRol() + solicitudDto.getIdEstado() + "1";
			}
			
			mapa.put("rol_estatus_pnl_proyecto_presupuesto", Integer.parseInt(rolEstado));
			mapa.put("rol_estatus_componentes_proyecto_presupuesto_c", Integer.parseInt(rolEstado));
			mapa.put("rol_estatus_componentes_proyecto_presupuesto_i", Integer.parseInt(rolEstado));
			mapa.put("rol_estatus_renderizar_componentes_proyecto_presupuesto_i", Integer.parseInt(rolEstado));
			mapa.put("rol_estatus_renderizar_motivo_rechazo_proyec_presupuesto", Integer.parseInt(rolEstado));
			mapa.put("rol_estatus_deshabilitar_motivo_rechazo_proyec_presupuesto", Integer.parseInt(rolEstado));
			mapa.put("rol_estatus_tipoSolicitud_adecuacion_recuperacion", Integer.parseInt(rolEstadoTipo));
			list = elementosPantalla.getElementosPermitidosPantalla(nombreEstadoVista, userDetailsVo.getIdRol(), mapa);
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al cargar la p�gina");
			context.addMessage("mensajes",
					new FacesMessage(SEVERITY_ERROR, "Error", "Ocurrio un error al cargar la p�gina"));
		}
	}
	
	public boolean getEditable(String nombreComponente) {
		boolean editable=false;
		for(ElementosPantallaDTO elemento:list) {
			if(elemento.getIdElemento().equals(nombreComponente)) {
				editable=elemento.isEditable();
			}
		}
		
		return editable;
	}
	
	public void uploadArchivoPpSoli(FileUploadEvent event) {
		String fileName = FilenameUtils.getName(event.getFile().getFileName());
		String nombreRepetido = "";
		try {

			for (int i = 0; i < listaArchSoli.size(); i++) {
				if (fileName.equalsIgnoreCase(listaArchSoli.get(i).getFile().getFileName())) {
					nombreRepetido = "true";
					break;
				}
			}
			
			for (int i = 0; i < listaArchivosPpSoli.size(); i++) {
				if (fileName.equalsIgnoreCase(listaArchivosPpSoli.get(i).getNombreArch())) {
					nombreRepetido = "true";
					break;
				}
			}
			
			if (!nombreRepetido.equals("true")) {
				SoliArchDto archivo = new SoliArchDto();
				// archivo.setIdArchivo(listaArchSoli.size());
				archivo.setDescripcion("Solicitud Elaboracion de Proyecto y Presupuesto");
				archivo.setIdSeccion(0);
				archivo.setNombreArch(fileName);
				archivo.setRuta("");
				archivo.setTamanio(event.getFile().getSize()/1024+ " kb");
				String nombre = userDetailsVo.getNombre() + " " + userDetailsVo.getApellidoPaterno() + " "
						+ userDetailsVo.getApellidoMaterno();
				archivo.setUsuario(nombre);
				archivo.setFechaCarga(dateFormatTime.format(new Date()));
				listaArchivosPpSoli.add(archivo);
				listaArchSoli.add(event);
				
				for (SoliArchDto fact: listaArchivosPpSoli) {
					if (fileName.equalsIgnoreCase(fact.getNombreArch())) {
						fact.setBotonEliminar("false");
					}
				}
				
				detalleSolicitudBean.setHeaderDialogo("Carga de Documento");
				detalleSolicitudBean.setMensajeDialogo("Carga exitosa del documento " + fileName);
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli2').show();");
			} else {
				detalleSolicitudBean.setHeaderDialogo("Carga de Documento");
				detalleSolicitudBean.setMensajeDialogo("No se puede cargar un archivo con el mismo nombre. " + fileName);
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			}
		} catch (Exception e) {
			LOGGER.error("Ocurri� un error al cargar los documentos: " + e);
			detalleSolicitudBean.setHeaderDialogo("Carga de Documento");
			detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al cargar el documento " + fileName);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	public void uploadArchivoPpAten(FileUploadEvent event) {
		String fileName = FilenameUtils.getName(event.getFile().getFileName());
		String nombreRepetido = "";
		try {

			for (int i = 0; i < listaArchAten.size(); i++) {
				if (fileName.equalsIgnoreCase(listaArchAten.get(i).getFile().getFileName())) {
					nombreRepetido = "true";
					break;
				}
			}
			
			for (int i = 0; i < listaArchivosPpAten.size(); i++) {
				if (fileName.equalsIgnoreCase(listaArchivosPpAten.get(i).getNombreArch())) {
					nombreRepetido = "true";
					break;
				}
			}
			
			if (!nombreRepetido.equals("true")) {
				SoliArchDto archivo = new SoliArchDto();
				// archivo.setIdArchivo(listaArchSoli.size());
				archivo.setDescripcion("Proyecto y Presupuesto");
				archivo.setIdSeccion(0);
				archivo.setNombreArch(fileName);
				archivo.setRuta("");
				archivo.setTamanio(event.getFile().getSize()/1024+ " kb");
				String nombre = userDetailsVo.getNombre() + " " + userDetailsVo.getApellidoPaterno() + " "
						+ userDetailsVo.getApellidoMaterno();
				archivo.setUsuario(nombre);
				archivo.setFechaCarga(dateFormatTime.format(new Date()));
				listaArchivosPpAten.add(archivo);
				listaArchAten.add(event);
				
				for (SoliArchDto fact: listaArchivosPpAten) {
					if (fileName.equalsIgnoreCase(fact.getNombreArch())) {
						fact.setBotonEliminar("false");
					}
				}
				
				detalleSolicitudBean.setHeaderDialogo("Carga de Documento");
				detalleSolicitudBean.setMensajeDialogo("Carga exitosa del documento " + fileName);
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli2').show();");
			} else {
				detalleSolicitudBean.setHeaderDialogo("Carga de Documento");
				detalleSolicitudBean.setMensajeDialogo("No se puede cargar un archivo con el mismo nombre " + fileName);
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			}
		} catch (Exception e) {
			LOGGER.error("Ocurri� un error al cargar los documentos: " + e);
			detalleSolicitudBean.setHeaderDialogo("Carga de Documento");
			detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al cargar el documento " + fileName);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	public void uploadArchivoPpFact(FileUploadEvent event) {
		String fileName = FilenameUtils.getName(event.getFile().getFileName());
		String nombreRepetido = "";
		try {

			for (int i = 0; i < listaArchFact.size(); i++) {
				if (fileName.equalsIgnoreCase(listaArchFact.get(i).getFile().getFileName())) {
					nombreRepetido = "true";
					break;
				}
			}
			
			for (int i = 0; i < listaArchivosPpFact.size(); i++) {
				if (fileName.equalsIgnoreCase(listaArchivosPpFact.get(i).getNombreArch())) {
					nombreRepetido = "true";
					break;
				}
			}
			
			if (!nombreRepetido.equals("true")) {
				SoliArchDto archivo = new SoliArchDto();
				// archivo.setIdArchivo(listaArchSoli.size());
				archivo.setDescripcion("Facturacion Proyecto y Presupuesto");
				archivo.setIdSeccion(0);
				archivo.setNombreArch(fileName);
				archivo.setRuta("");
				archivo.setTamanio(event.getFile().getSize()/1024+ " kb");
				String nombre = userDetailsVo.getNombre() + " " + userDetailsVo.getApellidoPaterno() + " "
						+ userDetailsVo.getApellidoMaterno();
				archivo.setUsuario(nombre);
				archivo.setFechaCarga(dateFormatTime.format(new Date()));
				listaArchivosPpFact.add(archivo);
				listaArchFact.add(event);
				
				for (SoliArchDto fact: listaArchivosPpFact) {
					if (fileName.equalsIgnoreCase(fact.getNombreArch())) {
						fact.setBotonEliminar("false");
					}
				}
							
				detalleSolicitudBean.setHeaderDialogo("Carga de Documento");
				detalleSolicitudBean.setMensajeDialogo("Carga exitosa del documento " + fileName);
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli2').show();");
			} else {
				detalleSolicitudBean.setHeaderDialogo("Carga de Documento");
				detalleSolicitudBean.setMensajeDialogo("No se puede cargar un archivo con el mismo nombre. " + fileName);
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			}
		} catch (Exception e) {
			LOGGER.error("Ocurri� un error al cargar los documentos: " + e);
			detalleSolicitudBean.setHeaderDialogo("Carga de Documento");
			detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al cargar el documento " + fileName);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	public void uploadArchivoPpAcuerdo(FileUploadEvent event) {
		String fileName = FilenameUtils.getName(event.getFile().getFileName());
		String nombreRepetido = "";
		try {

			for (int i = 0; i < listaArchAcuerdo.size(); i++) {
				if (fileName.equalsIgnoreCase(listaArchAcuerdo.get(i).getFile().getFileName())) {
					nombreRepetido = "true";
					break;
				}
			}
			
			for (int i = 0; i < listaArchivosPpAcuerdo.size(); i++) {
				if (fileName.equalsIgnoreCase(listaArchivosPpAcuerdo.get(i).getNombreArch())) {
					nombreRepetido = "true";
					break;
				}
			}
			
			if (!nombreRepetido.equals("true")) {
				SoliArchDto archivo = new SoliArchDto();
				archivo.setDescripcion("Acuerdo de Sitio");
				archivo.setIdSeccion(0);
				archivo.setNombreArch(fileName);
				archivo.setRuta("");
				archivo.setTamanio(event.getFile().getSize()/1024+ " kb");
				String nombre = userDetailsVo.getNombre() + " " + userDetailsVo.getApellidoPaterno() + " "
						+ userDetailsVo.getApellidoMaterno();
				archivo.setUsuario(nombre);
				archivo.setFechaCarga(dateFormatTime.format(new Date()));
				listaArchivosPpAcuerdo.add(archivo);
				listaArchAcuerdo.add(event);
				
				for (SoliArchDto fact: listaArchivosPpAcuerdo) {
					if (fileName.equalsIgnoreCase(fact.getNombreArch())) {
						fact.setBotonEliminar("false");
					}
				}
				
				detalleSolicitudBean.setHeaderDialogo("Carga de Documento");
				detalleSolicitudBean.setMensajeDialogo("Carga exitosa del documento " + fileName);
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli2').show();");
			} else {
				detalleSolicitudBean.setHeaderDialogo("Carga de Documento");
				detalleSolicitudBean.setMensajeDialogo("No se puede cargar un archivo con el mismo nombre " + fileName);
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			}
		} catch (Exception e) {
			LOGGER.error("Ocurri� un error al cargar los documentos: " + e);
			detalleSolicitudBean.setHeaderDialogo("Carga de Documento");
			detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al cargar el documento " + fileName);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	public void confirmacionEliminacionSoli(SoliArchDto archivo) {
		this.archivoSoli = archivo;
	}

	public void confirmacionEliminacionAten(SoliArchDto archivo) {
		this.archivoAten = archivo;
	}
	
	public void confirmacionEliminacionFact(SoliArchDto archivo) {
		this.archivoFact = archivo;
	}
	
	public void confirmacionEliminacionAcuerdo(SoliArchDto archivo) {
		this.archivoAcuerdo = archivo;
	}
	
	public void eliminarArchivoPpSoli() {
		try {
			for (int i = 0; i < listaArchSoli.size(); i++) {
				String nombre = FilenameUtils.getName(listaArchSoli.get(i).getFile().getFileName());
				if (nombre.equalsIgnoreCase(archivoSoli.getNombreArch())) {
					listaArchSoli.remove(i);
				}
			}
			
			detalleSolicitudBean.setHeaderDialogo("Eliminar Documento");
			detalleSolicitudBean.setMensajeDialogo("Eiminaci�n exitosa de documento: " + archivoSoli.getNombreArch());
			listaArchivosPpSoli.remove(archivoSoli);
			if(archivoSoli.getIdArchivo() != null) {
				listaArchivosPpSoliTmp.add(archivoSoli);
			}
			this.archivoSoli = new SoliArchDto();
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli2').show();");
		} catch (Exception e) {
			LOGGER.info("Ocurri� un error al eliminar el archivo: " + e);
			detalleSolicitudBean.setHeaderDialogo("Eliminar Documento");
			detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al eliminar el documento.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	public void eliminarArchivoPpAten() {
		try {
			for (int i = 0; i < listaArchAten.size(); i++) {
				String nombre = FilenameUtils.getName(listaArchAten.get(i).getFile().getFileName());
				if (nombre.equalsIgnoreCase(archivoAten.getNombreArch())) {
					listaArchAten.remove(i);
				}
			}

			detalleSolicitudBean.setHeaderDialogo("Eliminar Documento");
			detalleSolicitudBean.setMensajeDialogo("Eiminaci�n exitosa de documento: " + archivoAten.getNombreArch());
			listaArchivosPpAten.remove(archivoAten);
			this.archivoAten = new SoliArchDto();
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli2').show();");
		} catch (Exception e) {
			LOGGER.info("Ocurrio un error al eliminar los archivos " + e);
			detalleSolicitudBean.setHeaderDialogo("Eliminar Documento");
			detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al eliminar el documento.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	public void eliminarArchivoPpFact() {
		try {
			for (int i = 0; i < listaArchFact.size(); i++) {
				String nombre = FilenameUtils.getName(listaArchFact.get(i).getFile().getFileName());
				if (nombre.equalsIgnoreCase(archivoFact.getNombreArch())) {
					listaArchFact.remove(i);
				}
			}

			detalleSolicitudBean.setHeaderDialogo("Eliminar Documento");
			detalleSolicitudBean.setMensajeDialogo("Eiminaci�n exitosa de documento: " + archivoFact.getNombreArch());
			listaArchivosPpFact.remove(archivoFact);
			this.archivoFact = new SoliArchDto();
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli2').show();");
		} catch (Exception e) {
			LOGGER.info("Ocurrio un error al eliminar los archivos " + e);
			detalleSolicitudBean.setHeaderDialogo("Eliminar Documento");
			detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al eliminar el documento.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	public void eliminarArchivoPpAcuerdo() {
		try {
			for (int i = 0; i < listaArchAcuerdo.size(); i++) {
				String nombre = FilenameUtils.getName(listaArchAcuerdo.get(i).getFile().getFileName());
				if (nombre.equalsIgnoreCase(archivoAcuerdo.getNombreArch())) {
					listaArchAcuerdo.remove(i);
				}
			}

			detalleSolicitudBean.setHeaderDialogo("Eliminar Documento");
			detalleSolicitudBean.setMensajeDialogo("Eiminaci�n exitosa de documento: " + archivoAcuerdo.getNombreArch());
			listaArchivosPpAcuerdo.remove(archivoAcuerdo);
			this.archivoAcuerdo = new SoliArchDto();
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli2').show();");
		} catch (Exception e) {
			LOGGER.info("Ocurrio un error al eliminar los archivos " + e);
			detalleSolicitudBean.setHeaderDialogo("Eliminar Documento");
			detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al eliminar el documento.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	public void verArchivoPrevioSoli(SoliArchDto archivo) {
		try {
			archivoDescarga = getArchivoFileByIdSoli(archivo);
		} catch(Exception error){
			LOGGER.error("Ocurri� un error al intentar descargar el archivo: " + error);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvmodalDescargaPp').hide();");
			detalleSolicitudBean.setHeaderDialogo("Descargar Documento");
			detalleSolicitudBean.setMensajeDialogo("Ocurrio un error al descargar el documento");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	public DefaultStreamedContent getArchivoFileByIdSoli(SoliArchDto archivo) {
		FileUploadEvent arch = null;
		File file = null;
		InputStream inputStream = null;
		try {
		if (archivo.getRuta().equals("")) {
			for (int i = 0; i < listaArchSoli.size(); i++) {
				if (archivo.getNombreArch().equalsIgnoreCase(listaArchSoli.get(i).getFile().getFileName())) {
					arch = listaArchSoli.get(i);
					break;
				}
			}
			inputStream = arch.getFile().getInputstream();
		} else {
			file = new File(archivo.getRuta() + File.separator + archivo.getNombreArch());
			inputStream = new FileInputStream(file);
		}
		} catch(Exception e) {
			LOGGER.error("Ocurri� un error al intentar descargar el archivo: " + e);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvmodalDescargaPp').hide();");
			detalleSolicitudBean.setHeaderDialogo("Descargar Documento");
			detalleSolicitudBean.setMensajeDialogo("Ocurrio un error al descargar el documento");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
		return new DefaultStreamedContent(inputStream, "application/octet-stream",
				archivo.getNombreArch());
	}
	
	public void verArchivoPrevioAten(SoliArchDto archivo) {
		try {
			archivoDescarga = getArchivoFileByIdAten(archivo);
		} catch(Exception error){
			LOGGER.error("Ocurri� un error al intentar descargar el archivo: " + error);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvmodalDescargaPp').hide();");
			detalleSolicitudBean.setHeaderDialogo("Descargar Documento");
			detalleSolicitudBean.setMensajeDialogo("Ocurrio un error al descargar el documento");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	public DefaultStreamedContent getArchivoFileByIdAten(SoliArchDto archivo) {
		FileUploadEvent arch = null;
		File file = null;
		InputStream inputStream = null;
		try {
		if (archivo.getRuta().equals("")) {
			for (int i = 0; i < listaArchAten.size(); i++) {
				if (archivo.getNombreArch().equalsIgnoreCase(listaArchAten.get(i).getFile().getFileName())) {
					arch = listaArchAten.get(i);
					break;
				}
			}
			inputStream = arch.getFile().getInputstream();
		} else {
			file = new File(archivo.getRuta() + File.separator + archivo.getNombreArch());
			inputStream = new FileInputStream(file);
		}
		} catch(Exception e) {
			LOGGER.error("Ocurri� un error al intentar descargar el archivo: " + e);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvmodalDescargaPp').hide();");
			detalleSolicitudBean.setHeaderDialogo("Descargar Documento");
			detalleSolicitudBean.setMensajeDialogo("Ocurrio un error al descargar el documento");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
		return new DefaultStreamedContent(inputStream, "application/octet-stream",
				archivo.getNombreArch());
	}
	
	public void verArchivoPrevioFact(SoliArchDto archivo) {
		try {
			archivoDescarga = getArchivoFileByIdFact(archivo);
		} catch(Exception error){
			LOGGER.error("Ocurri� un error al intentar descargar el archivo: " + error);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvmodalDescargaPp').hide();");
			detalleSolicitudBean.setHeaderDialogo("Descargar Documento");
			detalleSolicitudBean.setMensajeDialogo("Ocurrio un error al descargar el documento");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	public DefaultStreamedContent getArchivoFileByIdFact(SoliArchDto archivo) {
		FileUploadEvent arch = null;
		File file = null;
		InputStream inputStream = null;
		try {
		if (archivo.getRuta().equals("")) {
			for (int i = 0; i < listaArchFact.size(); i++) {
				if (archivo.getNombreArch().equalsIgnoreCase(listaArchFact.get(i).getFile().getFileName())) {
					arch = listaArchFact.get(i);
					break;
				}
			}
			inputStream = arch.getFile().getInputstream();
		} else {
			file = new File(archivo.getRuta() + File.separator + archivo.getNombreArch());
			inputStream = new FileInputStream(file);
		}
		} catch(Exception e) {
			LOGGER.error("Ocurri� un error al intentar descargar el archivo: " + e);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvmodalDescargaPp').hide();");
			detalleSolicitudBean.setHeaderDialogo("Descargar Documento");
			detalleSolicitudBean.setMensajeDialogo("Ocurrio un error al descargar el documento");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
		return new DefaultStreamedContent(inputStream, "application/octet-stream",
				archivo.getNombreArch());
	}
	
	public void verArchivoPrevioAcuerdo(SoliArchDto archivo) {
		try {
			archivoDescarga = getArchivoFileByIdAcuerdo(archivo);
		} catch(Exception error){
			LOGGER.error("Ocurri� un error al intentar descargar el archivo: " + error);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvmodalDescargaPp').hide();");
			detalleSolicitudBean.setHeaderDialogo("Descargar Documento");
			detalleSolicitudBean.setMensajeDialogo("Ocurrio un error al descargar el documento");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	public DefaultStreamedContent getArchivoFileByIdAcuerdo(SoliArchDto archivo) {
		FileUploadEvent arch = null;
		File file = null;
		InputStream inputStream = null;
		try {
		if (archivo.getRuta().equals("")) {
			for (int i = 0; i < listaArchAcuerdo.size(); i++) {
				if (archivo.getNombreArch().equalsIgnoreCase(listaArchAcuerdo.get(i).getFile().getFileName())) {
					arch = listaArchAcuerdo.get(i);
					break;
				}
			}
			inputStream = arch.getFile().getInputstream();
		} else {
			file = new File(archivo.getRuta() + File.separator + archivo.getNombreArch());
			inputStream = new FileInputStream(file);
		}
		} catch(Exception e) {
			LOGGER.error("Ocurri� un error al intentar descargar el archivo: " + e);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvmodalDescargaPp').hide();");
			detalleSolicitudBean.setHeaderDialogo("Descargar Documento");
			detalleSolicitudBean.setMensajeDialogo("Ocurrio un error al descargar el documento");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
		return new DefaultStreamedContent(inputStream, "application/octet-stream",
				archivo.getNombreArch());
	}
	
	public boolean uploadArchivo(UploadedFile archivo, String rutaDestino) {
		try {
			File fileDestino = new File(rutaDestino);
			if (!fileDestino.exists()) {
				fileDestino.getParentFile().mkdirs();
			}
			try (InputStream input = archivo.getInputstream();
					OutputStream output = new FileOutputStream(fileDestino)) {
				byte[] buffer = new byte[1024];
				int bytesRead;
				while ((bytesRead = input.read(buffer)) != -1) {
					output.write(buffer, 0, bytesRead);
				}
			}
			return true;
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al mover el archivo a la ruta destino: " + e);
			return false;
		}

	}

	public boolean getVisible(String nombreComponente) {
		boolean visible=false;
		for(ElementosPantallaDTO elemento:list) {
			if(elemento.getIdElemento().equals(nombreComponente)) {
				visible=elemento.isVisible();
			}
		}
		return visible;
	}
	
	public void crearSolicitudPp(String estatus) {
		try {
			crearSolicitudProyectoPresupuesto(estatus);
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al crear la solicitud de Elaboraci�n de Proyecto y Presupuesto: " + e);
			detalleSolicitudBean.setHeaderDialogo("Crear Proyecto y Presupuesto");
			detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al crear la solicitud de Elaboraci�n de Proyecto y Presupuesto.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	public void atenderSolicitudPp(String estatus) {
		try {
			atenderSolicitudProyectoPresupuesto(estatus);
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al atender la solicitud de Elaboraci�n de Proyecto y Presupuesto: " + e);
			detalleSolicitudBean.setHeaderDialogo("Atender Proyecto y Presupuesto");
			detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al atender la solicitud de Elaboraci�n de Proyecto y Presupuesto.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	public void rechazarSolicitudPp() {
		try {
			rechazarSolicitudProyectoPresupuesto(proyectoService.consultaIdEstadoBitacora("SOLICITUD PROYECTO Y PRESUPUESTO RECHAZADA"));
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al rechazar la solicitud de Elaboraci�n de Proyecto y Presupuesto: " + e);
			detalleSolicitudBean.setHeaderDialogo("Rechazar Proyecto y Presupuesto");
			detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al rechazar la solicitud de Elaboraci�n de Proyecto y Presupuesto.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}	
	}
	
	public void rechazarConcesionarioSolicitudPp(String estatus) {
		try {
			rechazarConcesionarioSolicitudProyectoPresupuesto(estatus);
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al rechazar la solicitud de Elaboraci�n de Proyecto y Presupuesto: " + e);
			detalleSolicitudBean.setHeaderDialogo("Rechazar Proyecto y Presupuesto");
			detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al rechazar la solicitud de Elaboraci�n de Proyecto y Presupuesto.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}	
	}
	
	public void solicitarPagoPp(String estatus) {
		try {
			solicitarPagoProyectoPresupuesto(estatus);
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al atender la solicitud de Elaboraci�n de Proyecto y Presupuesto: " + e);
			detalleSolicitudBean.setHeaderDialogo("Solicitud pago Proyecto y Presupuesto");
			detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al realizar la solicitud de pago Elaboraci�n de Proyecto y Presupuesto.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	public void solicitarAcuerdoSitioPp(String estatus) {
		try {
			solicitarAcuerdoSitioProyectoPresupuesto(estatus);
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al atender la solicitud de Elaboraci�n de Proyecto y Presupuesto: " + e);
			detalleSolicitudBean.setHeaderDialogo("Solicitud de acuerdo de sitio Proyecto y Presupuesto");
			detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al realizar la solicitud de acuerdo de sitio Elaboraci�n de Proyecto y Presupuesto.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
		
	}
		
	private void crearSolicitudProyectoPresupuesto(String estatus) throws TransactionalOVITException {
		if (!observacionesSolicitud.equals("") && observacionesSolicitud.trim().length() > 0) {
			if (ValidacionUtil.validarCaracteres(observacionesSolicitud)) {
				if (listaArchivosPpSoli.size() > 0) {
					ProyectoPresupuestoDto proyecto = new ProyectoPresupuestoDto();
					proyecto.setObservacionesSolicitud(observacionesSolicitud);
					proyecto.setFechaCreacion(dateFormat.format(new Date()));
					proyecto.setIdFolio(solicitudDto.getFolio());

					ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness.getConstantOfDataBase(
							ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_PROYECTO_PRESUPUESTO);
					String ruta = String.valueOf(configurationUtilsVo.getValor()) + solicitudDto.getFolio()
							+ File.separator + solicitudDto.getIdEstado();
					boolean archivoSubido = false;
					boolean archivoGuardado = false;
					for (FileUploadEvent fileUploadEvent : listaArchSoli) {

						String fileName = null;
						InputStream inputStream = null;
						fileName = FilenameUtils.getName(fileUploadEvent.getFile().getFileName());
						T3SegdSoliArch archivo = new T3SegdSoliArch();
						archivo.setIdFolio(solicitudDto.getFolio());
						archivo.setDescripcion("Solicitud Elaboracion de Proyecto y Presupuesto");
						archivo.setIdSeccion(0);
						archivo.setNombreArchivo(fileName);
						archivo.setRuta(ruta);
						archivo.setRevision("1");
						archivo.setTamanio(fileUploadEvent.getFile().getSize()/1024+ " kb");
						archivo.setUsuario(userDetailsVo.getIdUsuario());
						archivo.setFechaCarga(new Date());

						File directorioTemp = new File(ruta);
						if (!directorioTemp.exists()) {
							directorioTemp.mkdirs();
						}
						try {
							inputStream = fileUploadEvent.getFile().getInputstream();
						} catch (IOException e) {
							LOGGER.error("Error al cargar el archivo a la ruta: " + ruta + " Error: " + e);
						}
						String rutaA = directorioTemp.getPath() + File.separator + fileName;
						File verificaSiExiste = new File(rutaA);
						archivoGuardado = proyectoService.guardarArchivo(archivo);
						archivoSubido = subirArchivo(inputStream, verificaSiExiste);
						if (!archivoGuardado || !archivoSubido) {
							break;
						}
					}
					boolean proyectoGuardado = proyectoService.crearProyectoPresupuesto(proyecto);
					boolean solicitudModificada = proyectoService.updateEstadoSolicitud(solicitudDto.getFolio(),
							estatus);
					if (proyectoGuardado && solicitudModificada && archivoGuardado && archivoSubido) {
						detalleSolicitudBean.insertarBitacora("");
						detalleSolicitudBean.setHeaderDialogo("Crear Proyecto y Presupuesto");
						detalleSolicitudBean.setMensajeDialogo("Se cre� la solicitud de Elaboraci�n de Proyecto y Presupuesto con �xito.");
						org.primefaces.context.RequestContext.getCurrentInstance()
								.execute("PF('dlgMsjExitoSoli').show();");
					} else {
						detalleSolicitudBean.setHeaderDialogo("Crear Proyecto y Presupuesto");
						detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al crear la solicitud de Elaboraci�n de Proyecto y Presupuesto.");
						org.primefaces.context.RequestContext.getCurrentInstance()
								.execute("PF('dlgMsjErrorSoli').show();");
					}
				} else {
					detalleSolicitudBean.setHeaderDialogo("Crear Proyecto y Presupuesto");
					detalleSolicitudBean.setMensajeDialogo("Se debe de cargar al menos un archivo.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
				}
			} else {
				detalleSolicitudBean.setHeaderDialogo("Crear Proyecto y Presupuesto");
				detalleSolicitudBean.setMensajeDialogo("No es posible ingresar caracteres especiales en el campo observaciones.");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			}
		} else {
			detalleSolicitudBean.setHeaderDialogo("Crear Proyecto y Presupuesto");
			detalleSolicitudBean.setMensajeDialogo("Favor de ingresar un valor para el campo observaciones.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
		}
	}
	
	public void corregirSolicitudPp(String estatus) {
		try {
			corregirSolicitudProyectoPresupuesto(estatus);
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al corregir la solicitud de Elaboraci�n de Proyecto y Presupuesto: " + e);
			detalleSolicitudBean.setHeaderDialogo("Corregir Proyecto y Presupuesto");
			detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al corregir la solicitud de Elaboraci�n de Proyecto y Presupuesto.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
		
	}
	
	public void corregirSolicitudProyectoPresupuesto(String estatus) throws TransactionalOVITException {
		if (!observacionesSolicitud.equals("") && observacionesSolicitud.trim().length() > 0) {
			if (ValidacionUtil.validarCaracteres(observacionesSolicitud)) {
				if (listaArchivosPpSoli.size() > 0) {
					ProyectoPresupuestoDto proyecto = new ProyectoPresupuestoDto();
					proyecto.setObservacionesSolicitud(observacionesSolicitud);
					proyecto.setIdProyecto(listaProyecto.get(0).getIdProyecto());

					ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness.getConstantOfDataBase(
							ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_PROYECTO_PRESUPUESTO);
					String ruta = String.valueOf(configurationUtilsVo.getValor()) + solicitudDto.getFolio()
							+ File.separator + solicitudDto.getIdEstado();
					boolean archivoSubido = false;
					boolean archivoGuardado = false;
					boolean archivoEliminado = false;
					if (listaArchSoli.size() > 0) {
						for (FileUploadEvent fileUploadEvent : listaArchSoli) {

							String fileName = null;
							InputStream inputStream = null;
							fileName = FilenameUtils.getName(fileUploadEvent.getFile().getFileName());
							T3SegdSoliArch archivo = new T3SegdSoliArch();
							archivo.setIdFolio(solicitudDto.getFolio());
							archivo.setDescripcion("Solicitud Elaboracion de Proyecto y Presupuesto");
							archivo.setIdSeccion(0);
							archivo.setNombreArchivo(fileName);
							archivo.setRuta(ruta);
							archivo.setRevision("1");
							archivo.setTamanio(fileUploadEvent.getFile().getSize()/1024+ " kb");
							archivo.setUsuario(userDetailsVo.getIdUsuario());
							archivo.setFechaCarga(new Date());

							File directorioTemp = new File(ruta);
							if (!directorioTemp.exists()) {
								directorioTemp.mkdirs();
							}
							try {
								inputStream = fileUploadEvent.getFile().getInputstream();
							} catch (IOException e) {
								LOGGER.error("Error al cargar el archivo a la ruta: " + ruta + " Error: " + e);
							}
							String rutaA = directorioTemp.getPath() + File.separator + fileName;
							File verificaSiExiste = new File(rutaA);
							archivoGuardado = proyectoService.guardarArchivo(archivo);
							archivoSubido = subirArchivo(inputStream, verificaSiExiste);
							if (!archivoGuardado || !archivoSubido) {
								break;
							}
						}
					} else {
						archivoSubido = true;
						archivoGuardado = true;
					}

					if (listaArchivosPpSoliTmp.size() > 0) {
						for (SoliArchDto archivo : listaArchivosPpSoliTmp) {
							File fileDestino = new File(archivo.getRuta() + File.separator + archivo.getNombreArch());
							if (fileDestino.exists()) {
								fileDestino.delete();
								archivoEliminado = proyectoService.eliminarArchivo(archivo);
								if (!archivoEliminado) {
									break;
								}
							} else {
								archivoEliminado = false;
								break;
							}
						}
					} else {
						archivoEliminado = true;
					}

					boolean proyectoModificado = proyectoService.corregirProyectoPresupuesto(proyecto);
					boolean solicitudModificada = proyectoService.updateEstadoSolicitud(solicitudDto.getFolio(),
							estatus);
					if (proyectoModificado && solicitudModificada && archivoGuardado && archivoSubido
							&& archivoEliminado) {
						detalleSolicitudBean.insertarBitacora("");
						detalleSolicitudBean.setHeaderDialogo("Corregir Proyecto y Presupuesto");
						detalleSolicitudBean.setMensajeDialogo("Se corrigi� la solicitud de Elaboraci�n de Proyecto y Presupuesto con �xito.");
						org.primefaces.context.RequestContext.getCurrentInstance()
								.execute("PF('dlgMsjExitoSoli').show();");
					} else {
						detalleSolicitudBean.setHeaderDialogo("Corregir Proyecto y Presupuesto");
						detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al corregir la solicitud de Elaboraci�n de Proyecto y Presupuesto.");
						org.primefaces.context.RequestContext.getCurrentInstance()
								.execute("PF('dlgMsjErrorSoli').show();");
					}
				} else {
					detalleSolicitudBean.setHeaderDialogo("Corregir Proyecto y Presupuesto");
					detalleSolicitudBean.setMensajeDialogo("Se debe de cargar al menos un archivo.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
				}
			} else {
				detalleSolicitudBean.setHeaderDialogo("Corregir Proyecto y Presupuesto");
				detalleSolicitudBean.setMensajeDialogo("No es posible ingresar caracteres especiales en el campo observaciones.");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			}
		} else {
			detalleSolicitudBean.setHeaderDialogo("Corregir Proyecto y Presupuesto");
			detalleSolicitudBean.setMensajeDialogo("Favor de ingresar un valor para el campo observaciones.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
		}
	}
	
	private void atenderSolicitudProyectoPresupuesto(String estatus) throws TransactionalOVITException {
		if (!observacionesAtencion.equals("") && observacionesAtencion.length() > 0) {
			if (ValidacionUtil.validarCaracteres(observacionesAtencion)) {
				if (listaArchivosPpAten.size() > 0) {
					ProyectoPresupuestoDto proyecto = new ProyectoPresupuestoDto();
					proyecto.setIdProyecto(listaProyecto.get(0).getIdProyecto());
					proyecto.setObservacionesAtencion(observacionesAtencion);

					ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness.getConstantOfDataBase(
							ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_PROYECTO_PRESUPUESTO);
					String ruta = String.valueOf(configurationUtilsVo.getValor()) + solicitudDto.getFolio()
							+ File.separator + solicitudDto.getIdEstado();
					boolean archivoSubido = false;
					boolean archivoGuardado = false;
					for (FileUploadEvent fileUploadEvent : listaArchAten) {

						String fileName = null;
						InputStream inputStream = null;
						fileName = FilenameUtils.getName(fileUploadEvent.getFile().getFileName());
						T3SegdSoliArch archivo = new T3SegdSoliArch();
						archivo.setIdFolio(solicitudDto.getFolio());
						archivo.setDescripcion("Proyecto y Presupuesto");
						archivo.setIdSeccion(0);
						archivo.setNombreArchivo(fileName);
						archivo.setRuta(ruta);
						archivo.setRevision("1");
						archivo.setTamanio(fileUploadEvent.getFile().getSize()/1024+ " kb");
						archivo.setUsuario(userDetailsVo.getIdUsuario());
						archivo.setFechaCarga(new Date());

						File directorioTemp = new File(ruta);
						if (!directorioTemp.exists()) {
							directorioTemp.mkdirs();
						}
						try {
							inputStream = fileUploadEvent.getFile().getInputstream();
						} catch (IOException e) {
							LOGGER.error("Error al cargar el archivo a la ruta: " + ruta + " Error: " + e);
						}
						String rutaA = directorioTemp.getPath() + File.separator + fileName;
						File verificaSiExiste = new File(rutaA);
						archivoGuardado = proyectoService.guardarArchivo(archivo);
						archivoSubido = subirArchivo(inputStream, verificaSiExiste);
						if (!archivoGuardado || !archivoSubido) {
							break;
						}
					}
					boolean proyectoModificado = proyectoService.atenderProyectoPresupuesto(proyecto);
					boolean solicitudModificada = proyectoService.updateEstadoSolicitud(solicitudDto.getFolio(),
							estatus);
					if (proyectoModificado && solicitudModificada && archivoGuardado && archivoSubido) {
						detalleSolicitudBean.insertarBitacora("");
						detalleSolicitudBean.setHeaderDialogo("Atender Proyecto y Presupuesto");
						detalleSolicitudBean.setMensajeDialogo("Se atendi� la solicitud de Elaboraci�n de Proyecto y Presupuesto con �xito.");
						org.primefaces.context.RequestContext.getCurrentInstance()
								.execute("PF('dlgMsjExitoSoli').show();");
					} else {
						detalleSolicitudBean.setHeaderDialogo("Atender Proyecto y Presupuesto");
						detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al atender la solicitud de Elaboraci�n de Proyecto y Presupuesto.");
						org.primefaces.context.RequestContext.getCurrentInstance()
								.execute("PF('dlgMsjErrorSoli').show();");
					}
				} else {
					detalleSolicitudBean.setHeaderDialogo("Atender Proyecto y Presupuesto");
					detalleSolicitudBean.setMensajeDialogo("Se debe de cargar al menos un archivo.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
				}
			} else {
				detalleSolicitudBean.setHeaderDialogo("Atender Proyecto y Presupuesto");
				detalleSolicitudBean.setMensajeDialogo("No es posible ingresar caracteres especiales en el campo observaciones.");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			}
		} else {
			detalleSolicitudBean.setHeaderDialogo("Atender Proyecto y Presupuesto");
			detalleSolicitudBean.setMensajeDialogo("Favor de ingresar un valor para el campo observaciones.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
		}
	}
	
	private void rechazarSolicitudProyectoPresupuesto(String estatus) {
		if (ValidacionUtil.isEmpty(motivoR)) {
			detalleSolicitudBean.setHeaderDialogo("Rechazar Proyecto y Presupuesto");
			detalleSolicitudBean.setMensajeDialogo("Favor de ingresar un valor para el campo motivo de rechazo.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			return;
		}

		if (!ValidacionUtil.validarCaracteres(motivoR)) {
			detalleSolicitudBean.setHeaderDialogo("Rechazar Proyecto y Presupuesto");
			detalleSolicitudBean.setMensajeDialogo("No es posible ingresar caracteres especiales en el campo motivo rechazo.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			return;
		}
		
		ProyectoPresupuestoDto proyecto = new ProyectoPresupuestoDto();
		proyecto.setIdProyecto(listaProyecto.get(0).getIdProyecto());
		proyecto.setMotivoRechazo(motivoR);
		boolean proyectoModificado = proyectoService.rechazarProyectoPresupuesto(proyecto);
		boolean solicitudModificada = proyectoService.updateEstadoSolicitud(solicitudDto.getFolio(), estatus);
		if (proyectoModificado && solicitudModificada) {
			detalleSolicitudBean.insertarBitacora(motivoR);
			detalleSolicitudBean.setHeaderDialogo("Rechazar Proyecto y Presupuesto");
			detalleSolicitudBean.setMensajeDialogo("Se rechaz� la solicitud de Elaboraci�n de Proyecto y Presupuesto con �xito.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli').show();");
		} else {
			detalleSolicitudBean.setHeaderDialogo("Rechazar Proyecto y Presupuesto");
			detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al rechazar la solicitud de Elaboraci�n de Proyecto y Presupuesto.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	
	}
	
	private void rechazarConcesionarioSolicitudProyectoPresupuesto(String estatus) {
		boolean solicitudModificada = proyectoService.updateEstadoSolicitud(solicitudDto.getFolio(), estatus);
		if (solicitudModificada) {
			detalleSolicitudBean.insertarBitacora("");
			detalleSolicitudBean.setHeaderDialogo("Rechazar Proyecto y Presupuesto");
			detalleSolicitudBean.setMensajeDialogo("Se rechaz� la solicitud de Elaboraci�n de Proyecto y Presupuesto con �xito.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli').show();");
		} else {
			detalleSolicitudBean.setHeaderDialogo("Rechazar Proyecto y Presupuesto");
			detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al rechazar la solicitud de Elaboraci�n de Proyecto y Presupuesto.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}
	
	private void solicitarPagoProyectoPresupuesto(String estatus) throws TransactionalOVITException {
		if (listaArchivosPpFact.size() > 0 && listaArchFact.size() > 0) {
			ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness.
			getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_PROYECTO_PRESUPUESTO);
			String ruta = String.valueOf(configurationUtilsVo.getValor()) + solicitudDto.getFolio() + File.separator + solicitudDto.getIdEstado();
			boolean archivoSubido = false;
			boolean archivoGuardado = false;
			for (FileUploadEvent fileUploadEvent : listaArchFact) {
				
				String fileName = null;
				InputStream inputStream = null;
				fileName = FilenameUtils.getName(fileUploadEvent.getFile().getFileName());
				T3SegdSoliArch archivo = new T3SegdSoliArch();
			    archivo.setIdFolio(solicitudDto.getFolio());
			    archivo.setDescripcion("Facturacion Proyecto y Presupuesto");
			    archivo.setIdSeccion(0);
			    archivo.setNombreArchivo(fileName);
			    archivo.setRuta(ruta);
			    archivo.setRevision("1");
			    archivo.setTamanio(fileUploadEvent.getFile().getSize()/1024+ " kb");
			    archivo.setUsuario(userDetailsVo.getIdUsuario());
			    archivo.setFechaCarga(new Date());
			    
				File directorioTemp = new File(ruta);
				if (!directorioTemp.exists()) {
					directorioTemp.mkdirs();
				}
				try {
					inputStream = fileUploadEvent.getFile().getInputstream();
				} catch (IOException e) {
					LOGGER.error("Error al cargar el archivo a la ruta: " + ruta + " Error: " + e);
				}	
				String rutaA = directorioTemp.getPath() + File.separator + fileName;
				File verificaSiExiste = new File(rutaA);
				archivoGuardado = proyectoService.guardarArchivo(archivo);
				archivoSubido = subirArchivo(inputStream, verificaSiExiste);
				if(!archivoGuardado || !archivoSubido) {
			    	break;
			    }
			}		
			boolean solicitudModificada = proyectoService.updateEstadoSolicitud(solicitudDto.getFolio(), estatus);
			if (solicitudModificada && archivoGuardado && archivoSubido) {
				detalleSolicitudBean.insertarBitacora("");
				detalleSolicitudBean.setHeaderDialogo("Solicitud pago Proyecto y Presupuesto");
				detalleSolicitudBean.setMensajeDialogo("Se atendi� la solicitud de pago Elaboraci�n de Proyecto y Presupuesto con �xito.");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli').show();");
			} else {
				detalleSolicitudBean.setHeaderDialogo("Solicitud pago Proyecto y Presupuesto");
				detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al realizar la solicitud de pago Elaboraci�n de Proyecto y Presupuesto.");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
			}
		} else {
			detalleSolicitudBean.setHeaderDialogo("Solicitud pago Proyecto y Presupuesto");
			detalleSolicitudBean.setMensajeDialogo("Se debe de cargar al menos un archivo.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
		}
	}
	
	public void solicitarRecuperacionAdecuacionPp(String estatus) {
		ProyectoPresupuestoDto proyecto = new ProyectoPresupuestoDto();
		boolean proyectoModificado = false;
		boolean solicitudModificada = false;
		if (!solicitudSelect.equals("")) {
			if (solicitudSelect.equals("1") && !observacionesRecuperacion.trim().equals("")
					&& observacionesRecuperacion.trim().length() > 0) {
				if (!ValidacionUtil.validarCaracteres(observacionesRecuperacion)) {
					detalleSolicitudBean.setHeaderDialogo("Solicitar Adecuaci�n / Recuperaci�n");
					detalleSolicitudBean.setMensajeDialogo("No es posible ingresar caracteres especiales en el campo observaciones recuperaci�n.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
					return;
				}
				proyecto.setIdProyecto(listaProyecto.get(0).getIdProyecto());
				proyecto.setIdTipoSolicitud(solicitudSelect);
				proyecto.setObservacionesRecuperacion(observacionesRecuperacion);
				proyectoModificado = proyectoService.solicitarAdecuacionRecuperacion(proyecto);
				solicitudModificada = proyectoService.updateEstadoSolicitud(solicitudDto.getFolio(), estatus);
				if (proyectoModificado && solicitudModificada) {
					detalleSolicitudBean.insertarBitacora("");
					detalleSolicitudBean.setHeaderDialogo("Solicitar Adecuaci�n / Recuperaci�n");
					detalleSolicitudBean.setMensajeDialogo("Se gener� la solicitud de Adecuaci�n / Recuperaci�n con �xito.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli').show();");
				} else {
					detalleSolicitudBean.setHeaderDialogo("Solicitar Adecuaci�n / Recuperaci�n.");
					detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al generar la solicitud de Adecuaci�n / Recuperaci�n.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
				}
			} else if (solicitudSelect.equals("2") && !observacionesAdecuacion.trim().equals("")
					&& observacionesAdecuacion.trim().length() > 0) {
				if (!ValidacionUtil.validarCaracteres(observacionesAdecuacion)) {
					detalleSolicitudBean.setHeaderDialogo("Solicitar Adecuaci�n / Recuperaci�n");
					detalleSolicitudBean.setMensajeDialogo("No es posible ingresar caracteres especiales en el campo observaciones adecuaci�n.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
					return;
				}
				proyecto.setIdProyecto(listaProyecto.get(0).getIdProyecto());
				proyecto.setIdTipoSolicitud(solicitudSelect);
				proyecto.setObservacionesAdecuacion(observacionesAdecuacion);
				proyectoModificado = proyectoService.solicitarAdecuacionRecuperacion(proyecto);
				solicitudModificada = proyectoService.updateEstadoSolicitud(solicitudDto.getFolio(), estatus);
				if (proyectoModificado && solicitudModificada) {
					detalleSolicitudBean.setHeaderDialogo("Solicitar Adecuaci�n / Recuperaci�n");
					detalleSolicitudBean.setMensajeDialogo("Se gener� la solicitud de Adecuaci�n / Recuperaci�n con �xito.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli').show();");
				} else {
					detalleSolicitudBean.setHeaderDialogo("Solicitar Adecuaci�n / Recuperaci�n");
					detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al generar la solicitud de Adecuaci�n / Recuperaci�n.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
				}
			} else if (solicitudSelect.equals("3") && !observacionesRecuperacion.trim().equals("")
					&& observacionesRecuperacion.trim().length() > 0 && !observacionesAdecuacion.trim().equals("")
					&& observacionesAdecuacion.trim().length() > 0) {
				if (!ValidacionUtil.validarCaracteres(observacionesAdecuacion) || !ValidacionUtil.validarCaracteres(observacionesRecuperacion)) {
					detalleSolicitudBean.setHeaderDialogo("Solicitar Adecuaci�n / Recuperaci�n");
					detalleSolicitudBean.setMensajeDialogo("No es posible ingresar caracteres especiales en el campo observaciones adecuaci�n / recuperaci�n.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
					return;
				}
				proyecto.setIdProyecto(listaProyecto.get(0).getIdProyecto());
				proyecto.setIdTipoSolicitud(solicitudSelect);
				proyecto.setObservacionesRecuperacion(observacionesRecuperacion);
				proyecto.setObservacionesAdecuacion(observacionesAdecuacion);
				proyectoModificado = proyectoService.solicitarAdecuacionRecuperacion(proyecto);
				solicitudModificada = proyectoService.updateEstadoSolicitud(solicitudDto.getFolio(), estatus);
				if (proyectoModificado && solicitudModificada) {
					detalleSolicitudBean.setHeaderDialogo("Solicitar Adecuaci�n / Recuperaci�n.");
					detalleSolicitudBean.setMensajeDialogo("Se gener� la solicitud de Adecuaci�n / Recuperaci�n con �xito.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli').show();");
				} else {
					detalleSolicitudBean.setHeaderDialogo("Solicitar Adecuaci�n / Recuperaci�n");
					detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al generar la solicitud de Adecuaci�n / Recuperaci�n.");
					org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
				}
			} else {
				detalleSolicitudBean.setHeaderDialogo("Solicitar Adecuaci�n / Recuperaci�n");
				detalleSolicitudBean.setMensajeDialogo("Favor de ingresar un valor para el campo observaciones Adecuaci�n / Recuperaci�n.");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
			}
		} else {
			detalleSolicitudBean.setHeaderDialogo("Solicitar Adecuaci�n / Recuperaci�n");
			detalleSolicitudBean.setMensajeDialogo("Favor de seleccionar un valor del combo Adecuaci�n / Recuperaci�n.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
		}
	}
	
	private void solicitarAcuerdoSitioProyectoPresupuesto(String estatus) throws TransactionalOVITException {
		if (listaArchivosPpAcuerdo.size() > 0 && listaArchAcuerdo.size() > 0) {
			
			ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness.
			getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_PROYECTO_PRESUPUESTO);
			String ruta = String.valueOf(configurationUtilsVo.getValor()) + solicitudDto.getFolio() + File.separator + solicitudDto.getIdEstado();
			boolean archivoSubido = false;
			boolean archivoGuardado = false;
			for (FileUploadEvent fileUploadEvent : listaArchAcuerdo) {
				
				String fileName = null;
				InputStream inputStream = null;
				fileName = FilenameUtils.getName(fileUploadEvent.getFile().getFileName());
				T3SegdSoliArch archivo = new T3SegdSoliArch();
			    archivo.setIdFolio(solicitudDto.getFolio());
			    archivo.setDescripcion("Acuerdo de Sitio");
			    archivo.setIdSeccion(0);
			    archivo.setNombreArchivo(fileName);
			    archivo.setRuta(ruta);
			    archivo.setRevision("1");
			    archivo.setTamanio(fileUploadEvent.getFile().getSize()/1024+ " kb");
			    archivo.setUsuario(userDetailsVo.getIdUsuario());
			    archivo.setFechaCarga(new Date());
			    
				File directorioTemp = new File(ruta);
				if (!directorioTemp.exists()) {
					directorioTemp.mkdirs();
				}
				try {
					inputStream = fileUploadEvent.getFile().getInputstream();
				} catch (IOException e) {
					LOGGER.error("Error al cargar el archivo a la ruta: " + ruta + " Error: " + e);
				}	
				String rutaA = directorioTemp.getPath() + File.separator + fileName;
				File verificaSiExiste = new File(rutaA);
				archivoGuardado = proyectoService.guardarArchivo(archivo);
				archivoSubido = subirArchivo(inputStream, verificaSiExiste);
				if(!archivoGuardado || !archivoSubido) {
			    	break;
			    }
			}		
			boolean solicitudModificada = proyectoService.updateEstadoSolicitud(solicitudDto.getFolio(), estatus);
			if (solicitudModificada && archivoGuardado && archivoSubido) {
				detalleSolicitudBean.insertarBitacora("");
				detalleSolicitudBean.setHeaderDialogo("Solicitud acuerdo de sitio Proyecto y Presupuesto");
				detalleSolicitudBean.setMensajeDialogo("Se atendi� la solicitud de acuerdo de sitio Elaboraci�n de Proyecto y Presupuesto con �xito.");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli').show();");
			} else {
				detalleSolicitudBean.setHeaderDialogo("Solicitud acuerdo de sitio Proyecto y Presupuesto");
				detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al realizar la solicitud de acuerdo de sitio Elaboraci�n de Proyecto y Presupuesto.");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
			}
		} else {
			detalleSolicitudBean.setHeaderDialogo("Solicitud acuerdo de sitio Proyecto y Presupuesto");
			detalleSolicitudBean.setMensajeDialogo("Se debe de cargar al menos un archivo.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
		}
	}
	
	public void cambiaTipoSolicitud() {
		if(solicitudSelect.equals("1")) {
			muestraRecuperacion = true;
			muestraAdecuacion = false;
			observacionesRecuperacion = "";
			observacionesAdecuacion = "";
		} else if(solicitudSelect.equals("2")) {
			muestraAdecuacion = true;
			muestraRecuperacion = false;
			observacionesRecuperacion = "";
			observacionesAdecuacion = "";
		} else if(solicitudSelect.equals("3")) {
			muestraRecuperacion = true;
			muestraAdecuacion = true;
			observacionesRecuperacion = "";
			observacionesAdecuacion = "";
		} else if(solicitudSelect.equals("null")) {
			muestraAdecuacion = false;
			muestraRecuperacion = false;
			observacionesRecuperacion = "";
			observacionesAdecuacion = "";
		}
	}
	
	public void cargaTipoSolicitud(String tipoSolicitud) {
		if(tipoSolicitud.equals("1")) {
			muestraRecuperacion = true;
			muestraAdecuacion = false;
		} else if(tipoSolicitud.equals("2")) {
			muestraAdecuacion = true;
			muestraRecuperacion = false;
		} else if(tipoSolicitud.equals("3")) {
			muestraRecuperacion = true;
			muestraAdecuacion = true;
		} else if(tipoSolicitud.equals("null")) {
			muestraAdecuacion = false;
			muestraRecuperacion = false;
		}
	}
	
	public void limpiarMotivoRechazo() {
		motivoR = "";
	}
	
	private static boolean subirArchivo(InputStream origen, File destino) {
		OutputStream out = null;
		try {
			InputStream in = origen;
			out = new FileOutputStream(destino);

			byte[] buf = new byte[1024];
			int len;

			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			in.close();
			out.close();
		} catch (IOException e) {
			LOGGER.error("Error al subir el archivo");
			return false;
		} finally {
			close(out);
		}
		return true;
	}
	
	private static void close(Closeable closable) {
		try {
			if (closable != null) {
				closable.close();
			}
		} catch (IOException e) {
			LOGGER.error("Error al cerrar OutputStream");
		}
	}

	public String getObservacionesSolicitud() {
		return observacionesSolicitud;
	}

	public void setObservacionesSolicitud(String observacionesSolicitud) {
		this.observacionesSolicitud = observacionesSolicitud;
	}
	
	public List<SoliArchDto> getListaArchivosPpSoli() {
		return listaArchivosPpSoli;
	}

	public void setListaArchivosPpSoli(List<SoliArchDto> listaArchivosPpSoli) {
		this.listaArchivosPpSoli = listaArchivosPpSoli;
	}

	public List<SoliArchDto> getListaArchivosPpAten() {
		return listaArchivosPpAten;
	}

	public void setListaArchivosPpAten(List<SoliArchDto> listaArchivosPpAten) {
		this.listaArchivosPpAten = listaArchivosPpAten;
	}

	public String getObservacionesAtencion() {
		return observacionesAtencion;
	}

	public void setObservacionesAtencion(String observacionesAtencion) {
		this.observacionesAtencion = observacionesAtencion;
	}
	
	public String getMotivoRechazo() {
		return motivoRechazo;
	}

	public void setMotivoRechazo(String motivoRechazo) {
		this.motivoRechazo = motivoRechazo;
	}

	public SolicitudDto getSolicitudDto() {
		return solicitudDto;
	}

	public void setSolicitudDto(SolicitudDto solicitudDto) {
		this.solicitudDto = solicitudDto;
	}
	
	public List<SoliArchDto> getListaArchivosPpFact() {
		return listaArchivosPpFact;
	}

	public void setListaArchivosPpFact(List<SoliArchDto> listaArchivosPpFact) {
		this.listaArchivosPpFact = listaArchivosPpFact;
	}

	public String getHeaderDialogo() {
		return headerDialogo;
	}

	public void setHeaderDialogo(String headerDialogo) {
		this.headerDialogo = headerDialogo;
	}

	public String getMensajeDialogo() {
		return mensajeDialogo;
	}

	public void setMensajeDialogo(String mensajeDialogo) {
		this.mensajeDialogo = mensajeDialogo;
	}

	public List<TipoSolicitudDto> getListaTipoSolicitud() {
		return listaTipoSolicitud;
	}

	public void setListaTipoSolicitud(List<TipoSolicitudDto> listaTipoSolicitud) {
		this.listaTipoSolicitud = listaTipoSolicitud;
	}

	public String getSolicitudSelect() {
		return solicitudSelect;
	}

	public void setSolicitudSelect(String solicitudSelect) {
		this.solicitudSelect = solicitudSelect;
	}

	public String getObservacionesRecuperacion() {
		return observacionesRecuperacion;
	}

	public void setObservacionesRecuperacion(String observacionesRecuperacion) {
		this.observacionesRecuperacion = observacionesRecuperacion;
	}

	public String getObservacionesAdecuacion() {
		return observacionesAdecuacion;
	}

	public void setObservacionesAdecuacion(String observacionesAdecuacion) {
		this.observacionesAdecuacion = observacionesAdecuacion;
	}
	
	public boolean isMuestraRecuperacion() {
		return muestraRecuperacion;
	}

	public void setMuestraRecuperacion(boolean muestraRecuperacion) {
		this.muestraRecuperacion = muestraRecuperacion;
	}

	public boolean isMuestraAdecuacion() {
		return muestraAdecuacion;
	}

	public void setMuestraAdecuacion(boolean muestraAdecuacion) {
		this.muestraAdecuacion = muestraAdecuacion;
	}

	public List<SoliArchDto> getListaArchivosPpAcuerdo() {
		return listaArchivosPpAcuerdo;
	}

	public void setListaArchivosPpAcuerdo(List<SoliArchDto> listaArchivosPpAcuerdo) {
		this.listaArchivosPpAcuerdo = listaArchivosPpAcuerdo;
	}
	
	public DefaultStreamedContent getArchivoDescarga() {
		return archivoDescarga;
	}

	public void setArchivoDescarga(DefaultStreamedContent archivoDescarga) {
		this.archivoDescarga = archivoDescarga;
	}

	public String getMotivoR() {
		return motivoR;
	}

	public void setMotivoR(String motivoR) {
		this.motivoR = motivoR;
	}

	public boolean isTabProyecto() {
		return tabProyecto;
	}

	public void setTabProyecto(boolean tabProyecto) {
		this.tabProyecto = tabProyecto;
	}
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.incidencia.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.webflow.execution.RequestContext;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.IIncidenciaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.IIncidenciaService.AdjuntoUi;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.OperadorDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.user.service.UserCatalogService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ExternalUserFindVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.InternalUserFindVo;

@Controller("incidenciaBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class IncidenciaBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggerFactory.getLogger(IncidenciaBean.class);

	@Autowired(required = false)
	private IIncidenciaService incidenciaService;

	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;

	@Autowired
	private UserCatalogService userCatalogService;

	private String sitioId;
	private String tipo;
	private String descripcion;
	private int indiceEtapa = 0;
	private String styles = darEstilo("#FFC000");;
	private List<Object> sitios = new ArrayList<Object>();

	private List<String> tiposIncidencia = new ArrayList<String>();
	private String folioIncidenciaCreada;
	private String operadorUsuarioPerfilRaw;
	private String concesionarioIdSuscripcion;
	private boolean adjuntosError;

	private long maxBytesAdjunto = 10L * 1024 * 1024;

	private String regexExtensionesPermitidas = "/(\\.|\\/)(pdf)$/";
	private String formatosHumanos = "PDF";
	private int maxMb = 10;

	private List<AdjuntoUi> adjuntosUi = new ArrayList<AdjuntoUi>();

	private static final String CFG_IDENT = "INCIDENCIAS";

	private String concesionarioUsuario;
	private Long idIncidenciaCreada;

	private String uploadErrTitle;
	private String uploadErrMsg;

	public void cargaInicial(RequestContext rc) {
		String flowId = "N/A";
		try {
			if (rc != null && rc.getActiveFlow() != null) {
				flowId = rc.getActiveFlow().getId();
			}
		} catch (Exception ignore) {
			// No-op
		}

		boolean esFlowMantenimiento = "incidenciasMantenimiento-flow".equals(flowId);

		log.info("IncidenciaBean.cargaInicial INICIO - flow={}, esMantenimiento={}", flowId, esFlowMantenimiento);

		try {
			// Esto sí se ocupa en ambos flows (restricciones de upload, tamaños, etc.)
			cargarParametrosDesdeConfiguracion();

			// Alta Incidencia: carga perfil + catálogos + limpia formulario.
			// Mantenimiento: NO debe depender de catálogos/perfil de alta.
			if (!esFlowMantenimiento) {
				cargarConcesionarioDesdePerfil();
				String concesionarioIdentificador = getConcesionarioIdentificadorParaSuscripciones();
				cargarCatalogos(concesionarioIdentificador);

				limpiarFormulario();
			}

			log.info(
					"IncidenciaBean.cargaInicial FIN - flow={}, esMantenimiento={}, concesionarioUsuario={}, sitios.size={}, tiposIncidencia.size={}",
					flowId, esFlowMantenimiento, concesionarioUsuario, (sitios != null ? sitios.size() : 0),
					(tiposIncidencia != null ? tiposIncidencia.size() : 0));

		} catch (Throwable throwable) {
			log.error("IncidenciaBean.cargaInicial ERROR - flow={}, esMantenimiento={}, concesionarioUsuario={}",
					flowId, esFlowMantenimiento, concesionarioUsuario, throwable);
		}

	}

	private void cargarCatalogos(String concesionarioIdentificador) {

		// 1) SITIOS (si falla, no bloquea TIPOS)
		try {
			List<Object> sitiosTmp = safeList((List<Object>) incidenciaService
					.listarSitiosSuscritosParaAltaIncidencia(concesionarioIdentificador));

			this.sitios.clear();
			this.sitios.addAll(sitiosTmp);

		} catch (Exception ex) {
			log.error("Error al cargar sitios suscritos para alta de incidencia. concesionarioIdentificador={}",
					concesionarioIdentificador, ex);
			this.sitios.clear();
		}

		// 2) TIPOS
		try {
			List<String> tiposTmp = safeList(incidenciaService.catalogoTiposIncidencia());
			this.tiposIncidencia.clear();
			this.tiposIncidencia.addAll(tiposTmp);

		} catch (Exception ex) {
			log.error("Error al cargar catálogo de tipos de incidencia.", ex);
			this.tiposIncidencia.clear();
		}
	}

	private void cargarParametrosDesdeConfiguracion() {
		Long cfgMaxBytes = getCfgLong(CFG_IDENT, "MAX_BYTES_ADJUNTO", null);
		Integer cfgMaxArch = getCfgInt(CFG_IDENT, "MAX_ARCHIVOS", null);
		String cfgRegex = getCfgStr(CFG_IDENT, "REGEX_EXT_PERMITIDAS", null);
		String cfgFormatos = getCfgStr(CFG_IDENT, "FORMATOS_HUMANOS", null);

		if (incidenciaService != null) {
			if (cfgMaxBytes == null)
				cfgMaxBytes = incidenciaService.obtenerMaxBytesAdjunto();
			if (cfgMaxArch == null)
				cfgMaxArch = incidenciaService.obtenerMaxArchivos();
			if (cfgRegex == null)
				cfgRegex = incidenciaService.obtenerRegexExtensiones();
			if (cfgFormatos == null)
				cfgFormatos = incidenciaService.obtenerFormatosHumanos();
		}

		if (cfgMaxBytes != null)
			this.maxBytesAdjunto = cfgMaxBytes;

		if (cfgRegex != null)
			this.regexExtensionesPermitidas = cfgRegex;
		if (cfgFormatos != null)
			this.formatosHumanos = cfgFormatos;

		this.maxMb = (int) (this.maxBytesAdjunto / (1024 * 1024));
	}

	@SuppressWarnings("unchecked")
	private static <T> List<T> safeList(List<T> origen) {
		return (origen != null) ? origen : new ArrayList<T>();
	}

	private Integer getCfgInt(String ident, String key, Integer defaultVal) {
		if (configurationUtilsBusiness == null)
			return defaultVal;
		try {
			ConfigurationUtilsVo cfg = configurationUtilsBusiness.getConstantOfDataBase(ident, key);
			if (cfg == null || cfg.getValor() == null)
				return defaultVal;
			return Integer.parseInt(cfg.getValor());
		} catch (Exception e) {
			return defaultVal;
		}
	}

	private Long getCfgLong(String ident, String key, Long defaultVal) {
		if (configurationUtilsBusiness == null)
			return defaultVal;
		try {
			ConfigurationUtilsVo cfg = configurationUtilsBusiness.getConstantOfDataBase(ident, key);
			if (cfg == null || cfg.getValor() == null)
				return defaultVal;
			return Long.parseLong(cfg.getValor());
		} catch (Exception e) {
			return defaultVal;
		}
	}

	private String getCfgStr(String ident, String key, String defaultVal) {
		if (configurationUtilsBusiness == null)
			return defaultVal;
		try {
			ConfigurationUtilsVo cfg = configurationUtilsBusiness.getConstantOfDataBase(ident, key);
			if (cfg == null || cfg.getValor() == null)
				return defaultVal;
			return cfg.getValor();
		} catch (Exception e) {
			return defaultVal;
		}
	}

	private void cargarConcesionarioDesdePerfil() {
		try {
			Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

			if (!(principal instanceof UserDetailsVo)) {
				log.warn("Incidencias-> principal no es UserDetailsVo: {}", principal);
				return;
			}

			UserDetailsVo userDetailsVo = (UserDetailsVo) principal;
			Integer idUsuario = userDetailsVo.getIdUsuario();

			if (idUsuario == null) {
				log.warn("Incidencias-> idUsuario nulo en UserDetailsVo");
				return;
			}

			if (userCatalogService == null) {
				log.warn("Incidencias-> userCatalogService es NULL, no se puede obtener concesionario.");
				return;
			}

			String operadorUsuarioRaw = userCatalogService.obtenerOperadorUsuario(idUsuario);
			this.operadorUsuarioPerfilRaw = operadorUsuarioRaw;

			if (operadorUsuarioRaw == null || operadorUsuarioRaw.trim().isEmpty()) {
				log.warn("Incidencias-> Usuario {} sin operador asignado", idUsuario);
				return;
			}

			String operadorTrim = operadorUsuarioRaw.trim();
			String codigoOperador = operadorTrim;
			String nombreOperador = null;
			this.concesionarioIdSuscripcion = codigoOperador;

			int indiceSeparador = operadorTrim.indexOf(':');
			if (indiceSeparador >= 0) {
				codigoOperador = operadorTrim.substring(0, indiceSeparador).trim();
				if (indiceSeparador + 1 < operadorTrim.length()) {
					nombreOperador = operadorTrim.substring(indiceSeparador + 1).trim();
				}
			}

			if (nombreOperador != null && !nombreOperador.isEmpty()) {
				concesionarioUsuario = nombreOperador;
				log.debug("Incidencias-> concesionarioUsuario (desde operadorRaw) = [{}]", concesionarioUsuario);
				return;
			}

			String descripcionOperador = null;
			List<OperadorDto> empresas = userCatalogService.obtenerEmpresas();
			if (empresas != null) {
				for (OperadorDto operadorDto : empresas) {
					if (operadorDto == null || operadorDto.getGrupoOperador() == null) {
						continue;
					}
					String codigo = operadorDto.getGrupoOperador().trim();
					if (codigo.equals(codigoOperador)) {
						descripcionOperador = operadorDto.getDescripcion();
						break;
					}
				}
			}

			if (descripcionOperador != null && !descripcionOperador.trim().isEmpty()) {
				concesionarioUsuario = descripcionOperador.trim();
			} else {
				concesionarioUsuario = codigoOperador;
			}

			log.debug("Incidencias-> Usuario {} operadorRaw [{}] codigoOperador [{}] concesionarioUsuario [{}]",
					idUsuario, operadorUsuarioRaw, codigoOperador, concesionarioUsuario);

		} catch (Exception exception) {
			log.error("Incidencias-> Error al cargar concesionario desde perfil", exception);
		}
	}

	public void handleFileUpload(FileUploadEvent e) {
		UploadedFile f = (e != null) ? e.getFile() : null;

		if (f == null) {
			mostrarPopupUploadError("Archivo inválido", "No se recibió el archivo.");
			addCallbackParamSafe("upOk", false);
			return;
		}

		if (adjuntosUi == null) {
			adjuntosUi = new ArrayList<AdjuntoUi>();
		}

		try {
			if (incidenciaService == null) {
				mostrarPopupUploadError("Servicio no disponible", "No fue posible validar el archivo.");
				addCallbackParamSafe("upOk", false);
				return;
			}

			// Validación por archivo
			incidenciaService.validarAdjunto(f.getFileName(), f.getContentType(), f.getSize());

			// Validación por total
			long totalActual = sumarBytesAdjuntos();
			long totalNuevo = totalActual + f.getSize();
			if (totalNuevo > maxBytesAdjunto) {
				mostrarPopupUploadError("Tamaño excedido",
						"El total de evidencias no debe exceder " + getMaxMb() + " MB.");
				addCallbackParamSafe("upOk", false);
				return;
			}

			// OK: agrega archivo
			// OK: agrega archivo
			adjuntosUi.add(new AdjuntoUi(f.getFileName(), f.getSize(), f.getContents()));

			// CLAVE: si antes estaba en rojo porque faltaban evidencias, al agregar se
			// quita
			this.adjuntosError = false;

			addCallbackParamSafe("upOk", true);

		} catch (IllegalArgumentException iae) {
			mostrarUploadError("Archivo no permitido", iae.getMessage());
			addCallbackParamSafe("upOk", false);
			return;

		} catch (Exception ex) {
			log.error("Incidencias-> error al procesar adjunto en alta", ex);
			mostrarPopupUploadError("Error", "No fue posible procesar el archivo.");
			addCallbackParamSafe("upOk", false);
			return;
		}
	}

	public void quitarAdjunto(AdjuntoUi adj) {
		if (adjuntosUi != null && adj != null) {
			adjuntosUi.remove(adj);
		}

		// NO lo pongas rojo aquí. Solo limpiamos el flag para que no quede “pegado”
		// y vuelva a evaluarse al presionar "Generar".
		this.adjuntosError = false;
	}

	private long sumarBytesAdjuntos() {
		long total = 0L;
		if (adjuntosUi == null) {
			return 0L;
		}
		for (AdjuntoUi a : adjuntosUi) {
			if (a != null) {
				total += a.getTamanio();
			}
		}
		return total;
	}

	private String bytesToMbStr(long bytes) {
		double mb = bytes / (1024d * 1024d);
		double red = Math.round(mb * 100.0) / 100.0; // 2 decimales
		return String.valueOf(red);
	}

	private void addCallbackParamSafe(String key, Object value) {
		try {
			// PrimeFaces.current().ajax().addCallbackParam(...)
			Class<?> pf = Class.forName("org.primefaces.PrimeFaces");
			Object current = pf.getMethod("current").invoke(null);
			Object ajax = current.getClass().getMethod("ajax").invoke(current);
			ajax.getClass().getMethod("addCallbackParam", String.class, Object.class).invoke(ajax, key, value);
			return;
		} catch (Exception ignore) {
			// continue
		}
		try {
			// RequestContext.getCurrentInstance().addCallbackParam(...)
			Class<?> rc = Class.forName("org.primefaces.context.RequestContext");
			Object inst = rc.getMethod("getCurrentInstance").invoke(null);
			inst.getClass().getMethod("addCallbackParam", String.class, Object.class).invoke(inst, key, value);
		} catch (Exception ignore) {
			// no-op
		}
	}

	public String generar() {
		FacesContext ctx = FacesContext.getCurrentInstance();

		try {
			this.idIncidenciaCreada = null;
			this.folioIncidenciaCreada = null;
			this.adjuntosError = false;

			// Validación de adjuntos en UI
			if (adjuntosUi == null || adjuntosUi.isEmpty()) {
				this.adjuntosError = true;
				FacesContext.getCurrentInstance().validationFailed();
				return null;
			}

			if (incidenciaService == null) {
				ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Servicio no disponible"));
				return null;
			}

			// Obtener Usuario de Sesión
			Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			if (!(principal instanceof UserDetailsVo)) {
				ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Sesión no válida."));
				return null;
			}

			UserDetailsVo userDetailsVo = (UserDetailsVo) principal;

			// Construir Nombre
			StringBuilder sb = new StringBuilder();
			if (userDetailsVo.getNombre() != null)
				sb.append(userDetailsVo.getNombre().trim());
			if (userDetailsVo.getApellidoPaterno() != null)
				sb.append(" ").append(userDetailsVo.getApellidoPaterno().trim());
			if (userDetailsVo.getApellidoMaterno() != null)
				sb.append(" ").append(userDetailsVo.getApellidoMaterno().trim());
			String nombreUsuarioCreacion = sb.toString().trim();

			// Obtener Correo (Ojo: Aquí es donde llega vacío si el VO no lo trae)
			// Obtener Correo (si no viene en sesión, se consulta a BD vía Security y se
			// cachea en sesión)
			String correoUsuarioCreacion = (userDetailsVo.getCorreo() != null) ? userDetailsVo.getCorreo().trim() : "";

			if (correoUsuarioCreacion.isEmpty()) {
			    Integer idUsuario = userDetailsVo.getIdUsuario();
			    Integer idRol = userDetailsVo.getIdRol(); // aquí validas concesionario por rol si aplica

			    // 1) intenta con rol (si viene)
			    String correoDb = incidenciaService.obtenerCorreoExternoPorUsuario(idUsuario, idRol);

			    // 2) fallback sin rol (por si el rol no coincide o viene null)
			    if (correoDb == null || correoDb.trim().isEmpty()) {
			        correoDb = incidenciaService.obtenerCorreoExternoPorUsuario(idUsuario, null);
			    }

			    if (correoDb != null && !correoDb.trim().isEmpty()) {
			        correoUsuarioCreacion = correoDb.trim();
			        userDetailsVo.setCorreo(correoUsuarioCreacion); // cache sesión
			        log.info("Incidencias-> Correo recuperado desde T3SEGO_DATO_USUA_EXTE para usuario {}.", idUsuario);
			    } else {
			        log.warn("Incidencias-> El usuario ID {} no tiene correo en sesión ni en T3SEGO_DATO_USUA_EXTE.", idUsuario);
			    }
			}


			// Validar Concesionario
			if (concesionarioUsuario == null || concesionarioUsuario.trim().isEmpty()) {
				cargarConcesionarioDesdePerfil();
			}

			// Validar Datos Negocio
			incidenciaService.validarAlta(sitioId, tipo, descripcion, adjuntosUi);

			// --- LLAMADA AL SERVICIO ---
			// El servicio se encarga de guardar la incidencia Y los adjuntos.
			Long id = incidenciaService.crearIncidencia(sitioId, tipo, descripcion, adjuntosUi, nombreUsuarioCreacion,
					correoUsuarioCreacion, concesionarioUsuario);

			this.idIncidenciaCreada = id;
			this.folioIncidenciaCreada = incidenciaService.generarFolioIncidencia(id);

			// --- CORRECCIÓN IMPORTANTE ---
			// Eliminamos el bloque "if (adjuntos != null) { guardarAdjuntos... }"
			// porque eso duplicaba la lógica y causaba error de compilación.

		} catch (IllegalArgumentException e) {
			log.warn("Incidencias-> validación: {}", e.getMessage());
			ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Validación", e.getMessage()));
			FacesContext.getCurrentInstance().validationFailed();
		} catch (Exception e) {
			log.error("Incidencias-> error al crear", e);
			ctx.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Ocurrió un error al crear la incidencia."));
			FacesContext.getCurrentInstance().validationFailed();
		}

		return null;
	}

	public void limpiarFormulario() {
		this.idIncidenciaCreada = null;
		this.folioIncidenciaCreada = null;
		this.sitioId = null;
		this.tipo = null;
		this.descripcion = null;

		if (this.adjuntosUi != null) {
			this.adjuntosUi.clear();
		}

		// CLAVE
		this.adjuntosError = false;

		this.styles = darEstilo("#FFC000");
	}

	private void updateComponentSafe(String clientId) {
		try {
			// PrimeFaces.current().ajax().update(...)
			Class<?> pf = Class.forName("org.primefaces.PrimeFaces");
			Object current = pf.getMethod("current").invoke(null);
			Object ajax = current.getClass().getMethod("ajax").invoke(current);
			ajax.getClass().getMethod("update", String.class).invoke(ajax, clientId);
			return;
		} catch (Exception ignore) {
			// continue
		}
		try {
			// RequestContext.getCurrentInstance().update(...)
			Class<?> rc = Class.forName("org.primefaces.context.RequestContext");
			Object inst = rc.getMethod("getCurrentInstance").invoke(null);
			inst.getClass().getMethod("update", String.class).invoke(inst, clientId);
		} catch (Exception ignore) {
			// no-op
		}
	}

	private void executeScriptSafe(String script) {
		try {
			// PrimeFaces.current().executeScript(...)
			Class<?> pf = Class.forName("org.primefaces.PrimeFaces");
			Object current = pf.getMethod("current").invoke(null);
			current.getClass().getMethod("executeScript", String.class).invoke(current, script);
			return;
		} catch (Exception ignore) {
			// continue
		}
		try {
			// RequestContext.getCurrentInstance().execute(...)
			Class<?> rc = Class.forName("org.primefaces.context.RequestContext");
			Object inst = rc.getMethod("getCurrentInstance").invoke(null);
			inst.getClass().getMethod("execute", String.class).invoke(inst, script);
		} catch (Exception ignore) {
			// no-op
		}
	}

	private void mostrarPopupUploadError(String title, String msg) {
		this.uploadErrTitle = (title != null ? title : "Error");
		this.uploadErrMsg = (msg != null ? msg : "No fue posible procesar el archivo.");

		// Actualiza el diálogo y lo muestra en la MISMA respuesta del upload
		updateComponentSafe("formInc:dlgUpErr");
		executeScriptSafe("if (typeof PF === 'function') { PF('dlgUpErr').show(); }");
	}

	private void mostrarUploadError(String title, String msg) {
		this.uploadErrTitle = (title != null && !title.trim().isEmpty()) ? title : "Error";
		this.uploadErrMsg = (msg != null && !msg.trim().isEmpty()) ? msg : "No fue posible procesar el archivo.";

		// CLAVE: actualiza el contenido que contiene los outputText
		updateComponentSafe("formInc:dlgUpErrContent");

		// mostrar
		executeScriptSafe("if (typeof PF === 'function') { PF('dlgUpErr').show(); }");
	}

	public void mostrarUploadErrorDesdeCliente() {
		FacesContext fc = FacesContext.getCurrentInstance();
		String t = fc.getExternalContext().getRequestParameterMap().get("t");
		String m = fc.getExternalContext().getRequestParameterMap().get("m");
		mostrarUploadError(t, m);
	}

	private String getConcesionarioIdentificadorParaSuscripciones() {

		if (concesionarioIdSuscripcion != null && !concesionarioIdSuscripcion.trim().isEmpty()) {
			return concesionarioIdSuscripcion.trim();
		}

		if (operadorUsuarioPerfilRaw == null) {
			return null;
		}

		String raw = operadorUsuarioPerfilRaw.trim();
		if (raw.isEmpty()) {
			return null;
		}

		int idx = raw.indexOf(':');
		if (idx >= 0) {
			String codigo = raw.substring(0, idx).trim();
			if (!codigo.isEmpty()) {
				return codigo;
			}
		}

		return raw;
	}

	private String resolverCorreoUsuarioCreacion(UserDetailsVo userDetailsVo) {
		if (userDetailsVo == null) {
			return "";
		}

		// 1) Prioridad: lo que venga en sesión
		String correoSesion = safeTrim(userDetailsVo.getCorreo());
		if (!isBlank(correoSesion)) {
			return correoSesion;
		}

		Integer idUsuario = userDetailsVo.getIdUsuario();
		if (idUsuario == null) {
			return "";
		}

		String correoRecuperado = "";

		// 2) Intento principal: según tipo de usuario
		try {
			if (esUsuarioInterno(userDetailsVo)) {
				InternalUserFindVo interno = userCatalogService.loadUserInternal(idUsuario);
				correoRecuperado = extraerCorreoDesdeInternalUser(interno);
			} else {
				ExternalUserFindVo externo = userCatalogService.loadUserExternal(idUsuario);
				correoRecuperado = extraerCorreoDesdeExternalUser(externo);
			}
		} catch (TransactionalOVITException ex) {
			log.warn("Incidencias-> No fue posible obtener correo (tipo actual) para usuario {}: {}", idUsuario,
					ex.getMessage());
		} catch (Exception ex) {
			log.warn("Incidencias-> Error inesperado al resolver correo (tipo actual) para usuario {}: {}", idUsuario,
					ex.toString());
		}

		if (!isBlank(correoRecuperado)) {
			// Cache en sesión para que no vuelva a consultar en esta sesión
			userDetailsVo.setCorreo(correoRecuperado);
			return correoRecuperado;
		}

		// 3) Fallback: intenta el “otro” catálogo (por si el tipo no coincide con donde
		// está el correo)
		try {
			if (esUsuarioInterno(userDetailsVo)) {
				ExternalUserFindVo externo = userCatalogService.loadUserExternal(idUsuario);
				correoRecuperado = extraerCorreoDesdeExternalUser(externo);
			} else {
				InternalUserFindVo interno = userCatalogService.loadUserInternal(idUsuario);
				correoRecuperado = extraerCorreoDesdeInternalUser(interno);
			}
		} catch (TransactionalOVITException ex) {
			log.warn("Incidencias-> No fue posible obtener correo (fallback) para usuario {}: {}", idUsuario,
					ex.getMessage());
		} catch (Exception ex) {
			log.warn("Incidencias-> Error inesperado al resolver correo (fallback) para usuario {}: {}", idUsuario,
					ex.toString());
		}

		if (!isBlank(correoRecuperado)) {
			userDetailsVo.setCorreo(correoRecuperado);
			return correoRecuperado;
		}

		return "";
	}

	private String extraerCorreoDesdeInternalUser(InternalUserFindVo interno) {
		if (interno == null || interno.getInternalDataVo() == null) {
			return "";
		}
		return safeTrim(interno.getInternalDataVo().getCorreo());
	}

	private String extraerCorreoDesdeExternalUser(ExternalUserFindVo externo) {
		if (externo == null || externo.getExternalDataUser() == null) {
			return "";
		}
		return safeTrim(externo.getExternalDataUser().getCorreo());
	}

	private boolean esUsuarioInterno(UserDetailsVo userDetailsVo) {
		return userDetailsVo.getIdTipoUsuario() != null && userDetailsVo.getIdTipoUsuario().intValue() == 0;
	}

	private boolean isBlank(String value) {
		return value == null || value.trim().isEmpty();
	}

	private String safeTrim(String value) {
		return value == null ? "" : value.trim();
	}

	public int getIndiceEtapa() {
		return indiceEtapa;
	}

	public void setIndiceEtapa(int indiceEtapa) {
		this.indiceEtapa = indiceEtapa;
	}

	public String getStyles() {
		return styles;
	}

	public void setStyles(String styles) {
		this.styles = styles;
	}

	private String darEstilo(String colorBarraActiva) {
		StringBuilder sb = new StringBuilder();
		sb.append(".ui-steps.custom { margin-bottom: 30px; }")
				.append(".ui-steps.custom .ui-steps-item .ui-menuitem-link { height: 10px; padding: 0 1em; }")
				.append(".ui-steps.custom .ui-steps-item .ui-steps-number { background-color: #0081c2; color: #FFFFFF; display: inline-block; width: 30px; border-radius: 10px; margin-top: -10px; margin-bottom: 10px; }")
				.append(".ui-widget-overlay { position: fixed; }")
				.append(".ui-state-highlight a, .ui-widget-content .ui-state-highlight a, .ui-widget-header .ui-state-highlight a{ color: #000000; font-weight: bold; background-color: ")
				.append(colorBarraActiva).append("; }");
		return sb.toString();
	}

	public String getSitioId() {
		return sitioId;
	}

	public void setSitioId(String sitioId) {
		this.sitioId = sitioId;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public List<?> getSitios() {
		return sitios;
	}

	public void setSitios(List<Object> sitios) {
		this.sitios = sitios;
	}

	public List<String> getTiposIncidencia() {
		return tiposIncidencia;
	}

	public void setTiposIncidencia(List<String> tiposIncidencia) {
		this.tiposIncidencia = tiposIncidencia;
	}

	public long getMaxBytesAdjunto() {
		return maxBytesAdjunto;
	}

	public void setMaxBytesAdjunto(long maxBytesAdjunto) {
		this.maxBytesAdjunto = maxBytesAdjunto;
	}

	public String getRegexExtensionesPermitidas() {
		return regexExtensionesPermitidas;
	}

	public void setRegexExtensionesPermitidas(String regexExtensionesPermitidas) {
		this.regexExtensionesPermitidas = regexExtensionesPermitidas;
	}

	public String getFormatosHumanos() {
		return formatosHumanos;
	}

	public void setFormatosHumanos(String formatosHumanos) {
		this.formatosHumanos = formatosHumanos;
	}

	public int getMaxMb() {
		return maxMb;
	}

	public void setMaxMb(int maxMb) {
		this.maxMb = maxMb;
	}

	public List<AdjuntoUi> getAdjuntosUi() {
		return adjuntosUi;
	}

	public void setAdjuntosUi(List<AdjuntoUi> adjuntosUi) {
		this.adjuntosUi = adjuntosUi;
	}

	public String getConcesionarioUsuario() {
		return concesionarioUsuario;
	}

	public void setConcesionarioUsuario(String concesionarioUsuario) {
		this.concesionarioUsuario = concesionarioUsuario;
	}

	/** Getter requerido por el XHTML: #{incidenciaBean.totalMbAdjuntos} */
	public String getTotalMbAdjuntos() {
		return bytesToMbStr(sumarBytesAdjuntos());
	}

	public Long getIdIncidenciaCreada() {
		return idIncidenciaCreada;
	}

	public void setIdIncidenciaCreada(Long idIncidenciaCreada) {
		this.idIncidenciaCreada = idIncidenciaCreada;
	}

	public String getUploadErrTitle() {
		return uploadErrTitle;
	}

	public void setUploadErrTitle(String uploadErrTitle) {
		this.uploadErrTitle = uploadErrTitle;
	}

	public String getUploadErrMsg() {
		return uploadErrMsg;
	}

	public void setUploadErrMsg(String uploadErrMsg) {
		this.uploadErrMsg = uploadErrMsg;
	}

	public boolean isAdjuntosError() {
		return adjuntosError;
	}

	public void setAdjuntosError(boolean adjuntosError) {
		this.adjuntosError = adjuntosError;
	}

	public String getFolioIncidenciaCreada() {
		return folioIncidenciaCreada;
	}

	public void setFolioIncidenciaCreada(String folioIncidenciaCreada) {
		this.folioIncidenciaCreada = folioIncidenciaCreada;
	}
}

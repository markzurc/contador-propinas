package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.incidencia.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.webflow.execution.RequestContext;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.IIncidenciaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.IIncidenciaService.AdjuntoUi;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.OperadorDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.user.service.UserCatalogService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ExternalUserFindVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ReportUserVo;

@Controller("incidenciaBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class IncidenciaBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggerFactory.getLogger(IncidenciaBean.class);

	@Autowired(required = false)
	private IIncidenciaService incidenciaService;

	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;

	@Autowired
	private UserCatalogService userCatalogService;

	private String sitioId;
	private String tipo;
	private String descripcion;
	private int indiceEtapa = 0;
	private String styles;
	private List<?> sitios = new ArrayList<Object>();
	private List<String> tiposIncidencia = new ArrayList<String>();
	private String folioIncidenciaCreada;
	private String operadorUsuarioPerfilRaw;

	private boolean adjuntosError;

	private long maxBytesAdjunto = 10L * 1024 * 1024;

	private String regexExtensionesPermitidas = "/(\\.|\\/)(pdf)$/";
	private String formatosHumanos = "PDF";
	private int maxMb = 10;

	private List<AdjuntoUi> adjuntosUi = new ArrayList<AdjuntoUi>();

	private static final String CFG_IDENT = "INCIDENCIAS";

	private String concesionarioUsuario;
	private Long idIncidenciaCreada;

	private String uploadErrTitle;
	private String uploadErrMsg;

	public void cargaInicial(RequestContext rc) {
		try {
			cargarConcesionarioDesdePerfil();
			cargarCatalogos();
			cargarParametrosDesdeConfiguracion();

			limpiarFormulario();

			log.debug("Incidencias-> concesionarioUsuario (perfil): {}", concesionarioUsuario);
		} catch (Exception ex) {
			log.error("Incidencias-> error en cargaInicial; se continúa con valores por defecto.", ex);
		}
	}

	private void cargarCatalogos() {
		if (incidenciaService == null) {
			log.warn("Incidencias-> incidenciaService es NULL. Verifica @Service.");
			this.sitios.clear();
			this.tiposIncidencia.clear();
			return;
		}

		String concesionarioIdentificador = getConcesionarioIdentificadorParaSuscripciones();
		this.sitios = safeList(incidenciaService.listarSitiosSuscritosParaAltaIncidencia(concesionarioIdentificador));
		this.tiposIncidencia = safeList(incidenciaService.catalogoTiposIncidencia());
	}

	private void cargarParametrosDesdeConfiguracion() {
		Long cfgMaxBytes = getCfgLong(CFG_IDENT, "MAX_BYTES_ADJUNTO", null);
		Integer cfgMaxArch = getCfgInt(CFG_IDENT, "MAX_ARCHIVOS", null);
		String cfgRegex = getCfgStr(CFG_IDENT, "REGEX_EXT_PERMITIDAS", null);
		String cfgFormatos = getCfgStr(CFG_IDENT, "FORMATOS_HUMANOS", null);

		if (incidenciaService != null) {
			if (cfgMaxBytes == null)
				cfgMaxBytes = incidenciaService.obtenerMaxBytesAdjunto();
			if (cfgMaxArch == null)
				cfgMaxArch = incidenciaService.obtenerMaxArchivos();
			if (cfgRegex == null)
				cfgRegex = incidenciaService.obtenerRegexExtensiones();
			if (cfgFormatos == null)
				cfgFormatos = incidenciaService.obtenerFormatosHumanos();
		}

		if (cfgMaxBytes != null)
			this.maxBytesAdjunto = cfgMaxBytes;

		if (cfgRegex != null)
			this.regexExtensionesPermitidas = cfgRegex;
		if (cfgFormatos != null)
			this.formatosHumanos = cfgFormatos;

		this.maxMb = (int) (this.maxBytesAdjunto / (1024 * 1024));
	}

	@SuppressWarnings("unchecked")
	private <T> List<T> safeList(List<?> origen) {
		if (origen == null)
			return new ArrayList<T>();
		return (List<T>) origen;
	}

	private Integer getCfgInt(String ident, String key, Integer defaultVal) {
		if (configurationUtilsBusiness == null)
			return defaultVal;
		try {
			ConfigurationUtilsVo cfg = configurationUtilsBusiness.getConstantOfDataBase(ident, key);
			if (cfg == null || cfg.getValor() == null)
				return defaultVal;
			return Integer.parseInt(cfg.getValor());
		} catch (Exception e) {
			return defaultVal;
		}
	}

	private Long getCfgLong(String ident, String key, Long defaultVal) {
		if (configurationUtilsBusiness == null)
			return defaultVal;
		try {
			ConfigurationUtilsVo cfg = configurationUtilsBusiness.getConstantOfDataBase(ident, key);
			if (cfg == null || cfg.getValor() == null)
				return defaultVal;
			return Long.parseLong(cfg.getValor());
		} catch (Exception e) {
			return defaultVal;
		}
	}

	private String getCfgStr(String ident, String key, String defaultVal) {
		if (configurationUtilsBusiness == null)
			return defaultVal;
		try {
			ConfigurationUtilsVo cfg = configurationUtilsBusiness.getConstantOfDataBase(ident, key);
			if (cfg == null || cfg.getValor() == null)
				return defaultVal;
			return cfg.getValor();
		} catch (Exception e) {
			return defaultVal;
		}
	}

	private void cargarConcesionarioDesdePerfil() {
		try {
			Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

			if (!(principal instanceof UserDetailsVo)) {
				log.warn("Incidencias-> principal no es UserDetailsVo: {}", principal);
				return;
			}

			UserDetailsVo userDetailsVo = (UserDetailsVo) principal;
			Integer idUsuario = userDetailsVo.getIdUsuario();

			if (idUsuario == null) {
				log.warn("Incidencias-> idUsuario nulo en UserDetailsVo");
				return;
			}

			if (userCatalogService == null) {
				log.warn("Incidencias-> userCatalogService es NULL, no se puede obtener concesionario.");
				return;
			}

			String operadorUsuarioRaw = userCatalogService.obtenerOperadorUsuario(idUsuario);
			this.operadorUsuarioPerfilRaw = operadorUsuarioRaw;

			if (operadorUsuarioRaw == null || operadorUsuarioRaw.trim().isEmpty()) {
				log.warn("Incidencias-> Usuario {} sin operador asignado", idUsuario);
				return;
			}

			String operadorTrim = operadorUsuarioRaw.trim();
			String codigoOperador = operadorTrim;
			String nombreOperador = null;

			int indiceSeparador = operadorTrim.indexOf(':');
			if (indiceSeparador >= 0) {
				codigoOperador = operadorTrim.substring(0, indiceSeparador).trim();
				if (indiceSeparador + 1 < operadorTrim.length()) {
					nombreOperador = operadorTrim.substring(indiceSeparador + 1).trim();
				}
			}

			if (nombreOperador != null && !nombreOperador.isEmpty()) {
				concesionarioUsuario = nombreOperador;
				log.debug("Incidencias-> concesionarioUsuario (desde operadorRaw) = [{}]", concesionarioUsuario);
				return;
			}

			String descripcionOperador = null;
			List<OperadorDto> empresas = userCatalogService.obtenerEmpresas();
			if (empresas != null) {
				for (OperadorDto operadorDto : empresas) {
					if (operadorDto == null || operadorDto.getGrupoOperador() == null) {
						continue;
					}
					String codigo = operadorDto.getGrupoOperador().trim();
					if (codigo.equals(codigoOperador)) {
						descripcionOperador = operadorDto.getDescripcion();
						break;
					}
				}
			}

			if (descripcionOperador != null && !descripcionOperador.trim().isEmpty()) {
				concesionarioUsuario = descripcionOperador.trim();
			} else {
				concesionarioUsuario = codigoOperador;
			}

			log.debug("Incidencias-> Usuario {} operadorRaw [{}] codigoOperador [{}] concesionarioUsuario [{}]",
					idUsuario, operadorUsuarioRaw, codigoOperador, concesionarioUsuario);

		} catch (Exception exception) {
			log.error("Incidencias-> Error al cargar concesionario desde perfil", exception);
		}
	}

	public void handleFileUpload(FileUploadEvent e) {
		UploadedFile f = (e != null) ? e.getFile() : null;

		if (f == null) {
			mostrarPopupUploadError("Archivo inválido", "No se recibió el archivo.");
			addCallbackParamSafe("upOk", false);
			return;
		}

		if (adjuntosUi == null) {
			adjuntosUi = new ArrayList<AdjuntoUi>();
		}

		try {
			if (incidenciaService == null) {
				mostrarPopupUploadError("Servicio no disponible", "No fue posible validar el archivo.");
				addCallbackParamSafe("upOk", false);
				return;
			}

			// Validación por archivo
			incidenciaService.validarAdjunto(f.getFileName(), f.getContentType(), f.getSize());

			// Validación por total
			long totalActual = sumarBytesAdjuntos();
			long totalNuevo = totalActual + f.getSize();
			if (totalNuevo > maxBytesAdjunto) {
				mostrarPopupUploadError("Tamaño excedido",
						"El total de evidencias no debe exceder " + getMaxMb() + " MB.");
				addCallbackParamSafe("upOk", false);
				return;
			}

			// OK: agrega archivo
			// OK: agrega archivo
			adjuntosUi.add(new AdjuntoUi(f.getFileName(), f.getSize(), f.getContents()));

			// CLAVE: si antes estaba en rojo porque faltaban evidencias, al agregar se
			// quita
			this.adjuntosError = false;

			addCallbackParamSafe("upOk", true);

		} catch (IllegalArgumentException iae) {
			mostrarUploadError("Archivo no permitido", iae.getMessage());
			addCallbackParamSafe("upOk", false);
			return;

		} catch (Exception ex) {
			log.error("Incidencias-> error al procesar adjunto en alta", ex);
			mostrarPopupUploadError("Error", "No fue posible procesar el archivo.");
			addCallbackParamSafe("upOk", false);
			return;
		}
	}

	public void quitarAdjunto(AdjuntoUi adj) {
		if (adjuntosUi != null && adj != null) {
			adjuntosUi.remove(adj);
		}

		// NO lo pongas rojo aquí. Solo limpiamos el flag para que no quede “pegado”
		// y vuelva a evaluarse al presionar "Generar".
		this.adjuntosError = false;
	}

	private long sumarBytesAdjuntos() {
		long total = 0L;
		if (adjuntosUi == null) {
			return 0L;
		}
		for (AdjuntoUi a : adjuntosUi) {
			if (a != null) {
				total += a.getTamanio();
			}
		}
		return total;
	}

	private String bytesToMbStr(long bytes) {
		double mb = bytes / (1024d * 1024d);
		double red = Math.round(mb * 100.0) / 100.0; // 2 decimales
		return String.valueOf(red);
	}

	private void addCallbackParamSafe(String key, Object value) {
		try {
			// PrimeFaces.current().ajax().addCallbackParam(...)
			Class<?> pf = Class.forName("org.primefaces.PrimeFaces");
			Object current = pf.getMethod("current").invoke(null);
			Object ajax = current.getClass().getMethod("ajax").invoke(current);
			ajax.getClass().getMethod("addCallbackParam", String.class, Object.class).invoke(ajax, key, value);
			return;
		} catch (Exception ignore) {
			// continue
		}
		try {
			// RequestContext.getCurrentInstance().addCallbackParam(...)
			Class<?> rc = Class.forName("org.primefaces.context.RequestContext");
			Object inst = rc.getMethod("getCurrentInstance").invoke(null);
			inst.getClass().getMethod("addCallbackParam", String.class, Object.class).invoke(inst, key, value);
		} catch (Exception ignore) {
			// no-op
		}
	}

	public String generar() {
		FacesContext ctx = FacesContext.getCurrentInstance();

		try {
			// SIEMPRE limpia id anterior antes de generar (ok)
			this.idIncidenciaCreada = null;
			this.folioIncidenciaCreada = null;

			this.adjuntosError = false;

			if (adjuntosUi == null || adjuntosUi.isEmpty()) {
				this.adjuntosError = true;
				FacesContext.getCurrentInstance().validationFailed();
				return null;
			}

			if (incidenciaService == null) {
				ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"No fue posible procesar la incidencia.", "Servicio no disponible"));
				FacesContext.getCurrentInstance().validationFailed();
				return null;
			}

			Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			if (!(principal instanceof UserDetailsVo)) {
				ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"No fue posible obtener los datos del usuario.", "Sesión no válida."));
				FacesContext.getCurrentInstance().validationFailed();
				return null;
			}

			UserDetailsVo userDetailsVo = (UserDetailsVo) principal;

			// --- tu lógica de nombre/correo/concesionario tal cual ---
			StringBuilder sb = new StringBuilder();
			if (userDetailsVo.getNombre() != null)
				sb.append(userDetailsVo.getNombre().trim());
			if (userDetailsVo.getApellidoPaterno() != null) {
				if (sb.length() > 0)
					sb.append(" ");
				sb.append(userDetailsVo.getApellidoPaterno().trim());
			}
			if (userDetailsVo.getApellidoMaterno() != null) {
				if (sb.length() > 0)
					sb.append(" ");
				sb.append(userDetailsVo.getApellidoMaterno().trim());
			}
			String nombreUsuarioCreacion = sb.toString().trim();

			String correoUsuarioCreacion = ""; // tu misma lógica para llenarlo
			Integer idUsuario = userDetailsVo.getIdUsuario();
			// ... (tu lógica existente sin cambios) ...

			if (concesionarioUsuario == null || concesionarioUsuario.trim().isEmpty()) {
				cargarConcesionarioDesdePerfil();
			}

			// valida + crea
			incidenciaService.validarAlta(sitioId, tipo, descripcion, adjuntosUi);

			Long id = incidenciaService.crearIncidencia(sitioId, tipo, descripcion, adjuntosUi, nombreUsuarioCreacion,
					correoUsuarioCreacion, concesionarioUsuario);

			// CLAVE: aquí NO limpias.
			this.idIncidenciaCreada = id;

			this.folioIncidenciaCreada = (incidenciaService != null) ? incidenciaService.generarFolioIncidencia(id)
					: null;

		} catch (IllegalArgumentException e) {
			log.warn("Incidencias-> validación al crear incidencia: {}", e.getMessage());
			ctx.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Validación de incidencia", e.getMessage()));
			FacesContext.getCurrentInstance().validationFailed();
		} catch (Exception e) {
			log.error("Incidencias-> error al crear la incidencia", e);
			this.idIncidenciaCreada = null;
			this.folioIncidenciaCreada = null;
			ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Ocurrió un error al crear la incidencia.", "Intente nuevamente más tarde."));
			FacesContext.getCurrentInstance().validationFailed();
		}

		return null;
	}

	public void limpiarFormulario() {
		this.idIncidenciaCreada = null;
		this.folioIncidenciaCreada = null;
		this.sitioId = null;
		this.tipo = null;
		this.descripcion = null;

		if (this.adjuntosUi != null) {
			this.adjuntosUi.clear();
		}

		// CLAVE
		this.adjuntosError = false;

		this.styles = darEstilo("#FFC000");
	}

	private void updateComponentSafe(String clientId) {
		try {
			// PrimeFaces.current().ajax().update(...)
			Class<?> pf = Class.forName("org.primefaces.PrimeFaces");
			Object current = pf.getMethod("current").invoke(null);
			Object ajax = current.getClass().getMethod("ajax").invoke(current);
			ajax.getClass().getMethod("update", String.class).invoke(ajax, clientId);
			return;
		} catch (Exception ignore) {
			// continue
		}
		try {
			// RequestContext.getCurrentInstance().update(...)
			Class<?> rc = Class.forName("org.primefaces.context.RequestContext");
			Object inst = rc.getMethod("getCurrentInstance").invoke(null);
			inst.getClass().getMethod("update", String.class).invoke(inst, clientId);
		} catch (Exception ignore) {
			// no-op
		}
	}

	private void executeScriptSafe(String script) {
		try {
			// PrimeFaces.current().executeScript(...)
			Class<?> pf = Class.forName("org.primefaces.PrimeFaces");
			Object current = pf.getMethod("current").invoke(null);
			current.getClass().getMethod("executeScript", String.class).invoke(current, script);
			return;
		} catch (Exception ignore) {
			// continue
		}
		try {
			// RequestContext.getCurrentInstance().execute(...)
			Class<?> rc = Class.forName("org.primefaces.context.RequestContext");
			Object inst = rc.getMethod("getCurrentInstance").invoke(null);
			inst.getClass().getMethod("execute", String.class).invoke(inst, script);
		} catch (Exception ignore) {
			// no-op
		}
	}

	private void mostrarPopupUploadError(String title, String msg) {
		this.uploadErrTitle = (title != null ? title : "Error");
		this.uploadErrMsg = (msg != null ? msg : "No fue posible procesar el archivo.");

		// Actualiza el diálogo y lo muestra en la MISMA respuesta del upload
		updateComponentSafe("formInc:dlgUpErr");
		executeScriptSafe("if (typeof PF === 'function') { PF('dlgUpErr').show(); }");
	}

	private void mostrarUploadError(String title, String msg) {
		this.uploadErrTitle = (title != null && !title.trim().isEmpty()) ? title : "Error";
		this.uploadErrMsg = (msg != null && !msg.trim().isEmpty()) ? msg : "No fue posible procesar el archivo.";

		// CLAVE: actualiza el contenido que contiene los outputText
		updateComponentSafe("formInc:dlgUpErrContent");

		// mostrar
		executeScriptSafe("if (typeof PF === 'function') { PF('dlgUpErr').show(); }");
	}

	public void mostrarUploadErrorDesdeCliente() {
		FacesContext fc = FacesContext.getCurrentInstance();
		String t = fc.getExternalContext().getRequestParameterMap().get("t");
		String m = fc.getExternalContext().getRequestParameterMap().get("m");
		mostrarUploadError(t, m);
	}

	private String getConcesionarioIdentificadorParaSuscripciones() {
		if (!isBlank(this.operadorUsuarioPerfilRaw)) {
			return this.operadorUsuarioPerfilRaw; // "ID: NOMBRE" cuando exista
		}
		return this.concesionarioUsuario; // fallback
	}

	private boolean isBlank(String texto) {
		return texto == null || texto.trim().isEmpty();
	}

	public int getIndiceEtapa() {
		return indiceEtapa;
	}

	public void setIndiceEtapa(int indiceEtapa) {
		this.indiceEtapa = indiceEtapa;
	}

	public String getStyles() {
		return styles;
	}

	public void setStyles(String styles) {
		this.styles = styles;
	}

	private String darEstilo(String colorBarraActiva) {
		StringBuilder sb = new StringBuilder();
		sb.append(".ui-steps.custom { margin-bottom: 30px; }")
				.append(".ui-steps.custom .ui-steps-item .ui-menuitem-link { height: 10px; padding: 0 1em; }")
				.append(".ui-steps.custom .ui-steps-item .ui-steps-number { background-color: #0081c2; color: #FFFFFF; display: inline-block; width: 30px; border-radius: 10px; margin-top: -10px; margin-bottom: 10px; }")
				.append(".ui-widget-overlay { position: fixed; }")
				.append(".ui-state-highlight a, .ui-widget-content .ui-state-highlight a, .ui-widget-header .ui-state-highlight a{ color: #000000; font-weight: bold; background-color: ")
				.append(colorBarraActiva).append("; }");
		return sb.toString();
	}

	public String getSitioId() {
		return sitioId;
	}

	public void setSitioId(String sitioId) {
		this.sitioId = sitioId;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public List<?> getSitios() {
		return sitios;
	}

	public void setSitios(List<?> sitios) {
		this.sitios = sitios;
	}

	public List<String> getTiposIncidencia() {
		return tiposIncidencia;
	}

	public void setTiposIncidencia(List<String> tiposIncidencia) {
		this.tiposIncidencia = tiposIncidencia;
	}

	public long getMaxBytesAdjunto() {
		return maxBytesAdjunto;
	}

	public void setMaxBytesAdjunto(long maxBytesAdjunto) {
		this.maxBytesAdjunto = maxBytesAdjunto;
	}

	public String getRegexExtensionesPermitidas() {
		return regexExtensionesPermitidas;
	}

	public void setRegexExtensionesPermitidas(String regexExtensionesPermitidas) {
		this.regexExtensionesPermitidas = regexExtensionesPermitidas;
	}

	public String getFormatosHumanos() {
		return formatosHumanos;
	}

	public void setFormatosHumanos(String formatosHumanos) {
		this.formatosHumanos = formatosHumanos;
	}

	public int getMaxMb() {
		return maxMb;
	}

	public void setMaxMb(int maxMb) {
		this.maxMb = maxMb;
	}

	public List<AdjuntoUi> getAdjuntosUi() {
		return adjuntosUi;
	}

	public void setAdjuntosUi(List<AdjuntoUi> adjuntosUi) {
		this.adjuntosUi = adjuntosUi;
	}

	public String getConcesionarioUsuario() {
		return concesionarioUsuario;
	}

	public void setConcesionarioUsuario(String concesionarioUsuario) {
		this.concesionarioUsuario = concesionarioUsuario;
	}

	/** Getter requerido por el XHTML: #{incidenciaBean.totalMbAdjuntos} */
	public String getTotalMbAdjuntos() {
		return bytesToMbStr(sumarBytesAdjuntos());
	}

	public Long getIdIncidenciaCreada() {
		return idIncidenciaCreada;
	}

	public void setIdIncidenciaCreada(Long idIncidenciaCreada) {
		this.idIncidenciaCreada = idIncidenciaCreada;
	}

	public String getUploadErrTitle() {
		return uploadErrTitle;
	}

	public void setUploadErrTitle(String uploadErrTitle) {
		this.uploadErrTitle = uploadErrTitle;
	}

	public String getUploadErrMsg() {
		return uploadErrMsg;
	}

	public void setUploadErrMsg(String uploadErrMsg) {
		this.uploadErrMsg = uploadErrMsg;
	}

	public boolean isAdjuntosError() {
		return adjuntosError;
	}

	public void setAdjuntosError(boolean adjuntosError) {
		this.adjuntosError = adjuntosError;
	}

	public String getFolioIncidenciaCreada() {
		return folioIncidenciaCreada;
	}

	public void setFolioIncidenciaCreada(String folioIncidenciaCreada) {
		this.folioIncidenciaCreada = folioIncidenciaCreada;
	}
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.rol.service;


import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX0;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX1;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX2;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX3;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX4;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX5;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX6;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX7;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX8;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.INDEX9;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.IBitacoraSoxBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.OVITUtils;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.IApplicationBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ApplicationVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ComponentVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.IRolBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolAclVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolApplicationVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.BitacoraSeguridadUtil;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.SnapshotRolAcls;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.TabAplicacionAclUtil;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.WrapperSelectUtil;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.TreeNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service("rolCatalogService")
public class RolCatalogService implements Serializable{

	private static final long serialVersionUID = 6787175618586555818L;
	public static final String STEP_ACLS="aclsRol";
	public static final String STEP_CONFIMR="confirm";
	public static final String MSJ_FOL_REQ= "El folio es requerido.";
	public static final String MSJ_FOL_ALPHA= "El folio debe ser alfanumerico.";
	
	public static final String FOLIO_VAL= "[A-Za-z0-9]+";
	public static final String SUCCES="succes";
	
	
	@Autowired
	@Qualifier("bitacoraSeguridadUtil")
	private BitacoraSeguridadUtil bitacoraSeguridadUtil;
	
	@Autowired
	@Qualifier("rolBusiness")
	private IRolBusiness rolBussines;
	
	@Autowired 
	@Qualifier("aplicacionBusiness")
	private IApplicationBusiness aplicacionBussinesImpl;
	private int index=0;
	
	private static final Logger logger = LogManager.getLogger(RolCatalogService.class);
	
	
	public RolVo loadRolById(int idRol) {
		RolVo rolVo=new RolVo();
		rolVo.setIdRol(idRol);
		List<RolVo> listaRoles=null;
			try{
				listaRoles=rolBussines.findByWithoutApplications(rolVo);
				}catch(TransactionalOVITException toe){
					logger.error("Ocurrio un error al cargar el rol:"+rolVo.getIdRol()+". ");
					logger.error("Error al ejecutar RolCatalogService.loadRolById: " + toe);
				}	
			if(!OVITUtils.isEmptyList(listaRoles) && listaRoles.size() > 1){
				for(RolVo rol:listaRoles){
					if(rol.getIdRol()==idRol){
				        return rol;
				        }
				}
			}
		
		return null;
		
	}
	
	public List<RolVo> getAllRoles() throws TransactionalOVITException{
		logger.info("Cargando roles del sistema ");
			List<RolVo> listaRoles=rolBussines.findByWithoutApplications (new RolVo());
			listaRoles=removeDelted(listaRoles);
		return listaRoles;
	}

	
	public List<ApplicationVo> getAllApp() throws TransactionalOVITException{
		logger.info("Cargando Apps del sistema ");
	    return aplicacionBussinesImpl.findByExample(new ApplicationVo());
	}

	public boolean existRolName(String nameToValidate) throws TransactionalOVITException{
		List<RolVo> listaRoles=rolBussines.findByWithoutApplications (new RolVo());
		for(RolVo rolVol:listaRoles){
			if(rolVol.getNombre().equals(nameToValidate)){
				return true; 
				}
		}
		return false;
	}
	
	
	public List<ApplicationVo> getApliacionesByRol(RolVo rol) throws TransactionalOVITException{
		 	RolApplicationVo rolApplicationVo= rolBussines.findByWithApplications(rol);
		return rolApplicationVo.getRolAplicacion().get(rol);
	}
	
	
	private List<RolVo> removeDelted(List<RolVo> listaRoles){
		List<RolVo> listBack= new ArrayList<RolVo>();	
		for(RolVo rol:listaRoles){
			if(rol.getIdEstatus()==INDEX0){
				listBack.add(rol);
			}
		}
		return listBack;
	}
	

	public void registraEnBitacora(String oldObj,Object newObj,String folio,int operationType){
		 bitacoraSeguridadUtil.registraEntradaBitacora(oldObj, newObj, folio, operationType);
	}
	
	
	public boolean merge(RolVo rol,List<ApplicationVo> selectedApps,List<TabAplicacionAclUtil> tabsAclsApps,String oldStateRolXml, String folio){
		
		boolean succes = true;
		rol.setListIdAplicacion(toIntegerList(selectedApps));
		rol.setIdEstatus(INDEX0);
		List<RolAclVo> allRelationsRolComp = new ArrayList<RolAclVo>();
		for (TabAplicacionAclUtil tabApp : tabsAclsApps) {
			allRelationsRolComp.addAll(generaRelacionesRolAcl(rol, tabApp));
		}
		
		try {
			if (rol.getIdRol() == null) {
				rol = rolBussines.createRol(rol, allRelationsRolComp);
				
				if (rol.getIdRol() == null){
					succes = false;
					bitacoraSeguridadUtil.registraEntradaBitacora("", new  SnapshotRolAcls(rol,allRelationsRolComp),folio,IBitacoraSoxBusiness.ERROR_CREATE);	
				}
				else{
						bitacoraSeguridadUtil.registraEntradaBitacora("", new  SnapshotRolAcls(rol,allRelationsRolComp),folio,IBitacoraSoxBusiness.CREATE);		
					}
			} else {
				succes = rolBussines.updateRol(rol, allRelationsRolComp);
				if(succes){
					bitacoraSeguridadUtil.registraEntradaBitacora(oldStateRolXml, new SnapshotRolAcls(rol,allRelationsRolComp),folio,IBitacoraSoxBusiness.UPDATE);
				}
				else{
					bitacoraSeguridadUtil.registraEntradaBitacora(oldStateRolXml, new SnapshotRolAcls(rol,allRelationsRolComp),folio,IBitacoraSoxBusiness.ERROR_MODIFY);
				}
			}
		} catch (TransactionalOVITException e) {
			succes = false;
			logger.error(e.getMessageError());
			logger.error("Error al ejecutar RolCatalogService.merge: " + e);
		}
		
		return succes;
	   
		
	}
	
	
	public String getXMLfromObject(Object obj){
		return bitacoraSeguridadUtil.getActualStateXML(obj);
	}
	
	public boolean updateRol(RolVo rol,List<RolAclVo> allRelationsRolComp,String folio){
		boolean succes = false;
		String oldStateRolXml=getXMLfromObject(new SnapshotRolAcls(rol,allRelationsRolComp));
		try {
			succes = rolBussines.updateRol(rol, allRelationsRolComp);
			
			if(succes){
				bitacoraSeguridadUtil.registraEntradaBitacora(oldStateRolXml, new SnapshotRolAcls(rol,allRelationsRolComp),folio,IBitacoraSoxBusiness.DROP);
			} else{
			    bitacoraSeguridadUtil.registraEntradaBitacora(oldStateRolXml, new SnapshotRolAcls(rol,allRelationsRolComp),folio,IBitacoraSoxBusiness.ERROR_DELETE);
			}

		} catch (TransactionalOVITException e) {
			succes = false;
			logger.error(e.getMessageError());
			logger.error("Error al ejecutar RolCatalogService.updateRol: " + e);
		}

		return succes;
	}
	
	
	
	public List<Integer> toIntegerList(List<ApplicationVo> selectedApps){
		List<Integer> listBack= new ArrayList<Integer>();
		if(selectedApps!=null){
			for(ApplicationVo app:selectedApps){
				listBack.add(app.getIdAplicacion());
			}
		}
		return listBack;
	}
	
	
	private List<RolAclVo> generaRelacionesRolAcl(RolVo rol,TabAplicacionAclUtil tabApp){
		List<RolAclVo> listaBack= new ArrayList<RolAclVo>();
		List<WrapperSelectUtil> listComponentes=tabApp.getComponentsSelected();
		
		for(WrapperSelectUtil wrapperSelect:listComponentes){
			RolAclVo rolAclVo= new RolAclVo();
			rolAclVo.setFlujo(wrapperSelect.getComponente().getFlujo());
			rolAclVo.setIdAplicacion(tabApp.getAplicacion().getIdAplicacion());
			rolAclVo.setIdRol(rol.getIdRol());
			rolAclVo.setIdComponente(wrapperSelect.getComponente().getIdComponente());
			rolAclVo.setIdPadre(wrapperSelect.getComponente().getIdPadre());
			rolAclVo.setNombre(wrapperSelect.getComponente().getNombre());
			rolAclVo.setPermiso(wrapperSelect.getPermisoChar());
			rolAclVo.setIdTipoComponente(wrapperSelect.getComponente().getIdTipoComponente());
			rolAclVo.setValorComponente(wrapperSelect.getComponente().getValorComponente());
			listaBack.add(rolAclVo);
		}
		
		return listaBack;
	}
	
		
	
	public String validaAcls(List<TabAplicacionAclUtil> tabsAclsApps){
		String resultado= "success";
		
		for(TabAplicacionAclUtil tab: tabsAclsApps){
				if(!tab.hasSeletedComponents()){
					tab.showErrorSeleccionados();
					if(resultado.equals("success")){
					     resultado= tab.getAplicacion().getNombre()+" ";
					}else{
						resultado+= tab.getAplicacion().getNombre()+" ";
						}
				}
			}
	   return resultado;
	}
	
	
	public List<RolAclVo>  fillTabsAcls(List<ApplicationVo> selectedApps,RolVo rol,List<TabAplicacionAclUtil> tabsAclsApps) throws TransactionalOVITException {
		
		List<RolAclVo> listaRolAclVo= new ArrayList<RolAclVo>();		
		
		if(!OVITUtils.isEmptyList(selectedApps)){
		for(ApplicationVo aplicacion:selectedApps){
			if(!isAclsAppLoaded(aplicacion,tabsAclsApps)){
				TabAplicacionAclUtil tabNuevo= new TabAplicacionAclUtil();
				tabNuevo.setAplicacion(aplicacion);
				List<ComponentVo> listaComponentes=getListComponents(aplicacion);
				tabNuevo.generaTreeNodeAclsByApp(listaComponentes);
				if(rol.getIdRol()!= null){
					 listaRolAclVo= rolBussines.findByRolAcl(rol.getIdRol(),aplicacion.getIdAplicacion());
					tabNuevo.selectLoadedbyRol(listaRolAclVo);
				}
				tabsAclsApps.add(tabNuevo);
			}
		}
		removeNotSelected(tabsAclsApps,selectedApps);
		}
		
		return listaRolAclVo;
	}
	
	private void removeNotSelected(List<TabAplicacionAclUtil> tabsAclsApps,List<ApplicationVo> selectedApps){
	 ArrayList<TabAplicacionAclUtil> toRemove= new ArrayList<TabAplicacionAclUtil>(); 	
	 for(TabAplicacionAclUtil tab: tabsAclsApps){
		  if(!selectedApps.contains(tab.getAplicacion())){
			  toRemove.add(tab);
		  }
		}
	 tabsAclsApps.removeAll(toRemove);
	}
	
	
	public List<ComponentVo>  getListComponents(ApplicationVo aplicacion){
		List<ComponentVo> listaComponentes= new ArrayList<ComponentVo>();
		try {
			listaComponentes =aplicacionBussinesImpl.componentsForApplication(aplicacion.getIdAplicacion());
		} catch (TransactionalOVITException e) {
			logger.error(e.getMessageError());
			logger.error("Error al ejecutar RolCatalogService.getListComponents: " + e);
		}
		return listaComponentes;
	}
	
		
	private boolean isAclsAppLoaded(ApplicationVo aplicacion,List<TabAplicacionAclUtil> tabsAclsApps){
		for(TabAplicacionAclUtil tabAplicacion:tabsAclsApps){
			if(tabAplicacion.getAplicacion().equals(aplicacion)){
					return Boolean.TRUE;
					}
		}
		return Boolean.FALSE;
	}


	public String  validaFolio(String folio){
		String mensajeError=SUCCES;
		
		if(folio.trim().isEmpty()){
			 mensajeError= MSJ_FOL_REQ;
		    }else if(!folio.matches(FOLIO_VAL)){
		    	mensajeError=MSJ_FOL_ALPHA;
		    }
		 return mensajeError;
		
	}
	
	
	public boolean isAsigned(Integer idRol) throws TransactionalOVITException {
			return rolBussines.isInUse(idRol);
	}
		
}

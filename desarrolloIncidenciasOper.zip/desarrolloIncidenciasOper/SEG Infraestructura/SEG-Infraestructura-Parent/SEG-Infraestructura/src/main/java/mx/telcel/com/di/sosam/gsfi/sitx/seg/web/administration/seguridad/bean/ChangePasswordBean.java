package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.seguridad.bean;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.IUserBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.external.authentication.IAuthenticationExternal;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.seguridad.service.ChangePasswordService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.webflow.execution.RequestContext;

@Controller("changePasswordBean")
public class ChangePasswordBean {

	private static final String OK = "ok";
	private static final String REQUIRED_FIELD = "Campo requerido.";
	@Autowired
	@Qualifier("changePasswordService")
	private ChangePasswordService changePasswordService;
	
	@Autowired
    @Qualifier("externalAuth")
    private IAuthenticationExternal authExternal;
	
	private String oldContra;
	private String newContra;
	private String confirmContra;
	private String errorValidacion;
	private String errorOldContra;
	private String errorNewContra;
	private String errorConfirmContra;
	private boolean userBlocked;
	private String currentFolio;
	private String mensajeError;
	private String errorLabel="Ha ocurrido un error en la actulizaci�n de la contrase�a";
	
	public void initChangePassword(RequestContext ctx)
			throws TransactionalOVITException {
		errorValidacion = "";
		oldContra = "";
		newContra = "";
		confirmContra = "";
		errorOldContra = "";
		errorNewContra = "";
		errorConfirmContra = "";
		changePasswordService.initValues();
		userBlocked = false;
		mensajeError = "";
		currentFolio = "";
		
	}

	public void dataValidation() throws TransactionalOVITException {
		errorOldContra = "";
		errorNewContra = "";
		errorConfirmContra = "";
		UserDetailsVo userDetailsVo =(UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		boolean validacion = true;
		if (oldContra.trim().isEmpty()) {
			errorOldContra = REQUIRED_FIELD;
			validacion = false;
		}else{
			int response = changePasswordService.validateLogIn(userDetailsVo.getIdUsuario(), encryptPasswordSEG(oldContra), encryptPasswordSEG(newContra.trim()));
			if (response == IUserBusiness.PASSWORD_CORRECT) {
				errorOldContra = OK;
			}
			if (response == IUserBusiness.PASSWORD_EXCEEDED) {
				errorOldContra = "La contrase�a actual no es correcta.";
				validacion = false;
				userBlocked = true;
			}
			if (response == IUserBusiness.PASSWORD_WRONG) {
				errorOldContra = "La contrase�a actual no es correcta.";
				validacion = false;
			}
		}
		if (newContra.trim().isEmpty()) {
			errorNewContra = REQUIRED_FIELD;
			validacion = false;
		}else{
			errorNewContra=OK;
			/***else if (changePasswordService.containsReservedWords(newContra.trim())) {
				errorNewContra = "La contrase�a no debe contener las palabras: "
						+ changePasswordService.getPalabrasReservadas() + " ";
				validacion = false;
			} else if (!changePasswordService.matchRegexp(newContra.trim())) {
				errorNewContra = changePasswordService.getRegexDescription();
				validacion = false;
			}***/
			if (!changePasswordService.validaLongitudPassword(newContra.trim())) {
				errorNewContra = "La contrase�a debe contener de "
						+ changePasswordService.getNumeroChars() + " a 30 caracteres.";
				validacion = false;
			} else {  
				int response = changePasswordService.validateLogIn(userDetailsVo.getIdUsuario(), encryptPasswordSEG(oldContra),encryptPasswordSEG(newContra.trim()));
				if (response == IUserBusiness.PASSWORD_SAME_ACTUAL) {
					errorNewContra = "La contrase�a debe ser diferente a la actual";
					validacion = false;
				}
				if (response == IUserBusiness.PASSWORD_NUM_VALIDATION) {
					errorNewContra = "No se puede utilizar las ultimas: "
							+ changePasswordService.getNumeroPassOld() + " contrase�as.";
					validacion = false;
				}
			}
		}
		if (confirmContra.trim().isEmpty()) {
			errorConfirmContra = REQUIRED_FIELD;
			    validacion = false;
		}else if(errorNewContra.equals(OK)){ 
			errorConfirmContra=OK;
			   if (!newContra.trim().equals(confirmContra.trim())) {
		    	    errorConfirmContra = "Las contrase�as no coinciden.";
					validacion = false;
				} 
		 }
		if (validacion && userDetailsVo.getIdEstatus() == 0) {
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlg').show()");
		}else if (validacion && (userDetailsVo.getIdEstatus() == 3 || userDetailsVo.getIdEstatus() == 4 || userDetailsVo.getIdEstatus() == 6 ) ){
			update();
		}
 
	}

	public void update() throws TransactionalOVITException {
		org.primefaces.context.RequestContext context = org.primefaces.context.RequestContext
				.getCurrentInstance();
		boolean validation = true;
		boolean succes = false;
		int respuestaCode=0;
		UserDetailsVo userDetailsVo =(UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
 
		
			respuestaCode = changePasswordService.changePassword(userDetailsVo.getIdUsuario(), encryptPasswordSEG(confirmContra));
			if(respuestaCode== IUserBusiness.UPDATE_PASS_CORRECT){
				succes=true;
			}

 
		if(succes){
			context.addCallbackParam("exit", true);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgExito2').show()");
		}else{
			context.addCallbackParam("succes", succes);
			context.addCallbackParam("validation", validation);
		}
 
	}
	private String encryptPasswordSEG(String password) throws TransactionalOVITException{
		String strPasswordCrypt = authExternal.encriptarAcceso(password);
		return strPasswordCrypt;
	}

	public String getNewContra() {
		return newContra;
	}

	public void setNewContra(String newPassword) {
		this.newContra = newPassword;
	}

	public String getErrorValidacion() {
		return errorValidacion;
	}

	public void setErrorValidacion(String errorValidacion) {
		this.errorValidacion = errorValidacion;
	}

	public String getOldContra() {
		return oldContra;
	}

	public void setOldContra(String oldContra) {
		this.oldContra = oldContra;
	}

	public String getConfirmContra() {
		return confirmContra;
	}

	public void setConfirmContra(String confirmContra) {
		this.confirmContra = confirmContra;
	}

	public String getErrorOldContra() {
		return errorOldContra;
	}

	public void setErrorOldContra(String errorOldContra) {
		this.errorOldContra = errorOldContra;
	}

	public String getErrorNewContra() {
		return errorNewContra;
	}

	public void setErrorNewContra(String errorNewContra) {
		this.errorNewContra = errorNewContra;
	}

	public String getErrorConfirmContra() {
		return errorConfirmContra;
	}

	public void setErrorConfirmContra(String errorConfirmContra) {
		this.errorConfirmContra = errorConfirmContra;
	}

	public boolean isUserBlocked() {
		return userBlocked;
	}

	public void setUserBlocked(boolean userBlocked) {
		this.userBlocked = userBlocked;
	}

	public String getCurrentFolio() {
		return currentFolio;
	}

	public void setCurrentFolio(String currentFolio) {
		this.currentFolio = currentFolio;
	}

	public String getMensajeError() {
		return mensajeError;
	}

	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}

	public boolean isRender() {
		return !changePasswordService.isRequiredChangePass();
	}

	public String getErrorLabel() {
		return errorLabel;
	}

	public void setErrorLabel(String errorLabel) {
		this.errorLabel = errorLabel;
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util;

import java.io.Serializable;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ComponentVo;

public class WrapperSelectUtil implements Serializable {

	private boolean selected;
	private ComponentVo componente;
	private boolean permiso;
	@SuppressWarnings("unused")
	private char permisoChar;
	@SuppressWarnings("unused")
	private String permisoString;
	private boolean disablePermiso;
	/**
	 * 
	 */
	private static final long serialVersionUID = 6081333072441643339L;

	WrapperSelectUtil() {
		selected = true;
	}

	public WrapperSelectUtil(ComponentVo componentVo) {
		componente = componentVo;
		disablePermiso=true;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public ComponentVo getComponente() {
		return componente;
	}

	public void setComponente(ComponentVo componente) {
		this.componente = componente;
	}

	public boolean isPermiso() {
		return permiso;
	}

	public void setPermiso(boolean permiso) {
		this.permiso = permiso;
	}

	public char getPermisoChar() {
		return permiso ? 'w' : 'r';
	}

	public void setPermisoChar(char permisoChar) {
		if (permisoChar == 'w'){
			permiso = true;}
		this.permisoChar = permisoChar;
	}

	public String getPermisoString() {
		return permiso ? "Edici�n" : "Lectura";
	}

	public void setPermisoString(String permisoString) {
		this.permisoString = permisoString;
	}

	public boolean isDisablePermiso() {
		return disablePermiso;
	}

	public void setDisablePermiso(boolean disablePermiso) {
		this.disablePermiso = disablePermiso;
	}

	
	
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util;

import java.io.Serializable;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.IBitacoraSoxBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.impl.BitacoraSoxBusinessImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Controller;



@Controller("wrapperConfigurationUtilsVo")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class WrapperConfigurationUtilsVo implements Serializable {

	/**
	 * 
	 */
	
	
	private IBitacoraSoxBusiness bitacoraSoxBusiness= new BitacoraSoxBusinessImpl();
	
	private static final long serialVersionUID = -3227064215400146341L;
	private ConfigurationUtilsVo configurationUtilsVo;
	private boolean showError;
	private String mensajeError;
	private boolean hasChange;
	private String initState;
	private String genericValor;
	private String tipoAsString;
	
	
	public WrapperConfigurationUtilsVo(){
	
	}

	
	
	public WrapperConfigurationUtilsVo(ConfigurationUtilsVo configurationUtilsVo) {
		super();
		genericValor=configurationUtilsVo.getValor();
		this.configurationUtilsVo = configurationUtilsVo;
		initState=bitacoraSoxBusiness.objectToXML(configurationUtilsVo);
		tipoAsString=configurationUtilsVo.getIdTipo()+"";
	}



	public ConfigurationUtilsVo getConfigurationUtilsVo() {
		genericValor=configurationUtilsVo.getValor();
		return configurationUtilsVo;
	}

	public void setConfigurationUtilsVo(ConfigurationUtilsVo configurationUtilsVo) {
		this.configurationUtilsVo = configurationUtilsVo;
	}



	public boolean isShowError() {
		return showError;
	}



	public void setShowError(boolean showError) {
		this.showError = showError;
	}



	public String getMensajeError() {
		return mensajeError;
	}



	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}



	public boolean isHasChange() {
		return hasChange;
	}



	public void setHasChange(boolean hasChange) {
		this.hasChange = hasChange;
	}



	public String getInitState() {
		return initState;
	}



	public void setInitState(String initState) {
		this.initState = initState;
	}



	public String getGenericValor() {
		return genericValor;
	}



	public void setGenericValor(String genericValor) {
		configurationUtilsVo.setValor(genericValor);
		this.genericValor = genericValor;
	}



	public String getTipoAsString() {
		return tipoAsString;
	}



	public void setTipoAsString(String tipoAsString) {
		this.tipoAsString = tipoAsString;
	}

	
	
		
	
}

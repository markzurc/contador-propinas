package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.IBitacoraSoxBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.vo.BitacoraSoxVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service("lazyBitacoraSoxVoModel")
public class LazyBitacoraSoxVoModel extends LazyDataModel<BitacoraSoxVo> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1192457300791809243L;
	private Integer idCurrentUser;
	private static final Logger logger = LogManager.getLogger(LazyBitacoraSoxVoModel.class);
	
	public LazyBitacoraSoxVoModel() {
		super();
	}
	
	public LazyBitacoraSoxVoModel(Integer idCurrentUser) {
		super();
		this.idCurrentUser=idCurrentUser;
	}

	@Autowired
	@Qualifier("bitacoraSox")
	private IBitacoraSoxBusiness bitacoraSoxBusiness;
	
	 
	@Override
	public Object getRowKey(BitacoraSoxVo car) {
		return car.getIdUsuario();
	}
	
	@Override
    public List<BitacoraSoxVo> load(int first, int pageSize, String sortField, SortOrder sortOrder, Map<String,Object> filters)  {
        List<BitacoraSoxVo> dataFault = new ArrayList<BitacoraSoxVo>();
        int dataSize;
        try {
        	dataSize=bitacoraSoxBusiness.getNumberOfElements(idCurrentUser);
        	 this.setRowCount(dataSize);
        if(dataSize > pageSize) {
                return bitacoraSoxBusiness.getContentPage(idCurrentUser, pageSize, (first / pageSize)+1);
        }else{
        	return bitacoraSoxBusiness.getContentPage(idCurrentUser,pageSize,1);
        }
        
        } catch (TransactionalOVITException e1) {
        	logger.error("Error al ejecutar load " + e1);
        	logger.error(e1.getMessageError());
		}
        
        return dataFault;
    }

	public Integer getIdCurrentUser() {
		return idCurrentUser;
	}

	public void setIdCurrentUser(Integer idCurrentUser) {
		this.idCurrentUser = idCurrentUser;
	}
	
}

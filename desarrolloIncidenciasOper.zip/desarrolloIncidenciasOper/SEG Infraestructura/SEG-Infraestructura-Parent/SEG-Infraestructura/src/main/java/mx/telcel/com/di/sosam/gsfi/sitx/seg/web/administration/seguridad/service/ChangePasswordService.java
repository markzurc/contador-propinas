package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.seguridad.service;

import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.STATUS_ACTIVO;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.STATUS_EXPIRADO;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.STATUS_NUEVO;
import static mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants.STATUS_REINICIADO;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.IBitacoraSoxBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.IUserBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.BitacoraSeguridadUtil;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.CommonAction;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.WrapperConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.user.service.UserCatalogService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.bean.MenuBean;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service("changePasswordService")
public class ChangePasswordService implements Serializable{

	private static final long serialVersionUID = 6787145618586555818L;
	private static final Map<Integer,String> ESTATUS_RESET;
	private static final Logger logger = LogManager.getLogger(ChangePasswordService.class);
	
	static{
		ESTATUS_RESET= new HashMap<Integer,String>();
		ESTATUS_RESET.put(STATUS_NUEVO, "nuevo");
		ESTATUS_RESET.put(STATUS_REINICIADO, "reiniciado");
		ESTATUS_RESET.put(STATUS_EXPIRADO, "expirado");
	}
	

	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;
	
	@Autowired
	@Qualifier("userBusiness")
	private IUserBusiness userBusinessImpl;
	
	
	@Autowired
	@Qualifier("bitacoraSeguridadUtil")
	private BitacoraSeguridadUtil bitacoraSeguridadUtil;
	
	@Autowired
	@Qualifier("menuBean")
	private MenuBean menuBean;
	
	@Autowired
	@Qualifier("userCatalogService")
	private UserCatalogService userCatalogService;
	
	
	private Integer numeroChars;
	private String palabrasReservadas;
	private String regex;
	private String regexDescription;
	private Integer numeroPassOld;
	private boolean renderBotonRegresa;
	
	
	public boolean validaLongitudPassword(String password){
		if(password.length() > 30 || password.length() < 8)
			return false;
		else 
			return true;
	}
	
	public boolean containsReservedWords(String password){
		boolean result=false;
		String[] reservedWords= palabrasReservadas.split(",");
		
		for(int x=0;x<reservedWords.length;x++){
			if(password.toUpperCase().contains(reservedWords[x].toUpperCase())){
				result=true; 
			}
		}
		return result;
	}

	
	public boolean matchRegexp(String password){
		   return password.matches(regex);
	}
	
	public boolean initValues(){
		
		try{
		ConfigurationUtilsVo configurationUtilsVo;
		
		configurationUtilsVo = configurationUtilsBusiness.
				getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.NUM_CHAR_PASSWORD);
		String numeroC=configurationUtilsVo.getValor();
		numeroChars=Integer.parseInt(numeroC);
		
		configurationUtilsVo = configurationUtilsBusiness.
				getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.RESERVED_WORDS_PASSWORD);
		palabrasReservadas=configurationUtilsVo.getValor();
		
		configurationUtilsVo = configurationUtilsBusiness.
				getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.REGX_PASSWORD);
		regex=configurationUtilsVo.getValor();
		 
		configurationUtilsVo = configurationUtilsBusiness.
				getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.REGX_DESCRIPTION);
		regexDescription=configurationUtilsVo.getValor();
		
		
		configurationUtilsVo = configurationUtilsBusiness.
				getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.NUM_PASS_NOT_REUSABLE);
		numeroC=configurationUtilsVo.getValor();
		numeroPassOld=Integer.parseInt(numeroC);
		
		 
		}catch(Exception e){
			logger.error("Error al ejecutar ChangePasswordService.initValues: " + e);
			return false;		
		}
				 
		return true;		 
				 
	}
	
	
	public int  validateLogIn(int userId,String password,String mewPassword) throws TransactionalOVITException{
		return userBusinessImpl.validatePassword(userId,password,mewPassword);
	}
	     
	public int  changePassword(int userId,String password){
		int result=0;//ok
		try {
			result=userBusinessImpl.updatePassword(userId,password, IUserBusiness.STATUS_ACTIVE);
//			if(result==0){
//			   bitacoraSeguridadUtil.registraEntradaBitacora("", new CommonAction("Cambio password"), "",IBitacoraSoxBusiness.UPDATE);
//			}
			
		} catch (TransactionalOVITException e) {
			logger.error("Error al ejecutar ChangePasswordService.changePassword: " + e);
			return 3;
		}
		return result;
	}
	
	
	public boolean isRequiredChangePass() {
		boolean changeFlag=true;
		UserDetailsVo userDetailsVo =(UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		boolean isRequired=true;
		
		boolean validacion = userCatalogService.requiereCambioPass(userDetailsVo.getIdRol().toString());
		if (validacion) {
			try {

				ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness
						.getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.FLAG_CHANGE_PASS);
				changeFlag = Boolean.parseBoolean(configurationUtilsVo.getValor());
			} catch (TransactionalOVITException toe) {
				changeFlag = true;
			}

			if (!changeFlag && isEstatusReset(userDetailsVo.getIdEstatus())) {
				try {
					userBusinessImpl.updateStatus(userDetailsVo.getIdUsuario(), STATUS_ACTIVO);
					userDetailsVo.setIdEstatus(STATUS_ACTIVO);
					isRequired = false;
				} catch (TransactionalOVITException toe) {
					logger.error("Error al ejecutar ChangePasswordService.isRequiredChangePass: " + toe);
					changeFlag = true;
				}
			} else if (changeFlag && isEstatusReset(userDetailsVo.getIdEstatus())) {
				isRequired = true;
			} else {
				isRequired = false;
			}

			renderBotonRegresa = isRequired;

			return isRequired;
		} else {
			return false;
		}
		
	}
	
	private boolean isEstatusReset(Integer idEstatus){
		return ESTATUS_RESET.containsKey(idEstatus);
	}
	
	public boolean saveParameter(WrapperConfigurationUtilsVo wrapperConfigurationUtilsVo){
		try {
			configurationUtilsBusiness.updateConfiguration(wrapperConfigurationUtilsVo.getConfigurationUtilsVo());
			return true;
		} catch (TransactionalOVITException e) {
			logger.error("Error al ejecutar ChangePasswordService.saveParameter: " + e);
			return false;
		}
	}
	
	/**
     * Metodo que determina si existe una redireccion de vista
     * @return 
     */
    public boolean esRedireccion(){
        UserDetailsVo userDetailsVo = (UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if(userDetailsVo.getVistaRedireccion().contains("idSolicitud")){
        	return true;
        } else {
        	return false;
        }
    }
    
	public Integer getNumeroChars() {
		return numeroChars;
	}

	public void setNumeroChars(Integer numeroChars) {
		this.numeroChars = numeroChars;
	}

	public String getPalabrasReservadas() {
		return palabrasReservadas;
	}

	public void setPalabrasReservadas(String palabrasReservadas) {
		this.palabrasReservadas = palabrasReservadas;
	}

	public String getRegex() {
		return regex;
	}

	public void setRegex(String regex) {
		this.regex = regex;
	}

	public String getRegexDescription() {
		return regexDescription;
	}

	public void setRegexDescription(String regexDescription) {
		this.regexDescription = regexDescription;
	}

	public Integer getNumeroPassOld() {
		return numeroPassOld;
	}

	public void setNumeroPassOld(Integer numeroPassOld) {
		this.numeroPassOld = numeroPassOld;
	}

	public boolean isRenderBotonRegresa() {
		return renderBotonRegresa;
	}

	public void setRenderBotonRegresa(boolean renderBotonRegresa) {
		this.renderBotonRegresa = renderBotonRegresa;
	}
	
}

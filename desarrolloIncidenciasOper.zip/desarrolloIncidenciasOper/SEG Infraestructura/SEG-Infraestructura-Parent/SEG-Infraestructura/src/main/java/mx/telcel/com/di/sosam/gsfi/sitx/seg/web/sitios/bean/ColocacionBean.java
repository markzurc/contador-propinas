package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.sitios.bean;

import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletResponse;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.elementosPantalla.IElementosPantallaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.proyecto.IProyectoPresupuestoService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.IColocacionService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.IFactibilidadService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.ISuscripcionSitioService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ElementosPantallaDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegdSoliArch;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.AntenaDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ColocacionTablaEspacioPisoDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ColocacionTablaEspacioTorreDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ProgramaColocacionDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SoliArchDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SolicitudDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.VerificacionColocacionDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util.ValidacionUtil;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.objetos.ColocacionTablaProgramaColocacionDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.objetos.TablaProgramaColocacionSortDTO;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;

@Controller("colocacionBean")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class ColocacionBean implements Serializable, Comparator<TablaProgramaColocacionSortDTO> {

	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;
	@Autowired
	private IColocacionService colocacionService;
	@Autowired
	private IFactibilidadService factibilidadService;
	@Autowired
	private IElementosPantallaService elementosPantallaService;
	@Autowired
	private DetalleSolicitudBean detalleSolicitudBean;
	@Autowired
	private IProyectoPresupuestoService proyectoService;
	@Autowired
	private DetalleSitioBean detalleSitioBean;

	@Autowired(required = false)
	private ISuscripcionSitioService suscripcionSitioService;

	private static final long serialVersionUID = -8715496866982916388L;
	private static final Logger LOGGER = LogManager.getLogger(ColocacionBean.class);
	private static final String SOLICITUD_CANCELADA = "3", SOLICITUD_FACTIBILIDAD_AUTORIZADA = "16",
			SOLICITUD_VISITA_TECNICA_AUTORIZADA = "20", SOLICITUD_COLOCACION_GENERADA = "21",
			SOLICITUD_COLOCACION_RECHAZADA = "22", SOLICITUD_COLOCACION_CORREGIDA = "23",
			SOLICITUD_COLOCACION_AUTORIZADA = "24", SOLICITUD_COLOCACION_ACUERDO_SITIO_FIRMADO = "30",
			SOLICITUD_PROGRAMA_COLOCACION_GENERADO = "31";
	private static final String ACCION_CANCELAR_SOLICITIUD = "3", ACCION_RECHAZAR_SOLICITUD = "7",
			ACCION_SOLICITAR_COLOCACION = "14", ACCION_SOLICITAR_VERIFICACION = "15", ACCION_CARGAR_ACUERDO = "16",
			ACCION_CARGAR_ACUERDO_FIRMADO = "18";
	private String valor = "", fechaActualCadena = "", observaciones, observacionesTelcel, RFcalibre, MWcalibre,
			superficie, transformador, observacionesVerificacionColocacion, areaUtilizadaPiso, espacioLineal,
			revisionEquiposPiso, revisionEquiposTorre, stringMotivoRechazo;
	private SimpleDateFormat formatoFechaUno;
	private Date fechaActual;
	private List<ColocacionTablaEspacioTorreDTO> listaEspacioEnTorre, listaEspacioEnTorreRespaldoEdicion;
	private List<ColocacionTablaEspacioPisoDTO> listaEspacioEnPiso, listaEspacioEnPisoRespaldoEdicion;
	private List<ColocacionTablaProgramaColocacionDTO> listaProgramaColocacion, listaSemanas;
	private List<FileUploadEvent> listaArchivoEvento;
	private List<FileUploadEvent> listaArchivoEventoVerificarColocacion;
	private List<FileUploadEvent> listaArchivosVcFactEvento;
	private List<SoliArchDto> listaArchivosTabla, listaArchivosTablaRespaldoEdicion;
	private List<SoliArchDto> listaArchivosTablaVerificarColocacion, listaArchivosTablaVerificarColocacionEdicion;
	private List<SoliArchDto> listaArchivosVcFact;
	private SoliArchDto archivoFact;
	ColocacionTablaEspacioTorreDTO altaEspacioTorre, leyendasAltaEspacioTorre, editarEspacioTorre,
			leyendasEditarEspacioTorre;
	ColocacionTablaEspacioPisoDTO altaEspacioPiso, editarEspacioEnPiso;
	ColocacionTablaProgramaColocacionDTO altaTablaProgramaCol, editarTablaProgramaCol;
	private String dimensionAlterRF1, dimensionAlterRF2, dimensionAlterEditRF1, dimensionAlterEditRF2;
	private String headerDialogo;
	private String mensajeDialogo;
	private boolean indicadorDimRF, indicadorEditDimRF, indicadorDimMW, indicadorEditDimMW;
	private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
	private SimpleDateFormat dateFormatTime = new SimpleDateFormat("dd/MM/yyyy hh:mm aa");
	private SolicitudDto solicitudDto;
	private UserDetailsVo userDetailsVo;
	private List<ElementosPantallaDTO> elementosPantalla;
	private List<VerificacionColocacionDto> listaVerificacion;
	private boolean renderSolicitudColocacion;
	private DefaultStreamedContent archivoDescarga;
	private List<TablaProgramaColocacionSortDTO> listO;

	private String seleccionadoSemana;
	private String actividad;
	private String tabActivity;
	private List<String> listaEquiposEnPiso;
	private List<String> listaEquiposEnTorre;
	private String selectEquiposPiso;
	private String selectEquiposTorre;
	private String fechaI;
	private String fechaF;
	private String motivoVc;
	private static boolean ordenFechas;
	private static List<String> duplicates;
	private List<AntenaDto> listAntenas;
	private String idFactibilidad;
	private List<String> listaErrores;

	public void cargaInicial(org.springframework.webflow.execution.RequestContext rc) {
		FacesContext context = FacesContext.getCurrentInstance();
		userDetailsVo = (UserDetailsVo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		String estado;
		String estatus_rol_colocacion;
		// Solicitud colocacion
		listaEspacioEnTorre = new ArrayList<>();
		listaEspacioEnPiso = new ArrayList<>();
		altaEspacioTorre = new ColocacionTablaEspacioTorreDTO();
		altaEspacioPiso = new ColocacionTablaEspacioPisoDTO();
		listaArchivoEvento = new ArrayList<>();
		listaArchivosTabla = new ArrayList<>();
		listaEspacioEnPisoRespaldoEdicion = new ArrayList<>();
		observaciones = "";
		stringMotivoRechazo = "";
		observacionesTelcel = "";
		RFcalibre = "";
		MWcalibre = "";
		superficie = "";
		transformador = "";
		leyendasRF();
		// Programa colocacion
		listO = new ArrayList<>();
		fechaActual = new Date();
		formatoFechaUno = new SimpleDateFormat("dd/MM/yyyy");
		fechaActualCadena = formatoFechaUno.format(fechaActual);
		editarTablaProgramaCol = new ColocacionTablaProgramaColocacionDTO();
		altaTablaProgramaCol = new ColocacionTablaProgramaColocacionDTO();
		listaProgramaColocacion = new ArrayList<>();
		listaSemanas = new ArrayList<>();
		listaSemanas = calculaSemanas();
		seleccionadoSemana = "";
		actividad = "";
		ordenFechas = false;
		duplicates = new ArrayList<>();
		// Verificacion colocacion
		listaArchivosTabla = new ArrayList<>();
		listaArchivoEventoVerificarColocacion = new ArrayList<>();
		listaArchivosTablaVerificarColocacion = new ArrayList<>();
		listaArchivosVcFactEvento = new ArrayList<>();
		listaArchivosVcFact = new ArrayList<>();
		listaEquiposEnPiso = new ArrayList<>();
		listaEquiposEnPiso.add("Si");
		listaEquiposEnTorre = new ArrayList<>();
		listaEquiposEnTorre.add("Si");
		observacionesVerificacionColocacion = "";
		areaUtilizadaPiso = "";
		espacioLineal = "";
		revisionEquiposPiso = "";
		revisionEquiposTorre = "";
		motivoVc = "";
		listAntenas = new ArrayList<>();

		try {
			valor = "Solicitud de Colocacion";
			System.out.println("Entro pantalla SolicitudColocacionBean");

			if (solicitudDto == null) {
				estado = "0";
				estatus_rol_colocacion = userDetailsVo.getIdRol() + "0";
			} else {
				estado = solicitudDto.getIdEstado();
				estatus_rol_colocacion = userDetailsVo.getIdRol() + solicitudDto.getIdEstado();
			}

			HashMap<String, Integer> validar = new HashMap<>();
			validar.put("estatus_rol_colocacion", Integer.parseInt(estatus_rol_colocacion));
			elementosPantalla = elementosPantallaService.getElementosPermitidosPantalla("colocacion",
					userDetailsVo.getIdRol(), validar);

			if (solicitudDto != null) {
				idFactibilidad = factibilidadService.getFactiPorFolio(solicitudDto.getFolio());
				listAntenas = factibilidadService.getAntenas(idFactibilidad);
				String existenciaSolCol = colocacionService
						.consultaExistenciaSolicitudColocacion(solicitudDto.getFolio());

				int countBitacora = colocacionService.consultaEstadoBitacora(solicitudDto.getFolio(),
						"SOLICITUD DE ADECUACION RECUPERACION ACUERDO SITIO GENERADO");
				tabActivity = "0";
				if (countBitacora > 0) {
					// ocultar el tab de solicitud de colocacion
					renderSolicitudColocacion = true;

					// solicitud e progarma
					programaColocacion();

					if (colocacionService.consultaEstadoBitacora(solicitudDto.getFolio(),
							"SOLICITUD PROGRAMA DE COLOCACION COMPLETADO") > 0) {
						tabActivity = "1";
						// validar exitencia de verificacion
						verificacionColocacion();
					}

				} else {

					// mostrar el tab de solicitud colocacion
					if (getEditable("tabSolicitudColocacion")) {
						renderSolicitudColocacion = false;
					} else {
						renderSolicitudColocacion = false;
					}
					// solicitud de colocacion
					solicitudColocacion(existenciaSolCol);

					if (colocacionService.consultaEstadoBitacora(solicitudDto.getFolio(),
							"SOLICITUD DE COLOCACION ACUERDO SITIO FIRMADO") > 0) {
						tabActivity = colocacionService.consultaEstadoBitacora(solicitudDto.getFolio(),
								"SOLICITUD PROGRAMA DE COLOCACION COMPLETADO") > 0 ? "2" : "1";
						// solicitud e progarma
						programaColocacion();
						verificacionColocacion();
					} else if (colocacionService.consultaEstadoBitacora(solicitudDto.getFolio(),
							"SOLICITUD PROGRAMA DE COLOCACION COMPLETADO") > 0) {
						tabActivity = "2";
						// validar exitencia de verificacion
						verificacionColocacion();
					}

				}
				if (colocacionService.consultaEstadoBitacora(solicitudDto.getFolio(), "SOLICITUD FINALIZADA") > 0) {
					tabActivity = "0";
				}
			}
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al cargar la p�gina");
			context.addMessage("mensajes",
					new FacesMessage(SEVERITY_ERROR, "Error", "Ocurrio un error al cargar la p�gina"));
		}

	}

	public void solicitudColocacion(String existenciaSolCol) {
		// solicitud
		listaEspacioEnTorre = new ArrayList<>();
		listaEspacioEnPiso = new ArrayList<>();
		altaEspacioTorre = new ColocacionTablaEspacioTorreDTO();
		altaEspacioPiso = new ColocacionTablaEspacioPisoDTO();
		listaArchivoEvento = new ArrayList<>();
		listaArchivosTabla = new ArrayList<>();
		listaEspacioEnPisoRespaldoEdicion = new ArrayList<>();
		observaciones = "";
		stringMotivoRechazo = "";
		observacionesTelcel = "";
		RFcalibre = "";
		MWcalibre = "";
		superficie = "";
		transformador = "";
		leyendasRF();

		listaArchivosTabla = colocacionService.obtenerArchivoEnTabla(solicitudDto.getFolio(),
				"/orbi/SEG/Solicitudes/" + solicitudDto.getFolio() + "/21");
		listaEspacioEnPisoRespaldoEdicion = colocacionService.obtenerEspacioPiso(solicitudDto.getFolio());
		listaEspacioEnPiso = colocacionService.obtenerEspacioPiso(solicitudDto.getFolio());
		listaEspacioEnTorre = colocacionService.obtenerEspacioTorre(solicitudDto.getFolio());

		if (Integer.parseInt(existenciaSolCol) > 0) {
			try {
				listaEspacioEnTorre = colocacionService.obtenerEspacioTorre(solicitudDto.getFolio());
				String allObjects = colocacionService.obtenerDatosSolicitudColocacion(solicitudDto.getFolio());
				String[] arregloInicial = allObjects.split("~");
				RFcalibre = arregloInicial[1];
				MWcalibre = arregloInicial[2];
				superficie = arregloInicial[3];
				transformador = arregloInicial[4];
				observaciones = arregloInicial[5];
				observacionesTelcel = arregloInicial[6];
			} catch (Exception e) {
				System.err.println("ColocacionBean:Error de inicio controlado: " + e);
			}
		} else {
			int conta1 = 1;
			int conta2 = 1;
			for (AntenaDto antena : listAntenas) {
				ColocacionTablaEspacioTorreDTO colo = new ColocacionTablaEspacioTorreDTO();
				if (antena.getTipo().contains("RF")) {
					colo.setTipoAntena(antena.getTipo().substring(0, antena.getTipo().length() - 2) + conta1
							+ antena.getTipo().substring(antena.getTipo().length() - 3));
					conta1++;
				} else {
					colo.setTipoAntena(antena.getTipo().substring(0, antena.getTipo().length() - 2) + conta2
							+ antena.getTipo().substring(antena.getTipo().length() - 3));
					conta2++;
				}
				colo.setDimensiones(antena.getDimenciones() + " CM");
				colo.setPeso(antena.getPeso() + " KG");
				listaEspacioEnTorre.add(colo);
			}
		}
	}

	public void programaColocacion() {
		// programa
		fechaActual = new Date();
		formatoFechaUno = new SimpleDateFormat("dd/MM/yyyy");
		fechaActualCadena = formatoFechaUno.format(fechaActual);
		editarTablaProgramaCol = new ColocacionTablaProgramaColocacionDTO();
		altaTablaProgramaCol = new ColocacionTablaProgramaColocacionDTO();
		listaProgramaColocacion = new ArrayList<>();
		listaSemanas = new ArrayList<>();
		listaSemanas = calculaSemanas();
		seleccionadoSemana = "";
		actividad = "";

		// Pantalla Programacion Colocacion
		// listaSemanas = calculaSemanas();
		if (!listaSemanas.isEmpty()) {

			altaTablaProgramaCol = new ColocacionTablaProgramaColocacionDTO();
			editarTablaProgramaCol = new ColocacionTablaProgramaColocacionDTO();
			List<ProgramaColocacionDto> listP = colocacionService.obtenerProgramaColocacion(solicitudDto.getFolio());
			if (!listP.isEmpty()) {
				for (ProgramaColocacionDto listaPrograma : listP) {
					ColocacionTablaProgramaColocacionDTO tabla = new ColocacionTablaProgramaColocacionDTO();
					tabla.setActividad(listaPrograma.getActividad());
					tabla.setFinalProgramado(listaPrograma.getFechaFinalProgramada());
					tabla.setFinalReal(listaPrograma.getFechaFinalProgramada());
					tabla.setInicioProgramado(listaPrograma.getFechaInicioProgramada());
					tabla.setInicioReal(listaPrograma.getFechaInicioProgramada());
					tabla.setSemana(listaPrograma.getSemana());
					listaProgramaColocacion.add(tabla);
				}
			}
		}

	}

	public void verificacionColocacion() {

		listaArchivoEventoVerificarColocacion = new ArrayList<>();
		listaArchivosTablaVerificarColocacion = new ArrayList<>();
		listaArchivosVcFactEvento = new ArrayList<>();
		listaArchivosVcFact = new ArrayList<>();
		listaEquiposEnPiso = new ArrayList<>();
		listaEquiposEnPiso.add("Si");
		listaEquiposEnTorre = new ArrayList<>();
		listaEquiposEnTorre.add("Si");
		observacionesVerificacionColocacion = "";
		areaUtilizadaPiso = "";
		espacioLineal = "";
		revisionEquiposPiso = "";
		revisionEquiposTorre = "";

		listaVerificacion = colocacionService.consultaListaVerificacion(solicitudDto.getFolio());
		if (!listaVerificacion.isEmpty()) {
			listaArchivosTablaVerificarColocacion = colocacionService.obtenerArchivoEnTabla(solicitudDto.getFolio(),
					"/orbi/SEG/Solicitudes/" + solicitudDto.getFolio() + "/26");
			listaArchivosVcFact = proyectoService.getArchivos(solicitudDto.getFolio(), "Facturacion Colocacion");
			listaArchivosVcFactEvento = new ArrayList<>();
			areaUtilizadaPiso = listaVerificacion.get(0).getAreaPiso() != null ? listaVerificacion.get(0).getAreaPiso()
					: "";
			espacioLineal = listaVerificacion.get(0).getEspacioLineal() != null
					? listaVerificacion.get(0).getEspacioLineal()
					: "";
			observacionesVerificacionColocacion = listaVerificacion.get(0).getObservacionesVerificacion() != null
					? listaVerificacion.get(0).getObservacionesVerificacion()
					: "";
			revisionEquiposPiso = listaVerificacion.get(0).getRevisionPiso() != null
					? listaVerificacion.get(0).getRevisionPiso()
					: "";
			revisionEquiposTorre = listaVerificacion.get(0).getRevisionTorre() != null
					? listaVerificacion.get(0).getRevisionTorre()
					: "";
		}
	}

	private void consultaDatosSolicitudColocacion(String folio) {
		fechaActual = new Date();
		formatoFechaUno = new SimpleDateFormat("dd/MM/yyyy");
		fechaActualCadena = formatoFechaUno.format(fechaActual);
		RFcalibre = "";
		MWcalibre = "";
		superficie = "";
		transformador = "";
		observaciones = "";
		observacionesTelcel = "";
		listaArchivoEvento = new ArrayList<>();
		listaArchivosTabla = new ArrayList<>();
		listaEspacioEnPiso = new ArrayList<>();
		listaEspacioEnTorre = new ArrayList<>();
		listaEspacioEnTorreRespaldoEdicion = new ArrayList<>();
		listaEspacioEnPisoRespaldoEdicion = new ArrayList<>();
		listaArchivosTablaRespaldoEdicion = new ArrayList<>();
		listaArchivosTablaVerificarColocacionEdicion = new ArrayList<>();
		altaEspacioTorre = new ColocacionTablaEspacioTorreDTO();
		altaEspacioPiso = new ColocacionTablaEspacioPisoDTO();
		leyendasRF();
		listaArchivosTabla = colocacionService.obtenerArchivoEnTabla(folio, "/orbi/SEG/Solicitudes/" + folio + "/21");
		listaEspacioEnPisoRespaldoEdicion = colocacionService.obtenerEspacioPiso(folio);
		listaEspacioEnPiso = colocacionService.obtenerEspacioPiso(folio);
		listaEspacioEnTorre = colocacionService.obtenerEspacioTorre(folio);
		try {
			String allObjects = colocacionService.obtenerDatosSolicitudColocacion(folio);
			String[] arregloInicial = allObjects.split("~");
			RFcalibre = arregloInicial[1];
			MWcalibre = arregloInicial[2];
			superficie = arregloInicial[3];
			transformador = arregloInicial[4];
			observaciones = arregloInicial[5];
			observacionesTelcel = arregloInicial[6];
		} catch (Exception e) {
			System.err.println("Inicializacion entra en error controlado, se continua normal: " + e);
		}

		// Pantalla Programacion Colocacion
		seleccionadoSemana = "";
		actividad = "";
		listaProgramaColocacion = new ArrayList<>();
		listaSemanas = new ArrayList<>();
		listaSemanas = calculaSemanas();
		altaTablaProgramaCol = new ColocacionTablaProgramaColocacionDTO();
		editarTablaProgramaCol = new ColocacionTablaProgramaColocacionDTO();
		List<ProgramaColocacionDto> listP = colocacionService.obtenerProgramaColocacion(folio);
		for (ProgramaColocacionDto listaPrograma : listP) {
			ColocacionTablaProgramaColocacionDTO tabla = new ColocacionTablaProgramaColocacionDTO();
			tabla.setActividad(listaPrograma.getActividad());
			tabla.setFinalProgramado(listaPrograma.getFechaFinalProgramada());
			tabla.setFinalReal(listaPrograma.getFechaFinalProgramada());
			tabla.setInicioProgramado(listaPrograma.getFechaInicioProgramada());
			tabla.setInicioReal(listaPrograma.getFechaInicioProgramada());
			tabla.setSemana(listaPrograma.getSemana());
			listaProgramaColocacion.add(tabla);
		}

		// Pantalla Verificacion Colocacion
		observacionesVerificacionColocacion = "";
		areaUtilizadaPiso = "";
		espacioLineal = "";
		revisionEquiposPiso = "";
		revisionEquiposTorre = "";
		listaArchivoEventoVerificarColocacion = new ArrayList<>();
		listaArchivosTablaVerificarColocacion = new ArrayList<>();
	}

	private void edicionSolicitudColocacionArchivos() {
		List<SoliArchDto> listaArchivosSolicitudColocacionActualizar = new ArrayList<>(),
				listaArchivosSolicitudColocacionInsertar = new ArrayList<>(),
				listaArchivosSolicitudColocacionEliminar = new ArrayList<>();
		listaArchivosTablaRespaldoEdicion = colocacionService.obtenerArchivoEnTabla(solicitudDto.getFolio(),
				"/orbi/SEG/Solicitudes/" + solicitudDto.getFolio() + "/21");
		int contadorListaActual = 0;
		for (SoliArchDto t : listaArchivosTabla) {
			int contadorListaAntigua = 0, existencia = 0;
			for (SoliArchDto m : listaArchivosTablaRespaldoEdicion) {
				if (t.getNombreArch().equals(m.getNombreArch())) {
					existencia = 1;
					if (t.getDescripcion().equals(m.getDescripcion())) {
						if (t.getTamanio().equals(m.getTamanio())) {

						} else {
							listaArchivosSolicitudColocacionActualizar.add(listaArchivosTabla.get(contadorListaActual));
						}
					} else {
						listaArchivosSolicitudColocacionActualizar.add(listaArchivosTabla.get(contadorListaActual));
					}
				}
				contadorListaAntigua++;
			}
			if (existencia == 0) {
				listaArchivosSolicitudColocacionInsertar.add(listaArchivosTabla.get(contadorListaActual));
			}
			contadorListaActual++;
		}

		int contadorListaAntigua = 0;
		for (SoliArchDto m : listaArchivosTablaRespaldoEdicion) {
			int existencia = 0;
			for (SoliArchDto t : listaArchivosTabla) {
				if (t.getNombreArch().equals(m.getNombreArch())) {
					existencia = 1;
				}
			}
			if (existencia == 0) {
				listaArchivosSolicitudColocacionEliminar
						.add(listaArchivosTablaRespaldoEdicion.get(contadorListaAntigua));
			}
			contadorListaAntigua++;
		}

		for (SoliArchDto k : listaArchivosSolicitudColocacionActualizar) {
			System.out.println("ACTUALIZAR: " + k.getNombreArch() + "|" + k.getDescripcion() + "|" + k.getTamanio());
		}
		for (SoliArchDto k : listaArchivosSolicitudColocacionInsertar) {
			System.out.println("INSERTAR: " + k.getNombreArch() + "|" + k.getDescripcion() + "|" + k.getTamanio());
		}
		for (SoliArchDto k : listaArchivosSolicitudColocacionEliminar) {
			System.out.println("ELIMINAR: " + k.getNombreArch() + "|" + k.getDescripcion() + "|" + k.getTamanio());
		}

		String rutaBase = "";
		try {
			ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness
					.getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_INF);
			rutaBase = String.valueOf(configurationUtilsVo.getValor());
		} catch (TransactionalOVITException e) {
			rutaBase = "";
		}
		rutaBase = rutaBase + solicitudDto.getFolio() + "/21";

		if (!listaArchivosSolicitudColocacionInsertar.isEmpty()) {
			insertaArchivoEnTabla(solicitudDto.getFolio(), rutaBase, listaArchivosSolicitudColocacionInsertar);
			for (SoliArchDto t : listaArchivosSolicitudColocacionInsertar) {
				for (FileUploadEvent h : listaArchivoEvento) {
					if (t.getNombreArch().equals(h.getFile().getFileName())) {
						try {
							File directorioTemp = new File(rutaBase);
							if (!directorioTemp.exists()) {
								directorioTemp.mkdirs();
							}
							String nombreArchivo = FilenameUtils.getName(h.getFile().getFileName());
							OutputStream out;
							try (InputStream in = h.getFile().getInputstream()) {
								out = new FileOutputStream(directorioTemp + "/" + nombreArchivo);
								byte[] buf = new byte[1024];
								int len;
								while ((len = in.read(buf)) > 0) {
									out.write(buf, 0, len);
								}
								in.close();
							}
							out.close();
						} catch (IOException e) {
						}
					}
				}
			}
		}
		if (!listaArchivosSolicitudColocacionActualizar.isEmpty()) {
			colocacionService.actualizaArchivoEnTabla(solicitudDto.getFolio(), rutaBase,
					listaArchivosSolicitudColocacionActualizar);
			for (SoliArchDto h : listaArchivosSolicitudColocacionActualizar) {
				for (FileUploadEvent j : listaArchivoEvento) {
					try {
						File directorioTemp = new File(rutaBase);
						if (!directorioTemp.exists()) {
							directorioTemp.mkdirs();
						}
						File archivoFisico = new File(rutaBase + "/" + h.getNombreArch());
						if (archivoFisico.exists()) {
							archivoFisico.delete();
						}
						String nombreArchivo = FilenameUtils.getName(j.getFile().getFileName());
						OutputStream out;
						try (InputStream in = j.getFile().getInputstream()) {
							out = new FileOutputStream(directorioTemp + "/" + nombreArchivo);
							byte[] buf = new byte[1024];
							int len;
							while ((len = in.read(buf)) > 0) {
								out.write(buf, 0, len);
							}
							in.close();
						}
						out.close();
					} catch (IOException e) {
					}
				}
			}
		}

		if (!listaArchivosSolicitudColocacionEliminar.isEmpty()) {
			colocacionService.eliminaArchivoEnTabla(solicitudDto.getFolio(), listaArchivosSolicitudColocacionEliminar);
			for (SoliArchDto h : listaArchivosSolicitudColocacionEliminar) {
				File archivoFisico = new File(rutaBase + "/" + h.getNombreArch());
				if (archivoFisico.exists()) {
					archivoFisico.delete();
				}
			}
		}
	}

	private void edicionSolicitudColocacionEspacioTorre() {
		List<ColocacionTablaEspacioTorreDTO> listaEspacioTorreSolicitudColocacionActualizar = new ArrayList<>(),
				listaEspacioTorreSolicitudColocacionInsertar = new ArrayList<>(),
				listaEspacioTorreSolicitudColocacionEliminar = new ArrayList<>();
		listaEspacioEnTorreRespaldoEdicion = colocacionService.obtenerEspacioTorre(solicitudDto.getFolio());
		int contadorListaActual = 0;
		for (ColocacionTablaEspacioTorreDTO t : listaEspacioEnTorre) {
			int contadorListaAntigua = 0, existencia = 0;
			for (ColocacionTablaEspacioTorreDTO m : listaEspacioEnTorreRespaldoEdicion) {
				if (t.getTipoAntena().equals(m.getTipoAntena())) {
					existencia = 1;
					if (t.getOrientacion().equals(m.getOrientacion())) {
						if (t.getNcr().equals(m.getNcr())) {
							if (t.getDimensiones().equals(m.getDimensiones())) {
								if (t.getFrecuenciasRX().equals(m.getFrecuenciasRX())) {
									if (t.getFrecuenciasTX().equals(m.getFrecuenciasTX())) {
										if (t.getPeso().equals(m.getPeso())) {
										} else {
											listaEspacioTorreSolicitudColocacionActualizar
													.add(listaEspacioEnTorre.get(contadorListaActual));
										}
									} else {
										listaEspacioTorreSolicitudColocacionActualizar
												.add(listaEspacioEnTorre.get(contadorListaActual));
									}
								} else {
									listaEspacioTorreSolicitudColocacionActualizar
											.add(listaEspacioEnTorre.get(contadorListaActual));
								}
							} else {
								listaEspacioTorreSolicitudColocacionActualizar
										.add(listaEspacioEnTorre.get(contadorListaActual));
							}
						} else {
							listaEspacioTorreSolicitudColocacionActualizar
									.add(listaEspacioEnTorre.get(contadorListaActual));
						}
					} else {
						listaEspacioTorreSolicitudColocacionActualizar
								.add(listaEspacioEnTorre.get(contadorListaActual));
					}
				}
				contadorListaAntigua++;
			}
			if (existencia == 0) {
				listaEspacioTorreSolicitudColocacionInsertar.add(listaEspacioEnTorre.get(contadorListaActual));
			}
			contadorListaActual++;
		}

		int contadorListaAntigua = 0;
		for (ColocacionTablaEspacioTorreDTO m : listaEspacioEnTorreRespaldoEdicion) {
			int existencia = 0;
			for (ColocacionTablaEspacioTorreDTO t : listaEspacioEnTorre) {
				if (t.getTipoAntena().equals(m.getTipoAntena())) {
					existencia = 1;
				}
			}
			if (existencia == 0) {
				listaEspacioTorreSolicitudColocacionEliminar
						.add(listaEspacioEnTorreRespaldoEdicion.get(contadorListaAntigua));
			}
			contadorListaAntigua++;
		}

		for (ColocacionTablaEspacioTorreDTO k : listaEspacioTorreSolicitudColocacionActualizar) {
			System.out.println("ACTUALIZAR: " + k.getTipoAntena() + "|" + k.getOrientacion() + "|" + k.getNcr() + "|"
					+ k.getDimensiones() + "|" + k.getFrecuenciasRX() + "|" + k.getFrecuenciasTX() + "|" + k.getPeso());
		}
		for (ColocacionTablaEspacioTorreDTO k : listaEspacioTorreSolicitudColocacionInsertar) {
			System.out.println("INSERTAR: " + k.getTipoAntena() + "|" + k.getOrientacion() + "|" + k.getNcr() + "|"
					+ k.getDimensiones() + "|" + k.getFrecuenciasRX() + "|" + k.getFrecuenciasTX() + "|" + k.getPeso());
		}
		for (ColocacionTablaEspacioTorreDTO k : listaEspacioTorreSolicitudColocacionEliminar) {
			System.out.println("ELIMINAR: " + k.getTipoAntena() + "|" + k.getOrientacion() + "|" + k.getNcr() + "|"
					+ k.getDimensiones() + "|" + k.getFrecuenciasRX() + "|" + k.getFrecuenciasTX() + "|" + k.getPeso());
		}

		if (!listaEspacioTorreSolicitudColocacionInsertar.isEmpty()) {
			colocacionService.insertaSolicitudColocacionEspacioTorre(solicitudDto.getFolio(),
					listaEspacioTorreSolicitudColocacionInsertar);
		}
		if (!listaEspacioTorreSolicitudColocacionActualizar.isEmpty()) {
			colocacionService.actualizaSolicitudColocacionEspacioTorre(solicitudDto.getFolio(),
					listaEspacioTorreSolicitudColocacionActualizar);
		}
		if (!listaEspacioTorreSolicitudColocacionEliminar.isEmpty()) {
			colocacionService.eliminaSolicitudColocacionEspacioTorre(solicitudDto.getFolio(),
					listaEspacioTorreSolicitudColocacionEliminar);
		}
	}

	private void edicionSolicitudColocacionEspacioPiso() {
		List<ColocacionTablaEspacioPisoDTO> listaEspacioPisoSolicitudColocacionActualizar = new ArrayList<>(),
				listaEspacioPisoSolicitudColocacionInsertar = new ArrayList<>(),
				listaEspacioPisoSolicitudColocacionEliminar = new ArrayList<>();
		listaEspacioEnPisoRespaldoEdicion = colocacionService.obtenerEspacioPiso(solicitudDto.getFolio());
		int contadorListaActual = 0;
		for (ColocacionTablaEspacioPisoDTO t : listaEspacioEnPiso) {
			int contadorListaAntigua = 0, existencia = 0;
			for (ColocacionTablaEspacioPisoDTO m : listaEspacioEnPisoRespaldoEdicion) {
				if (t.getGabinete().equals(m.getGabinete())) {
					existencia = 1;
					if (t.getTecnologia().equals(m.getTecnologia())) {
						if (t.getSuperficie().equals(m.getSuperficie())) {
						} else {
							listaEspacioPisoSolicitudColocacionActualizar
									.add(listaEspacioEnPiso.get(contadorListaActual));
						}
					} else {
						listaEspacioPisoSolicitudColocacionActualizar.add(listaEspacioEnPiso.get(contadorListaActual));
					}
				}
				contadorListaAntigua++;
			}
			if (existencia == 0) {
				listaEspacioPisoSolicitudColocacionInsertar.add(listaEspacioEnPiso.get(contadorListaActual));
			}
			contadorListaActual++;
		}

		int contadorListaAntigua = 0;
		for (ColocacionTablaEspacioPisoDTO m : listaEspacioEnPisoRespaldoEdicion) {
			int existencia = 0;
			for (ColocacionTablaEspacioPisoDTO t : listaEspacioEnPiso) {
				if (t.getGabinete().equals(m.getGabinete())) {
					existencia = 1;
				}
			}
			if (existencia == 0) {
				listaEspacioPisoSolicitudColocacionEliminar
						.add(listaEspacioEnPisoRespaldoEdicion.get(contadorListaAntigua));
			}
			contadorListaAntigua++;
		}

		for (ColocacionTablaEspacioPisoDTO k : listaEspacioPisoSolicitudColocacionActualizar) {
			System.out.println("ACTUALIZAR: " + k.getGabinete() + "|" + k.getTecnologia() + "|" + k.getSuperficie());
		}
		for (ColocacionTablaEspacioPisoDTO k : listaEspacioPisoSolicitudColocacionInsertar) {
			System.out.println("INSERTAR: " + k.getGabinete() + "|" + k.getTecnologia() + "|" + k.getSuperficie());
		}
		for (ColocacionTablaEspacioPisoDTO k : listaEspacioPisoSolicitudColocacionEliminar) {
			System.out.println("ELIMINAR: " + k.getGabinete() + "|" + k.getTecnologia() + "|" + k.getSuperficie());
		}

		if (!listaEspacioPisoSolicitudColocacionInsertar.isEmpty()) {
			colocacionService.insertaSolicitudColocacionEspacioPiso(solicitudDto.getFolio(),
					listaEspacioPisoSolicitudColocacionInsertar);
		}
		if (!listaEspacioPisoSolicitudColocacionActualizar.isEmpty()) {
			colocacionService.actualizaSolicitudColocacionEspacioPiso(solicitudDto.getFolio(),
					listaEspacioPisoSolicitudColocacionActualizar);
		}
		if (!listaEspacioPisoSolicitudColocacionEliminar.isEmpty()) {
			colocacionService.eliminarSolicitudColocacionEspacioPiso(solicitudDto.getFolio(),
					listaEspacioPisoSolicitudColocacionEliminar);
		}
	}

	public void leyendasRF() {
		leyendasAltaEspacioTorre = new ColocacionTablaEspacioTorreDTO();
		if (null == altaEspacioTorre.getTipoAntena()) {
			leyendasAltaEspacioTorre.setTipoAntena("Tipo Antena: ");
			leyendasAltaEspacioTorre.setOrientacion("Orientacion (GDOS): ");
			leyendasAltaEspacioTorre.setNcr("NCR (MTS): ");
			leyendasAltaEspacioTorre.setDimensiones("Dimensiones (CM): ");
			leyendasAltaEspacioTorre.setFrecuenciasRX("Frecuencias RX (MHz): ");
			leyendasAltaEspacioTorre.setFrecuenciasTX("Frecuencias TX (MHz): ");
			leyendasAltaEspacioTorre.setPeso("Peso (KG): ");
			indicadorDimRF = true;
			indicadorEditDimRF = false;
			indicadorDimMW = false;
			indicadorEditDimMW = false;
			dimensionAlterRF1 = "";
			dimensionAlterEditRF1 = "";
			dimensionAlterRF2 = "";
			dimensionAlterEditRF2 = "";
		} else {
			switch (altaEspacioTorre.getTipoAntena()) {
			case "RF":
				leyendasAltaEspacioTorre.setTipoAntena("Tipo Antena: ");
				leyendasAltaEspacioTorre.setOrientacion("Orientacion (GDOS): ");
				leyendasAltaEspacioTorre.setNcr("NCR (MTS): ");
				leyendasAltaEspacioTorre.setDimensiones("Dimensiones (CM): ");
				leyendasAltaEspacioTorre.setFrecuenciasRX("Frecuencias RX (MHz): ");
				leyendasAltaEspacioTorre.setFrecuenciasTX("Frecuencias TX (MHz): ");
				leyendasAltaEspacioTorre.setPeso("Peso (KG): ");
				indicadorDimRF = true;
				indicadorDimMW = false;
				dimensionAlterRF1 = "";
				dimensionAlterRF2 = "";
				break;
			case "MW":
				leyendasAltaEspacioTorre.setTipoAntena("Tipo Antena: ");
				leyendasAltaEspacioTorre.setOrientacion("Orientacion (GDOS): ");
				leyendasAltaEspacioTorre.setNcr("NCR (MTS): ");
				leyendasAltaEspacioTorre.setDimensiones("Dimensiones (CM): ");
				leyendasAltaEspacioTorre.setFrecuenciasRX("Frecuencias RX (MHz): ");
				leyendasAltaEspacioTorre.setFrecuenciasTX("Frecuencias TX (GHz): ");
				leyendasAltaEspacioTorre.setPeso("Peso (KG): ");
				indicadorDimRF = false;
				indicadorDimMW = true;
				dimensionAlterRF1 = "";
				dimensionAlterRF2 = "";
				break;
			default:
				break;
			}
		}

		editarEspacioEnPiso = new ColocacionTablaEspacioPisoDTO();
		editarEspacioTorre = new ColocacionTablaEspacioTorreDTO();
	}

	public void cambiaTipoDocumentoSolCol(SoliArchDto o) {
		System.out.println(o.getDescripcion());
	}

	public void altaEspacioEnTorre() {
		if (altaEspacioTorre.getTipoAntena().equals("RF")) {
			if (validarCampo(altaEspacioTorre.getTipoAntena(), "Tipo de Antena")
					|| validarCampo(altaEspacioTorre.getOrientacion(), "Orientaci�n")
					|| validarCampo(altaEspacioTorre.getNcr(), "NCR(MTS)")
					|| validarCampo(altaEspacioTorre.getFrecuenciasRX(), "Frecuencia RX")
					|| validarCampo(altaEspacioTorre.getFrecuenciasTX(), "Frecuencia TX")
					|| validarCampo(altaEspacioTorre.getPeso(), "Peso")
					|| validarCampo(dimensionAlterRF1, "Dimensiones (Valor X Valor)")
					|| validarCampo(dimensionAlterRF2, "Dimensiones (Valor X Valor)")
					|| validarCampoNumericoValido(altaEspacioTorre.getOrientacion(), "Orientacion (GDOS)")
					|| validarCampoNumericoValido(altaEspacioTorre.getNcr(), "NCR(MTS)")
					|| validarCampoNumericoMayorCero(altaEspacioTorre.getFrecuenciasRX(), "Frecuencia RX (MHz)")
					|| validarCampoNumericoMayorCero(altaEspacioTorre.getFrecuenciasTX(), "Frecuencia TX (MHz)")
					|| validarCampoNumericoMayorCero(altaEspacioTorre.getPeso(), "Peso (KG)")
					|| validarCampoNumericoMayorCero(dimensionAlterRF1, "Dimension 1 (CM)")
					|| validarCampoNumericoMayorCero(dimensionAlterRF2, "Dimension 2 (CM)")) {

				detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
				limpiarRegistros();

				return;
			}
			if (!ValidacionUtil.validaLongitud(altaEspacioTorre.getTipoAntena(), 30)
					|| !ValidacionUtil.validaLongitud(altaEspacioTorre.getOrientacion(), 30)
					|| !ValidacionUtil.validaLongitud(altaEspacioTorre.getNcr(), 30)
					|| !ValidacionUtil.validaLongitud(altaEspacioTorre.getFrecuenciasRX(), 30)
					|| !ValidacionUtil.validaLongitud(altaEspacioTorre.getFrecuenciasTX(), 30)
					|| !ValidacionUtil.validaLongitud(altaEspacioTorre.getPeso(), 30)
					|| !ValidacionUtil.validaLongitud(dimensionAlterRF1, 30)
					|| !ValidacionUtil.validaLongitud(dimensionAlterRF2, 30)) {
				headerDialogo = "Solicitud de Colocaci�n";
				mensajeDialogo = "Se ha detectado valores inadecuado.";
				detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
				limpiarRegistros();
				return;
			}
		} else if (altaEspacioTorre.getTipoAntena().equals("MW")) {
			if (validarCampo(altaEspacioTorre.getTipoAntena(), "Tipo de Antena")
					|| validarCampo(altaEspacioTorre.getOrientacion(), "Orientaci�n")
					|| validarCampo(altaEspacioTorre.getNcr(), "NCR(MTS)")
					|| validarCampo(altaEspacioTorre.getFrecuenciasRX(), "Frecuencia RX")
					|| validarCampo(altaEspacioTorre.getFrecuenciasTX(), "Frecuencia TX")
					|| validarCampo(altaEspacioTorre.getPeso(), "Peso")
					|| validarCampo(altaEspacioTorre.getDimensiones(), "Dimension 1")
					|| validarCampoNumericoValido(altaEspacioTorre.getOrientacion(), "Orientaci�n")
					|| validarCampoNumericoValido(altaEspacioTorre.getNcr(), "NCR(MTS)")
					|| validarCampoNumericoMayorCero(altaEspacioTorre.getFrecuenciasRX(), "Frecuencia RX")
					|| validarCampoNumericoMayorCero(altaEspacioTorre.getFrecuenciasTX(), "Frecuencia TX")
					|| validarCampoNumericoMayorCero(altaEspacioTorre.getPeso(), "Peso")
					|| validarCampoNumericoMayorCero(altaEspacioTorre.getDimensiones(), "Dimensiones")) {
				detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
				limpiarRegistros();

				return;
			}
			if (!ValidacionUtil.validaLongitud(altaEspacioTorre.getTipoAntena(), 30)
					|| !ValidacionUtil.validaLongitud(altaEspacioTorre.getOrientacion(), 30)
					|| !ValidacionUtil.validaLongitud(altaEspacioTorre.getNcr(), 30)
					|| !ValidacionUtil.validaLongitud(altaEspacioTorre.getFrecuenciasRX(), 30)
					|| !ValidacionUtil.validaLongitud(altaEspacioTorre.getFrecuenciasTX(), 30)
					|| !ValidacionUtil.validaLongitud(altaEspacioTorre.getPeso(), 30)
					|| !ValidacionUtil.validaLongitud(altaEspacioTorre.getDimensiones(), 30)) {
				headerDialogo = "Solicitud de Colocaci�n";
				mensajeDialogo = "Se ha detectado valores inadecuado.";
				detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
				limpiarRegistros();

				return;
			}
		} else if (validarCampo(altaEspacioTorre.getTipoAntena(), "Tipo de Antena")) {
			detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
			limpiarRegistros();
			return;
		}
		int contador = 0;
		ColocacionTablaEspacioTorreDTO objetoTemporal = new ColocacionTablaEspacioTorreDTO();
		if (altaEspacioTorre.getTipoAntena() != null && !altaEspacioTorre.getTipoAntena().equals("")) {
			Integer numeral = obtenerNumTipoAntena(altaEspacioTorre.getTipoAntena());
			objetoTemporal.setTipoAntena("Antena " + String.valueOf(numeral) + " " + altaEspacioTorre.getTipoAntena());
			contador++;
		}
		if (contador == 1) {
			if (altaEspacioTorre.getOrientacion() != null && !altaEspacioTorre.getOrientacion().equals("")) {
				objetoTemporal.setOrientacion(altaEspacioTorre.getOrientacion() + " GDOS");
				contador++;
			}
			if (altaEspacioTorre.getNcr() != null && !altaEspacioTorre.getNcr().equals("")) {
				objetoTemporal.setNcr(altaEspacioTorre.getNcr() + " MTS");
				contador++;
			}
			if (altaEspacioTorre.getTipoAntena().equals("RF")) {
				if (!dimensionAlterRF1.isEmpty() && !dimensionAlterRF2.isEmpty()) {
					objetoTemporal.setDimensiones(dimensionAlterRF1 + " X " + dimensionAlterRF2 + " CM");
					dimensionAlterRF1 = "";
					dimensionAlterRF2 = "";
					contador++;
				}
			} else if (altaEspacioTorre.getDimensiones() != null && !altaEspacioTorre.getDimensiones().equals("")) {
				objetoTemporal.setDimensiones(altaEspacioTorre.getDimensiones() + " CM");
				contador++;
			}
			if (altaEspacioTorre.getFrecuenciasRX() != null && !altaEspacioTorre.getFrecuenciasRX().equals("")) {
				String unidad = "";
				if (altaEspacioTorre.getTipoAntena().equals("RF")) {
					unidad = " MHz";
				} else {
					unidad = " GHz";
				}
				objetoTemporal.setFrecuenciasRX(altaEspacioTorre.getFrecuenciasRX() + unidad);
				contador++;
			}
			if (altaEspacioTorre.getFrecuenciasTX() != null && !altaEspacioTorre.getFrecuenciasTX().equals("")) {
				String unidad = "";
				if (altaEspacioTorre.getTipoAntena().equals("RF")) {
					unidad = " MHz";
				} else {
					unidad = " GHz";
				}
				objetoTemporal.setFrecuenciasTX(altaEspacioTorre.getFrecuenciasTX() + unidad);
				contador++;
			}
			if (altaEspacioTorre.getPeso() != null && !altaEspacioTorre.getPeso().equals("")) {
				objetoTemporal.setPeso(altaEspacioTorre.getPeso() + " KG");
				contador++;
			}
		}
		if (contador == 7) {
			listaEspacioEnTorre.add(objetoTemporal);
			headerDialogo = "Solicitud Colocaci�n";
			mensajeDialogo = "Se agrego la antena con exito";
			detalleSolicitudBean.mensajeConfirmacion(headerDialogo, mensajeDialogo);
			altaEspacioTorre = new ColocacionTablaEspacioTorreDTO();
		}
	}

	public void eliminarAntena(ColocacionTablaEspacioTorreDTO antena) {
		try {
			listaEspacioEnTorre.remove(antena);
			// org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgEliminarAntena').show();");
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error");
		}
	}

	public void eliminaEspacioPiso(ColocacionTablaEspacioPisoDTO esPiso) {
		try {
			listaEspacioEnPiso.remove(esPiso);
		} catch (Exception e) {
		}
	}

	public void eliminaProgramacionColocacion(ColocacionTablaProgramaColocacionDTO programa) {
		try {
			Integer cont = 1;
			listaProgramaColocacion.remove(programa);
			for (ColocacionTablaProgramaColocacionDTO list : listaProgramaColocacion) {
				list.setSemana("Tarea " + cont);
				cont++;
			}
		} catch (Exception e) {
		}
	}

	private int obtenerNumTipoAntena(String tipoAntena) {
		int numeral = 1;
		String ultimoRegistro = "";
		if (null == listaEspacioEnTorre) {
			return 1;
		} else {
			for (ColocacionTablaEspacioTorreDTO temp : listaEspacioEnTorre) {
				if (temp.getTipoAntena().contains(tipoAntena)) {
					ultimoRegistro = temp.getTipoAntena();
					numeral++;
				}
			}
			if (ultimoRegistro.contains(String.valueOf(numeral))) {
				numeral++;
			}
		}
		return numeral;
	}

	public void actualizaRegistroEspacioTorre() {
		if (editarEspacioTorre.getTipoAntena().contains("RF")) {
			if (validarCampo(editarEspacioTorre.getTipoAntena(), "Tipo de Antena")
					|| validarCampo(editarEspacioTorre.getOrientacion(), "Orientaci�n")
					|| validarCampo(editarEspacioTorre.getNcr(), "NCR(MTS)")
					|| validarCampo(editarEspacioTorre.getFrecuenciasRX(), "Frecuencia RX")
					|| validarCampo(editarEspacioTorre.getFrecuenciasTX(), "Frecuencia TX")
					|| validarCampo(editarEspacioTorre.getPeso(), "Peso")
					|| validarCampo(dimensionAlterEditRF1, "Dimension 1")
					|| validarCampo(dimensionAlterEditRF2, "Dimension 2")
					|| validarCampoNumericoValido(editarEspacioTorre.getOrientacion(), "Orientacion (GDOS)")
					|| validarCampoNumericoValido(editarEspacioTorre.getNcr(), "NCR (MTS)")
					|| validarCampoNumericoMayorCero(editarEspacioTorre.getFrecuenciasRX(), "Frecuencia RX (MHz)")
					|| validarCampoNumericoMayorCero(editarEspacioTorre.getFrecuenciasTX(), "Frecuencia TX (MHz)")
					|| validarCampoNumericoMayorCero(editarEspacioTorre.getPeso(), "Peso (KG)")
					|| validarCampoNumericoMayorCero(dimensionAlterEditRF1, "Dimension 1 (CM)")
					|| validarCampoNumericoMayorCero(dimensionAlterEditRF2, "Dimension 2 (CM)")) {
				detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
				limpiarRegistros();

				return;
			}
			if (!ValidacionUtil.validaLongitud(editarEspacioTorre.getTipoAntena(), 30)
					|| !ValidacionUtil.validaLongitud(editarEspacioTorre.getOrientacion(), 30)
					|| !ValidacionUtil.validaLongitud(editarEspacioTorre.getNcr(), 30)
					|| !ValidacionUtil.validaLongitud(editarEspacioTorre.getFrecuenciasRX(), 30)
					|| !ValidacionUtil.validaLongitud(editarEspacioTorre.getFrecuenciasTX(), 30)
					|| !ValidacionUtil.validaLongitud(editarEspacioTorre.getPeso(), 30)
					|| !ValidacionUtil.validaLongitud(dimensionAlterEditRF1, 30)
					|| !ValidacionUtil.validaLongitud(dimensionAlterEditRF2, 30)) {
				headerDialogo = "Solicitud de Colocaci�n";
				mensajeDialogo = "Se ha detectado valores inadecuado.";
				detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
				limpiarRegistros();
				return;
			}
		} else if (editarEspacioTorre.getTipoAntena().contains("MW")) {
			if (validarCampo(editarEspacioTorre.getTipoAntena(), "Tipo de Antena")
					|| validarCampo(editarEspacioTorre.getOrientacion(), "Orientaci�n")
					|| validarCampo(editarEspacioTorre.getNcr(), "NCR(MTS)")
					|| validarCampo(editarEspacioTorre.getFrecuenciasRX(), "Frecuencia RX")
					|| validarCampo(editarEspacioTorre.getFrecuenciasTX(), "Frecuencia TX")
					|| validarCampo(editarEspacioTorre.getPeso(), "Peso")
					|| validarCampo(editarEspacioTorre.getDimensiones(), "Dimensiones")
					|| validarCampoNumericoValido(editarEspacioTorre.getOrientacion(), "Orientacion (GDOS)")
					|| validarCampoNumericoValido(editarEspacioTorre.getNcr(), "NCR (MTS)")
					|| validarCampoNumericoMayorCero(editarEspacioTorre.getFrecuenciasRX(), "Frecuencia RX (GHz)")
					|| validarCampoNumericoMayorCero(editarEspacioTorre.getFrecuenciasTX(), "Frecuencia TX (GHz)")
					|| validarCampoNumericoMayorCero(editarEspacioTorre.getPeso(), "Peso (KG)")
					|| validarCampoNumericoMayorCero(editarEspacioTorre.getDimensiones(), "Dimensiones (CM)")) {
				detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
				limpiarRegistros();

				return;
			}
			if (!ValidacionUtil.validaLongitud(editarEspacioTorre.getTipoAntena(), 30)
					|| !ValidacionUtil.validaLongitud(editarEspacioTorre.getOrientacion(), 30)
					|| !ValidacionUtil.validaLongitud(editarEspacioTorre.getNcr(), 30)
					|| !ValidacionUtil.validaLongitud(editarEspacioTorre.getFrecuenciasRX(), 30)
					|| !ValidacionUtil.validaLongitud(editarEspacioTorre.getFrecuenciasTX(), 30)
					|| !ValidacionUtil.validaLongitud(editarEspacioTorre.getPeso(), 30)
					|| !ValidacionUtil.validaLongitud(editarEspacioTorre.getDimensiones(), 30)) {
				headerDialogo = "Solicitud de Colocaci�n";
				mensajeDialogo = "Se ha detectado valores inadecuado.";
				detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
				limpiarRegistros();

				return;
			}
		}
		ColocacionTablaEspacioTorreDTO auxiliarTemporal = new ColocacionTablaEspacioTorreDTO();
		int contador = 0;
		auxiliarTemporal.setTipoAntena(editarEspacioTorre.getTipoAntena());
		if (null != editarEspacioTorre.getOrientacion() && !editarEspacioTorre.getOrientacion().isEmpty()) {
			auxiliarTemporal.setOrientacion(editarEspacioTorre.getOrientacion() + " GDOS");
			contador++;
		}
		if (null != editarEspacioTorre.getNcr() && !editarEspacioTorre.getNcr().isEmpty()) {
			auxiliarTemporal.setNcr(editarEspacioTorre.getNcr() + " MTS");
			contador++;
		}
		if (editarEspacioTorre.getTipoAntena().contains("RF")) {
			if (!dimensionAlterEditRF1.isEmpty() && !dimensionAlterEditRF2.isEmpty()) {
				auxiliarTemporal.setDimensiones(dimensionAlterEditRF1 + " X " + dimensionAlterEditRF2 + " CM");
				contador++;
				if (null != editarEspacioTorre.getFrecuenciasRX() && !editarEspacioTorre.getFrecuenciasRX().isEmpty()) {
					auxiliarTemporal.setFrecuenciasRX(editarEspacioTorre.getFrecuenciasRX() + " MHz");
					contador++;
				}
				if (null != editarEspacioTorre.getFrecuenciasTX() && !editarEspacioTorre.getFrecuenciasTX().isEmpty()) {
					auxiliarTemporal.setFrecuenciasTX(editarEspacioTorre.getFrecuenciasTX() + " MHz");
					contador++;
				}
			}
		} else {
			auxiliarTemporal.setDimensiones(editarEspacioTorre.getDimensiones() + " CM");
			contador++;
			if (null != editarEspacioTorre.getFrecuenciasRX() && !editarEspacioTorre.getFrecuenciasRX().isEmpty()) {
				auxiliarTemporal.setFrecuenciasRX(editarEspacioTorre.getFrecuenciasRX() + " MHz");
				contador++;
			}
			if (null != editarEspacioTorre.getFrecuenciasTX() && !editarEspacioTorre.getFrecuenciasTX().isEmpty()) {
				auxiliarTemporal.setFrecuenciasTX(editarEspacioTorre.getFrecuenciasTX() + " GHz");
				contador++;
			}
		}

		if (null != editarEspacioTorre.getPeso() && !editarEspacioTorre.getPeso().isEmpty()) {
			auxiliarTemporal.setPeso(editarEspacioTorre.getPeso() + " KG");
			contador++;
		}
		if (contador == 6) {
			int recorrido = 0;
			for (ColocacionTablaEspacioTorreDTO t : listaEspacioEnTorre) {
				if (editarEspacioTorre.getTipoAntena().equals(t.getTipoAntena())) {
					break;
				}
				recorrido++;
			}
			listaEspacioEnTorre.set(recorrido, auxiliarTemporal);
			headerDialogo = "Solicitud Colocaci�n";
			mensajeDialogo = "Se actualizo el registro de la antena con exito";
			detalleSolicitudBean.mensajeConfirmacion(headerDialogo, mensajeDialogo);
		}
	}

	public void actualizarTablaEspacioPiso() {
		if (validarCampo(editarEspacioEnPiso.getTecnologia(), "Tecnologia")
				|| validarCampo(editarEspacioEnPiso.getSuperficie(), "Superficie")
				|| validarCampoNumericoMayorCero(editarEspacioEnPiso.getSuperficie(), "Superficie")) {
			limpiarRegistros();
			detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);

			return;
		}
		if (!ValidacionUtil.validarSoloLetras(editarEspacioEnPiso.getTecnologia())
				|| !ValidacionUtil.validarCaracteres(editarEspacioEnPiso.getTecnologia())
				|| !ValidacionUtil.validaLongitud(editarEspacioEnPiso.getTecnologia(), 30)) {
			headerDialogo = "Solicitud de Colocaci�n";
			mensajeDialogo = "Se ha detectado valores inadecuado.";
			detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
			limpiarRegistros();
			return;
		}
		int j = 0;
		ColocacionTablaEspacioPisoDTO auxiliarEspacioPiso = new ColocacionTablaEspacioPisoDTO();
		auxiliarEspacioPiso.setGabinete(editarEspacioEnPiso.getGabinete());
		j++;
		if (editarEspacioEnPiso.getSuperficie() != null && !editarEspacioEnPiso.getSuperficie().isEmpty()) {
			auxiliarEspacioPiso.setSuperficie(editarEspacioEnPiso.getSuperficie());
			j++;
		}
		if (editarEspacioEnPiso.getTecnologia() != null && !editarEspacioEnPiso.getTecnologia().isEmpty()) {
			auxiliarEspacioPiso.setTecnologia(editarEspacioEnPiso.getTecnologia());
			j++;
		}
		if (j == 3) {
			int i = 0;
			for (ColocacionTablaEspacioPisoDTO temporal : listaEspacioEnPiso) {
				if (editarEspacioEnPiso.getGabinete().equals(temporal.getGabinete())) {
					break;
				}
				i++;
			}
			listaEspacioEnPiso.set(i, editarEspacioEnPiso);
			headerDialogo = "Solicitud Colocaci�n";
			mensajeDialogo = "Se actualizo el registro de espacio en piso";
			detalleSolicitudBean.mensajeConfirmacion(headerDialogo, mensajeDialogo);
			editarEspacioEnPiso = new ColocacionTablaEspacioPisoDTO();
		}
	}

	public void actualizaProgramacionColocacion() {
		if (validarCampo(editarTablaProgramaCol.getSemana(), "Tarea")
				|| validarCampo(editarTablaProgramaCol.getActividad(), "Actividad")
				|| validarCampo(editarTablaProgramaCol.getInicioProgramado(), "Fecha de Inicio")
				|| validarCampo(editarTablaProgramaCol.getFinalProgramado(), "Fceha final")) {
			limpiarRegistros();
			detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
			return;

		}
		int contadorIntegridad = 0;
		ColocacionTablaProgramaColocacionDTO aux = new ColocacionTablaProgramaColocacionDTO();
		if (editarTablaProgramaCol.getSemana() != null && !editarTablaProgramaCol.getSemana().isEmpty()) {
			aux.setSemana(editarTablaProgramaCol.getSemana());
			contadorIntegridad++;
		}

		if (editarTablaProgramaCol.getActividad() != null && !editarTablaProgramaCol.getActividad().isEmpty()) {
			aux.setActividad(editarTablaProgramaCol.getActividad());
			contadorIntegridad++;
		}

		if (editarTablaProgramaCol.getInicioProgramado() != null
				&& !editarTablaProgramaCol.getInicioProgramado().isEmpty()) {
			aux.setInicioProgramado(editarTablaProgramaCol.getInicioProgramado());
			aux.setInicioReal(editarTablaProgramaCol.getInicioProgramado());
			contadorIntegridad++;
		}
		if (editarTablaProgramaCol.getFinalProgramado() != null
				&& !editarTablaProgramaCol.getFinalProgramado().isEmpty()) {
			aux.setFinalProgramado(editarTablaProgramaCol.getFinalProgramado());
			aux.setFinalReal(editarTablaProgramaCol.getFinalProgramado());
			contadorIntegridad++;
		}
		if (contadorIntegridad == 4) {
			int j = 0;
			for (ColocacionTablaProgramaColocacionDTO o : listaProgramaColocacion) {
				if (o.getSemana().equals(editarTablaProgramaCol.getSemana())) {
					break;
				}
				j++;
			}
			listaProgramaColocacion.set(j, aux);
		}
	}

	public void asignaValorEdicionEspacioTorre(ColocacionTablaEspacioTorreDTO antena) {
		try {
			leyendasEditarEspacioTorre = new ColocacionTablaEspacioTorreDTO();
			editarEspacioTorre = new ColocacionTablaEspacioTorreDTO();
			editarEspacioTorre.setTipoAntena(antena.getTipoAntena());
			if (antena.getOrientacion() != null) {
				editarEspacioTorre
						.setOrientacion(antena.getOrientacion().substring(0, antena.getOrientacion().length() - 4));
			}
			if (antena.getNcr() != null) {
				editarEspacioTorre.setNcr(antena.getNcr().substring(0, antena.getNcr().length() - 4));
			}
			if (antena.getDimensiones() != null) {
				if (antena.getTipoAntena().contains("RF")) {
					String dimensionTratada = antena.getDimensiones().substring(0,
							antena.getDimensiones().length() - 3);
					int i = 0, contador = 0;
					while (i < dimensionTratada.length()) {
						String tempChar = String.valueOf(antena.getDimensiones().charAt(i));
						if (tempChar.equals("X")) {
							contador = i;
						}
						i++;
					}
					dimensionAlterEditRF1 = dimensionTratada.substring(0, contador - 1);
					dimensionAlterEditRF2 = dimensionTratada.substring(contador + 2);
					indicadorEditDimRF = true;
					indicadorEditDimMW = false;
					leyendasEditarEspacioTorre.setTipoAntena("Tipo Antena: ");
					leyendasEditarEspacioTorre.setOrientacion("Orientacion (GDOS): ");
					leyendasEditarEspacioTorre.setNcr("NCR (MTS): ");
					leyendasEditarEspacioTorre.setDimensiones("Dimensiones (CM): ");
					leyendasEditarEspacioTorre.setFrecuenciasRX("Frecuencias RX (MHz): ");
					leyendasEditarEspacioTorre.setFrecuenciasTX("Frecuencias TX (GHz): ");
					leyendasEditarEspacioTorre.setPeso("Peso (KG): ");
				} else if (antena.getTipoAntena().contains("MW")) {
					editarEspacioTorre
							.setDimensiones(antena.getDimensiones().substring(0, antena.getDimensiones().length() - 3));
					indicadorEditDimRF = false;
					indicadorEditDimMW = true;
					dimensionAlterEditRF1 = "";
					dimensionAlterEditRF2 = "";
					leyendasEditarEspacioTorre.setTipoAntena("Tipo Antena: ");
					leyendasEditarEspacioTorre.setOrientacion("Orientacion (GDOS): ");
					leyendasEditarEspacioTorre.setNcr("NCR (MTS): ");
					leyendasEditarEspacioTorre.setDimensiones("Dimensiones (CM): ");
					leyendasEditarEspacioTorre.setFrecuenciasRX("Frecuencias RX (MHz): ");
					leyendasEditarEspacioTorre.setFrecuenciasTX("Frecuencias TX (GHz): ");
					leyendasEditarEspacioTorre.setPeso("Peso (KG): ");
				}
			}
			if (antena.getFrecuenciasRX() != null) {
				editarEspacioTorre.setFrecuenciasRX(
						antena.getFrecuenciasRX().substring(0, antena.getFrecuenciasRX().length() - 4));
			}
			if (antena.getFrecuenciasTX() != null) {
				editarEspacioTorre.setFrecuenciasTX(
						antena.getFrecuenciasTX().substring(0, antena.getFrecuenciasTX().length() - 4));
			}
			editarEspacioTorre.setPeso(antena.getPeso().substring(0, antena.getPeso().length() - 3));
			FacesContext.getCurrentInstance().getPartialViewContext().getRenderIds()
					.add("formSolicitudes:tbView:acordionPanelColocacion:dialogoEdicionEspacioTorre");
		} catch (Exception e) {
		}
	}

	public void asignaValorEdicionEspacioPiso(ColocacionTablaEspacioPisoDTO espacio) {
		editarEspacioEnPiso = new ColocacionTablaEspacioPisoDTO();
		editarEspacioEnPiso.setGabinete(espacio.getGabinete());
		editarEspacioEnPiso.setTecnologia(espacio.getTecnologia());
		editarEspacioEnPiso.setSuperficie(espacio.getSuperficie());
		FacesContext.getCurrentInstance().getPartialViewContext().getRenderIds()
				.add("formSolicitudes:tbView:acordionPanelColocacion:editarDialogoEspacioPiso");
	}

	public void altaEspacioPisoMetodo() {
		if (validarCampo(altaEspacioPiso.getTecnologia(), "Tecnologia")
				|| validarCampo(altaEspacioPiso.getSuperficie(), "Superficie")
				|| validarCampoNumericoMayorCero(altaEspacioPiso.getSuperficie(), "Superficie (m2)")) {
			detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
			limpiarRegistros();
			return;
		}
		if (!ValidacionUtil.validarSoloLetras(altaEspacioPiso.getTecnologia())
				|| !ValidacionUtil.validarCaracteres(altaEspacioPiso.getTecnologia())
				|| !ValidacionUtil.validaLongitud(altaEspacioPiso.getTecnologia(), 30)) {
			headerDialogo = "Solicitud de Colocaci�n";
			mensajeDialogo = "Se ha detectado valores inadecuado.";
			detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
			limpiarRegistros();
			return;
		}
		ColocacionTablaEspacioPisoDTO objectAlta = new ColocacionTablaEspacioPisoDTO();
		int numGabinete = 1, contador = 0;
		if (null != listaEspacioEnPiso) {
			numGabinete = listaEspacioEnPiso.size() + 1;
			for (ColocacionTablaEspacioPisoDTO temp : listaEspacioEnPiso) {
				if (temp.getGabinete().contains(String.valueOf(numGabinete))) {
					numGabinete++;
				}
			}
		}
		objectAlta.setGabinete("Gabinete " + numGabinete);
		if (null != altaEspacioPiso.getSuperficie() && !altaEspacioPiso.getSuperficie().isEmpty()) {
			objectAlta.setSuperficie(altaEspacioPiso.getSuperficie());
			contador++;
		}
		if (null != altaEspacioPiso.getTecnologia() && !altaEspacioPiso.getTecnologia().isEmpty()) {
			objectAlta.setTecnologia(altaEspacioPiso.getTecnologia());
			contador++;
		}

		if (contador == 2) {
			listaEspacioEnPiso.add(objectAlta);
			headerDialogo = "Solicitud Colocaci�n";
			mensajeDialogo = "Se agrego el registro de espacio en piso con exito";
			detalleSolicitudBean.mensajeConfirmacion(headerDialogo, mensajeDialogo);
			altaEspacioPiso = new ColocacionTablaEspacioPisoDTO();
		}
	}

	public void cargaArchivoSolicitudColocacion(FileUploadEvent event) {
		try {
			String nombreArchivo = FilenameUtils.getName(event.getFile().getFileName());
			String nombreRepetido = "";
			for (int i = 0; i < listaArchivoEvento.size(); i++) {
				if (nombreArchivo.equalsIgnoreCase(listaArchivoEvento.get(i).getFile().getFileName())) {
					nombreRepetido = "true";
					break;
				}
			}
			if (!nombreRepetido.equals("true")) {
				SoliArchDto archivo = new SoliArchDto();
				archivo.setDescripcion("Solicitud de Colocaci\u00F3n");
				archivo.setRevision("1");
				archivo.setIdSeccion(0);
				archivo.setNombreArch(nombreArchivo);
				archivo.setRuta("");
				archivo.setTamanio(event.getFile().getSize() / 1024 + " kb");
				String nombre = userDetailsVo.getNombre() + " " + userDetailsVo.getApellidoPaterno() + " "
						+ userDetailsVo.getApellidoMaterno();
				archivo.setUsuario(nombre);
				archivo.setNombreUsu(nombre);
				archivo.setFechaCarga(dateFormatTime.format(new Date()));
				listaArchivosTabla.add(archivo);
				listaArchivoEvento.add(event);

				for (SoliArchDto fact : listaArchivosTabla) {
					if (nombreArchivo.equalsIgnoreCase(fact.getNombreArch())) {
						fact.setBotonEliminar("false");
					}
				}
				headerDialogo = "Solicitud Colocaci�n";
				mensajeDialogo = "Se cargo el documento Exitosamente";
				detalleSolicitudBean.mensajeConfirmacion(headerDialogo, mensajeDialogo);
			} else {
				headerDialogo = "Solicitud Colocaci�n";
				mensajeDialogo = "No se puede cargar un archivo con el mismo nombre";
				detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
			}
		} catch (Exception e) {
			headerDialogo = "Solicitud Colocaci�n";
			mensajeDialogo = "Ocurri� un error al cargar los documentos:";
			detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
		}
	}

	private void edicionVerificacionColocacionArchivos() {
		List<SoliArchDto> listaArchivosSolicitudColocacionActualizar = new ArrayList<>(),
				listaArchivosSolicitudColocacionInsertar = new ArrayList<>(),
				listaArchivosSolicitudColocacionEliminar = new ArrayList<>();
		listaArchivosTablaVerificarColocacionEdicion = colocacionService.obtenerArchivoEnTabla(solicitudDto.getFolio(),
				"/orbi/SEG/Solicitudes/" + solicitudDto.getFolio() + "/26");
		int contadorListaActual = 0;
		for (SoliArchDto t : listaArchivosTablaVerificarColocacion) {
			int contadorListaAntigua = 0, existencia = 0;
			for (SoliArchDto m : listaArchivosTablaVerificarColocacionEdicion) {
				if (t.getNombreArch().equals(m.getNombreArch())) {
					existencia = 1;
					if (t.getDescripcion().equals(m.getDescripcion())) {
						if (t.getTamanio().equals(m.getTamanio())) {

						} else {
							listaArchivosSolicitudColocacionActualizar
									.add(listaArchivosTablaVerificarColocacion.get(contadorListaActual));
						}
					} else {
						listaArchivosSolicitudColocacionActualizar
								.add(listaArchivosTablaVerificarColocacion.get(contadorListaActual));
					}
				}
				contadorListaAntigua++;
			}
			if (existencia == 0) {
				listaArchivosSolicitudColocacionInsertar
						.add(listaArchivosTablaVerificarColocacion.get(contadorListaActual));
			}
			contadorListaActual++;
		}

		int contadorListaAntigua = 0;
		for (SoliArchDto m : listaArchivosTablaVerificarColocacionEdicion) {
			int existencia = 0;
			for (SoliArchDto t : listaArchivosTablaVerificarColocacion) {
				if (t.getNombreArch().equals(m.getNombreArch())) {
					existencia = 1;
				}
			}
			if (existencia == 0) {
				listaArchivosSolicitudColocacionEliminar
						.add(listaArchivosTablaVerificarColocacionEdicion.get(contadorListaAntigua));
			}
			contadorListaAntigua++;
		}

		for (SoliArchDto k : listaArchivosSolicitudColocacionActualizar) {
			System.out.println("ACTUALIZAR: " + k.getNombreArch() + "|" + k.getDescripcion() + "|" + k.getTamanio());
		}
		for (SoliArchDto k : listaArchivosSolicitudColocacionInsertar) {
			System.out.println("INSERTAR: " + k.getNombreArch() + "|" + k.getDescripcion() + "|" + k.getTamanio());
		}
		for (SoliArchDto k : listaArchivosSolicitudColocacionEliminar) {
			System.out.println("ELIMINAR: " + k.getNombreArch() + "|" + k.getDescripcion() + "|" + k.getTamanio());
		}

		String rutaBase = "";
		try {
			ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness
					.getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_INF);
			rutaBase = String.valueOf(configurationUtilsVo.getValor());
		} catch (TransactionalOVITException e) {
			rutaBase = "";
		}
		rutaBase = rutaBase + solicitudDto.getFolio() + "/26";

		if (!listaArchivosSolicitudColocacionInsertar.isEmpty()) {
			insertaArchivoEnTabla(solicitudDto.getFolio(), rutaBase, listaArchivosSolicitudColocacionInsertar);
			for (SoliArchDto t : listaArchivosSolicitudColocacionInsertar) {
				for (FileUploadEvent h : listaArchivoEventoVerificarColocacion) {
					if (t.getNombreArch().equals(h.getFile().getFileName())) {
						try {
							File directorioTemp = new File(rutaBase);
							if (!directorioTemp.exists()) {
								directorioTemp.mkdirs();
							}
							String nombreArchivo = FilenameUtils.getName(h.getFile().getFileName());
							OutputStream out;
							try (InputStream in = h.getFile().getInputstream()) {
								out = new FileOutputStream(directorioTemp + "/" + nombreArchivo);
								byte[] buf = new byte[1024];
								int len;
								while ((len = in.read(buf)) > 0) {
									out.write(buf, 0, len);
								}
								in.close();
							}
							out.close();
						} catch (IOException e) {
						}
					}
				}
			}
		}
		if (!listaArchivosSolicitudColocacionActualizar.isEmpty()) {
			colocacionService.actualizaArchivoEnTabla(solicitudDto.getFolio(), rutaBase,
					listaArchivosSolicitudColocacionActualizar);
			for (SoliArchDto h : listaArchivosSolicitudColocacionActualizar) {
				for (FileUploadEvent j : listaArchivoEventoVerificarColocacion) {
					try {
						File directorioTemp = new File(rutaBase);
						if (!directorioTemp.exists()) {
							directorioTemp.mkdirs();
						}
						File archivoFisico = new File(rutaBase + "/" + h.getNombreArch());
						if (archivoFisico.exists()) {
							archivoFisico.delete();
						}
						String nombreArchivo = FilenameUtils.getName(j.getFile().getFileName());
						OutputStream out;
						try (InputStream in = j.getFile().getInputstream()) {
							out = new FileOutputStream(directorioTemp + "/" + nombreArchivo);
							byte[] buf = new byte[1024];
							int len;
							while ((len = in.read(buf)) > 0) {
								out.write(buf, 0, len);
							}
							in.close();
						}
						out.close();
					} catch (IOException e) {
					}
				}
			}
		}

		if (!listaArchivosSolicitudColocacionEliminar.isEmpty()) {
			colocacionService.eliminaArchivoEnTabla(solicitudDto.getFolio(), listaArchivosSolicitudColocacionEliminar);
			for (SoliArchDto h : listaArchivosSolicitudColocacionEliminar) {
				File archivoFisico = new File(rutaBase + "/" + h.getNombreArch());
				if (archivoFisico.exists()) {
					archivoFisico.delete();
				}
			}
		}
	}

	public void descargarArchivo(String nombre) {
		String rutaBase = "";
		try {
			ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness
					.getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_INF);
			rutaBase = String.valueOf(configurationUtilsVo.getValor());
		} catch (TransactionalOVITException e) {
			rutaBase = "";
		}
		FacesContext context = FacesContext.getCurrentInstance();
		FacesMessage facesMessage = new FacesMessage();
		File file = new File(rutaBase + nombre);

		if (file.exists()) {
			HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();
			response.reset();
			response.setHeader("Content-Type", "application/octet-stream");
			response.setHeader("Content-Disposition", "attachment;filename=\"" + nombre + "\"");
			response.setContentLength((int) file.length());
			try (InputStream in = new FileInputStream(file); OutputStream out = response.getOutputStream()) {
				byte[] buffer = new byte[1024];
				int bytesRead;
				while ((bytesRead = in.read(buffer)) != -1) {
					out.write(buffer, 0, bytesRead);
				}
				context.responseComplete();
			} catch (IOException e) {
				headerDialogo = "Solicitud Colocaci�n";
				mensajeDialogo = "Hubo un problema al descargar el archivo.";
				detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
//                facesMessage.setDetail("Hubo un problema al descargar el archivo.");
//                facesMessage.setSummary("Error!");
//                facesMessage.setSeverity(FacesMessage.SEVERITY_ERROR);
//                context.addMessage("msjProyectoPresupuesto", facesMessage);
			}
		} else {
			headerDialogo = "Solicitud Colocaci�n";
			mensajeDialogo = "No existe el archivo en la ruta especificada.";
			detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
//            facesMessage.setDetail("No existe el archivo en la ruta especificada.");
//            facesMessage.setSummary("Error!");
//            facesMessage.setSeverity(FacesMessage.SEVERITY_ERROR);
//            context.addMessage("msjProyectoPresupuesto", facesMessage);
		}
	}

	public void eliminaArchivoSolicitudColocacion(SoliArchDto archivo) {
		FileUploadEvent tempEvento = null;
		for (FileUploadEvent t : listaArchivoEvento) {
			if (t.getFile().getFileName().equals(archivo.getNombreArch())) {
				tempEvento = t;
				break;
			}
		}
		listaArchivoEvento.remove(tempEvento);
		SoliArchDto tempArch = new SoliArchDto();
		for (SoliArchDto t : listaArchivosTabla) {
			if (t.getNombreArch().equals(archivo.getNombreArch())) {
				tempArch = t;
			}
		}
		listaArchivosTabla.remove(tempArch);
	}

	private List<ColocacionTablaProgramaColocacionDTO> calculaSemanas() {
		List<ColocacionTablaProgramaColocacionDTO> listaTemporal = new ArrayList<>();
		for (int i = 1; i < 53; i++) {
			ColocacionTablaProgramaColocacionDTO e = new ColocacionTablaProgramaColocacionDTO();
			e.setSemana("Tarea " + i);
			listaTemporal.add(e);
		}
		return listaTemporal;
	}

	public void limpiarCampos() {
		seleccionadoSemana = "";
		actividad = "";
		fechaI = "";
		fechaF = "";
	}

	public void agregarProgramacionColocacion() {
		try {
			Integer cont = listaProgramaColocacion.size() + 1;
			altaTablaProgramaCol.setInicioProgramado(fechaI);
			altaTablaProgramaCol.setFinalProgramado(fechaF);
			altaTablaProgramaCol.setSemana("Tarea " + cont);
			altaTablaProgramaCol.setActividad(actividad);
			if (altaTablaProgramaCol.getSemana().equals("") || altaTablaProgramaCol.getSemana().isEmpty()
					|| altaTablaProgramaCol.getActividad().trim().equals("")
					|| altaTablaProgramaCol.getActividad().isEmpty()
					|| altaTablaProgramaCol.getInicioProgramado() == null
					|| altaTablaProgramaCol.getInicioProgramado().isEmpty()
					|| altaTablaProgramaCol.getFinalProgramado() == null
					|| altaTablaProgramaCol.getFinalProgramado().isEmpty()) {
				limpiarCampos();

				detalleSolicitudBean.setHeaderDialogo("Programa de Colocaci�n");
				detalleSolicitudBean.setMensajeDialogo("No es posible crear la actividad con datos incompletos");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
				return;
			} else if (!ValidacionUtil.validarCaracteres(altaTablaProgramaCol.getActividad())) {
				limpiarCampos();
				detalleSolicitudBean.setHeaderDialogo("Programa de Colocaci�n");
				detalleSolicitudBean.setMensajeDialogo("No se aceptan caracteres especiales en Actividad");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
				return;
			} else if (!ValidacionUtil.validaLongitud(altaTablaProgramaCol.getActividad(), 250)) {
				limpiarCampos();
				detalleSolicitudBean.setHeaderDialogo("Programa de Colocaci�n");
				detalleSolicitudBean.setMensajeDialogo("El numero maximo de caracteres para Actividad es 50");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
				return;
			} else if (!altaTablaProgramaCol.getInicioProgramado().equals("")
					&& !altaTablaProgramaCol.getFinalProgramado().equals("")) {
				if (altaTablaProgramaCol.getInicioProgramado()
						.matches("^([0-2][0-9]|3[0-1])(\\/)(0[1-9]|1[0-2])\\2(\\d{4})$")) {
					try {
						String[] fh = altaTablaProgramaCol.getInicioProgramado().split("/");
						Integer dia = Integer.parseInt(fh[0]);
						Integer mes = Integer.parseInt(fh[1]);
						Integer anio = Integer.parseInt(fh[2]);
						LocalDate fechaD = LocalDate.of(anio, mes, dia);
					} catch (DateTimeException e) {
						limpiarCampos();
						detalleSolicitudBean.setHeaderDialogo("Programa de Colocaci�n");
						detalleSolicitudBean
								.setMensajeDialogo("La fecha inicio debe cumplir con el siguiente formato dd/MM/yyyy");
						org.primefaces.context.RequestContext.getCurrentInstance()
								.execute("PF('dlgMsjWarningSoli').show();");
						return;
					}
				} else {
					limpiarCampos();
					detalleSolicitudBean.setHeaderDialogo("Programa de Colocaci�n");
					detalleSolicitudBean
							.setMensajeDialogo("La fecha inicio debe cumplir con el siguiente formato dd/MM/yyyy");
					org.primefaces.context.RequestContext.getCurrentInstance()
							.execute("PF('dlgMsjWarningSoli').show();");
					return;
				}
				if (altaTablaProgramaCol.getFinalProgramado()
						.matches("^([0-2][0-9]|3[0-1])(\\/)(0[1-9]|1[0-2])\\2(\\d{4})$")) {
					try {
						String[] fh = altaTablaProgramaCol.getFinalProgramado().split("/");
						Integer dia = Integer.parseInt(fh[0]);
						Integer mes = Integer.parseInt(fh[1]);
						Integer anio = Integer.parseInt(fh[2]);
						LocalDate fechaD = LocalDate.of(anio, mes, dia);
					} catch (DateTimeException e) {
						limpiarCampos();
						detalleSolicitudBean.setHeaderDialogo("Programa de Colocaci�n");
						detalleSolicitudBean
								.setMensajeDialogo("La fecha final debe cumplir con el siguiente formato dd/MM/yyyy");
						org.primefaces.context.RequestContext.getCurrentInstance()
								.execute("PF('dlgMsjWarningSoli').show();");
						return;
					}

				} else {
					limpiarCampos();
					detalleSolicitudBean.setHeaderDialogo("Programa de Colocaci�n");
					detalleSolicitudBean
							.setMensajeDialogo("La fecha final debe cumplir con el siguiente formato dd/MM/yyyy");
					org.primefaces.context.RequestContext.getCurrentInstance()
							.execute("PF('dlgMsjWarningSoli').show();");
					return;
				}
			}
			if (!altaTablaProgramaCol.getInicioProgramado().equals("")
					&& !altaTablaProgramaCol.getFinalProgramado().equals("")) {
				SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy");
				Date fechaInicioDate = null;
				Date fechaFinDate = null;
				try {
					fechaInicioDate = date.parse(altaTablaProgramaCol.getInicioProgramado());
				} catch (Exception e) {
					limpiarCampos();
					detalleSolicitudBean.setHeaderDialogo("Programa de Colocaci�n");
					detalleSolicitudBean
							.setMensajeDialogo("La fecha inicio debe cumplir con el siguiente formato dd/MM/yyyy");
					org.primefaces.context.RequestContext.getCurrentInstance()
							.execute("PF('dlgMsjWarningSoli').show();");
					return;
				}
				try {
					fechaFinDate = date.parse(altaTablaProgramaCol.getFinalProgramado());
				} catch (Exception e) {
					limpiarCampos();
					detalleSolicitudBean.setHeaderDialogo("Programa de Colocaci�n");
					detalleSolicitudBean
							.setMensajeDialogo("La fecha final debe cumplir con el siguiente formato dd/MM/yyyy");
					org.primefaces.context.RequestContext.getCurrentInstance()
							.execute("PF('dlgMsjWarningSoli').show();");
					return;
				}

				Date fA = new Date();
				if (fA.after(fechaInicioDate)) {
					limpiarCampos();
					detalleSolicitudBean.setHeaderDialogo("Programa de Colocaci�n");
					detalleSolicitudBean.setMensajeDialogo("La fecha inicio debe ser mayor al dia actual");
					org.primefaces.context.RequestContext.getCurrentInstance()
							.execute("PF('dlgMsjWarningSoli').show();");
					return;
				}

				if (fechaInicioDate.after(fechaFinDate)) {
					limpiarCampos();
					detalleSolicitudBean.setHeaderDialogo("Programa de Colocaci�n");
					detalleSolicitudBean.setMensajeDialogo("La fecha inicio no puede ser mayor a la fecha final");
					org.primefaces.context.RequestContext.getCurrentInstance()
							.execute("PF('dlgMsjWarningSoli').show();");
					return;
				}
			}
			int indicadorRegRepetido = 0, contador = 0, indicadorActividadRep = 0;
			if (altaTablaProgramaCol.getSemana() != null && !altaTablaProgramaCol.getSemana().isEmpty()) {
				if (listaProgramaColocacion != null) {
					for (ColocacionTablaProgramaColocacionDTO o : listaProgramaColocacion) {
						if (o.getSemana().equals(altaTablaProgramaCol.getSemana())
								|| o.getActividad().equals(altaTablaProgramaCol.getActividad())) {
							indicadorRegRepetido = 1;
							indicadorActividadRep = 1;
							break;
						}
					}
				}
				contador++;
			}
			if (altaTablaProgramaCol.getActividad() != null && !altaTablaProgramaCol.getActividad().isEmpty()) {
				contador++;
			}

			if (altaTablaProgramaCol.getInicioProgramado() != null
					&& !altaTablaProgramaCol.getInicioProgramado().isEmpty()) {
				altaTablaProgramaCol.setInicioReal(altaTablaProgramaCol.getInicioProgramado());
				contador++;
			}

			if (altaTablaProgramaCol.getFinalProgramado() != null
					&& !altaTablaProgramaCol.getFinalProgramado().isEmpty()) {
				altaTablaProgramaCol.setFinalReal(altaTablaProgramaCol.getFinalProgramado());
				contador++;
			}
			if (indicadorRegRepetido == 0 && indicadorActividadRep == 0) {
				if (contador == 4) {
					listaProgramaColocacion.add(altaTablaProgramaCol);
					altaTablaProgramaCol = new ColocacionTablaProgramaColocacionDTO();
				}
				altaTablaProgramaCol.setInicioProgramado("");
				altaTablaProgramaCol.setFinalProgramado("");
				limpiarCampos();
			} else {
				limpiarCampos();
				detalleSolicitudBean.setHeaderDialogo("Programa de Colocaci�n");
				detalleSolicitudBean.setMensajeDialogo("No es posible repetir semana o actividad.");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			}
			listO = new ArrayList<>();
			for (ColocacionTablaProgramaColocacionDTO l : listaProgramaColocacion) {
				TablaProgramaColocacionSortDTO n = new TablaProgramaColocacionSortDTO();
				n.setActividad(l.getActividad());
				n.setInicioProgramado(new SimpleDateFormat("dd/MM/yyyy").parse(l.getInicioProgramado()));
				n.setFinalProgramado(new SimpleDateFormat("dd/MM/yyyy").parse(l.getFinalProgramado()));
				n.setSemana(l.getSemana());
				listO.add(n);
			}
			cont = 1;
			ordenFechas = false;
			Collections.sort(listO, new ColocacionBean());
			listaProgramaColocacion = new ArrayList<>();

			duplicates = new ArrayList<>();
			Set<String> set = new HashSet<>();
			for (TablaProgramaColocacionSortDTO i : listO) {
				if (set.contains(new SimpleDateFormat("dd/MM/yyyy").format(i.getFinalProgramado()))) {
					if (!duplicates.contains(new SimpleDateFormat("dd/MM/yyyy").format(i.getFinalProgramado()))) {
						duplicates.add(new SimpleDateFormat("dd/MM/yyyy").format(i.getFinalProgramado()));
					}
				} else {
					set.add(new SimpleDateFormat("dd/MM/yyyy").format(i.getFinalProgramado()));
				}
			}

			ordenFechas = true;
			Collections.sort(listO, new ColocacionBean());

			for (TablaProgramaColocacionSortDTO listP : listO) {
				ColocacionTablaProgramaColocacionDTO n = new ColocacionTablaProgramaColocacionDTO();
				n.setActividad(listP.getActividad());
				n.setInicioProgramado(new SimpleDateFormat("dd/MM/yyyy").format(listP.getInicioProgramado()));
				n.setFinalProgramado(new SimpleDateFormat("dd/MM/yyyy").format(listP.getFinalProgramado()));
				n.setSemana("Tarea " + cont);
				listaProgramaColocacion.add(n);
				cont++;
			}
		} catch (Exception e) {
			limpiarCampos();
			detalleSolicitudBean.setHeaderDialogo("Programa de Colocaci�n");
			detalleSolicitudBean.setMensajeDialogo("Ocurrio un error al agregar la actividad.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
		}
	}

	@Override
	public int compare(TablaProgramaColocacionSortDTO o1, TablaProgramaColocacionSortDTO o2) {
		boolean inicioFin = false;
		if (ordenFechas) {
			for (String string : duplicates) {
				if (string.equals(new SimpleDateFormat("dd/MM/yyyy").format(o1.getFinalProgramado()))
						&& string.equals(new SimpleDateFormat("dd/MM/yyyy").format(o2.getFinalProgramado()))) {
					inicioFin = true;
					break;
				} else {
					inicioFin = false;
				}
			}
			if (inicioFin) {
				return o1.getInicioProgramado().compareTo(o2.getInicioProgramado());
			} else {
				return o1.getFinalProgramado().compareTo(o2.getFinalProgramado());
			}

		} else {
			return o1.getFinalProgramado().compareTo(o2.getFinalProgramado());
		}
	}

	public void generaProgramaColocacion(String[] values, SolicitudDto parametroSolicitud) {
		if (listaProgramaColocacion.size() > 0) {
			List<ProgramaColocacionDto> listaPrograma = new ArrayList<ProgramaColocacionDto>();
			for (ColocacionTablaProgramaColocacionDTO list : listaProgramaColocacion) {
				ProgramaColocacionDto programaColocacionDto = new ProgramaColocacionDto();
				programaColocacionDto.setActividad(list.getActividad());
				programaColocacionDto.setFechaFinalProgramada(list.getFinalProgramado());
				programaColocacionDto.setFechaInicioProgramada(list.getInicioProgramado());
				programaColocacionDto.setIdFolio(parametroSolicitud.getFolio());
				programaColocacionDto.setSemana(list.getSemana());
				listaPrograma.add(programaColocacionDto);
			}
			boolean resp = colocacionService.insertaProgramaColocacion(listaPrograma);
			boolean solicitudModificada = proyectoService.updateEstadoSolicitud(solicitudDto.getFolio(), values[0]);
			if (resp && solicitudModificada) {
				detalleSolicitudBean.insertarBitacora("");
				detalleSolicitudBean.setHeaderDialogo("Programa de Colocaci�n");
				detalleSolicitudBean.setMensajeDialogo("Programa de Colocaci�n Exitosa.");
				seleccionadoSemana = "";
				actividad = "";
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli').show();");
			} else {
				detalleSolicitudBean.setHeaderDialogo("Programa de Colocaci�n");
				detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al crear la Solicitud.");
				seleccionadoSemana = "";
				actividad = "";
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
			}
		} else {
			detalleSolicitudBean.setHeaderDialogo("Programa de Colocaci�n");
			detalleSolicitudBean.setMensajeDialogo("Debes agregar una actividad.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
		}
	}

	public void completarColocacion(String[] values) {

		boolean solicitudModificada = proyectoService.updateEstadoSolicitud(solicitudDto.getFolio(), values[0]);

		if (solicitudModificada) {
			detalleSolicitudBean.insertarBitacora("");
			detalleSolicitudBean.setHeaderDialogo("Programa de Colocaci�n");
			detalleSolicitudBean.setMensajeDialogo("Programa de Colocaci�n Exitosa.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli').show();");
		} else {
			detalleSolicitudBean.setHeaderDialogo("Programa de Colocaci�n");
			detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al crear la Solicitud.");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjErrorSoli').show();");
		}
	}

	public void solicitarVerificacionColocacion(String estatus) {
		if (!areaUtilizadaPiso.trim().equals("") && areaUtilizadaPiso.trim().length() > 0
				&& ValidacionUtil.validaLongitud(areaUtilizadaPiso, 20)) {
			if (Double.parseDouble(areaUtilizadaPiso) <= 0) {
				// headerDialogo = "Solicitar Verificaci�n";
				// mensajeDialogo = "El valor del campo: �rea utilizada en piso debe ser mayor a
				// 0";
				detalleSolicitudBean.setHeaderDialogo("Solicitar Verificaci�n");
				detalleSolicitudBean.setMensajeDialogo("El valor del campo: �rea utilizada en piso debe ser mayor a 0");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
				return;
			}
			if (!espacioLineal.trim().equals("") && espacioLineal.trim().length() > 0
					&& ValidacionUtil.validaLongitud(espacioLineal, 20)) {
				if (Double.parseDouble(espacioLineal) <= 0) {
					// headerDialogo = "Solicitar Verificaci�n";
					// mensajeDialogo = "El valor del campo: Espacio lineal debe ser mayor a 0";
					detalleSolicitudBean.setHeaderDialogo("Solicitar Verificaci�n");
					detalleSolicitudBean
							.setMensajeDialogo("El valor del campo: �rea utilizada en piso debe ser mayor a 0");
					org.primefaces.context.RequestContext.getCurrentInstance()
							.execute("PF('dlgMsjWarningSoli').show();");
					return;
				}
				if (!revisionEquiposPiso.trim().equals("") && revisionEquiposPiso.trim().length() > 0
						&& ValidacionUtil.validaLongitud(revisionEquiposPiso, 20)) {
					if (!revisionEquiposTorre.trim().equals("") && revisionEquiposTorre.trim().length() > 0
							&& ValidacionUtil.validaLongitud(revisionEquiposTorre, 20)) {
						if (listaArchivosTablaVerificarColocacion.size() > 0) {
							if (this.cargaArchivosVerificacionEnRuta(solicitudDto.getFolio(), estatus,
									listaArchivoEventoVerificarColocacion)) {
								int countBitacora = colocacionService.consultaEstadoBitacora(solicitudDto.getFolio(),
										"SOLICITUD DE VERIFICACION GENERADA");
								VerificacionColocacionDto colocacion = new VerificacionColocacionDto();
								colocacion.setIdFolio(solicitudDto.getFolio());
								colocacion.setAreaPiso(areaUtilizadaPiso);
								colocacion.setEspacioLineal(espacioLineal);
								colocacion.setRevisionPiso(revisionEquiposPiso);
								colocacion.setRevisionTorre(revisionEquiposTorre);
								boolean crearVerificacion = false;
								if (countBitacora > 0) {
									crearVerificacion = colocacionService.corregirVerificacionColocacion(colocacion);
								} else {
									crearVerificacion = colocacionService.insertaVerificacionColocacion(colocacion);
								}

								boolean solicitudModificada = factibilidadService
										.modificarSitioEstado(solicitudDto.getFolio(), estatus);
								if (crearVerificacion && solicitudModificada) {
									detalleSolicitudBean.insertarBitacora("");
									// headerDialogo = "Solicitar Verificaci�n";
									// mensajeDialogo = "Se cre� la solicitud de Verificaci�n de Colocaci�n con
									// exito.";
									detalleSolicitudBean.setHeaderDialogo("Solicitar Verificaci�n");
									detalleSolicitudBean.setMensajeDialogo(
											"Se cre� la solicitud de Verificaci�n de Colocaci�n con exito");
									org.primefaces.context.RequestContext.getCurrentInstance()
											.execute("PF('dlgMsjExitoSoli').show();");
								} else {
									// headerDialogo = "Solicitar Verificaci�n";
									// mensajeDialogo = "Ocurri� un error al crear la solicitud de Verificaci�n de
									// Colocaci�n.";
									detalleSolicitudBean.setHeaderDialogo("Solicitar Verificaci�n");
									detalleSolicitudBean.setMensajeDialogo(
											"Ocurri� un error al crear la solicitud de Verificaci�n de Colocaci�n");
									org.primefaces.context.RequestContext.getCurrentInstance()
											.execute("PF('dlgMsjErrorSoli').show();");
								}
							} else {
								// headerDialogo = "Solicitar Verificaci�n";
								// mensajeDialogo = "Ocurri� un error al cargar los archivos.";
								detalleSolicitudBean.setHeaderDialogo("Solicitar Verificaci�n");
								detalleSolicitudBean.setMensajeDialogo("Ocurri� un error al cargar los archivos");
								org.primefaces.context.RequestContext.getCurrentInstance()
										.execute("PF('dlgMsjErrorSoli').show();");
							}
						} else {
							// headerDialogo = "Solicitar Verificaci�n";
							// mensajeDialogo = "Se debe cargar al menos un archivo para Solicitar
							// Verificaci�n.";
							detalleSolicitudBean.setHeaderDialogo("Solicitar Verificaci�n");
							detalleSolicitudBean.setMensajeDialogo(
									"Se debe cargar al menos un archivo para Solicitar Verificaci�n");
							org.primefaces.context.RequestContext.getCurrentInstance()
									.execute("PF('dlgMsjWarningSoli').show();");
						}
					} else {
						// headerDialogo = "Solicitar Verificaci�n";
						// mensajeDialogo = "Se debe cargar un valor correcto para el campo Revisi�n de
						// los equipos en torre.";
						detalleSolicitudBean.setHeaderDialogo("Solicitar Verificaci�n");
						detalleSolicitudBean.setMensajeDialogo(
								"Se debe cargar un valor correcto para el campo Revisi�n de los equipos en torre");
						org.primefaces.context.RequestContext.getCurrentInstance()
								.execute("PF('dlgMsjWarningSoli').show();");
					}
				} else {
					// headerDialogo = "Solicitar Verificaci�n";
					// mensajeDialogo = "Se debe cargar un valor correcto para el campo Revisi�n de
					// los equipos en piso.";
					detalleSolicitudBean.setHeaderDialogo("Solicitar Verificaci�n");
					detalleSolicitudBean.setMensajeDialogo(
							"Se debe cargar un valor correcto para el campo Revisi�n de los equipos en piso");
					org.primefaces.context.RequestContext.getCurrentInstance()
							.execute("PF('dlgMsjWarningSoli').show();");
				}
			} else {
				// headerDialogo = "Solicitar Verificaci�n";
				// mensajeDialogo = "Se debe cargar un valor correcto para el campo Espacio
				// lineal.";
				detalleSolicitudBean.setHeaderDialogo("Solicitar Verificaci�n");
				detalleSolicitudBean.setMensajeDialogo("Se debe cargar un valor correcto para el campo Espacio lineal");
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			}
		} else {
			// headerDialogo = "Solicitar Verificaci�n";
			// mensajeDialogo = "Se debe cargar un valor correcto para el campo �rea
			// utilizada en piso.";
			detalleSolicitudBean.setHeaderDialogo("Solicitar Verificaci�n");
			detalleSolicitudBean
					.setMensajeDialogo("Se debe cargar un valor correcto para el campo �rea utilizada en piso");
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
		}
	}

	public void cargaArchivoVerificarColocacion(FileUploadEvent event) {
		String rutaBase = "";
		String nombreArchivo = FilenameUtils.getName(event.getFile().getFileName());
		try {
			ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness
					.getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_INF);
			rutaBase = String.valueOf(configurationUtilsVo.getValor());
		} catch (TransactionalOVITException e) {
			rutaBase = "";
		}
		try {
			String nombreRepetido = "";
			for (int i = 0; i < listaArchivoEventoVerificarColocacion.size(); i++) {
				if (nombreArchivo
						.equalsIgnoreCase(listaArchivoEventoVerificarColocacion.get(i).getFile().getFileName())) {
					nombreRepetido = "true";
					break;
				}
			}
			if (!nombreRepetido.equals("true")) {
				SoliArchDto archivo = new SoliArchDto();
				archivo.setDescripcion("Verificacion Colocacion");
				archivo.setIdSeccion(0);
				archivo.setNombreArch(nombreArchivo);
				archivo.setRuta("");
				archivo.setTamanio(event.getFile().getSize() / 1024 + " kb");
				String nombre = userDetailsVo.getNombre() + " " + userDetailsVo.getApellidoPaterno() + " "
						+ userDetailsVo.getApellidoMaterno();
				archivo.setUsuario(nombre);
				archivo.setFechaCarga(dateFormatTime.format(new Date()));
				listaArchivosTablaVerificarColocacion.add(archivo);
				listaArchivoEventoVerificarColocacion.add(event);

				for (SoliArchDto fact : listaArchivosTablaVerificarColocacion) {
					if (nombreArchivo.equalsIgnoreCase(fact.getNombreArch())) {
						fact.setBotonEliminar("false");
					}
				}

				File directorioTemp = new File(rutaBase);
				if (!directorioTemp.exists()) {
					directorioTemp.mkdirs();
				}
				OutputStream out;
				try (InputStream in = event.getFile().getInputstream()) {
					out = new FileOutputStream(directorioTemp + "/" + nombreArchivo);
					byte[] buf = new byte[1024];
					int len;
					while ((len = in.read(buf)) > 0) {
						out.write(buf, 0, len);
					}
					in.close();
				}
				out.close();
				/***
				 * facesMessage.setDetail("Carga exitosa de documentos.");
				 * facesMessage.setSummary("Listo!");
				 * facesMessage.setSeverity(FacesMessage.SEVERITY_INFO);
				 ***/
				detalleSolicitudBean.setHeaderDialogo("Carga Documento");
				detalleSolicitudBean.setMensajeDialogo("Carga exitosa de documentos: " + nombreArchivo);
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjExitoSoli2').show();");
			} else {
				/***
				 * facesMessage.setDetail("No se puede cargar un archivo con el mismo nombre");
				 * facesMessage.setSummary("Advertencia!");
				 * facesMessage.setSeverity(FacesMessage.SEVERITY_WARN);
				 ***/
				detalleSolicitudBean.setHeaderDialogo("Carga Documento");
				detalleSolicitudBean
						.setMensajeDialogo("No se puede cargar un archivo con el mismo nombre: " + nombreArchivo);
				org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
			}
		} catch (IOException e) {
			/***
			 * facesMessage.setDetail("Ocurri� un error al cargar los documentos: " +
			 * e.getMessage()); facesMessage.setSummary("Error!");
			 * facesMessage.setSeverity(FacesMessage.SEVERITY_ERROR);
			 ***/
			detalleSolicitudBean.setHeaderDialogo("Carga Documento");
			detalleSolicitudBean
					.setMensajeDialogo("No se puede cargar un archivo con el mismo nombre: " + nombreArchivo);
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjWarningSoli').show();");
		}
	}

	public void verArchivoPrevioColocacionSoli(SoliArchDto archivo) {
		try {
			archivoDescarga = getArchivoFileByIdColocacionSoli(archivo);
		} catch (Exception error) {
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvmodalDescargaColoSoli').hide();");
			headerDialogo = "Descargar Documento";
			mensajeDialogo = "Ocurrio un error al descargar el documento";
			detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
		}
	}

	public DefaultStreamedContent getArchivoFileByIdColocacionSoli(SoliArchDto archivo) {
		FileUploadEvent arch = null;
		File file = null;
		InputStream inputStream = null;
		try {
			if (archivo.getRuta() == null || archivo.getRuta().equals("")) {
				for (int i = 0; i < listaArchivoEvento.size(); i++) {
					if (archivo.getNombreArch().equalsIgnoreCase(listaArchivoEvento.get(i).getFile().getFileName())) {
						arch = listaArchivoEvento.get(i);
						break;
					}
				}
				inputStream = arch.getFile().getInputstream();
			} else {
				file = new File(archivo.getRuta() + File.separator + archivo.getNombreArch());
				inputStream = new FileInputStream(file);
			}
		} catch (Exception e) {
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvmodalDescargaColoSoli').hide();");
			headerDialogo = "Descargar Documento";
			mensajeDialogo = "Ocurrio un error al descargar el documento";
			detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
		}
		return new DefaultStreamedContent(inputStream, "application/octet-stream", archivo.getNombreArch());
	}

	public void verArchivoPrevioVeriColo(SoliArchDto archivo) {
		try {
			archivoDescarga = getArchivoFileByIdVeriColo(archivo);
		} catch (Exception error) {
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvmodalDescargaVeriColo').hide();");
			headerDialogo = "Descargar Documento";
			mensajeDialogo = "Ocurrio un error al descargar el documento";
			detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
		}
	}

	public DefaultStreamedContent getArchivoFileByIdVeriColo(SoliArchDto archivo) {
		FileUploadEvent arch = null;
		File file = null;
		InputStream inputStream = null;
		try {
			if (archivo.getRuta().equals("")) {
				for (int i = 0; i < listaArchivoEventoVerificarColocacion.size(); i++) {
					if (archivo.getNombreArch()
							.equalsIgnoreCase(listaArchivoEventoVerificarColocacion.get(i).getFile().getFileName())) {
						arch = listaArchivoEventoVerificarColocacion.get(i);
						break;
					}
				}
				inputStream = arch.getFile().getInputstream();
			} else {
				file = new File(archivo.getRuta() + File.separator + archivo.getNombreArch());
				inputStream = new FileInputStream(file);
			}
		} catch (Exception e) {
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvmodalDescargaVeriColo').hide();");
			headerDialogo = "Descargar Documento";
			mensajeDialogo = "Ocurrio un error al descargar el documento";
			detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
		}
		return new DefaultStreamedContent(inputStream, "application/octet-stream", archivo.getNombreArch());
	}

	public void verArchivoPrevioVeriColoFact(SoliArchDto archivo) {
		try {
			archivoDescarga = getArchivoFileByIdVeriColoFact(archivo);
		} catch (Exception error) {
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvmodalDescargaVeriColo').hide();");
			headerDialogo = "Descargar Documento";
			mensajeDialogo = "Ocurrio un error al descargar el documento";
			detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
		}
	}

	public DefaultStreamedContent getArchivoFileByIdVeriColoFact(SoliArchDto archivo) {
		FileUploadEvent arch = null;
		File file = null;
		InputStream inputStream = null;
		try {
			if (archivo.getRuta().equals("")) {
				for (int i = 0; i < listaArchivosVcFactEvento.size(); i++) {
					if (archivo.getNombreArch()
							.equalsIgnoreCase(listaArchivosVcFactEvento.get(i).getFile().getFileName())) {
						arch = listaArchivosVcFactEvento.get(i);
						break;
					}
				}
				inputStream = arch.getFile().getInputstream();
			} else {
				file = new File(archivo.getRuta() + File.separator + archivo.getNombreArch());
				inputStream = new FileInputStream(file);
			}
		} catch (Exception e) {
			org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('wvmodalDescargaVeriColo').hide();");
			headerDialogo = "Descargar Documento";
			mensajeDialogo = "Ocurrio un error al descargar el documento";
			detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
		}
		return new DefaultStreamedContent(inputStream, "application/octet-stream", archivo.getNombreArch());
	}

	public void eliminaArchivoVerificarColocacion(SoliArchDto archivo) {
		FileUploadEvent tempEvento = null;
		for (FileUploadEvent t : listaArchivoEventoVerificarColocacion) {
			if (t.getFile().getFileName().equals(archivo.getNombreArch())) {
				tempEvento = t;
				break;
			}
		}
		listaArchivoEventoVerificarColocacion.remove(tempEvento);
		SoliArchDto tempArch = new SoliArchDto();
		for (SoliArchDto t : listaArchivosTablaVerificarColocacion) {
			if (t.getNombreArch().equals(archivo.getNombreArch())) {
				tempArch = t;
			}
		}
		listaArchivosTablaVerificarColocacion.remove(tempArch);

		String rutaBase = "";
		try {
			ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness
					.getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_INF);
			rutaBase = String.valueOf(configurationUtilsVo.getValor());
		} catch (TransactionalOVITException e) {
			rutaBase = "";
		}
		File archivoFisico = new File(rutaBase + archivo.getNombreArch());
		if (archivoFisico.exists()) {
			archivoFisico.delete();
		}
	}

	public void finalizarSolicitudColocacion(String estatus) {
		boolean colocacionModificada = proyectoService.updateEstadoSolicitud(solicitudDto.getFolio(), estatus);
		if (colocacionModificada) {
			registrarSuscripcionSiAplica();
			detalleSolicitudBean.insertarBitacora("");
			registrarSuscripcionSitioConcesionario();
			headerDialogo = "Verificaci�n Colocaci�n";
			mensajeDialogo = "Se finaliz� la solicitud con �xito.";
			detalleSolicitudBean.mensajeExito(headerDialogo, mensajeDialogo);
//			org.primefaces.context.RequestContext.getCurrentInstance()
//					.execute("PF('dlgMsjExitoVC').show();");
		} else {
			headerDialogo = "Verificaci�n Colocaci�n";
			mensajeDialogo = "Ocurri� un error al actualizar el estatus de la solicitud.";
			detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
//			org.primefaces.context.RequestContext.getCurrentInstance()
//					.execute("PF('dlgMsjErrorVC').show();");
		}
	}

	// registroSuscripcion
	private void registrarSuscripcionSiAplica() {
	    if (suscripcionSitioService == null) {
	        LOGGER.warn("SuscripcionSitioService no est� disponible; no se registrar� suscripci�n.");
	        return;
	    }

	    if (solicitudDto == null) {
	        return;
	    }

	    String idSitio = solicitudDto.getSitio();
	    String folioSolicitud = solicitudDto.getFolio();

	    // IMPORTANTE: usar GRUPO_OPERADOR como identificador consistente del concesionario
	    String concesionario = solicitudDto.getGrupoOperador();
	    if (concesionario == null || concesionario.trim().isEmpty()) {
	        concesionario = solicitudDto.getConcesionario(); // fallback defensivo
	    }

	    if (idSitio == null || idSitio.trim().isEmpty()
	            || concesionario == null || concesionario.trim().isEmpty()
	            || folioSolicitud == null || folioSolicitud.trim().isEmpty()) {
	        return;
	    }

	    try {
	        suscripcionSitioService.registrarSuscripcion(idSitio, concesionario, folioSolicitud);
	        LOGGER.info("Suscripci�n registrada/validada para sitio {} y concesionario {} (folio {}).",
	                idSitio, concesionario, folioSolicitud);
	    } catch (Exception exception) {
	        LOGGER.error("No se pudo registrar suscripci�n para sitio {} y concesionario {} (folio {}).",
	                idSitio, concesionario, folioSolicitud, exception);
	    }
	}


	public void rechazarSolicitudVc() {
		try {
			rechazarVerificacionColocacion(
					proyectoService.consultaIdEstadoBitacora("SOLICITUD VERIFICACION RECHAZADA"));
		} catch (Exception e) {
			headerDialogo = "Rechazar Proyecto y Presupuesto";
			mensajeDialogo = "Ocurri� un error al rechazar la verificaci�n de colocaci�n.";
			detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
		}
	}

	public void rechazarVerificacionColocacion(String estatus) {
		// int countBitacora =
		// colocacionService.consultaEstadoBitacora(solicitudDto.getFolio(), "SOLICITUD
		// DE VERIFICACION RECHAZADA");

		if (ValidacionUtil.isEmpty(motivoVc)) {
			headerDialogo = "Verificaci�n Rechazada";
			mensajeDialogo = "Favor de ingresar un valor en el campo observaciones.";
			detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
			return;
		}

		if (!ValidacionUtil.validarCaracteres(motivoVc)) {
			headerDialogo = "Verificaci�n Rechazada";
			mensajeDialogo = "No se permiten caracteres especiales en: motivo rechazo.";
			detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
			return;
		}
		/***
		 * if (countBitacora > 0) { estatus = "33"; }
		 ***/
		VerificacionColocacionDto colocacion = new VerificacionColocacionDto();
		colocacion.setIdFolio(solicitudDto.getFolio());
		colocacion.setObservacionesVerificacion(motivoVc);
		boolean colocacionModificada = colocacionService.updateVerificacionColocacion(colocacion);
		boolean solicitudModificada = proyectoService.updateEstadoSolicitud(solicitudDto.getFolio(), estatus);
		if (solicitudModificada && colocacionModificada) {
			detalleSolicitudBean.insertarBitacora(motivoVc);
			headerDialogo = "Verificaci�n Rechazada";
			mensajeDialogo = "Se rechaz� la solicitud con �xito.";
			detalleSolicitudBean.mensajeExito(headerDialogo, mensajeDialogo);
		} else {
			headerDialogo = "Verificaci�n Rechazada";
			mensajeDialogo = "Ocurri� un error al actualizar el estatus de la solicitud.";
			detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
		}
	}

	public void corregirVerificacionColocacion(String estatus) {
		if (!areaUtilizadaPiso.trim().equals("") && areaUtilizadaPiso.trim().length() > 0) {
			if (Double.parseDouble(areaUtilizadaPiso) <= 0) {
				headerDialogo = "Solicitar Verificaci�n";
				mensajeDialogo = "El valor del campo: �rea utilizada en piso debe ser mayor a 0";
				detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
				return;
			}
			if (!espacioLineal.trim().equals("") && espacioLineal.trim().length() > 0) {
				if (Double.parseDouble(espacioLineal) <= 0) {
					headerDialogo = "Solicitar Verificaci�n";
					mensajeDialogo = "El valor del campo: �rea utilizada en piso debe ser mayor a 0";
					detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
					return;
				}
				if (!revisionEquiposPiso.trim().equals("") && revisionEquiposPiso.trim().length() > 0) {
					if (!revisionEquiposTorre.trim().equals("") && revisionEquiposTorre.trim().length() > 0) {
						if (listaArchivoEventoVerificarColocacion.size() > 0) {
							edicionVerificacionColocacionArchivos();
							VerificacionColocacionDto colocacion = new VerificacionColocacionDto();
							colocacion.setIdFolio(solicitudDto.getFolio());
							colocacion.setAreaPiso(areaUtilizadaPiso);
							colocacion.setEspacioLineal(espacioLineal);
							colocacion.setRevisionPiso(revisionEquiposPiso);
							colocacion.setRevisionTorre(revisionEquiposTorre);
							boolean actualizarVerificacion = colocacionService
									.corregirVerificacionColocacion(colocacion);
							boolean solicitudModificada = factibilidadService
									.modificarSitioEstado(solicitudDto.getFolio(), estatus);
							if (actualizarVerificacion && solicitudModificada) {
								detalleSolicitudBean.insertarBitacora("");
								headerDialogo = "Corregir Verificaci�n";
								mensajeDialogo = "Se actualiz� la solicitud de Verificaci�n de Colocaci�n con exito.";
								detalleSolicitudBean.mensajeExito(headerDialogo, mensajeDialogo);
							} else {
								headerDialogo = "Corregir Verificaci�n";
								mensajeDialogo = "Ocurri� un error al actualizar la solicitud de Verificaci�n de Colocaci�n.";
								detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
							}
						} else {
							headerDialogo = "Solicitar Verificaci�n";
							mensajeDialogo = "Se debe cargar al menos un archivo para Solicitar Verificaci�n.";
							detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
						}
					} else {
						headerDialogo = "Solicitar Verificaci�n";
						mensajeDialogo = "Se debe cargar un valor para el campo Revisi�n de los equipos en torre.";
						detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
					}
				} else {
					headerDialogo = "Solicitar Verificaci�n";
					mensajeDialogo = "Se debe cargar un valor para el campo Revisi�n de los equipos en piso.";
					detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
				}
			} else {
				headerDialogo = "Solicitar Verificaci�n";
				mensajeDialogo = "Se debe cargar un valor para el campo Espacio lineal.";
				detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
			}
		} else {
			headerDialogo = "Solicitar Verificaci�n";
			mensajeDialogo = "Se debe cargar un valor para el campo �rea utilizada en piso.";
			detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
		}
	}

	public void uploadArchivoVcFact(FileUploadEvent event) {
		String fileName = FilenameUtils.getName(event.getFile().getFileName());
		String nombreRepetido = "";
		try {

			for (int i = 0; i < listaArchivosVcFactEvento.size(); i++) {
				if (fileName.equalsIgnoreCase(listaArchivosVcFactEvento.get(i).getFile().getFileName())) {
					nombreRepetido = "true";
					break;
				}
			}

			for (int i = 0; i < listaArchivosVcFact.size(); i++) {
				if (fileName.equalsIgnoreCase(listaArchivosVcFact.get(i).getNombreArch())) {
					nombreRepetido = "true";
					break;
				}
			}

			if (!nombreRepetido.equals("true")) {
				SoliArchDto archivo = new SoliArchDto();
				// archivo.setIdArchivo(listaArchSoli.size());
				archivo.setDescripcion("Facturacion Colocacion");
				archivo.setIdSeccion(0);
				archivo.setNombreArch(fileName);
				archivo.setRuta("");
				archivo.setTamanio(event.getFile().getSize() / 1024 + " kb");
				String nombre = userDetailsVo.getNombre() + " " + userDetailsVo.getApellidoPaterno() + " "
						+ userDetailsVo.getApellidoMaterno();
				archivo.setUsuario(nombre);
				archivo.setFechaCarga(dateFormatTime.format(new Date()));
				listaArchivosVcFact.add(archivo);
				listaArchivosVcFactEvento.add(event);

				headerDialogo = "Carga de Documento";
				mensajeDialogo = "Carga exitosa del documento " + fileName;
				detalleSolicitudBean.mensajeConfirmacion(headerDialogo, mensajeDialogo);
			} else {
				headerDialogo = "Carga de Documento";
				mensajeDialogo = "No se puede cargar un archivo con el mismo nombre " + fileName;
				detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
			}
		} catch (Exception e) {
			headerDialogo = "Carga de Documento";
			mensajeDialogo = "Ocurri� un error al cargar el documento " + fileName;
			detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
		}
	}

	public void descargarArchivoFactVC(String rutaArchivo, String nombre) {
		FacesContext context = FacesContext.getCurrentInstance();
		FileUploadEvent arch = null;
		File file = null;
		if (rutaArchivo.equals("")) {
			for (int i = 0; i < listaArchivosVcFactEvento.size(); i++) {
				if (nombre.equalsIgnoreCase(listaArchivosVcFactEvento.get(i).getFile().getFileName())) {
					arch = listaArchivosVcFactEvento.get(i);
					break;
				}
			}
			String nombreAux = FilenameUtils.getName(arch.getFile().getFileName());
			HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();
			response.reset();
			response.setHeader("Content-Type", "application/octet-stream"); // Tipo gen�rico para archivos binarios
			response.setHeader("Content-Disposition", "attachment;filename=\"" + nombreAux + "\""); // Nombre de archivo
																									// para la descarga
			response.setContentLength((int) arch.getFile().getSize()); // Establecer el tama�o del archivo
			response.setContentType(arch.getFile().getContentType());

			// Enviar el archivo al navegador
			try (InputStream in = arch.getFile().getInputstream(); OutputStream out = response.getOutputStream()) {

				byte[] buffer = new byte[1024]; // Buffer para leer el archivo en trozos
				int bytesRead;
				while ((bytesRead = in.read(buffer)) != -1) {
					out.write(buffer, 0, bytesRead); // Escribir los bytes en la respuesta HTTP
				}

				// Finalizar la respuesta
				context.responseComplete();
			} catch (IOException e) {
				headerDialogo = "Descargar Documento";
				mensajeDialogo = "Hubo un problema al descargar el documento";
				detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
			}
		} else {
			file = new File(rutaArchivo + File.separator + nombre);

			if (file.exists()) {

				HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();
				response.reset();
				response.setHeader("Content-Type", "application/octet-stream");
				response.setHeader("Content-Disposition", "attachment;filename=\"" + nombre + "\"");
				response.setContentLength((int) file.length());

				try (InputStream in = new FileInputStream(file); OutputStream out = response.getOutputStream()) {

					byte[] buffer = new byte[1024];
					int bytesRead;
					while ((bytesRead = in.read(buffer)) != -1) {
						out.write(buffer, 0, bytesRead);
					}

					context.responseComplete();
				} catch (IOException e) {
					headerDialogo = "Descargar Documento";
					mensajeDialogo = "Hubo un problema al descargar el documento";
					detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
				}
			} else {
				headerDialogo = "Descargar Documento";
				mensajeDialogo = "No existe el archivo en la ruta especificada";
				detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
			}
		}
	}

	public void confirmacionEliminacionFact(SoliArchDto archivo) {
		this.archivoFact = archivo;
	}

	public void eliminarArchivoVcFact() {
		try {
			for (int i = 0; i < listaArchivosVcFactEvento.size(); i++) {
				String nombre = FilenameUtils.getName(listaArchivosVcFactEvento.get(i).getFile().getFileName());
				if (nombre.equalsIgnoreCase(archivoFact.getNombreArch())) {
					listaArchivosVcFactEvento.remove(i);
				}
			}

			headerDialogo = "Eliminar Documento";
			mensajeDialogo = "Eliminaci�n exitosa de documento: " + archivoFact.getNombreArch();
			listaArchivosVcFact.remove(archivoFact);
			this.archivoFact = new SoliArchDto();
			detalleSolicitudBean.mensajeConfirmacion(headerDialogo, mensajeDialogo);
		} catch (Exception e) {
			LOGGER.info("Ocurrio un error al eliminar los archivos " + e);
			headerDialogo = "Eliminar Documento";
			mensajeDialogo = "Ocurri� un error al eliminar el documento";
			detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
		}
	}

	public void facturacionColocacionGenerada(String estatus) throws TransactionalOVITException {
		if (!areaUtilizadaPiso.trim().equals("") && areaUtilizadaPiso.trim().length() > 0) {
			if (Double.parseDouble(areaUtilizadaPiso) <= 0) {
				headerDialogo = "Solicitar Verificaci�n";
				mensajeDialogo = "El valor del campo: �rea utilizada en piso debe ser mayor a 0";
				detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
				return;
			}
			if (!espacioLineal.trim().equals("") && espacioLineal.trim().length() > 0) {
				if (Double.parseDouble(espacioLineal) <= 0) {
					headerDialogo = "Solicitar Verificaci�n";
					mensajeDialogo = "El valor del campo: �rea utilizada en piso debe ser mayor a 0";
					detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
					return;
				}
				if (!revisionEquiposPiso.trim().equals("") && revisionEquiposPiso.trim().length() > 0) {
					if (!revisionEquiposTorre.trim().equals("") && revisionEquiposTorre.trim().length() > 0) {
						if (listaArchivosVcFactEvento.size() > 0 && listaArchivosVcFact.size() > 0) {
							ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness
									.getConstantOfDataBase(
											ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_PROYECTO_PRESUPUESTO);
							String ruta = String.valueOf(configurationUtilsVo.getValor()) + solicitudDto.getFolio()
									+ File.separator + solicitudDto.getIdEstado();
							boolean archivoSubido = false;
							boolean archivoGuardado = false;
							for (FileUploadEvent fileUploadEvent : listaArchivosVcFactEvento) {

								String fileName = null;
								InputStream inputStream = null;
								fileName = FilenameUtils.getName(fileUploadEvent.getFile().getFileName());
								T3SegdSoliArch archivo = new T3SegdSoliArch();
								archivo.setIdFolio(solicitudDto.getFolio());
								archivo.setDescripcion("Facturacion Colocacion");
								archivo.setIdSeccion(0);
								archivo.setNombreArchivo(fileName);
								archivo.setRuta(ruta);
								archivo.setRevision("1");
								archivo.setTamanio(fileUploadEvent.getFile().getSize() / 1024 + " kb");
								archivo.setUsuario(userDetailsVo.getIdUsuario());
								archivo.setFechaCarga(new Date());

								File directorioTemp = new File(ruta);
								if (!directorioTemp.exists()) {
									directorioTemp.mkdirs();
								}
								try {
									inputStream = fileUploadEvent.getFile().getInputstream();
								} catch (IOException e) {
									headerDialogo = "Solicitud pago Colocaci�n";
									mensajeDialogo = "Error al cargar el archivo en la ruta " + ruta;
									detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
								}
								String rutaA = directorioTemp.getPath() + File.separator + fileName;
								File verificaSiExiste = new File(rutaA);
								archivoGuardado = proyectoService.guardarArchivo(archivo);
								archivoSubido = subirArchivo(inputStream, verificaSiExiste);
								if (!archivoGuardado || !archivoSubido) {
									break;
								}
							}
							// edicionVerificacionColocacionArchivos();
							VerificacionColocacionDto colocacion = new VerificacionColocacionDto();
							colocacion.setIdFolio(solicitudDto.getFolio());
							colocacion.setAreaPiso(areaUtilizadaPiso);
							colocacion.setEspacioLineal(espacioLineal);
							colocacion.setRevisionPiso(revisionEquiposPiso);
							colocacion.setRevisionTorre(revisionEquiposTorre);
							boolean actualizarVerificacion = colocacionService
									.corregirVerificacionColocacion(colocacion);
							boolean solicitudModificada = factibilidadService
									.modificarSitioEstado(solicitudDto.getFolio(), estatus);
							if (actualizarVerificacion && solicitudModificada) {
								detalleSolicitudBean.insertarBitacora("");
								headerDialogo = "Corregir Verificaci�n";
								mensajeDialogo = "Se actualiz� la solicitud de Verificaci�n de Colocaci�n con exito.";
								detalleSolicitudBean.mensajeExito(headerDialogo, mensajeDialogo);
							} else {
								headerDialogo = "Corregir Verificaci�n";
								mensajeDialogo = "Ocurri� un error al actualizar la solicitud de Verificaci�n de Colocaci�n.";
								detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
							}
						} else {
							headerDialogo = "Solicitar Verificaci�n";
							mensajeDialogo = "Se debe cargar al menos un archivo para Solicitar Verificaci�n.";
							detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
						}
					} else {
						headerDialogo = "Solicitar Verificaci�n";
						mensajeDialogo = "Se debe cargar un valor para el campo Revisi�n de los equipos en torre.";
						detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
					}
				} else {
					headerDialogo = "Solicitar Verificaci�n";
					mensajeDialogo = "Se debe cargar un valor para el campo Revisi�n de los equipos en piso.";
					detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
				}
			} else {
				headerDialogo = "Solicitar Verificaci�n";
				mensajeDialogo = "Se debe cargar un valor para el campo Espacio lineal.";
				detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
			}
		} else {
			headerDialogo = "Solicitud pago Colocaci�n";
			mensajeDialogo = "Se debe de cargar al menos un archivo.";
			detalleSolicitudBean.mensajeWarning(headerDialogo, mensajeDialogo);
		}
	}

	private static boolean subirArchivo(InputStream origen, File destino) {
		OutputStream out = null;
		try {
			InputStream in = origen;
			out = new FileOutputStream(destino);

			byte[] buf = new byte[1024];
			int len;

			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			in.close();
			out.close();
		} catch (IOException e) {
			return false;
		} finally {
			close(out);
		}
		return true;
	}

	private static void close(Closeable closable) {
		try {
			if (closable != null) {
				closable.close();
			}
		} catch (IOException e) {
			System.err.println("Error al cerrar OutputStream: " + e);
		}
	}

	public void avanzarEstatusColocacion(String[] values, SolicitudDto parametroSolicitud) {
		RequestContext requestContext = RequestContext.getCurrentInstance();
		if (values[0].equals(SOLICITUD_COLOCACION_RECHAZADA) && values[2].equals(ACCION_RECHAZAR_SOLICITUD)) {
			requestContext.execute("PF('dlgRechazoSolCol').show();");
		} else if (values[0].equals(SOLICITUD_COLOCACION_GENERADA) && values[2].equals(ACCION_SOLICITAR_COLOCACION)) {
			if (validacionSolicitudColocacion(SOLICITUD_COLOCACION_GENERADA)) {
				if (colocacionService.insertaPrincipalSolicitudColocacion(parametroSolicitud.getFolio(), RFcalibre,
						MWcalibre, superficie, transformador, observaciones, observacionesTelcel)) {
					if (colocacionService.insertaSolicitudColocacionEspacioTorre(parametroSolicitud.getFolio(),
							listaEspacioEnTorre)) {
						if (colocacionService.insertaSolicitudColocacionEspacioPiso(parametroSolicitud.getFolio(),
								listaEspacioEnPiso)) {
							if (this.cargaArchivosEnRuta(parametroSolicitud.getFolio(), SOLICITUD_COLOCACION_GENERADA,
									listaArchivoEvento)) {
								actualizaSolicitud(parametroSolicitud.getFolio(), SOLICITUD_COLOCACION_GENERADA,
										ACCION_SOLICITAR_COLOCACION);
								detalleSolicitudBean.insertarBitacora("");
							} else {
								headerDialogo = "Solicitud de Colocaci�n";
								mensajeDialogo = "No se pudieron crear archivos, contactar administrador. No hay cambios.";
								detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
//                                requestContext.execute("PF('dlgColocacionMsjErrorR').show();");
							}
						} else {
							headerDialogo = "Solicitud de Colocaci�n";
							mensajeDialogo = "No se pudo registrar Espacio en Piso, contactar administrador. No hay cambios.";
							detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
//                            requestContext.execute("PF('dlgColocacionMsjErrorR').show();");
						}
					} else {
						headerDialogo = "Solicitud de Colocaci�n";
						mensajeDialogo = "No se pudo registrar Espacio en Torre, contactar administrador. No hay cambios.";
						detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
//                        requestContext.execute("PF('dlgColocacionMsjErrorR').show();");
					}
				} else {
					headerDialogo = "Solicitud de Colocaci�n";
					mensajeDialogo = "No se pudo registrar Solicitud Colocaci�n, contactar administrador. No hay cambios.";
					detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
//                    requestContext.execute("PF('dlgColocacionMsjErrorR').show();");
				}
			}
		} else if (values[0].equals(SOLICITUD_COLOCACION_CORREGIDA) && values[2].equals(ACCION_SOLICITAR_COLOCACION)) {
			observaciones = "";
			edicionSolicitudColocacionArchivos();
			edicionSolicitudColocacionEspacioTorre();
			edicionSolicitudColocacionEspacioPiso();
			colocacionService.actualizaPrincipalSolicitudColocacion(parametroSolicitud.getFolio(), RFcalibre, MWcalibre,
					superficie, transformador, observaciones, observacionesTelcel);
			detalleSolicitudBean.insertarBitacora("");
			actualizaSolicitud(parametroSolicitud.getFolio(), SOLICITUD_COLOCACION_CORREGIDA,
					ACCION_SOLICITAR_VERIFICACION);
		} else if (values[0].equals(SOLICITUD_COLOCACION_AUTORIZADA) && values[2].equals(ACCION_CARGAR_ACUERDO)) {
			if (listaArchivoEvento.size() > 0 && listaArchivosTabla.size() > 0) {
				edicionSolicitudColocacionArchivos();
				actualizaSolicitud(parametroSolicitud.getFolio(), SOLICITUD_COLOCACION_AUTORIZADA,
						ACCION_CARGAR_ACUERDO);
				detalleSolicitudBean.insertarBitacora("");
			} else {
				headerDialogo = "Solicitud de Colocaci�n";
				mensajeDialogo = "Es necesario cargar el acuerdo de sitio";
				detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
//                requestContext.execute("PF('dlgColocacionMsjErrorR').show();");
			}
		} else if (values[0].equals(SOLICITUD_COLOCACION_ACUERDO_SITIO_FIRMADO)
				&& values[2].equals(ACCION_CARGAR_ACUERDO_FIRMADO)) {
			if (listaArchivoEvento.size() > 0 && listaArchivosTabla.size() > 0) {
				edicionSolicitudColocacionArchivos();
				actualizaSolicitud(parametroSolicitud.getFolio(), SOLICITUD_COLOCACION_ACUERDO_SITIO_FIRMADO,
						ACCION_CARGAR_ACUERDO_FIRMADO);
				detalleSolicitudBean.insertarBitacora("");
			} else {
				headerDialogo = "Solicitud de Colocaci�n";
				mensajeDialogo = "Es necesario cargar el acuerdo de sitio firmado";
				detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
//               requestContext.execute("PF('dlgColocacionMsjErrorR').show();");
			}
		} else if (values[0].equals(SOLICITUD_CANCELADA) && values[2].equals(ACCION_CANCELAR_SOLICITIUD)) {
			actualizaSolicitud(parametroSolicitud.getFolio(), SOLICITUD_CANCELADA, ACCION_CANCELAR_SOLICITIUD);
		}
	}

	public void rechazoSolicitud() {
		System.out.println(stringMotivoRechazo);
		observaciones = stringMotivoRechazo;
		if (validacionSolicitudColocacion(SOLICITUD_COLOCACION_RECHAZADA)) {
			if (colocacionService.actualizaPrincipalSolicitudColocacion(solicitudDto.getFolio(), RFcalibre, MWcalibre,
					superficie, transformador, observaciones, observacionesTelcel)) {
				detalleSolicitudBean.insertarBitacora(observaciones);
				if (actualizaSolicitud(solicitudDto.getFolio(), SOLICITUD_COLOCACION_RECHAZADA,
						ACCION_RECHAZAR_SOLICITUD)) {
					org.primefaces.context.RequestContext.getCurrentInstance()
							.execute("PF('dlgRechazoSolCol').hide();");
				}
			}
		}
	}

	private boolean actualizaSolicitud(String folio, String estado, String accion) {
		boolean sitio = false;
		if (estado.equals(SOLICITUD_COLOCACION_RECHAZADA) && accion.equals(ACCION_RECHAZAR_SOLICITUD)) {
			sitio = factibilidadService.modificarSitioEstado(folio, SOLICITUD_COLOCACION_RECHAZADA);
			if (sitio) {
				headerDialogo = "Solicitud de Colocaci\u00F3n: Rechazo";
				mensajeDialogo = "Rechazo de la Solicitud de Colocacion generado con \u00E9xito.";
				detalleSolicitudBean.mensajeExito(headerDialogo, mensajeDialogo);
//                org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjColocacionExitoR').show();");
			} else {
				headerDialogo = "Solicitud de Colocaci\u00F3n: Rechazo";
				mensajeDialogo = "Rechazo de la Solicitud de Colocacion no fue generado con \u00E9xito.";
				detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
//                org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgColocacionMsjErrorR').show();");
			}
		} else if (estado.equals(SOLICITUD_COLOCACION_GENERADA) && accion.equals(ACCION_SOLICITAR_COLOCACION)) {
			sitio = factibilidadService.modificarSitioEstado(folio, SOLICITUD_COLOCACION_GENERADA);
			if (sitio) {
				headerDialogo = "Solicitud de Colocaci\u00F3n: Generaci\u00F3n";
				mensajeDialogo = "Solicitud de Colocaci\u00F3n generada con \u00E9xito.";
				detalleSolicitudBean.mensajeExito(headerDialogo, mensajeDialogo);
//                org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjColocacionExitoR').show();");
			} else {
				headerDialogo = "Solicitud de Colocaci\u00F3n: Generaci\u00F3n";
				mensajeDialogo = "Solicitud de Colocaci\u00F3n no fue generada con \u00E9xito.";
				detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
//                org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgColocacionMsjErrorR').show();");
			}
		} else if (estado.equals(SOLICITUD_COLOCACION_CORREGIDA) && accion.equals(ACCION_SOLICITAR_VERIFICACION)) {
			sitio = factibilidadService.modificarSitioEstado(folio, SOLICITUD_COLOCACION_CORREGIDA);
			if (sitio) {
				headerDialogo = "Solicitud de Colocaci\u00F3n: Correcci\u00F3n";
				mensajeDialogo = "Correcion de la Solicitud de Colocaci\u00F3n generada con \u00E9xito.";
				detalleSolicitudBean.mensajeExito(headerDialogo, mensajeDialogo);
//                org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjColocacionExitoR').show();");
			} else {
				headerDialogo = "Solicitud de Colocaci\u00F3n: Correcci\u00F3n";
				mensajeDialogo = "Correcion de la Solicitud de Colocaci\u00F3n no fue generada con \u00E9xito.";
				detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
//                org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgColocacionMsjErrorR').show();");
			}
		} else if (estado.equals(SOLICITUD_COLOCACION_AUTORIZADA) && accion.equals(ACCION_CARGAR_ACUERDO)) {
			sitio = factibilidadService.modificarSitioEstado(folio, SOLICITUD_COLOCACION_AUTORIZADA);
			if (sitio) {
				headerDialogo = "Solicitud de Colocaci\u00F3n: Autorizaci\u00F3n";
				mensajeDialogo = "Autorizaci\u00F3n de la Solicitud de Colocaci\u00F3n generada con \u00E9xito.";
				detalleSolicitudBean.mensajeExito(headerDialogo, mensajeDialogo);
//                org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjColocacionExitoR').show();");
			} else {
				headerDialogo = "Solicitud de Colocaci\u00F3n: Autorizaci\u00F3n";
				mensajeDialogo = "Autorizaci\u00F3n de la Solicitud de Colocaci\u00F3n no fue generada con \u00E9xito.";
				detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
//                org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgColocacionMsjErrorR').show();");
			}
		} else if (estado.equals(SOLICITUD_COLOCACION_ACUERDO_SITIO_FIRMADO)
				&& accion.equals(ACCION_CARGAR_ACUERDO_FIRMADO)) {
			sitio = factibilidadService.modificarSitioEstado(folio, SOLICITUD_COLOCACION_ACUERDO_SITIO_FIRMADO);
			if (sitio) {
				headerDialogo = "Solicitud de Colocaci\u00F3n: Autorizaci\u00F3n";
				mensajeDialogo = "Carga de Acuerdo Firmado generado con \u00E9xito.";
				detalleSolicitudBean.mensajeExito(headerDialogo, mensajeDialogo);
//                org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjColocacionExitoR').show();");
			} else {
				headerDialogo = "Solicitud de Colocaci\u00F3n: Autorizaci\u00F3n";
				mensajeDialogo = "Carga de Acuerdo Firmado no fue generado con \u00E9xito.";
				detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
//                org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgColocacionMsjErrorR').show();");
			}
		} else if (estado.equals(SOLICITUD_CANCELADA) && accion.equals(ACCION_CANCELAR_SOLICITIUD)) {
			sitio = factibilidadService.modificarSitioEstado(folio, SOLICITUD_CANCELADA);
			if (sitio) {
				headerDialogo = "Cancelaci\u00F3n Solicitud";
				mensajeDialogo = "Cancelaci\u00F3n de la solicitud generada con \u00E9xito.";
				detalleSolicitudBean.mensajeExito(headerDialogo, mensajeDialogo);
//                org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgMsjColocacionExitoR').show();");
			} else {
				headerDialogo = "Cancelaci\u00F3n de Solicitud";
				mensajeDialogo = "Cancelaci\u00F3n de la solicitud no fue generada con \u00E9xito.";
				detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
//                org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgColocacionMsjErrorR').show();");
			}
		}
		return sitio;
	}

	private boolean validacionSolicitudColocacion(String estado) {
		listaErrores = new ArrayList<>();
		boolean indicador = false;
		String concatenacionDeResultados = "";
		if (estado.equals(SOLICITUD_COLOCACION_GENERADA)) {
			for (ColocacionTablaEspacioTorreDTO tabla : listaEspacioEnTorre) {
				if (tabla.getFrecuenciasRX() == null || tabla.getFrecuenciasTX() == null || tabla.getNcr() == null
						|| tabla.getOrientacion() == null) {
					concatenacionDeResultados += "false";
					listaErrores.add("Los valores se encuentran incompletos para: Tabla Espacio en Torre.");
					break;
				}
			}
			if (listaEspacioEnTorre != null && !listaEspacioEnTorre.isEmpty()) {
				concatenacionDeResultados += "true";
			} else {
				concatenacionDeResultados += "false";
				listaErrores.add("Se debe especificar un valor para: Tabla Espacio en Torre.");
			}
			if (listaEspacioEnPiso != null && !listaEspacioEnPiso.isEmpty()) {
				concatenacionDeResultados += "true";
			} else {
				concatenacionDeResultados += "false";
				listaErrores.add("Se debe especificar un valor para: Tabla Espacio en Piso.");
			}
			if (RFcalibre != null && !RFcalibre.isEmpty()) {
				concatenacionDeResultados += "true";
			} else {
				concatenacionDeResultados += "false";
				listaErrores.add("Se debe especificar un valor para: Linea de transmisi�n RF calibre.");
			}
			if (ValidacionUtil.validaLongitud(RFcalibre, 20)) {
				concatenacionDeResultados += "true";
			} else {
				concatenacionDeResultados += "false";
				listaErrores.add("Solo se permiten 20 car�cteres en: Linea de transmisi�n RF calibre.");
			}
			if (ValidacionUtil.validarCaracteres(RFcalibre)) {
				concatenacionDeResultados += "true";
			} else {
				concatenacionDeResultados += "false";
				listaErrores.add("No se permiten car�teres especiales en: Linea de transmisi�n RF calibre.");
			}
			if (MWcalibre != null && !MWcalibre.isEmpty()) {
				concatenacionDeResultados += "true";
			} else {
				concatenacionDeResultados += "false";
				listaErrores.add("Se debe especificar un valor para: Linea de transmisi�n MW calibre.");
			}
			if (ValidacionUtil.validaLongitud(MWcalibre, 20)) {
				concatenacionDeResultados += "true";
			} else {
				concatenacionDeResultados += "false";
				listaErrores.add("Solo se permiten 20 car�cteres en: Linea de transmisi�n MW calibre.");
			}
			if (ValidacionUtil.validarCaracteres(MWcalibre)) {
				concatenacionDeResultados += "true";
			} else {
				concatenacionDeResultados += "false";
				listaErrores.add("No se permiten car�1teres especiales en: Linea de transmisi�n MW calibre.");
			}
			if (superficie != null && !superficie.isEmpty()) {
				concatenacionDeResultados += "true";
			} else {
				concatenacionDeResultados += "false";
				listaErrores.add("Se debe especificar un valor para: Superficie.");
			}
			if (ValidacionUtil.validaLongitud(superficie, 20)) {
				concatenacionDeResultados += "true";
			} else {
				concatenacionDeResultados += "false";
				listaErrores.add("Solo se permiten 20 car�1cteres en: Superficie.");
			}
			if (!validarCampoNumericoMayorCeroAvanzaStatus(superficie, "Superficie")) {
				concatenacionDeResultados += "true";
			} else {
				concatenacionDeResultados += "false";
				listaErrores.add("El valor del campo Superficie no debe ser menor o igual a cero.");
			}
			if (transformador != null && !transformador.isEmpty()) {
				concatenacionDeResultados += "true";
			} else {
				concatenacionDeResultados += "false";
				listaErrores.add("Se debe especificar un valor para: Capacidad de Transformador.");
			}
			if (ValidacionUtil.validaLongitud(transformador, 20)) {
				concatenacionDeResultados += "true";
			} else {
				concatenacionDeResultados += "false";
				listaErrores.add("Solo se permiten 20 car�1cteres en: Capacidad de Transformador.");
			}
			if (!validarCampoNumericoMayorCeroAvanzaStatus(transformador, "Superficie")) { /// realiozar ajuste
				concatenacionDeResultados += "true";
			} else {
				concatenacionDeResultados += "false";
				listaErrores.add("El valor del campo Capacidad de Transformador no debe ser menor o igual a cero.");
			}

			if (!listaArchivosTabla.isEmpty()) {
				if (listaArchivoEvento.size() == listaArchivosTabla.size()) {
					concatenacionDeResultados += "true";
				} else {
					concatenacionDeResultados += "false";
					listaErrores.add("La carga de archivos no es posible, elimine y vuelva a cargarlos.");
				}
			}

			if (concatenacionDeResultados.contains("false")) {
//                headerDialogo = "Solicitud de Colocaci\u00F3n: Generaci\u00F3n";
//                mensajeDialogo = mensaje;
//                detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
				org.primefaces.context.RequestContext.getCurrentInstance()
						.execute("PF('wvdlgValidacionesColocacion').show();");
				indicador = false;
			} else {
				indicador = true;
			}

		} else if (estado.equals(SOLICITUD_COLOCACION_RECHAZADA)) {
			if (!observaciones.isEmpty() && !observaciones.trim().equals("")) {
				concatenacionDeResultados += "true";
			} else {
				concatenacionDeResultados += "false";
				listaErrores.add("Se debe especificar un valor para: Motivo Rechazo.");
			}
			if (ValidacionUtil.validaLongitud(observaciones, 250)) {
				concatenacionDeResultados += "true";
			} else {
				concatenacionDeResultados += "false";
				listaErrores.add("Solo se permiten 250 car�1cteres en: Motivo Rechazo.");
			}
			if (ValidacionUtil.validarCaracteres(observaciones)) {
				concatenacionDeResultados += "true";
			} else {
				if (!observaciones.isEmpty() && !observaciones.trim().equals("")) {
					concatenacionDeResultados += "false";
					listaErrores.add("No se permiten car�teres especiales en: Motivo Rechazo.");
				}
			}

			if (concatenacionDeResultados.contains("false")) {
//                headerDialogo = "Solicitud de Colocaci\u00F3n: Rechazo";
//                mensajeDialogo = mensaje;
//                detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
				org.primefaces.context.RequestContext.getCurrentInstance()
						.execute("PF('wvdlgValidacionesColocacion').show();");
				indicador = false;
			} else {
				indicador = true;
			}

		}
		return indicador;
	}

	public boolean validarCampoNumericoMayorCeroAvanzaStatus(String numero, String campo) {
		boolean indicador;
		try {
			Double valorTemporal = Double.valueOf(numero);
			indicador = valorTemporal <= Double.valueOf("0");
		} catch (NumberFormatException e) {
			indicador = true;
		}
		return indicador;
	}

	private boolean cargaArchivosEnRuta(String folio, String estadoRuta, List<FileUploadEvent> listaArchivos) {
		boolean bandera;
		try {
			String rutaBase = "";
			try {
				ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness
						.getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_INF);
				rutaBase = String.valueOf(configurationUtilsVo.getValor());
			} catch (TransactionalOVITException e) {
				rutaBase = "";
			}
			if (!rutaBase.isEmpty()) {
				File directorioTemp = new File(rutaBase + folio + "/" + estadoRuta);
				if (!directorioTemp.exists()) {
					directorioTemp.mkdirs();
				}

				for (FileUploadEvent event : listaArchivos) {
					String nombreArchivo = FilenameUtils.getName(event.getFile().getFileName());
					OutputStream out;
					try (InputStream in = event.getFile().getInputstream()) {
						out = new FileOutputStream(directorioTemp + "/" + nombreArchivo);
						byte[] buf = new byte[1024];
						int len;
						while ((len = in.read(buf)) > 0) {
							out.write(buf, 0, len);
						}
						in.close();
					}
					out.close();
				}
			}
			bandera = insertaArchivoEnTabla(folio, rutaBase + folio + "/" + estadoRuta, listaArchivosTabla);
		} catch (IOException error) {
			bandera = false;
		}
		return bandera;
	}

	private boolean insertaArchivoEnTabla(String folio, String ruta, List<SoliArchDto> lista) {
		try {
			List<SoliArchDto> listaAuxiliar = new ArrayList<>();
			for (SoliArchDto t : lista) {
				t.setRuta(ruta);
				t.setUsuario(userDetailsVo.getIdUsuario().toString());
				listaAuxiliar.add(t);
			}
			return colocacionService.insertaArchivoEnTabla(folio, listaAuxiliar);
		} catch (Exception e) {
			return false;
		}
	}

	private boolean cargaArchivosVerificacionEnRuta(String folio, String estadoRuta,
			List<FileUploadEvent> listaArchivos) {
		boolean bandera;
		try {
			String rutaBase = "";
			try {
				ConfigurationUtilsVo configurationUtilsVo = configurationUtilsBusiness
						.getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.RUTA_ARCHIVOS_INF);
				rutaBase = String.valueOf(configurationUtilsVo.getValor());
			} catch (TransactionalOVITException e) {
				rutaBase = "";
			}
			if (!rutaBase.isEmpty()) {
				File directorioTemp = new File(rutaBase + folio + "/" + estadoRuta);
				if (!directorioTemp.exists()) {
					directorioTemp.mkdirs();
				}

				for (FileUploadEvent event : listaArchivos) {
					String nombreArchivo = FilenameUtils.getName(event.getFile().getFileName());
					OutputStream out;
					try (InputStream in = event.getFile().getInputstream()) {
						out = new FileOutputStream(directorioTemp + "/" + nombreArchivo);
						byte[] buf = new byte[1024];
						int len;
						while ((len = in.read(buf)) > 0) {
							out.write(buf, 0, len);
						}
						in.close();
					}
					out.close();
				}
			}
			bandera = insertaArchivoEnTabla(folio, rutaBase + folio + "/" + estadoRuta,
					listaArchivosTablaVerificarColocacion);
		} catch (IOException error) {
			bandera = false;
		}
		return bandera;
	}

	public void mostrarMensajeError(String mensajeError) {
		this.mensajeDialogo = mensajeError;
		this.headerDialogo = "Error";
		detalleSolicitudBean.mensajeError(headerDialogo, mensajeDialogo);
//        org.primefaces.context.RequestContext.getCurrentInstance().execute("PF('dlgColocacionMsjErrorR').show();");
	}

	private boolean validarCampo(String value, String nombreCampo) {
		if (value == null || value.trim().isEmpty()) {
			this.headerDialogo = "Solicitud Colocaci�n";
			this.mensajeDialogo = "Favor de ingresar un valor para el campo " + nombreCampo + ". ";
			return true;
		}
		return false;
	}

	private boolean validarCampoNumericoMayorCero(String numero, String campo) {
		boolean indicador;
		try {
			Double valorTemporal = Double.valueOf(numero);
			indicador = valorTemporal <= Double.valueOf("0");
			this.headerDialogo = "Solicitud Colocacion";
			this.mensajeDialogo = "El valor del campo: " + campo + " debe ser numerico y mayor a 0. ";
		} catch (NumberFormatException e) {
			this.headerDialogo = "Solicitud Colocacion";
			this.mensajeDialogo = "El valor utilizado en: " + campo + " no es un numero";
			indicador = true;
		}
		return indicador;
	}

	private boolean validarCampoNumericoValido(String numero, String campo) {
		boolean indicador;
		try {
			Double valorTemporal = Double.valueOf(numero);
			indicador = false;
		} catch (NumberFormatException e) {
			this.headerDialogo = "Solicitud Colocacion";
			this.mensajeDialogo = "El valor utilizado en: " + campo + " no es un numero";
			indicador = true;
		}
		return indicador;
	}

	public void limpiarRegistros() {
		altaEspacioPiso = new ColocacionTablaEspacioPisoDTO();
		altaEspacioTorre = new ColocacionTablaEspacioTorreDTO();
		this.altaTablaProgramaCol = new ColocacionTablaProgramaColocacionDTO();
		dimensionAlterRF1 = "";
		dimensionAlterRF2 = "";

	}

	public void limpiarMotivoRechazoSoliColo() {
		stringMotivoRechazo = "";
	}

	public void limpiarMotivoRechazo() {
		motivoVc = "";
	}

	public boolean getVisible(String nombreComponente) {
		boolean visible = false;
		for (ElementosPantallaDTO elemento : this.elementosPantalla) {
			if (elemento.getIdElemento().equals(nombreComponente)) {
				visible = elemento.isVisible();
			}
		}
		return visible;
	}

	public boolean getEditable(String nombreComponente) {
		boolean editable = false;
		for (ElementosPantallaDTO elemento : this.elementosPantalla) {
			if (elemento.getIdElemento().equals(nombreComponente)) {
				editable = elemento.isEditable();
			}
		}

		return editable;
	}

	private void registrarSuscripcionSitioConcesionario() {
		if (suscripcionSitioService == null) {
			LOGGER.warn("SuscripcionSitioService no disponible. No se registrara suscripcion.");
			return;
		}
		if (solicitudDto == null) {
			LOGGER.warn("No se registra suscripcion porque solicitudDto es null.");
			return;
		}

		String sitioId = solicitudDto.getSitio();
		String concesionario = solicitudDto.getConcesionario();
		String folioSolicitud = solicitudDto.getFolio();

		if (isBlank(sitioId) || isBlank(concesionario) || isBlank(folioSolicitud)) {
			LOGGER.warn("No se registra suscripcion: datos incompletos. sitioId={}, concesionario={}, folio={}",
					sitioId, concesionario, folioSolicitud);
			return;
		}

		try {
			suscripcionSitioService.registrarSuscripcion(sitioId, concesionario, folioSolicitud);
			LOGGER.info(
					"Suscripcion registrada (flujo colocacion/verificacion): sitioId={}, concesionario={}, folio={}",
					sitioId, concesionario, folioSolicitud);
		} catch (Exception exception) {
			LOGGER.error("Error registrando suscripcion sitio/concesionario. sitioId={}, concesionario={}, folio={}",
					sitioId, concesionario, folioSolicitud, exception);
		}
	}

	private boolean isBlank(String value) {
		return value == null || value.trim().isEmpty();
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public Date getFechaActual() {
		return fechaActual;
	}

	public void setFechaActual(Date fechaActual) {
		this.fechaActual = fechaActual;
	}

	public String getFechaActualCadena() {
		return fechaActualCadena;
	}

	public void setFechaActualCadena(String fechaActualCadena) {
		this.fechaActualCadena = fechaActualCadena;
	}

	public List<ColocacionTablaEspacioTorreDTO> getListaEspacioEnTorre() {
		return listaEspacioEnTorre;
	}

	public void setListaEspacioEnTorre(List<ColocacionTablaEspacioTorreDTO> listaEspacioEnTorre) {
		this.listaEspacioEnTorre = listaEspacioEnTorre;
	}

	public ColocacionTablaEspacioTorreDTO getAltaEspacioTorre() {
		return altaEspacioTorre;
	}

	public void setAltaEspacioTorre(ColocacionTablaEspacioTorreDTO altaEspacioTorre) {
		this.altaEspacioTorre = altaEspacioTorre;
	}

	public ColocacionTablaEspacioTorreDTO getLeyendasAltaEspacioTorre() {
		return leyendasAltaEspacioTorre;
	}

	public void setLeyendasAltaEspacioTorre(ColocacionTablaEspacioTorreDTO leyendasAltaEspacioTorre) {
		this.leyendasAltaEspacioTorre = leyendasAltaEspacioTorre;
	}

	public String getDimensionAlterRF1() {
		return dimensionAlterRF1;
	}

	public void setDimensionAlterRF1(String dimensionAlterRF1) {
		this.dimensionAlterRF1 = dimensionAlterRF1;
	}

	public String getDimensionAlterRF2() {
		return dimensionAlterRF2;
	}

	public void setDimensionAlterRF2(String dimensionAlterRF2) {
		this.dimensionAlterRF2 = dimensionAlterRF2;
	}

	public boolean isIndicadorDimRF() {
		return indicadorDimRF;
	}

	public void setIndicadorDimRF(boolean indicadorDimRF) {
		this.indicadorDimRF = indicadorDimRF;
	}

	public boolean isIndicadorDimMW() {
		return indicadorDimMW;
	}

	public void setIndicadorDimMW(boolean indicadorDimMW) {
		this.indicadorDimMW = indicadorDimMW;
	}

	public ColocacionTablaEspacioTorreDTO getEditarEspacioTorre() {
		return editarEspacioTorre;
	}

	public void setEditarEspacioTorre(ColocacionTablaEspacioTorreDTO editarEspacioTorre) {
		this.editarEspacioTorre = editarEspacioTorre;
	}

	public String getDimensionAlterEditRF1() {
		return dimensionAlterEditRF1;
	}

	public void setDimensionAlterEditRF1(String dimensionAlterEditRF1) {
		this.dimensionAlterEditRF1 = dimensionAlterEditRF1;
	}

	public String getDimensionAlterEditRF2() {
		return dimensionAlterEditRF2;
	}

	public void setDimensionAlterEditRF2(String dimensionAlterEditRF2) {
		this.dimensionAlterEditRF2 = dimensionAlterEditRF2;
	}

	public boolean isIndicadorEditDimRF() {
		return indicadorEditDimRF;
	}

	public void setIndicadorEditDimRF(boolean indicadorEditDimRF) {
		this.indicadorEditDimRF = indicadorEditDimRF;
	}

	public boolean isIndicadorEditDimMW() {
		return indicadorEditDimMW;
	}

	public void setIndicadorEditDimMW(boolean indicadorEditDimMW) {
		this.indicadorEditDimMW = indicadorEditDimMW;
	}

	public ColocacionTablaEspacioTorreDTO getLeyendasEditarEspacioTorre() {
		return leyendasEditarEspacioTorre;
	}

	public void setLeyendasEditarEspacioTorre(ColocacionTablaEspacioTorreDTO leyendasEditarEspacioTorre) {
		this.leyendasEditarEspacioTorre = leyendasEditarEspacioTorre;
	}

	public List<ColocacionTablaEspacioPisoDTO> getListaEspacioEnPiso() {
		return listaEspacioEnPiso;
	}

	public void setListaEspacioEnPiso(List<ColocacionTablaEspacioPisoDTO> listaEspacioEnPiso) {
		this.listaEspacioEnPiso = listaEspacioEnPiso;
	}

	public ColocacionTablaEspacioPisoDTO getAltaEspacioPiso() {
		return altaEspacioPiso;
	}

	public void setAltaEspacioPiso(ColocacionTablaEspacioPisoDTO altaEspacioPiso) {
		this.altaEspacioPiso = altaEspacioPiso;
	}

	public ColocacionTablaEspacioPisoDTO getEditarEspacioEnPiso() {
		return editarEspacioEnPiso;
	}

	public void setEditarEspacioEnPiso(ColocacionTablaEspacioPisoDTO editarEspacioEnPiso) {
		this.editarEspacioEnPiso = editarEspacioEnPiso;
	}

	public List<FileUploadEvent> getListaArchivoEvento() {
		return listaArchivoEvento;
	}

	public void setListaArchivoEvento(List<FileUploadEvent> listaArchivoEvento) {
		this.listaArchivoEvento = listaArchivoEvento;
	}

	public List<SoliArchDto> getListaArchivosTabla() {
		return listaArchivosTabla;
	}

	public void setListaArchivosTabla(List<SoliArchDto> listaArchivosTabla) {
		this.listaArchivosTabla = listaArchivosTabla;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	public String getObservacionesTelcel() {
		return observacionesTelcel;
	}

	public void setObservacionesTelcel(String observacionesTelcel) {
		this.observacionesTelcel = observacionesTelcel;
	}

	public String getRFcalibre() {
		return RFcalibre;
	}

	public void setRFcalibre(String RFcalibre) {
		this.RFcalibre = RFcalibre;
	}

	public String getMWcalibre() {
		return MWcalibre;
	}

	public void setMWcalibre(String MWcalibre) {
		this.MWcalibre = MWcalibre;
	}

	public String getSuperficie() {
		return superficie;
	}

	public void setSuperficie(String superficie) {
		this.superficie = superficie;
	}

	public String getTransformador() {
		return transformador;
	}

	public void setTransformador(String transformador) {
		this.transformador = transformador;
	}

	public List<ColocacionTablaProgramaColocacionDTO> getListaProgramaColocacion() {
		return listaProgramaColocacion;
	}

	public void setListaProgramaColocacion(List<ColocacionTablaProgramaColocacionDTO> listaProgramaColocacion) {
		this.listaProgramaColocacion = listaProgramaColocacion;
	}

	public ColocacionTablaProgramaColocacionDTO getAltaTablaProgramaCol() {
		return altaTablaProgramaCol;
	}

	public void setAltaTablaProgramaCol(ColocacionTablaProgramaColocacionDTO altaTablaProgramaCol) {
		this.altaTablaProgramaCol = altaTablaProgramaCol;
	}

	public ColocacionTablaProgramaColocacionDTO getEditarTablaProgramaCol() {
		return editarTablaProgramaCol;
	}

	public void setEditarTablaProgramaCol(ColocacionTablaProgramaColocacionDTO editarTablaProgramaCol) {
		this.editarTablaProgramaCol = editarTablaProgramaCol;
	}

	public List<ColocacionTablaProgramaColocacionDTO> getListaSemanas() {
		return listaSemanas;
	}

	public void setListaSemanas(List<ColocacionTablaProgramaColocacionDTO> listaSemanas) {
		this.listaSemanas = listaSemanas;
	}

	public String getObservacionesVerificacionColocacion() {
		return observacionesVerificacionColocacion;
	}

	public void setObservacionesVerificacionColocacion(String observacionesVerificacionColocacion) {
		this.observacionesVerificacionColocacion = observacionesVerificacionColocacion;
	}

	public String getAreaUtilizadaPiso() {
		return areaUtilizadaPiso;
	}

	public void setAreaUtilizadaPiso(String areaUtilizadaPiso) {
		this.areaUtilizadaPiso = areaUtilizadaPiso;
	}

	public String getEspacioLineal() {
		return espacioLineal;
	}

	public void setEspacioLineal(String espacioLineal) {
		this.espacioLineal = espacioLineal;
	}

	public String getRevisionEquiposPiso() {
		return revisionEquiposPiso;
	}

	public void setRevisionEquiposPiso(String revisionEquiposPiso) {
		this.revisionEquiposPiso = revisionEquiposPiso;
	}

	public String getRevisionEquiposTorre() {
		return revisionEquiposTorre;
	}

	public void setRevisionEquiposTorre(String revisionEquiposTorre) {
		this.revisionEquiposTorre = revisionEquiposTorre;
	}

	public List<FileUploadEvent> getListaArchivoEventoVerificarColocacion() {
		return listaArchivoEventoVerificarColocacion;
	}

	public void setListaArchivoEventoVerificarColocacion(List<FileUploadEvent> listaArchivoEventoVerificarColocacion) {
		this.listaArchivoEventoVerificarColocacion = listaArchivoEventoVerificarColocacion;
	}

	public List<SoliArchDto> getListaArchivosTablaVerificarColocacion() {
		return listaArchivosTablaVerificarColocacion;
	}

	public void setListaArchivosTablaVerificarColocacion(List<SoliArchDto> listaArchivosTablaVerificarColocacion) {
		this.listaArchivosTablaVerificarColocacion = listaArchivosTablaVerificarColocacion;
	}

	public String getHeaderDialogo() {
		return headerDialogo;
	}

	public void setHeaderDialogo(String headerDialogo) {
		this.headerDialogo = headerDialogo;
	}

	public String getMensajeDialogo() {
		return mensajeDialogo;
	}

	public void setMensajeDialogo(String mensajeDialogo) {
		this.mensajeDialogo = mensajeDialogo;
	}

	public SolicitudDto getSolicitudDto() {
		return solicitudDto;
	}

	public void setSolicitudDto(SolicitudDto solicitudDto) {
		this.solicitudDto = solicitudDto;
	}

	public List<ElementosPantallaDTO> getElementosPantalla() {
		return elementosPantalla;
	}

	public void setElementosPantalla(List<ElementosPantallaDTO> elementosPantalla) {
		this.elementosPantalla = elementosPantalla;
	}

	public List<SoliArchDto> getListaArchivosVcFact() {
		return listaArchivosVcFact;
	}

	public void setListaArchivosVcFact(List<SoliArchDto> listaArchivosVcFact) {
		this.listaArchivosVcFact = listaArchivosVcFact;
	}

	public boolean isRenderSolicitudColocacion() {
		return renderSolicitudColocacion;
	}

	public void setRenderSolicitudColocacion(boolean renderSolicitudColocacion) {
		this.renderSolicitudColocacion = renderSolicitudColocacion;
	}

	public DefaultStreamedContent getArchivoDescarga() {
		return archivoDescarga;
	}

	public void setArchivoDescarga(DefaultStreamedContent archivoDescarga) {
		this.archivoDescarga = archivoDescarga;
	}

	public String getSeleccionadoSemana() {
		return seleccionadoSemana;
	}

	public void setSeleccionadoSemana(String seleccionadoSemana) {
		this.seleccionadoSemana = seleccionadoSemana;
	}

	public String getActividad() {
		return actividad;
	}

	public void setActividad(String actividad) {
		this.actividad = actividad;
	}

	public List<String> getListaEquiposEnPiso() {
		return listaEquiposEnPiso;
	}

	public void setListaEquiposEnPiso(List<String> listaEquiposEnPiso) {
		this.listaEquiposEnPiso = listaEquiposEnPiso;
	}

	public List<String> getListaEquiposEnTorre() {
		return listaEquiposEnTorre;
	}

	public void setListaEquiposEnTorre(List<String> listaEquiposEnTorre) {
		this.listaEquiposEnTorre = listaEquiposEnTorre;
	}

	public String getSelectEquiposPiso() {
		return selectEquiposPiso;
	}

	public void setSelectEquiposPiso(String selectEquiposPiso) {
		this.selectEquiposPiso = selectEquiposPiso;
	}

	public String getSelectEquiposTorre() {
		return selectEquiposTorre;
	}

	public void setSelectEquiposTorre(String selectEquiposTorre) {
		this.selectEquiposTorre = selectEquiposTorre;
	}

	public String getTabActivity() {
		return tabActivity;
	}

	public void setTabActivity(String tabActivity) {
		this.tabActivity = tabActivity;
	}

	public String getStringMotivoRechazo() {
		return stringMotivoRechazo;
	}

	public void setStringMotivoRechazo(String stringMotivoRechazo) {
		this.stringMotivoRechazo = stringMotivoRechazo;
	}

	public String getFechaI() {
		return fechaI;
	}

	public void setFechaI(String fechaI) {
		this.fechaI = fechaI;
	}

	public String getFechaF() {
		return fechaF;
	}

	public void setFechaF(String fechaF) {
		this.fechaF = fechaF;
	}

	public String getMotivoVc() {
		return motivoVc;
	}

	public void setMotivoVc(String motivoVc) {
		this.motivoVc = motivoVc;
	}

	public List<String> getListaErrores() {
		return listaErrores;
	}

	public void setListaErrores(List<String> listaErrores) {
		this.listaErrores = listaErrores;
	}
}

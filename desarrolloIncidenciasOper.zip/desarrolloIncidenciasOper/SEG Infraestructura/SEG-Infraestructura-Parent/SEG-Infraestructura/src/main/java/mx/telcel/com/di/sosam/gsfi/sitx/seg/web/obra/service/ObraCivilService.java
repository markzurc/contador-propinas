package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.obra.service;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto.ObraCivilVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.web.commons.util.Constants;

import java.util.List;

import org.springframework.stereotype.Service;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

@Service("obraCivilService")
public class ObraCivilService {
	
	private int index = 0;
	private static String[] columNamesObra={"ID Sitio","Nombre Sitio","Latitud","Longitud", "Region", "Fecha Inicio Obra Civil"};
	
	XSSFCellStyle bordeDerechoStyle = null;
	
	public void toExcel(XSSFWorkbook hssfWorkbook,List<ObraCivilVo> listaObras) {
		XSSFSheet sheet = hssfWorkbook.getSheetAt(Constants.INDEX0);  
		sheet.setDisplayGridlines(false);
		sheet.setPrintGridlines(false);
		XSSFCellStyle headerStyle = Constants.getLevelStyle(hssfWorkbook,Constants.INDEX1);
		headerStyle.setAlignment(HorizontalAlignment.CENTER);
		XSSFCellStyle campoStyle = Constants.getLevelStyle(hssfWorkbook,Constants.INDEX5);
		campoStyle.setBorderBottom(CellStyle.BORDER_THIN);
		campoStyle.setBorderLeft(CellStyle.BORDER_THIN);
		campoStyle.setBorderRight(CellStyle.BORDER_THIN);
		campoStyle.setBorderTop(CellStyle.BORDER_THIN);
		//APPs
		
		//Estilo para el borde derecho
		bordeDerechoStyle = Constants.getLevelStyle(hssfWorkbook,Constants.INDEX2);
		bordeDerechoStyle.setBorderRight(CellStyle.BORDER_THIN);
		bordeDerechoStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		bordeDerechoStyle.setBorderTop(CellStyle.BORDER_THIN);
		bordeDerechoStyle.setTopBorderColor(IndexedColors.WHITE.getIndex());
		bordeDerechoStyle.setBorderBottom(CellStyle.BORDER_THIN);
		bordeDerechoStyle.setBottomBorderColor(IndexedColors.WHITE.getIndex());
		bordeDerechoStyle.setLeftBorderColor(CellStyle.BORDER_THIN);
		bordeDerechoStyle.setLeftBorderColor(IndexedColors.WHITE.getIndex());
		
		insertaCell(sheet,Constants.INDEX0,Constants.INDEX0,"Reporte Nueva Obra Civil",headerStyle);
		sheet.addMergedRegion(new CellRangeAddress(Constants.INDEX0,Constants.INDEX0,0,5));
		index = 2;
		addColumnsNames(sheet, Constants.INDEX1,Constants.getLevelStyle(hssfWorkbook,Constants.INDEX2),columNamesObra);
				
		for(ObraCivilVo obra: listaObras){
			insertaCell(sheet, index,Constants.INDEX0,obra.getIdObra(),campoStyle);
			insertaCell(sheet, index,Constants.INDEX1,obra.getNombre(),campoStyle);
			insertaCell(sheet, index,Constants.INDEX2,obra.getLatitud(),campoStyle);
			insertaCell(sheet, index,Constants.INDEX3,obra.getLongitud(),campoStyle);
			insertaCell(sheet, index,Constants.INDEX4,obra.getRegion(),campoStyle);
			insertaCell(sheet, index,Constants.INDEX5,obra.getFechaInicioStr(),campoStyle);
			
			index++;
		}
		
		ajustarTodasColumnas(sheet,6,index);
		
	}

	private void insertaCell( XSSFSheet sheet,int rowIndex,int column,String value,XSSFCellStyle style){
		XSSFRow commonRow= sheet.getRow(rowIndex);
		if(commonRow==null){
			commonRow=sheet.createRow(rowIndex);
		}
		XSSFCell nombre = commonRow.createCell(column);

		nombre.setCellValue(value);
			
		nombre.setCellStyle(style);	
	}
	
	private void addColumnsNames(XSSFSheet sheet, int position, XSSFCellStyle style, String[] titles) {
		int column = Constants.INDEX0;
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setRightBorderColor(IndexedColors.WHITE.getIndex());
		style.setBorderTop(CellStyle.BORDER_THIN);
		style.setTopBorderColor(IndexedColors.WHITE.getIndex());
		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setBottomBorderColor(IndexedColors.WHITE.getIndex());
		style.setLeftBorderColor(CellStyle.BORDER_THIN);
		style.setLeftBorderColor(IndexedColors.WHITE.getIndex());
		for (String titleColumn : titles) {
			
			if (column == 5) {
				insertaCell(sheet, position, column, titleColumn, bordeDerechoStyle);
			}else {
				insertaCell(sheet, position, column, titleColumn, style);
			}
			
			column += 1;
		}
	}

private void ajustarTodasColumnas(XSSFSheet sheet, int numColumnas, int numFilas) {
    for (int col = 0; col < numColumnas; col++) {
        int anchoMax = 0;
        
        for (int fila = 1; fila < numFilas; fila++) {
            XSSFRow row = sheet.getRow(fila);
            if (row != null) {
                XSSFCell cell = row.getCell(col);
                if (cell != null && !cell.getStringCellValue().isEmpty()) {	                    
                	String texto = cell.getStringCellValue();
                	if (texto.length() > anchoMax) {
                		anchoMax  = texto.length();	
                		
					}
                }
            }
        }
        if (col == 5) {
        	sheet.setColumnWidth(col, (anchoMax ) * 256);
		}else {
			sheet.setColumnWidth(col, (anchoMax + 3) * 260);
		}
    }
}
	
	
}
package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.commons.util;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolAclVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolVo;


@javax.xml.bind.annotation.XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SnapshotRolAcls {
	@javax.xml.bind.annotation.XmlElement(nillable=true)
	private RolVo rol;
	
	@XmlElementWrapper(name = "ACLS_asociados")
    @XmlElement(name = "RolAclVo")
	private List<RolAclVo> allRelationsRolComp = new ArrayList<RolAclVo>();
	
	public SnapshotRolAcls(){}
	
	public SnapshotRolAcls(RolVo rol, List<RolAclVo> allRelationsRolComp) {
		super();
		this.rol = rol;
		this.allRelationsRolComp = allRelationsRolComp;
	}
	public RolVo getRol() {
		return rol;
	}
	public void setRol(RolVo rol) {
		this.rol = rol;
	}
	public List<RolAclVo> getAllRelationsRolComp() {
		return allRelationsRolComp;
	}
	public void setAllRelationsRolComp(List<RolAclVo> allRelationsRolComp) {
		this.allRelationsRolComp = allRelationsRolComp;
	}
	
}

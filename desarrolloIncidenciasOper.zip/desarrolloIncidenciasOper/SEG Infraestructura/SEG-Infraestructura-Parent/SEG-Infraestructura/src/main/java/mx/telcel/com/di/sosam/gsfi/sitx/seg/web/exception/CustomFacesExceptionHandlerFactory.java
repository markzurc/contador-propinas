package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.exception;

import javax.faces.context.ExceptionHandler;
import javax.faces.context.ExceptionHandlerFactory;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class CustomFacesExceptionHandlerFactory extends ExceptionHandlerFactory {


	private ExceptionHandlerFactory parent;
	private String errorFlow;
	private String errorPageId;
	private boolean isFirstTry = true;

	public CustomFacesExceptionHandlerFactory() {
	}

	public CustomFacesExceptionHandlerFactory(ExceptionHandlerFactory parent) {
		this.parent = parent;
	}

	@Override
	public ExceptionHandler getExceptionHandler() {
		
		if (((this.errorFlow == null) || (this.errorPageId == null)) && (this.isFirstTry)){
	      ApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext((ServletContext)FacesContext.getCurrentInstance().getExternalContext().getContext());
	      
	      Object beanFromSpringContext = ctx.getBean("facesExceptionHandlerErrorFlow");
	      

	      this.errorFlow = (beanFromSpringContext != null ? (String)beanFromSpringContext : null);
	      
	      if (this.errorFlow == null) {
	        this.errorFlow = "error-flow";
	      }
	      
	      beanFromSpringContext = ctx.getBean("facesExceptionHandlerErrorPageId");
	      
	      this.errorPageId = (beanFromSpringContext != null ? (String)beanFromSpringContext : null);
	      if (this.errorPageId == null) {
	        this.errorPageId = "/WEB-INF/errorPage.xhtml";
	      }
	      
	      this.isFirstTry = false;
	    }
		ExceptionHandler result = this.parent.getExceptionHandler();
	    result = new CustomFacesExceptionHandler(result, this.errorFlow, this.errorPageId);
	    
	    return result;
	}
	
	  public void setErrorFlow(String errorFlow) {
	    this.errorFlow = errorFlow;
	  }
	  
	  public void setErrorPageId(String errorPageId){
	    this.errorPageId = errorPageId;
	  }

}
package mx.telcel.com.di.sosam.gsfi.sitx.seg.web.administration.perfiles.acceso;

import java.util.Map;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;

public interface IPermPerfDocsService {
	
	Map<String, Boolean> getPermisosAcciones(Integer estatusProceso, Integer rolUsuario, String elemento) throws TransactionalOVITException;
	
	int getPerfilUsuario(int rol) throws TransactionalOVITException;
}

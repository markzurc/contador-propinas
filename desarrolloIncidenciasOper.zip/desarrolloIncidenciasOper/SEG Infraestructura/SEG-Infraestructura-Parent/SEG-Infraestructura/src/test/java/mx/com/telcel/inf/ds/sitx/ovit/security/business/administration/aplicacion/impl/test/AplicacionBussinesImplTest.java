package mx.com.telcel.inf.ds.sitx.ovit.security.business.administration.aplicacion.impl.test;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.test.InitDataSource;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.IApplicationBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ApplicationVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ComponentVo;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class AplicacionBussinesImplTest extends InitDataSource {
	
	private ApplicationVo applicationVo;
	
	@Autowired
	@Qualifier("aplicacionBusiness")
	private IApplicationBusiness aplicacionBussinesImpl;
	
	@Before
	public void init(){
		applicationVo = new ApplicationVo();
	}
	
	@Test
	public void findByTest() throws TransactionalOVITException{
		List<ApplicationVo> lstAplicacionVo;
		lstAplicacionVo = aplicacionBussinesImpl.findByExample(applicationVo);
		Assert.assertNotNull(lstAplicacionVo);
		for(ApplicationVo aplicacionVoTemp : lstAplicacionVo){
			System.out.println(aplicacionVoTemp.getNombre());
		}
	}
	
	@Test
	public void componentsForApplication() throws TransactionalOVITException{
		List<ComponentVo> lstComponenteVo;
		lstComponenteVo = aplicacionBussinesImpl.componentsForApplication(0);
		Assert.assertNotNull(lstComponenteVo);
		for(ComponentVo aplicacionVoTemp : lstComponenteVo){
			System.out.println(aplicacionVoTemp.getNombre());
		}
	}

}

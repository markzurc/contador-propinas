package mx.com.telcel.inf.ds.sitx.ovit.web.business.testalta.testapp;

import org.hibernate.Session;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import mx.com.telcel.inf.ds.sitx.ovit.web.business.testalta.testapp.request.ApplicationOneRequest;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.application.thirdparty.IApplicationMethods;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.application.thirdparty.response.ApplicationGenericResponse;

/**
 * 
 * <h1>ApplicationOne</h1>
 * <p>
 * Esta clase es de uso del test por lo que no debe ser utilizada en otro lado.
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 17/03/2015
 *
 */

@Service("applicationOne")
@Scope("prototype")
public class ApplicationOne implements IApplicationMethods{

	@Override
	public <T> ApplicationGenericResponse executeInsert(T request) {
		ApplicationOneRequest appRequest = (ApplicationOneRequest) request;
		System.out.println("Esta el la respuesta de la aplicacion one");
		System.out.println(appRequest.getMessageOne());
		System.out.println(appRequest.getNumberOne());
		System.out.println(appRequest.isBoolOne());
		
		ApplicationGenericResponse response = new ApplicationGenericResponse();
		response.setMessage("Todo Salio Bien");
		return response;
	}

	@Override
	public <T> ApplicationGenericResponse executeUpdate(T request) {
		return null;
	}

	@Override
	public void setSession(Session session) {
		
	}

}

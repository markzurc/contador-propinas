package mx.com.telcel.inf.ds.sitx.ovit.security.business.administration.rol.impl.test;

import java.util.ArrayList;
import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.test.InitDataSource;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.IRolBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolAclVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolApplicationVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolTypeVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolVo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class RolBusinessImplTest extends InitDataSource{
	
	private RolVo rolVo;
	
	private static final Logger logger = LogManager.getLogger(RolBusinessImplTest.class);
	
	@Autowired
	@Qualifier("rolBusiness")
	private IRolBusiness rolBusiness;
	
	@Before
	public void init(){
		rolVo = new RolVo();
	}
	
	@Test
	public void testCreateRol() throws TransactionalOVITException{
		rolVo.setDescripcion("Prueba de estatus");
		rolVo.setNombre("Rol_Estatus_Activo");
		rolVo.setIdTipoRol(0);
		rolVo.setIdEstatus(0);
		List<Integer> lstAplicaciones = new ArrayList<Integer>(1);
		List<RolAclVo> lstRolAclVos = new ArrayList<RolAclVo>(1);
		RolAclVo rolAclVo = new RolAclVo();
		rolAclVo.setFlujo("Mi flujo");
		rolAclVo.setIdAplicacion(0);
		rolAclVo.setIdComponente(0);
		rolAclVo.setIdPadre(1);
		rolAclVo.setIdRol(7);
		rolAclVo.setNombre("Esta chido");
		rolAclVo.setPermiso('E');
		rolAclVo.setIdTipoComponente(0);
		lstRolAclVos.add(rolAclVo);
		lstAplicaciones.add(0);
		rolVo.setListIdAplicacion(lstAplicaciones);
		rolVo = rolBusiness.createRol(rolVo, lstRolAclVos);
		Assert.assertNotNull(rolVo.getIdRol());
		logger.info("ID_ROL: "+rolVo.getIdRol());
		System.out.println("Termino");
	}
	
	@Test
	public void testUpdateRol() throws TransactionalOVITException{
		rolVo.setDescripcion("septimo Rol de prueba");
		rolVo.setNombre("Rol_nueve");
		rolVo.setIdTipoRol(0);
		rolVo.setIdRol(9);
		List<Integer> lstAplicaciones = new ArrayList<Integer>(1);
		lstAplicaciones.add(0);
		rolVo.setListIdAplicacion(lstAplicaciones);
		Assert.assertTrue(rolBusiness.updateRol(rolVo, null));
		logger.info("ID_ROL: "+rolVo.getIdRol());
		System.out.println("Termino");
	}
	
	@Test
	public void findByExampleTest() throws TransactionalOVITException{
//		rolVo.setDescripcion("quinto Rol de prueba");
//		rolVo.setNombre("Rol_Chris");
//		rolVo.setTipo(0);
//		rolVo.setIdRol(5);
//		List<Integer> lstAplicaciones = new ArrayList<Integer>(1);
//		lstAplicaciones.add(0);
//		rolVo.setListIdAplicacion(lstAplicaciones);
		List<RolVo> lstRolVo = rolBusiness.findByWithoutApplications(rolVo);
		RolApplicationVo rolApplicationVo = rolBusiness.findByWithApplications(rolVo);
		Assert.assertNotNull(rolApplicationVo);
		Assert.assertNotNull(lstRolVo);
//		for(RolVo temp:lstRolVo)
//			System.out.println(temp.getNombre());
		System.out.println("Termino");
	}
	
	@Test
	public void findByRolAcl() throws TransactionalOVITException{
		List<RolAclVo> lstRolAclVos = rolBusiness.findByRolAcl(1, 1);
		Assert.assertNotNull(lstRolAclVos);
		for(RolAclVo rolAclVo : lstRolAclVos){
			System.out.println(rolAclVo.toString());
		}
	}
	
	@Test
	public void getRoltypeTest() throws TransactionalOVITException{
		List<RolTypeVo> lstRolTypeVos = rolBusiness.getRoltype();
		Assert.assertNotNull(lstRolTypeVos);
		for(RolTypeVo rolVo : lstRolTypeVos){
			System.out.println("Nombre: "+rolVo.toString());
		}
	}
	
	@Test
	public void isInUseTest() throws TransactionalOVITException{
		System.out.println(rolBusiness.isInUse(1));
	}
}

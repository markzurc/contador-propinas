package mx.com.telcel.inf.ds.sitx.ovit.web.business.testalta.testapp;

import mx.com.telcel.inf.ds.sitx.ovit.web.business.testalta.testapp.request.ApplicationTwoRequest;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.application.thirdparty.IApplicationMethods;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.application.thirdparty.response.ApplicationGenericResponse;

import org.hibernate.Session;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;


/**
 * 
 * <h1>ApplicationTwo</h1>
 * <p>
 * Esta clase es de uso del test por lo que no debe ser utilizada en otro lado.
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 17/03/2015
 *
 */
@Service("applicationTwo")
@Scope("prototype")
public class ApplicationTwo  implements IApplicationMethods{

	@Override
	public <T> ApplicationGenericResponse executeInsert(T request) {
		ApplicationTwoRequest appRequest = (ApplicationTwoRequest) request;
		System.out.println("Esta el la respuesta de la aplicacion two");
		System.out.println(appRequest.getMessageTwo());
		System.out.println(appRequest.getNumberTwo());
		System.out.println(appRequest.isBoolTwo());
		
		ApplicationGenericResponse response = new ApplicationGenericResponse();
		response.setMessage("Todo Salio Bien");
		return response;
	}

	@Override
	public <T> ApplicationGenericResponse executeUpdate(T request) {
		return null;
	}

	@Override
	public void setSession(Session session) {
		
	}
	
	
}

package mx.com.telcel.inf.ds.sitx.ovit.security.business.administration.user.impl.test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import mx.com.telcel.inf.ds.sitx.ovit.web.business.testalta.testapp.request.ApplicationOneRequest;
import mx.com.telcel.inf.ds.sitx.ovit.web.business.testalta.testapp.request.ApplicationTwoRequest;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.exception.SendingMailOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.test.InitDataSource;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.application.thirdparty.request.ApplicationGenericRequest;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.IUserBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ExternalDataVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ExternalUserFindVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ExternalUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.InternalUserFindVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.UserContraVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.UserVo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class UserBusinessImplTest extends InitDataSource {

	private static final Logger logger = LogManager.getLogger(UserBusinessImplTest.class);
	

	private UserVo userVo;
	private ApplicationOneRequest appOneRequest;
	private ApplicationTwoRequest appTwoRequest;

	@Before
	public void init() {
		userVo = new UserVo();
		appOneRequest = new ApplicationOneRequest();
		appTwoRequest = new ApplicationTwoRequest();
		// Request de aplicacion one
		appOneRequest.setBoolOne(true);
		appOneRequest.setMessageOne("Mensaje de aplicacion 1");
		appOneRequest.setNumberOne(1);
		// Request de applicacion two
		appTwoRequest.setBoolTwo(false);
		appTwoRequest.setMessageTwo("Mensaje de aplicacion 2");
		appTwoRequest.setNumberTwo(2);
	}

	@Autowired
	@Qualifier("userBusiness")
	private IUserBusiness userBusinessImpl;

	@Test
	public void testCreateUser() throws TransactionalOVITException,
			SendingMailOVITException {
		userVo.setApellidoMaterno("Manatie".toUpperCase());
		userVo.setApellidoPaterno("Nose".toUpperCase());
		userVo.setIdEstatus(0);
		userVo.setIdRol(121);
		userVo.setIdTipoUsuario(1);
		userVo.setNombre("Chuleta".toUpperCase());
		userVo.setContra("Telcel01");
		userVo.setRfc("cafsgbe538ujh".toUpperCase());
		userVo.setFechaLogueo(new Date());
		userVo.setUsuarioCreacion("EX000005");
		userVo.setFechaCreacion(new Date());

		ExternalUserVo externalUserVo = new ExternalUserVo();
		ExternalDataVo externalDataVo = new ExternalDataVo(43,
				"julio.salinas@mail.telcel.com");

		externalUserVo.setUserVo(userVo);
		externalUserVo.setExternalDataVo(externalDataVo);
		externalDataVo.setNumeroEmpleado("EX00456");

		List<ApplicationGenericRequest> listRequest = new ArrayList<ApplicationGenericRequest>();

		listRequest.add(appOneRequest);
		listRequest.add(appTwoRequest);
		userBusinessImpl.createUser(externalUserVo, listRequest);

		Assert.assertNotNull(userVo.getIdUsuario());
		logger.info("Termino");
	}

	@Test
	public void tesUpdatetUser() throws TransactionalOVITException {
		userVo.setApellidoMaterno("Castro".toUpperCase());
		userVo.setApellidoPaterno("Peralta".toUpperCase());
		userVo.setIdEstatus(0);
		userVo.setIdRol(-1);
		userVo.setIdTipoUsuario(1);
		userVo.setNombre("Christian".toUpperCase());
		userVo.setRfc("cafsgbe538ujh".toUpperCase());
		userVo.setFechaLogueo(new Date());
		userVo.setIdUsuario(313);
		userVo.setUsuarioModificacion("EX000005");
		userVo.setFechaModificacion(new Date());

		ExternalUserVo externalUserVo = new ExternalUserVo();
		ExternalDataVo externalDataVo = new ExternalDataVo(43,
				"algo@blablabla.com");

		externalUserVo.setUserVo(userVo);
		externalUserVo.setExternalDataVo(externalDataVo);
		externalDataVo.setNumeroEmpleado("EX001111");
		userBusinessImpl.updateUser(externalUserVo);
		logger.info("Termino");
	}

	@Test
	public void findAllReportUsersTest() throws TransactionalOVITException {
		List<ReportUserVo> lstReportUserVos = userBusinessImpl
				.findAllReportUsers();
		Assert.assertNotNull(lstReportUserVos);
		for (ReportUserVo temp : lstReportUserVos) {
			System.out.println(temp.toString());
		}
		logger.info("Termino");
	}

	@Test
	public void findExternalUserByIdTest() throws TransactionalOVITException {
		ExternalUserFindVo userVos = userBusinessImpl.findExternalUserById(27);
		Assert.assertNotNull(userVos);
		System.out.println(userVos.toString());
	}

	@Test
	public void findInternalUserByIdTest() throws TransactionalOVITException {
		InternalUserFindVo userVos = userBusinessImpl.findInternalUserById(43);
		Assert.assertNotNull(userVos);
		System.out.println(userVos.toString());
	}

	@Test
	public void updatePasswordTest() throws TransactionalOVITException {
		userBusinessImpl.updatePassword(2, "Telcel04",
				IUserBusiness.STATUS_ACTIVE);
		System.out.println("Termino");
	}

	@Test
	public void validatePasswordTest() throws TransactionalOVITException {
		int response = userBusinessImpl.validatePassword(2, "Telcel04",
				"Telcel04");
		if (response == IUserBusiness.PASSWORD_SAME_ACTUAL) {
			System.out.println("Password repetido");
		}
		if (response == IUserBusiness.PASSWORD_NUM_VALIDATION) {
			System.out.println("Password repetido");
		}
		if (response == IUserBusiness.PASSWORD_CORRECT) {
			System.out.println("Password correcto");
		}
		if (response == IUserBusiness.PASSWORD_EXCEEDED) {
			System.out.println("Password excedido");
		}
		if (response == IUserBusiness.PASSWORD_WRONG) {
			System.out.println("Password incorrecto");
		}
		System.out.println("Termino");
	}

	@Test
	public void validateLogInTest() throws TransactionalOVITException {
		UserDetailsVo userDetailsVo = userBusinessImpl.validateLogIn(
				"EX000006", "Telcel04");
		System.out.println(userDetailsVo);
	}

	@Test
	public void resetPasswordTest() throws TransactionalOVITException,
			SendingMailOVITException {
		userBusinessImpl.resetPassword(313);
	}

	@Test
	public void updateStatusTest() throws TransactionalOVITException {
		userBusinessImpl.updateStatus(313, IUserBusiness.STATUS_RESET);
	}

	@Test
	public void obtainUserPasswordInfo() throws TransactionalOVITException {
		UserContraVo userPasswordVo = userBusinessImpl
				.obtainUserPasswordInfo(25);
		Assert.assertNotNull(userPasswordVo);
		System.out.println(userPasswordVo.getIdUsuario());
	}

	@Test
	public void updateUserApplicationListTest() throws TransactionalOVITException {
		List<ApplicationGenericRequest> listRequest = new ArrayList<ApplicationGenericRequest>();

		listRequest.add(appOneRequest);
		listRequest.add(appTwoRequest);
		
		userBusinessImpl.updateUserApplicationList(listRequest);
	}
}

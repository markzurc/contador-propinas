package mx.com.telcel.inf.ds.sitx.ovit.security.business.spml.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.test.InitDataSource;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.enums.SpmlEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.exception.SpmlOvitException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.manager.SpmlUserManager;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.telcel.dwi.spml2.server.Spml2ServerException;
import com.telcel.dwi.spml2.server.resource.User;


public class SpmlManagerTest extends InitDataSource{

	@Autowired
	@Qualifier("spmlUserManager")
	private SpmlUserManager spmlUserManager;
	
	private List<User> listUser;
	
	private User user;
	
	@Before
	public void init() {

		try {
			listUser = new ArrayList<User>();

			Map<String, String> mapa = new HashMap<String, String>();
			
			/*
			mapa.put(SpmlEnum.FOLIOSUA.getDescripcion(), 		"09876");
			*/
			
			mapa.put(SpmlEnum.NUMEROEMPLEADO.getDescripcion(), 	"0012");
			mapa.put(SpmlEnum.UNIVERSAL.getDescripcion(), 		"VI7XXE1");
			mapa.put(SpmlEnum.FIRSTNAME.getDescripcion(),		"DIANA");
			mapa.put(SpmlEnum.LASTNAME.getDescripcion(),		"GONZALEZ");
			mapa.put(SpmlEnum.MATERNO.getDescripcion(), 		"GOMEZ");
			mapa.put(SpmlEnum.APELLIDOS.getDescripcion(), 		null);
			mapa.put(SpmlEnum.FULLNAME.getDescripcion(),		"DIANA GONZALEZ GOMEZ");
			mapa.put(SpmlEnum.EMAIL.getDescripcion(), 			"dipaug@mail.telcel.com");
			mapa.put(SpmlEnum.FECHAINGRESO.getDescripcion(),	"01/10/2015");
			mapa.put(SpmlEnum.CLAVEREGION.getDescripcion(), 	"8");
			mapa.put(SpmlEnum.REGION.getDescripcion(),			"R08");
			mapa.put(SpmlEnum.CODIGOPUESTO.getDescripcion(), 	"SAN02");
			mapa.put(SpmlEnum.PUESTO.getDescripcion(), 			"SOLUTION ANALYST 2");
			mapa.put(SpmlEnum.PERFIL99.getDescripcion(), 		"2");
			mapa.put(SpmlEnum.TURNO.getDescripcion(),			"11:00 AM A 9:PM");
			mapa.put(SpmlEnum.UBICACION.getDescripcion(),		"Plaza Carso");
			mapa.put(SpmlEnum.DESCANSO1.getDescripcion(),		"DOMINGO");
			mapa.put(SpmlEnum.DESCANSO2.getDescripcion(),		"LUNES");
			mapa.put(SpmlEnum.CENTCOST.getDescripcion(),		"000CC09DX07");
			mapa.put(SpmlEnum.SPMLTIPO.getDescripcion(),		"02");
			
			/*
			mapa.put(SpmlEnum.TIPOUSUARIOIDM.getDescripcion(),	"312");
			mapa.put(SpmlEnum.ESTATUSIDM.getDescripcion(),		"123");
			mapa.put(SpmlEnum.ESTATUSRH.getDescripcion(),		"1234567890");
			mapa.put(SpmlEnum.EMPRESA.getDescripcion(),			"000001");
			*/
			
			mapa.put(SpmlEnum.CLAVDIRE.getDescripcion(),		"");
			mapa.put(SpmlEnum.CLAVDIRE.getDescripcion(),		"DIREC INF");
		 	mapa.put(SpmlEnum.DIRECCION.getDescripcion(),		" ");
		 	mapa.put(SpmlEnum.DIRECCION.getDescripcion(),		"DIRECCION DE INFORMATICA");
			mapa.put(SpmlEnum.CLAVSUBDIR.getDescripcion(), 		"SUBDI DES");
			mapa.put(SpmlEnum.SUBDIRECCION.getDescripcion(),	"SUBDIRECCION DE DESARROLLO DE SOFTWARE");
			mapa.put(SpmlEnum.CLAVGERE.getDescripcion(),		"GEREN 001");
			mapa.put(SpmlEnum.GERENCIA.getDescripcion(),		"GERENCIA DE SISTEMAS DE FACTURACION INTERCONEXION");
			mapa.put(SpmlEnum.CLAVDEPTO.getDescripcion(),		"DEPTO 001");
			mapa.put(SpmlEnum.DEPARTAMENTO.getDescripcion(),	"DEPARTAMENTO FACTURACION INTERCONEXION");
			mapa.put(SpmlEnum.CODIGOJEFE.getDescripcion(), 		"AMR");
			mapa.put(SpmlEnum.JEFE.getDescripcion(),  			"AMR");
			
			/*
			mapa.put(SpmlEnum.MOV1IDM.getDescripcion(),			"1234567890");
			mapa.put(SpmlEnum.MOV2IDM.getDescripcion(),			"BAJA");
			mapa.put(SpmlEnum.MOV3IDM.getDescripcion(),			"BAJA");
			mapa.put(SpmlEnum.MOV4IDM.getDescripcion(),			"S/A");
			mapa.put(SpmlEnum.MOV5IDM.getDescripcion(),			"BAJA");	
			*/
			
			this.user = new User("0012", mapa);

			listUser.add(user);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	
	@Test
	public void altaSpml() throws Spml2ServerException{
		for (User user : listUser) {
			String numEmp = user.getUserId();
			try{
				spmlUserManager.addUser(user);
			}catch(SpmlOvitException e){
				System.err.println("Error al guardar usuario "+ numEmp);
				System.err.println(e.getMessage());
			}catch(Spml2ServerException e){
				System.err.println(e.getMessage());
			}
		}
	}
	
	@Test
	public void modificacionSpml() throws Spml2ServerException{
		try{
			spmlUserManager.modifyUser(user);
		}catch(Spml2ServerException e){
			System.err.println(e.getMessage());
		}
	}
	
	@Test
	public void bajaSpml() throws Spml2ServerException{
		try{
			spmlUserManager.deleteUser(user.getUserId());
		}catch(SpmlOvitException e){
			System.err.println(e.getMessage());
		}catch(Spml2ServerException e){
			System.err.println(e.getMessage());
		}
	}
	
	@Test
	public void habilitaSpml() throws Spml2ServerException{
		try{
			spmlUserManager.enableUser(user.getUserId());
		}catch(SpmlOvitException e){
			System.err.println(e.getMessage());
		}catch(Spml2ServerException e){
			System.err.println(e.getMessage());
		}
	}
	
	@Test
	public void buscarSpml() throws Spml2ServerException{
		try{
			user = spmlUserManager.lookupUser(user.getUserId());
			System.out.println(user.toString());
		}catch(SpmlOvitException e){
			System.err.println(e.getMessage());
		}catch(Spml2ServerException e){
			System.err.println(e.getMessage());
		}
	}
	
	@Test
	public void listaSpml()throws Spml2ServerException{
		try{
			List<User> users = spmlUserManager.listUsers();
			for (User aux : users) {
				System.out.println(aux.toString());
			}
		}catch(SpmlOvitException e){
			System.err.println(e.getMessage());
		}catch(Spml2ServerException e){
			System.err.println(e.getMessage());
		}
	}
	
	
}

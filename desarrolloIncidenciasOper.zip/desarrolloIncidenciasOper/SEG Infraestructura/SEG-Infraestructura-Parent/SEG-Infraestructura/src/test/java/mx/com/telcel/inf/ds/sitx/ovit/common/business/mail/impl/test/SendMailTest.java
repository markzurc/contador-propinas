package mx.com.telcel.inf.ds.sitx.ovit.common.business.mail.impl.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.ISendMailBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.exception.SendingMailOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.vo.MessageVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.test.InitDataSource;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;

/**
 * 
 * <h1>SendMailTest</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 04/05/2015
 *
 */
public class SendMailTest extends InitDataSource {
	
	@Autowired
	@Qualifier("sendMailBusiness")
	private ISendMailBusiness sendMailBusiness;
	
	@Before
	public void init(){
		
	}
	
	@Test
	public void senMailToTest() throws SendingMailOVITException{
		List<String> addressTo = new ArrayList<String>();
		List<String> addressCC = new ArrayList<String>();
		List<String> addressBCC = new ArrayList<String>();
		addressCC.add("julio.salinas@mail.telcel.com");
		addressTo.add("rocio.martinezr@mail.telcel.com");
		addressBCC.add("humberto.hernandezm@mail.telcel.com");
		StringBuilder sbMensaje = new StringBuilder("Soy la peque�a voz de tu cabeza que te dice que quemes todo.");
		sendMailBusiness.senMailTo(addressTo, addressCC, addressBCC, "Prueba de metodo sendMail", sbMensaje.toString(),null,null);
	}
	
	@Test
	public void getNewUserMessage() throws TransactionalOVITException{
		MessageVo message = sendMailBusiness.getResetPasswordMessage();
		System.out.println(message.getAsunto());
		System.out.println(message.getValor());
	}
}

package mx.com.telcel.inf.ds.sitx.ovit.common.business.bitacora.sox.impl.test;

import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.IBitacoraSoxBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.vo.BitacoraSoxVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.test.InitDataSource;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.UserVo;

public class BitacoraSoxImplTest extends InitDataSource {
	
	@Autowired
	@Qualifier("bitacoraSox")
	private IBitacoraSoxBusiness bitacoraSoxBusiness;
	private BitacoraSoxVo bitacoraSoxVo;
	
	@Before
	public void init(){
		UserVo user = new UserVo();
		user.setApellidoMaterno("Julio");
		user.setNombre("Trevi�o");
		user.setIdRol(1);
		bitacoraSoxVo = new BitacoraSoxVo();
		bitacoraSoxVo.setObjetoFinal(bitacoraSoxBusiness.objectToXML(user));
		bitacoraSoxVo.setObjetoInicial(bitacoraSoxBusiness.objectToXML(user));
		bitacoraSoxVo.setFechaOperacion(new Date());
		bitacoraSoxVo.setFolioSua("00000000");
		bitacoraSoxVo.setIdAccion(IBitacoraSoxBusiness.CREATE);
		bitacoraSoxVo.setIdUsuario(0);
		bitacoraSoxVo.setNumeroEmpleado("SUA");
	}
	
	@Test
	public void createBitacoraSoxTest() throws TransactionalOVITException{
		bitacoraSoxBusiness.createBitacoraSox(bitacoraSoxVo);
		Assert.assertNotNull(bitacoraSoxVo.getIdBitacora());
	}
	
	@Test
	public void getNumberOfPagesTest() throws TransactionalOVITException{
		Integer result = bitacoraSoxBusiness.getNumberOfElements(20);
		Assert.assertNotNull(result);
		System.out.println(result);
	}
	
	@Test
	public void getContentPage() throws TransactionalOVITException{
		List<BitacoraSoxVo> lstBitacoraSoxVos = bitacoraSoxBusiness.getContentPage(20, 10, 11);
		Assert.assertNotNull(lstBitacoraSoxVos);
		for(BitacoraSoxVo temp : lstBitacoraSoxVos){
			System.out.println(temp.getIdBitacora());
			System.out.println(temp.getAccionDescripcion());
		}
	}

}

package mx.com.telcel.inf.ds.sitx.ovit.web.business.testalta.testapp.request;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.application.thirdparty.request.ApplicationGenericRequest;

public class ApplicationTwoRequest extends ApplicationGenericRequest{
	
	private String messageTwo;
	private int numberTwo;
	private boolean boolTwo;

	@Override
	public String getBeanNameSpring() {
		return "applicationTwo";
	}
	
	/**
	 * @return the messageTwo
	 */
	public String getMessageTwo() {
		return messageTwo;
	}
	/**
	 * @param messageTwo the messageTwo to set
	 */
	public void setMessageTwo(String messageTwo) {
		this.messageTwo = messageTwo;
	}
	/**
	 * @return the numberTwo
	 */
	public int getNumberTwo() {
		return numberTwo;
	}
	/**
	 * @param numberTwo the numberTwo to set
	 */
	public void setNumberTwo(int numberTwo) {
		this.numberTwo = numberTwo;
	}
	/**
	 * @return the boolTwo
	 */
	public boolean isBoolTwo() {
		return boolTwo;
	}
	/**
	 * @param boolTwo the boolTwo to set
	 */
	public void setBoolTwo(boolean boolTwo) {
		this.boolTwo = boolTwo;
	}
	
}

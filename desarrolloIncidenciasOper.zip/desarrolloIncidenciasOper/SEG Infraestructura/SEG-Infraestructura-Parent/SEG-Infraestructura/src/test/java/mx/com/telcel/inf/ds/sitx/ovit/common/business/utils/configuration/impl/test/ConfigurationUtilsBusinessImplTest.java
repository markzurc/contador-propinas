package mx.com.telcel.inf.ds.sitx.ovit.common.business.utils.configuration.impl.test;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.test.InitDataSource;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class ConfigurationUtilsBusinessImplTest extends InitDataSource {
	private static final Logger logger = LogManager.getLogger(ConfigurationUtilsBusinessImplTest.class);
	
	@Before
	public void init(){
		
	}
	
	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;
	
	@Test
	public void updateConfigTest() throws TransactionalOVITException{
		ConfigurationUtilsVo configurationUtilsVo;
		configurationUtilsVo = configurationUtilsBusiness.
				getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.NUM_CHAR_PASSWORD);
		
		configurationUtilsBusiness.updateConfiguration(configurationUtilsVo);
		logger.info("Termino");
	}
	
	@Test
	public void getListConstantOfDataBaseTest() throws TransactionalOVITException{
		List<ConfigurationUtilsVo> configurationUtilsVo;
		configurationUtilsVo = configurationUtilsBusiness.
				getListConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.class.getSimpleName());
		
		for(ConfigurationUtilsVo temp : configurationUtilsVo){
			System.out.println(temp.getIdParametro().toString().concat("\t").concat(temp.getNombreParametro()));
		}
		logger.info("Termino");
	}
}

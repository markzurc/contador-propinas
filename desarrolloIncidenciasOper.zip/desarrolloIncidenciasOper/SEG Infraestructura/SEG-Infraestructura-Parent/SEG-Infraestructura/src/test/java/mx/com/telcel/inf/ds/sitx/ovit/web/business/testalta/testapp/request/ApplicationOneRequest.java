package mx.com.telcel.inf.ds.sitx.ovit.web.business.testalta.testapp.request;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.application.thirdparty.request.ApplicationGenericRequest;

public class ApplicationOneRequest extends ApplicationGenericRequest{
	
	private String messageOne;
	private int numberOne;
	private boolean boolOne;
	
	@Override
	public String getBeanNameSpring() {
		return "applicationOne";
	}
	
	/**
	 * @return the messageOne
	 */
	public String getMessageOne() {
		return messageOne;
	}
	/**
	 * @param messageOne the messageOne to set
	 */
	public void setMessageOne(String messageOne) {
		this.messageOne = messageOne;
	}
	/**
	 * @return the numberOne
	 */
	public int getNumberOne() {
		return numberOne;
	}
	/**
	 * @param numberOne the numberOne to set
	 */
	public void setNumberOne(int numberOne) {
		this.numberOne = numberOne;
	}
	/**
	 * @return the boolOne
	 */
	public boolean isBoolOne() {
		return boolOne;
	}
	/**
	 * @param boolOne the boolOne to set
	 */
	public void setBoolOne(boolean boolOne) {
		this.boolOne = boolOne;
	}

}

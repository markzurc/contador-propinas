//For calendar
$(function() {
	$(".datepicker").datepicker({
		inline : true,
		firstDay : 1,
		dateFormat: 'dd/mm/yy'
	});
});
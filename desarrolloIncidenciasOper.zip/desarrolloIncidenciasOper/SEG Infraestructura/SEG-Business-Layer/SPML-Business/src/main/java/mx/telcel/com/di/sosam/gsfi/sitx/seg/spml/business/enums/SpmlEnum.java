package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.enums;

/**
 * <h2>SpmlEnum</h2>
 * 
 * <p>
 * 	SpmlEnum Enum class which contains the SPML keys.
 * <p>
 * 
 * @author hhernanm
 * @version 1.0
 * @since November 2015
 */
public enum SpmlEnum {
	NUMEROEMPLEADO("NUMEROEMPLEADO", false), 
	FIRSTNAME("FIRSTNAME", true),
	LASTNAME("LASTNAME", true),
	CLAVEREGION("CLAVEREGION", true),
	PERFIL99("PERFIL99", true),
	MATERNO("MATERNO", false), 
	JEFE("JEFE", false), 
	PUESTO("PUESTO", true),
	CODIGOJEFE("CODIGOJEFE", false),
	CODIGOPUESTO("CODIGOPUESTO", true), 
	EMAIL("EMAIL", true),
	//nuevos campos spml
	APELLIDOS("APELLIDOS", false),
	CENTCOST("CENTCOST", false),
	CLAVDEPTO("CLAVDEPTO", false),
	CLAVDIRE("CLAVDIRE", false),
	CLAVGERE("CLAVGERE", false),
	CLAVSUBDIR("CLAVSUBDIR", false),
	DEPARTAMENTO("DEPARTAMENTO", true),
	DESCANSO1("DESCANSO1", false),
	DESCANSO2("DESCANSO2", false),
	DIRECCION("DIRECCION", true),
	FECHAINGRESO("FECHAINGRESO", false),
	FULLNAME("FULLNAME", false),
	GERENCIA("GERENCIA", true),
	REGION("REGION", false),
	SUBDIRECCION("SUBDIRECCION", true),
	SPMLTIPO("SPMLTIPO", false),
	TURNO("TURNO", false),
	UBICACION("UBICACION", false),
	UNIVERSAL("UNIVERSAL", true),
	EMPRESA("EMPRESA", false),
	FOLIOSUA("FOLIOSUA", false),
	TIPOUSUARIOIDM("TIPOUSUARIOIDM", false),
	ESTATUSIDM("ESTATUSIDM", false),
	ESTATUSRH("ESTATUSRH", false),
	MOV1IDM("MOV1IDM", false),
	MOV2IDM("MOV2IDM", false),
	MOV3IDM("MOV3IDM", false),
	MOV4IDM("MOV4IDM", false),
	MOV5IDM("MOV5IDM", false),
	R00("R00", false),
	IDREG00("0", false);
	
	private String descripcion;
        private Boolean obligatorio;
	
	private SpmlEnum(String descripcion, Boolean obligatorio) {
		this.descripcion = descripcion;
                this.obligatorio = obligatorio;
	}

	public String getDescripcion() {
		return descripcion;
	}
        
        public Boolean isObligatorio() {
            return this.obligatorio;
        }
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business;

import java.util.Map;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.exception.SpmlOvitException;

/**
 * <h2> ISpmlValidations </h2>
 * 
 * <pre>
 * 	ISpmlValidations interface class which contains all the methods used to 
 * 	validate the information sent by SPML.
 * </pre>
 * 
 * @author hhenranm
 * @version 1.0
 * @since May 2015
 * 
 * @version 1.1
 * @since November 2015
 *
 */
public interface ISpmlValidations {
	
	static final int ROL_DEF = -1;
	static final String DIGIT_PATTERN = "\\d*";
	
	
	/**
	 * <h3> validateNumEmployment </h3>
	 * <pre>
	 * 	Method that validates the NUMEROEMPLEADO value.
	 * 	Rules:
	 * 		* Not null.
	 * 		* Not empty.
	 * 		* <= 250 characteres.
	 * </pre>
	 * 
	 * @author hhenranm
	 * @param  {@link String} numEmployment
	 * @return {@link String}
	 * @throws SpmlOvitException
	 */
	String validateNumEmployment(String numEmployment) throws SpmlOvitException;
	
	/**
	 * <h3> validateFistName </h3>
	 * <pre>
	 * 	Method that validates the FIRSTNAME value.
	 * 	Rules:
	 * 		* Not null.
	 * 		* Not empty.
	 * 		* <= 250 characteres.
	 * </pre>
	 * 
	 * @author hhenranm
	 * @param  {@link String firstName} 
	 * @return {@link String}
	 * @throws SpmlOvitException
	 */
	String validateFistName(String firstName) throws SpmlOvitException;
	
	/**
	 * <h3> validateLastName </h3>
	 * <pre>
	 *	Method that validates the LASTNAME value.
	 *	Rules:
	 * 		* Not null.
	 * 		* Not empty.
	 * 		* <= 250 characteres.
	 * </pre>
	 * 
	 * @author hhenranm
	 * @param  {@link String lastName} 
	 * @return {@link String firstName}
	 * @throws SpmlOvitException
	 */
	String validateLastName(String lastName) throws SpmlOvitException;
	
	/**
	 * <h3> validateRegion </h3>
	 * <pre>
	 *	Method that validates the REGION value.
	 *	Rules:
	 * 		* Not null.
	 * 		* Not empty.
	 * 		* <= 250 characteres.
	 * </pre>
	 * 
	 * @author hhenranm
	 * @param  {@link String region} 
	 * @return {@link String}
	 * @throws SpmlOvitException
	 */
	String validateRegion(String region) throws SpmlOvitException;
	
	/**
	 * <h3> validateRole </h3>
	 * <pre>
	 *	Method that validates the PERFIL99 value.
	 *	Rules:
	 * 		* Not null.
	 * 		* Not empty.
	 * 		* Is digit.
	 * 		* <= 250 characteres.
	 * </pre>
	 * 
	 * @author hhenranm
	 * @param  {@link String role} 
	 * @return {@link Integer}
	 * @throws SpmlOvitException
	 */
	Integer validateRole(String role) throws SpmlOvitException;
	
	/**
	 * <h3> validaEmpresaSua </h3>
	 * <pre>
	 *	Method that validates the EMPRESA and FOLIOSUA fields.
	 *	Rules:
	 * 		* Not null.
	 * 		* Not empty.
	 * 		* Is digit.
	 * 		* <= 10 characteres	.
	 * </pre>
	 * @author hhernanm
	 * @param {@link String fieldName}
	 * @param {@link String field}
	 * @throws SpmlOvitException
	 */
	void validaEmpresaSua(String fieldName,String field) throws SpmlOvitException;
	
	/**
	 * <h3> validateFields </h3>
	 * <pre>
	 *	Method that validates the rest of the new SPML fields.
	 *	Rules:
	 * 		* <= 250 characteres.
	 * </pre>
	 * @author hhernanm
	 * @param {@link String fieldName}
	 * @param {@link String field}
	 * @return {@link String}
	 * @throws SpmlOvitException
	 */
	String validateFields(String fieldName, String field) throws SpmlOvitException;
	
	/**
	 * <h3> validaMovs </h3>
	 * <pre>
	 * 	Method that validates the MOVn_IDM fileds.
	 * 	Rules:
	 * 		* Not null.
	 * 		* Not empty.
	 * 		* <= 3 characteres.
	 * </pre>
	 * @author hhernanm
	 * @param {@link String fieldName}
	 * @param {@link String mov}
	 * @throws SpmlOvitException
	 */
	void validaMovs(String fieldName, String mov) throws SpmlOvitException;
	
	/**
	 * <h3> validaIDM </h3>
	 * <pre>
	 * 	Method that validates the TIPOUSUARIOIDM and ESTATUSIDM fields.
	 * 	Rules:
	 * 		* Not null.
	 * 		* Not empty.
	 * 		* Is digit.
	 * 		* <= 3 characteres.	
	 * </pre>
	 * @author hhernanm
	 * @param {@link String fieldName}
	 * @param {@link String idm}
	 * @throws SpmlOvitException
	 */
	void validaIDM(String fieldName, String idm) throws SpmlOvitException;
	
	/**
	 * <h3> validateMap </h3>
	 * <pre>
	 * 	Method that validates the USER map contains all the SPML fields key.
	 * </pre>
	 * @author hhernanm
	 * @param user
	 * @throws SpmlOvitException
	 */
	void validateMap(Map<String,String> user) throws SpmlOvitException;

	/**
	 * <h3> validateMapModify </h3>
	 * <pre>
	 * 	Method that validates the USER map for an update process,
	 * </pre>
	 * @author hhernanm
	 * @param user
	 * @throws SpmlOvitException
	 */
	void validateMapModify(Map<String,String> user) throws SpmlOvitException;
}

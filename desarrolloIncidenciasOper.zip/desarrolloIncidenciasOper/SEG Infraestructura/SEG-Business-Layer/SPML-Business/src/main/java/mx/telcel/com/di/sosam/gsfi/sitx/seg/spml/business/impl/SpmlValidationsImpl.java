package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.mapper.MapperCustomFactory;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.ISpmlValidations;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.enums.SpmlEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.enums.SpmlErrorEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.exception.SpmlOvitException;

import org.springframework.stereotype.Service;

/**
 * <h2> ISpmlValidations </h2>
 * <pre>
 * 	The implementation class of {@link ISpmlValidations} interface.
 * </pre>
 * @author hhernanm
 * @see {@link ISpmlValidations}
 */
@Service("spmlValidations")
public class SpmlValidationsImpl extends MapperCustomFactory implements ISpmlValidations, Serializable {

	private static final long serialVersionUID = -8927213120516939684L;
	
	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.business.ISpmlValidations#validateNumEmployment(java.lang.String)
	 */
	@Override
	public String validateNumEmployment(String employeeNumber) throws SpmlOvitException {
		String employee;

		if(employeeNumber!=null && !"".equals(employeeNumber.trim()) && 
				(employeeNumber.length()>1 && employeeNumber.length()<=250)){
			employee = employeeNumber;
		}else{
			throw new SpmlOvitException(null, null, 
							String.format(SpmlErrorEnum.ERROR_EMPLOYEE.getMessageError(),
											employeeNumber));
		}
		
		return employee;
	}

	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.business.ISpmlValidations#validateFistName(java.lang.String)
	 */
	@Override
	public String validateFistName(String firstName) throws SpmlOvitException {
		String name;
		if(firstName!=null && !"".equals(firstName.trim()) && firstName.length()<=250){
			name = firstName;
		}else{
			throw new SpmlOvitException(null, null, 
							String.format(SpmlErrorEnum.ERROR_FIRST.getMessageError(),
											firstName));
		}
		return name;
	}

	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.business.ISpmlValidations#validateLastName(java.lang.String)
	 */
	@Override
	public String validateLastName(String lastName) throws SpmlOvitException {
		String apellidoPat;
		if(lastName!=null && !"".equals(lastName.trim()) && lastName.length()<=250){
			apellidoPat = lastName;
		}else{
			throw new SpmlOvitException(null, null, 
							String.format(SpmlErrorEnum.ERROR_LAST.getMessageError(), 
											lastName));
		}
		return apellidoPat;
	}

	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.business.ISpmlValidations#validateRegion(java.lang.String)
	 */
	@Override
	public String validateRegion(String region) throws SpmlOvitException {
		String nameRegion;
		if(region!=null && !"".equals(region.trim()) && region.length()<=250){
			nameRegion = region;
		}else{
			throw new SpmlOvitException(null, null, 
							String.format(SpmlErrorEnum.ERROR_REGION.getMessageError(), 
											region));
		}
		return nameRegion;
	}
	
	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.business.ISpmlValidations#validateRole(java.lang.String)
	 */
	@Override
	public Integer validateRole(String role) throws SpmlOvitException {
		Integer idRole;	
		if(role!=null && !"".equals(role.trim()) && role.matches(DIGIT_PATTERN) && role.length()<=250){
			idRole = Integer.valueOf(role);
		}else{
			idRole = ROL_DEF;
		}
		return idRole;
	}

	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.business.ISpmlValidations#validaEmpresaSua(java.lang.String)
	 */
	@Override
	public void validaEmpresaSua(String fieldName, String field) throws SpmlOvitException {
        //Se modifica condicion para prueba 
		if(field!=null && !"".equals(field.trim()) && field.length()<=100){
		}else{
			throw new SpmlOvitException(null, null, 
							String.format(SpmlErrorEnum.ERROR_FIELD.getMessageError(), 
									fieldName, field));
		}
	}
	
	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.business.ISpmlValidations#validaMovs(java.lang.String)
	 */
	@Override
	public void validaMovs(String fieldName, String mov) throws SpmlOvitException {
		if(mov!=null && !"".equals(mov.trim()) && mov.length()<=10){
		}else{
			throw new SpmlOvitException(null, null, 
							String.format(SpmlErrorEnum.ERROR_FIELD.getMessageError(), 
									fieldName, mov));
		}
	}
	
	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.business.ISpmlValidations#validaIDM(java.lang.String)
	 */
	@Override
	public void validaIDM(String fieldName, String idm) throws SpmlOvitException {
		if(idm!=null && !"".equals(idm.trim()) && idm.length()<=3){
		}else{
			throw new SpmlOvitException(null, null, 
							String.format(SpmlErrorEnum.ERROR_FIELD.getMessageError(), 
									fieldName, idm));
		}
	}
	
	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.business.ISpmlValidations#getSpmlMap(java.util.Map)
	 */
	@Override	
	public String validateFields(String fieldName, String field) throws SpmlOvitException{
		if(field!=null && !field.equals("") && field.length()<=250){
			return field;
		}else{
			throw new SpmlOvitException(null, null, 
							String.format(SpmlErrorEnum.ERROR_FIELD.getMessageError(), 
											fieldName,field));
		}
	}
        
	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.business.ISpmlValidations#validateMap(java.util.Map)
	 */
	@Override
	public void validateMap(Map<String, String> user) throws SpmlOvitException {
            List<SpmlEnum> spmEnum = new ArrayList<SpmlEnum>(EnumSet.allOf(SpmlEnum.class));           
            for (SpmlEnum aux : spmEnum) {
                if(aux.isObligatorio() && !user.containsKey(aux.getDescripcion())){
                    throw new SpmlOvitException(null, null, 
                            String.format(SpmlErrorEnum.ERROR_KEY.getMessageError(), 
                                    aux.getDescripcion()));
                }
            }
	}


	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.business.ISpmlValidations#validateMapModify(java.util.Map)
	 */
	@Override
	public void validateMapModify(Map<String, String> user) throws SpmlOvitException {
		
		Map<String,String> mapAux = new HashMap<String, String>(user);
		
		if(mapAux.containsKey(SpmlEnum.FIRSTNAME.getDescripcion())){
			validateFistName(mapAux.get(SpmlEnum.FIRSTNAME.getDescripcion()));
			mapAux.remove(SpmlEnum.FIRSTNAME.getDescripcion());
		}
		if(mapAux.containsKey(SpmlEnum.LASTNAME.getDescripcion())){
			validateLastName(mapAux.get(SpmlEnum.LASTNAME.getDescripcion()));
			mapAux.remove(SpmlEnum.LASTNAME.getDescripcion());
		}
		if(mapAux.containsKey(SpmlEnum.CLAVEREGION.getDescripcion())){
			validateRegion(mapAux.get(SpmlEnum.CLAVEREGION.getDescripcion()));
			mapAux.remove(SpmlEnum.CLAVEREGION.getDescripcion());
		}
		if(mapAux.containsKey(SpmlEnum.PERFIL99.getDescripcion())){
			validateRole(mapAux.get(SpmlEnum.PERFIL99.getDescripcion()));
			mapAux.remove(SpmlEnum.PERFIL99.getDescripcion());
		}
                
		if(user.containsKey(SpmlEnum.EMPRESA.getDescripcion())){
			validaEmpresaSua(SpmlEnum.EMPRESA.getDescripcion(), 
								user.get(SpmlEnum.EMPRESA.getDescripcion()));
			mapAux.remove(SpmlEnum.EMPRESA.getDescripcion());
		}
                
                if(user.containsKey(SpmlEnum.PUESTO.getDescripcion())){
			validateFields(SpmlEnum.PUESTO.getDescripcion(), 
								user.get(SpmlEnum.PUESTO.getDescripcion()));
			mapAux.remove(SpmlEnum.PUESTO.getDescripcion());
		}
                 
                if(user.containsKey(SpmlEnum.CODIGOPUESTO.getDescripcion())){
			validateFields(SpmlEnum.CODIGOPUESTO.getDescripcion(), 
								user.get(SpmlEnum.CODIGOPUESTO.getDescripcion()));
			mapAux.remove(SpmlEnum.CODIGOPUESTO.getDescripcion());
		} 
                
                if(user.containsKey(SpmlEnum.EMAIL.getDescripcion())){
			validateFields(SpmlEnum.EMAIL.getDescripcion(), 
								user.get(SpmlEnum.EMAIL.getDescripcion()));
			mapAux.remove(SpmlEnum.EMAIL.getDescripcion());
		}
                
                if(user.containsKey(SpmlEnum.DEPARTAMENTO.getDescripcion())){
			validateFields(SpmlEnum.DEPARTAMENTO.getDescripcion(), 
								user.get(SpmlEnum.DEPARTAMENTO.getDescripcion()));
			mapAux.remove(SpmlEnum.DEPARTAMENTO.getDescripcion());
		}
                
                if(user.containsKey(SpmlEnum.DIRECCION.getDescripcion())){
			validateFields(SpmlEnum.DIRECCION.getDescripcion(), 
								user.get(SpmlEnum.DIRECCION.getDescripcion()));
			mapAux.remove(SpmlEnum.DIRECCION.getDescripcion());
		}
                
                if(user.containsKey(SpmlEnum.GERENCIA.getDescripcion())){
			validateFields(SpmlEnum.GERENCIA.getDescripcion(), 
								user.get(SpmlEnum.GERENCIA.getDescripcion()));
			mapAux.remove(SpmlEnum.GERENCIA.getDescripcion());
		}
                
                if(user.containsKey(SpmlEnum.SUBDIRECCION.getDescripcion())){
			validateFields(SpmlEnum.SUBDIRECCION.getDescripcion(), 
								user.get(SpmlEnum.SUBDIRECCION.getDescripcion()));
			mapAux.remove(SpmlEnum.SUBDIRECCION.getDescripcion());
		}
                
                if(user.containsKey(SpmlEnum.UNIVERSAL.getDescripcion())){
			validateFields(SpmlEnum.UNIVERSAL.getDescripcion(), 
								user.get(SpmlEnum.UNIVERSAL.getDescripcion()));
			mapAux.remove(SpmlEnum.UNIVERSAL.getDescripcion());
		}
                
                for(Map.Entry<String, String> e : mapAux.entrySet()){
			
			validateFields(e.getKey().toString(),
								e.getValue()!=null?e.getValue().toString():"");	
		}
	}
	
}

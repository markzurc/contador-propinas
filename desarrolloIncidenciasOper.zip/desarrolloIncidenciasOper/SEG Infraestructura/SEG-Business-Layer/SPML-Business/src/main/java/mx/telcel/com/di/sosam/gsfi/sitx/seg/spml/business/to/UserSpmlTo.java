package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.to;

import java.io.Serializable;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.telcel.dwi.spml2.server.resource.User;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.enums.SpmlLogEnum;


/**
 * <h2> UserSpmlTo </h2>
 * 
 * @author hhernanm
 *
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder={"userId", "attributes", "excepcion"})
public class UserSpmlTo implements Serializable {
	
	private static final long serialVersionUID = 4554167079212766378L;
	
	@XmlElement(name = "userId")
	private String userId;
	
	@XmlElement(name = "attributes")
	private Map<String, String> attributes;
	
	@XmlElement(name = "excepcion")
	private String excepcion;
	
	
	
	public UserSpmlTo(User user){
		this.userId = user.getUserId()!=null?user.getUserId():"";
		this.attributes = user.getAttributes()!=null?user.getAttributes():null;
		this.excepcion = user.getAttributes().get(SpmlLogEnum.EXEPCION.getDescripcion())!=null?
								user.getAttributes().get(SpmlLogEnum.EXEPCION.getDescripcion()):null;
		this.attributes.remove(SpmlLogEnum.EXEPCION.getDescripcion());
	}

	public UserSpmlTo() {
		super();
	}
	
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the attributes
	 */
	public Map<String, String> getAttributes() {
		return attributes;
	}

	/**
	 * @param attributes the attributes to set
	 */
	public void setAttributes(Map<String, String> attributes) {
		this.attributes = attributes;
	}

	/**
	 * @return the excepcion
	 */
	public String getExcepcion() {
		return excepcion;
	}

	/**
	 * @param excepcion the excepcion to set
	 */
	public void setExcepcion(String excepcion) {
		this.excepcion = excepcion;
	}
	
	
	
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.vo;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "FoundUsersList")
@XmlAccessorType (XmlAccessType.FIELD)
public class FoundUsersList implements Serializable{
	
	private static final long serialVersionUID = 237174996811385309L;

	@XmlElement(name = "user")
	private List<FoundUserVo> users;
	
	public FoundUsersList() {
	}

	/**
	 * @return the users
	 */
	public List<FoundUserVo> getUsers() {
		return users;
	}

	/**
	 * @param users the users to set
	 */
	public void setUsers(List<FoundUserVo> users) {
		this.users = users;
	}
	
	
	
}

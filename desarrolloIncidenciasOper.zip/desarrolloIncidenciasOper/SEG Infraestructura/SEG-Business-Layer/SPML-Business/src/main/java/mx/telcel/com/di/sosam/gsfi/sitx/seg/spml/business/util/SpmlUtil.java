package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.util;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.ISpmlValidations;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.enums.SpmlEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.enums.SpmlErrorEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.enums.SpmlLogEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.exception.SpmlOvitException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.impl.SpmlValidationsImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.vo.InternalSpmlVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.vo.UserSPMLVo;



/**
 * <h2>SpmlUtil</h2>
 * 
 * @author hhernanm
 * @version 1.0
 */
public class SpmlUtil implements Serializable{

	private static final long serialVersionUID = -3089190444220882392L;

	private static Logger logger = LogManager.getLogger(SpmlValidationsImpl.class);
	
	
	public static InternalSpmlVo getSpmlMap(Map<String, String> userMap) throws SpmlOvitException {
		InternalSpmlVo internalSpmlVo = new InternalSpmlVo();
		try{
			
			ISpmlValidations spmlValidations = new SpmlValidationsImpl();
			
			internalSpmlVo.setApellidoMaterno(userMap.get(SpmlEnum.MATERNO.getDescripcion()));
                        
                        internalSpmlVo.setJefe(userMap.get(SpmlEnum.JEFE.getDescripcion()));
                        
                        internalSpmlVo.setPuesto(spmlValidations.validateFields(SpmlEnum.PUESTO.getDescripcion(),
												userMap.get(SpmlEnum.PUESTO.getDescripcion())));
                        internalSpmlVo.setCodigoJefe(userMap.get(SpmlEnum.CODIGOJEFE.getDescripcion()));
                        
                        internalSpmlVo.setCodigoPuesto(spmlValidations.validateFields(SpmlEnum.CODIGOPUESTO.getDescripcion(),
												userMap.get(SpmlEnum.CODIGOPUESTO.getDescripcion())));	
			
                        internalSpmlVo.setCorreo(spmlValidations.validateFields(SpmlEnum.EMAIL.getDescripcion(),
												userMap.get(SpmlEnum.EMAIL.getDescripcion())));
			
			internalSpmlVo.setApellidos(userMap.get(SpmlEnum.APELLIDOS.getDescripcion()));
                        
			internalSpmlVo.setCentCost(userMap.get(SpmlEnum.CENTCOST.getDescripcion()));
                        
			internalSpmlVo.setClavDepto(userMap.get(SpmlEnum.CLAVDEPTO.getDescripcion()));
                        
			internalSpmlVo.setClavDire(userMap.get(SpmlEnum.CLAVDIRE.getDescripcion()));
                        
			internalSpmlVo.setClavGere(userMap.get(SpmlEnum.CLAVGERE.getDescripcion()));
			
                        internalSpmlVo.setClavSubdir(userMap.get(SpmlEnum.CLAVSUBDIR.getDescripcion()));
                        
			internalSpmlVo.setDepartamento(spmlValidations.validateFields(SpmlEnum.DEPARTAMENTO.getDescripcion(),
												userMap.get(SpmlEnum.DEPARTAMENTO.getDescripcion())));
			
                        internalSpmlVo.setDescanso1(userMap.get(SpmlEnum.DESCANSO1.getDescripcion()));
			
                        internalSpmlVo.setDescanso2(userMap.get(SpmlEnum.DESCANSO2.getDescripcion()));
                        
			internalSpmlVo.setDireccion(spmlValidations.validateFields(SpmlEnum.DIRECCION.getDescripcion(),
												userMap.get(SpmlEnum.DIRECCION.getDescripcion())));
			
                        internalSpmlVo.setFechaIngreso(userMap.get(SpmlEnum.FECHAINGRESO.getDescripcion()));
			
                        internalSpmlVo.setFullname(userMap.get(SpmlEnum.FULLNAME.getDescripcion()));
                        
			internalSpmlVo.setGerencia(spmlValidations.validateFields(SpmlEnum.GERENCIA.getDescripcion(),
												userMap.get(SpmlEnum.GERENCIA.getDescripcion())));
			
                        internalSpmlVo.setRegion(userMap.get(SpmlEnum.REGION.getDescripcion()));
                        
			internalSpmlVo.setSubdireccion(spmlValidations.validateFields(SpmlEnum.SUBDIRECCION.getDescripcion(),
												userMap.get(SpmlEnum.SUBDIRECCION.getDescripcion())));
			
                        internalSpmlVo.setSpmlTipo(userMap.get(SpmlEnum.SPMLTIPO.getDescripcion()));
                        
			internalSpmlVo.setTurno(userMap.get(SpmlEnum.TURNO.getDescripcion()));
                        
			internalSpmlVo.setUbicacion(userMap.get(SpmlEnum.UBICACION.getDescripcion()));
			
                        internalSpmlVo.setUniversal(spmlValidations.validateFields(SpmlEnum.UNIVERSAL.getDescripcion(),
												userMap.get(SpmlEnum.UNIVERSAL.getDescripcion())));
                        
                        
		}catch(SpmlOvitException e){
			logger.error("Error al mapear informacion aprovisionada por SPML");
			throw e;
		}
		return internalSpmlVo;
	}
	
	public static Map<String, String> voToUser(UserSPMLVo element) throws SpmlOvitException{
		Map<String, String> objectAsMap = new HashMap<String, String>();
		try {
			BeanInfo info = Introspector.getBeanInfo(element.getClass());
			for (PropertyDescriptor pd : info.getPropertyDescriptors()) {
				Method reader = pd.getReadMethod();
				if (reader != null) {
					objectAsMap.put(pd.getName().toUpperCase(),
							reader.invoke(element)!=null?reader.invoke(element).toString():"");
				}
			}
		} catch (IntrospectionException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e) {
			logger.error("Error al convertir vo a mapa: " + e);
			logger.error("Error: ".concat(e.getMessage()));
			throw new SpmlOvitException(null, null, String.format(SpmlErrorEnum.ERROR_MAP.getMessageError(), 
					UserSPMLVo.class, Map.class, e.getMessage()));
		}
		
		return objectAsMap;

	}
	
	public static Map<String, String> mapSpmlTransformer(Map<String, String> element) throws SpmlOvitException{
		try{
			//elimina campos que no deben ser proporcionados a SPML
			element.remove(SpmlLogEnum.IDUSUARIO.getDescripcion());
			element.remove(SpmlLogEnum.USUARIOCREACION.getDescripcion());
			element.remove(SpmlLogEnum.FECHACREACION.getDescripcion());
			element.remove(SpmlLogEnum.USUARIOMODIFICACION.getDescripcion());
			element.remove(SpmlLogEnum.FECHAMODIFICACION.getDescripcion());
			element.remove(SpmlLogEnum.IDESTATUS.getDescripcion());
			element.remove(SpmlLogEnum.RFC.getDescripcion());
			element.remove(SpmlLogEnum.EXEPCION.getDescripcion());
			element.remove(SpmlLogEnum.CLASS.getDescripcion());
			
			element.remove(SpmlEnum.FOLIOSUA.getDescripcion());
			element.remove(SpmlEnum.EMPRESA.getDescripcion());
			element.remove(SpmlEnum.TIPOUSUARIOIDM.getDescripcion());
			element.remove(SpmlEnum.ESTATUSIDM.getDescripcion());
			element.remove(SpmlEnum.ESTATUSRH.getDescripcion());
			element.remove(SpmlEnum.MOV1IDM.getDescripcion());
			element.remove(SpmlEnum.MOV2IDM.getDescripcion());
			element.remove(SpmlEnum.MOV3IDM.getDescripcion());
			element.remove(SpmlEnum.MOV4IDM.getDescripcion());
			element.remove(SpmlEnum.MOV5IDM.getDescripcion());
			
			//se cambian los valores de los campos de ovit a su correspondiente en spml 
			element.put(SpmlEnum.FIRSTNAME.getDescripcion(), element.get("NOMBRE"));
			element.remove("NOMBRE");
			element.put(SpmlEnum.CLAVEREGION.getDescripcion(), element.get("IDREGION").equals(SpmlEnum.R00.getDescripcion())?SpmlEnum.IDREG00.getDescripcion():element.get("IDREGION"));
			element.remove("IDREGION");
			element.put(SpmlEnum.PERFIL99.getDescripcion(), element.get("IDROL"));
			element.remove("IDROL");
			element.put(SpmlEnum.MATERNO.getDescripcion(), element.get("APELLIDOMATERNO"));
			element.remove("APELLIDOMATERNO");
			element.put(SpmlEnum.EMAIL.getDescripcion(), element.get("CORREO"));
			element.remove("CORREO");
			element.put(SpmlEnum.LASTNAME.getDescripcion(), element.get("APELLIDOPATERNO"));
			element.remove("APELLIDOPATERNO");
			

		}catch (Exception e) {
			logger.error("Error al convertir vo a mapa: " + e);
			logger.error("Error: ".concat(e.getMessage()));
			throw new SpmlOvitException(null, null, String.format(SpmlErrorEnum.ERROR_MAP.getMessageError(), 
					UserSPMLVo.class, Map.class,e.getMessage()));
		}
		
		return element;
	}
	
	public static void mapSpmlTransforme(Map<String, String> element) throws SpmlOvitException{
		
	}
	
}

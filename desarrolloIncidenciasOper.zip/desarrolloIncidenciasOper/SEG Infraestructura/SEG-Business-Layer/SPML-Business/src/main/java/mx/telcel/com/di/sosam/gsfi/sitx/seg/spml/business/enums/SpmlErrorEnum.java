package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.enums;

/**
 * <h2>SpmlErrorEnum</h2>
 * 
 * <p>
 * 	SpmlErrorEnum Enum class which contains the SPML errors.
 * <p>
 * 
 * @author hhernanm
 * @version 1.0
 * @since November 2015
 */
public enum SpmlErrorEnum {
	ERROR_EMPLOYEE	("ERR_EMPLOYEE", 	"Numero de empleado incorrecto: %s"),
	ERROR_FIRST		("ERROR_FIRST", 	"Nombre incorrecto: %s"),
	ERROR_LAST		("ERROR_LAST", 		"Apellido paterno incorrecto: %s"),
	ERROR_REGION	("ERROR_LAST", 		"Region incorrecta: %s"),
	ERROR_FIELD		("ERROR_EMPTY", 	"%s, incorrecto: %s"),
	ERROR_USER_EXT	("ERROR_USER_EXT", 	"El usuario a dar de alta o modificar es un usuario externo existente"),
	ERROR_MAP		("ERROR_MAP", 		"Conversion de objeto %s a %s fallida - %s"),
	ERROR_KEY		("ERROR_MAP",		"Llave %s no existe en mapa de usuario"),
	
	ERROR_SIGNUP 			("SPML-E001", "Error al dar de alta a usuario"),
	USUARIO_DOES_NOT_EXISTS ("SPML-E002", "El usuario %s no existe o se encuentra deshabilitado"),
	ERROR_DELETE 			("SPML-E003", "Error al dar de baja a usuario %s"),
	ERROR_ENABLE 			("SPML-E004", "Error al habilitar a usuario %s"),
	ERROR_SEARCH 			("SPML-E005", "Error al buscar a usuario %s"),
	ERROR_MODIFY 			("SPML-E006", "Error al modificar a usuario %s"),
	ERROR_LIST 				("SPML-E007", "Error al consultar los usuarios internos"),
	ERROR_EMPTY_LIST 		("SPML-E008", "Lista de usuarios vacia");
	
	String codeError;
	String messageError;
	
	SpmlErrorEnum(String codeError, String messageError) {
		this.codeError = codeError;
		this.messageError = messageError;
	}

	/**
	 * @return the codeError
	 */
	public String getCodeError() {
		return codeError;
	}

	/**
	 * @param codeError the codeError to set
	 */
	public void setCodeError(String codeError) {
		this.codeError = codeError;
	}

	/**
	 * @return the messageError
	 */
	public String getMessageError() {
		return messageError;
	}

	/**
	 * @param messageError the messageError to set
	 */
	public void setMessageError(String messageError) {
		this.messageError = messageError;
	}
	
	
	
}

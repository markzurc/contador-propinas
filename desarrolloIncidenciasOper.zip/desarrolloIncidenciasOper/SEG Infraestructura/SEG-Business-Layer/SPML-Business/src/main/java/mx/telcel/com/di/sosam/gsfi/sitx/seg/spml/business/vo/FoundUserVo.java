package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="FoudUser")
@XmlAccessorType(XmlAccessType.FIELD)
public class FoundUserVo implements Serializable {
	
	private static final long serialVersionUID = -616688536632021497L;
	
	@XmlElement(name = "numeroEmpleado", nillable=true)
	private String numeroEmpleado;
	@XmlElement(name = "nombre", nillable=true)
	private String nombre;
	@XmlElement(name = "apellidoPaterno", nillable=true)
	private String apellidoPaterno;
	@XmlElement(name = "apellidoMaterno", nillable=true)
	private String apellidoMaterno;
	
	public FoundUserVo(){
		
	}
	
	public FoundUserVo(String numeroEmpleado, String nombre,
			String apellidoPaterno, String apellidoMaterno) {
		this.numeroEmpleado = numeroEmpleado;
		this.nombre = nombre;
		this.apellidoPaterno = apellidoPaterno;
		this.apellidoMaterno = apellidoMaterno;
	}
	/**
	 * @return the numeroEmpleado
	 */
	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}
	/**
	 * @param numeroEmpleado the numeroEmpleado to set
	 */
	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}
	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @return the apellidoPaterno
	 */
	public String getApellidoPaterno() {
		return apellidoPaterno;
	}
	/**
	 * @param apellidoPaterno the apellidoPaterno to set
	 */
	public void setApellidoPaterno(String apellidoPaterno) {
		this.apellidoPaterno = apellidoPaterno;
	}
	/**
	 * @return the apellidoMaterno
	 */
	public String getApellidoMaterno() {
		return apellidoMaterno;
	}
	/**
	 * @param apellidoMaterno the apellidoMaterno to set
	 */
	public void setApellidoMaterno(String apellidoMaterno) {
		this.apellidoMaterno = apellidoMaterno;
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.exception;

import com.telcel.dwi.spml2.server.Spml2ServerException;
/**
 * <h1>SpmlOvitException</h1>
 * <p>
 * </p>
 * @author hhernanm
 * @version 1.0
 */
public class SpmlOvitException extends Spml2ServerException {

	private static final long serialVersionUID = 97341463732982634L;
	
	private String message; 
	private String codeError;
	private String causeby;
	
	public SpmlOvitException(String message) {
		super(message);
	}
	
	
	public SpmlOvitException(String codeError, String message,String causeby) {
		super(message);
		this.codeError = codeError;
		this.message = message;
		this.causeby = causeby;
	}


	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}


	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return the codeError
	 */
	public String getCodeError() {
		return codeError;
	}


	/**
	 * @param codeError the codeError to set
	 */
	public void setCodeError(String codeError) {
		this.codeError = codeError;
	}
	
	/**
	 * @return the causeby
	 */
	public String getCauseby() {
		return causeby;
	}


	/**
	 * @param causeby the causeby to set
	 */
	public void setCauseby(String causeby) {
		this.causeby = causeby;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toStringError() {
		StringBuilder builder = new StringBuilder();
		builder.append("SpmlOvitException [");
		builder.append(codeError);
		builder.append("] ");
		builder.append(message);
		builder.append(" cause by ");
		builder.append(causeby);
		return builder.toString();
	}

}

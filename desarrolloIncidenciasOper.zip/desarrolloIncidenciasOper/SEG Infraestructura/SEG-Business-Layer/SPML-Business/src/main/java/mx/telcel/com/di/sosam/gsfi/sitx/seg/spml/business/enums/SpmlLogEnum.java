package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.enums;

/**
 * <h2>SpmlLogEnum</h2>
 * 
 * <p>
 * 	SpmlLogEnum Enum class which contains the SPML log key.
 * <p>
 * 
 * @author hhernanm
 * @version 1.0
 * @since November 2015
 */
public enum SpmlLogEnum {
	// utilizado para la llave de excepci�n del mapa User
	EXEPCION("EXCEPCION"),
	// utilizados para remover las llaves del mapa User
	IDUSUARIO("IDUSUARIO"), 
	USUARIOCREACION("USUARIOCREACION"), 
	FECHACREACION("FECHACREACION"),
	USUARIOMODIFICACION("USUARIOMODIFICACION"), 
	FECHAMODIFICACION("FECHAMODIFICACION"), 
	IDESTATUS("IDESTATUS"), 
	RFC("RFC"), 
	CLASS("CLASS");
	
	private String descripcion;
	
	private SpmlLogEnum(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getDescripcion() {
		return descripcion;
	}

}

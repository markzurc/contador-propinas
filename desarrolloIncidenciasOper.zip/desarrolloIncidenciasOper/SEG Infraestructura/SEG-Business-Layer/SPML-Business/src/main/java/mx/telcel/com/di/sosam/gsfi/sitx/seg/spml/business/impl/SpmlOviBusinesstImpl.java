package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.impl;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.IBitacoraSoxBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.vo.BitacoraSoxVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.error.ErrorSEGWeb;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.mapper.MapperCustomFactory;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcRol;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoDatoUsuaInte;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoUsua;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.TsegcDatosinternoId;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.ISpmlOvitBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.enums.SpmlEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.enums.SpmlErrorEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.vo.InternalSpmlVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.vo.UserSPMLVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.data.ISpmlDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.data.dto.UserSPMLDto;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
 
import com.telcel.dwi.spml2.server.resource.User;

/**
 * <h2> SpmlOviBusinesstImpl </h2>
 * 
 * <p>
 * 		The implementation class of {@link ISpmlOvitBusiness} interface.
 * </p>
 * 
 * @author chcastro
 * @author hhernanm
 * @version 1.0
 * @since May 2015
 * @see {@link ISpmlOvitBusiness}
 * 
 */

@Service("spmlOvit")
@Scope("prototype")
public class SpmlOviBusinesstImpl extends MapperCustomFactory implements ISpmlOvitBusiness, Serializable {

	private static final long serialVersionUID = 3811394320955709653L;
	private static final Logger logger = LogManager.getLogger(SpmlOviBusinesstImpl.class);
	private static final int TIPO_USUARIO = 0;
	
	@Autowired
	@Qualifier("bitacoraSox")
	private IBitacoraSoxBusiness bitacoraSoxBusiness;
	
	@Autowired
	@Qualifier("spmlDao")
	private ISpmlDao spmlDao;
	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.business.ISpmlOvitBusiness#createUserSPML(mx.com.telcel.inf.ds.sitx.ovit.spml.business.vo.UserSPMLVo)
	 */
	@Transactional(value = "transactionManagerOVITSPML", rollbackFor = Exception.class)
	@Override
	public void createUserSPML(InternalSpmlVo interUserSPMLVo)throws TransactionalOVITException {
		logger.info("Ejecutando UserBusinessImpl.validateLogIn");
		T7segoUsua tsegcUsuario;
		T7segoDatoUsuaInte datosinterno;
		BitacoraSoxVo bitacoraSoxVo;
		
		try {
			UserSPMLDto spmlDto = spmlDao.validateUser(interUserSPMLVo.getNumeroEmpleado());
			tsegcUsuario= getMapper().map(spmlDto, T7segoUsua.class);
			
			bitacoraSoxBusiness.setSession(spmlDao.getSession());
			bitacoraSoxVo = new BitacoraSoxVo();
			
			if(tsegcUsuario == null){
				logger.info("Creando usuario interno".concat(""));
				
				tsegcUsuario = getMapper().map(interUserSPMLVo, T7segoUsua.class);
				tsegcUsuario.setFechaCreacion(new Date());
				tsegcUsuario.setIdEstatus(ISpmlOvitBusiness.STATUS_ACTIVE);
				tsegcUsuario.setIdTipoUsuario(TIPO_USUARIO);
				tsegcUsuario.setUsuarioCreacion(USER_NAME_SPML);
				tsegcUsuario.setTsegcRol(new T7segcRol(interUserSPMLVo.getIdRol()));
			
				datosinterno = getMapper().map(interUserSPMLVo, T7segoDatoUsuaInte.class);
				datosinterno.setIdRol(interUserSPMLVo.getIdRol());
								
				bitacoraSoxVo.setObjetoInicial(bitacoraSoxBusiness.objectToXML(interUserSPMLVo));
				spmlDao.createUserSPML(tsegcUsuario, datosinterno);
				
				interUserSPMLVo.setIdUsuario(tsegcUsuario.getIdUsuario());
				interUserSPMLVo.setUsuarioCreacion(tsegcUsuario.getUsuarioCreacion());
				interUserSPMLVo.setFechaCreacion(tsegcUsuario.getFechaCreacion());
				interUserSPMLVo.setIdEstatus(tsegcUsuario.getIdEstatus());
				
				bitacoraSoxVo.setObjetoFinal(bitacoraSoxBusiness.objectToXML(interUserSPMLVo));
				bitacoraSoxVo.setIdAccion(IBitacoraSoxBusiness.CREATE);
			
			}else if(tsegcUsuario.getIdTipoUsuario() == TIPO_USUARIO) {
				logger.info("Actualizando usuario interno".concat(interUserSPMLVo.getNumeroEmpleado()));
				spmlDao.getSession().evict(tsegcUsuario);
				
				interUserSPMLVo.setIdUsuario(spmlDto.getIdUsuario());
				interUserSPMLVo.setUsuarioCreacion(spmlDto.getUsuarioCreacion());
				interUserSPMLVo.setFechaCreacion(new Date());		
				tsegcUsuario = getMapper().map(interUserSPMLVo, T7segoUsua.class);
				tsegcUsuario.setFechaModificacion(new Date());
                                //Modificacion de Fecha Logeo
                                tsegcUsuario.setFechaLogueo(null);
				tsegcUsuario.setIdEstatus(ISpmlOvitBusiness.STATUS_ACTIVE);
				tsegcUsuario.setIdTipoUsuario(TIPO_USUARIO);
				tsegcUsuario.setUsuarioModificacion(USER_NAME_SPML);
				tsegcUsuario.setTsegcRol(new T7segcRol(interUserSPMLVo.getIdRol()));
				
				datosinterno = getMapper().map(interUserSPMLVo, T7segoDatoUsuaInte.class);
				datosinterno.setId(new TsegcDatosinternoId(tsegcUsuario.getIdUsuario()));
				datosinterno.setIdRol(interUserSPMLVo.getIdRol());
				
				InternalSpmlVo iniData = getMapper().map(spmlDto, InternalSpmlVo.class);
				bitacoraSoxVo.setObjetoInicial(bitacoraSoxBusiness.objectToXML(iniData));
				
				spmlDao.updateUserSPML(tsegcUsuario, datosinterno);
				
				interUserSPMLVo.setIdUsuario(iniData.getIdUsuario());
				interUserSPMLVo.setFechaCreacion(iniData.getFechaCreacion());
				interUserSPMLVo.setUsuarioCreacion(iniData.getUsuarioCreacion());
				interUserSPMLVo.setFechaModificacion(tsegcUsuario.getFechaModificacion());
				interUserSPMLVo.setUsuarioModificacion(tsegcUsuario.getUsuarioModificacion());
				interUserSPMLVo.setIdEstatus(tsegcUsuario.getIdEstatus());
				
				bitacoraSoxVo.setObjetoFinal(bitacoraSoxBusiness.objectToXML(interUserSPMLVo));
				bitacoraSoxVo.setIdAccion(IBitacoraSoxBusiness.UPDATE);
			}else{
				throw new TransactionalOVITException(SpmlErrorEnum.ERROR_USER_EXT.getCodeError(), 
									SpmlErrorEnum.ERROR_USER_EXT.getMessageError());
			}
			bitacoraSoxVo.setFechaOperacion(new Date());
			bitacoraSoxVo.setFolioSua(interUserSPMLVo.getFolioSua());			
			bitacoraSoxVo.setIdUsuario(ID_USER_SPML);
			bitacoraSoxVo.setNumeroEmpleado(USER_NAME_SPML);
			bitacoraSoxBusiness.createBitacoraSox(bitacoraSoxVo);
		}catch(TransactionalOVITException e){
			logger.error("Descripcion del Error: Codigo: ".concat(e.toString()));
			throw e;
		}
		catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E01_ERROR_INSERT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E01_ERROR_INSERT.getMessageError()));
			logger.error("Error al ejecutar SpmlOviBusinesstImpl.createUserSPML: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E01_ERROR_INSERT.getCodeError(),
					ErrorSEGWeb.E01_ERROR_INSERT.getMessageError());
		}
	}
	
	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.business.ISpmlOvitBusiness#updateUserSPML(mx.com.telcel.inf.ds.sitx.ovit.spml.business.vo.UserSPMLVo)
	 */
	@Transactional(value = "transactionManagerOVITSPML", rollbackFor = Exception.class)
	@Override
	public void updateUserSPML(User user)throws TransactionalOVITException{
		logger.info("Ejecutando UserBusinessImpl.validateLogIn");
		T7segoUsua tsegcUsuario;
		T7segoDatoUsuaInte datosinterno;
		BitacoraSoxVo bitacoraSoxVo;
		
		try {
			UserSPMLDto spmlDto = spmlDao.validateUser(user.getUserId());
			tsegcUsuario = getUsuarioMod(spmlDto, user.getAttributes());
			
			bitacoraSoxBusiness.setSession(spmlDao.getSession());
			bitacoraSoxVo = new BitacoraSoxVo();
			
			if(tsegcUsuario == null){
				throw new TransactionalOVITException(ErrorSEGWeb.E09_ERROR_MOD_USER.getCodeError(),
						ErrorSEGWeb.E09_ERROR_MOD_USER.getMessageError());
				
			}else if (tsegcUsuario.getIdTipoUsuario() == TIPO_USUARIO){
				logger.info("Actualizando usuario interno".concat(user.getUserId()));
				spmlDao.getSession().evict(tsegcUsuario);

				tsegcUsuario.setFechaModificacion(new Date());
				tsegcUsuario.setUsuarioModificacion(USER_NAME_SPML);
				
				datosinterno = getExternoMod(spmlDto, user.getAttributes());
				datosinterno.setId(new TsegcDatosinternoId(tsegcUsuario.getIdUsuario()));
				
				InternalSpmlVo iniData = getMapper().map(spmlDto, InternalSpmlVo.class);
				bitacoraSoxVo.setObjetoInicial(bitacoraSoxBusiness.objectToXML(iniData));
				
				spmlDao.updateUserSPML(tsegcUsuario, datosinterno);
				
				InternalSpmlVo finData = getMapper().map(datosinterno, InternalSpmlVo.class);
				finData.setIdUsuario(tsegcUsuario.getIdUsuario());
				finData.setNombre(tsegcUsuario.getNombre());
				finData.setApellidoPaterno(tsegcUsuario.getApellidoPaterno());
				finData.setApellidoMaterno(tsegcUsuario.getApellidoMaterno());
				finData.setIdEstatus(tsegcUsuario.getIdEstatus());
				finData.setFechaCreacion(tsegcUsuario.getFechaCreacion());
				finData.setFechaModificacion(tsegcUsuario.getFechaModificacion());
				finData.setUsuarioCreacion(tsegcUsuario.getUsuarioCreacion());
				finData.setUsuarioModificacion(tsegcUsuario.getUsuarioModificacion());
				
				bitacoraSoxVo.setObjetoFinal(bitacoraSoxBusiness.objectToXML(finData));
				bitacoraSoxVo.setIdAccion(IBitacoraSoxBusiness.UPDATE);
			}else {
				throw new TransactionalOVITException(SpmlErrorEnum.ERROR_USER_EXT.getCodeError(), 
						SpmlErrorEnum.ERROR_USER_EXT.getMessageError());
			}
			bitacoraSoxVo.setFechaOperacion(new Date());
			bitacoraSoxVo.setFolioSua(user.getAttributes().get(SpmlEnum.FOLIOSUA.getDescripcion()));
			bitacoraSoxVo.setIdAccion(IBitacoraSoxBusiness.UPDATE);
			bitacoraSoxVo.setIdUsuario(ID_USER_SPML);
			bitacoraSoxVo.setNumeroEmpleado(USER_NAME_SPML);
			bitacoraSoxBusiness.createBitacoraSox(bitacoraSoxVo);
		}catch(TransactionalOVITException e ){
			logger.error("Descripcion del Error: Codigo: ".concat(e.toString()));
			throw e;
		}catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: ".concat(e.getMessage()));
			logger.error("Error al ejecutar SpmlOviBusinesstImpl.updateUserSPML: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError(),
					ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError());
		}
	}
	
	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.business.ISpmlOvitBusiness#updateUserStatus(java.lang.Integer, java.lang.String)
	 */
	@Transactional(value = "transactionManagerOVITSPML", rollbackFor = Exception.class)
	@Override
	public int updateUserStatus(Integer idEstatus, String numeroEmpleado) throws TransactionalOVITException {
		logger.info("Ejecutando UserBusinessImpl.updateUserStatus");
		T7segoUsua tsegcUsuario = null;
		BitacoraSoxVo bitacoraSoxVo;
		
		try {
			UserSPMLDto spmlDto = spmlDao.validateUser(numeroEmpleado);
			tsegcUsuario = getMapper().map(spmlDto, T7segoUsua.class);
			
			bitacoraSoxBusiness.setSession(spmlDao.getSession());
			bitacoraSoxVo = new BitacoraSoxVo();
			
			if(tsegcUsuario == null){
				throw new TransactionalOVITException(ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getCodeError(),
						ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getMessageError());
				
			}else if (tsegcUsuario.getIdTipoUsuario() == TIPO_USUARIO){
				
				tsegcUsuario.setTsegcRol(new T7segcRol(spmlDto.getIdRol()));
				
				UserSPMLVo iniData = getMapper().map(spmlDto, UserSPMLVo.class);
				bitacoraSoxVo.setObjetoInicial(bitacoraSoxBusiness.objectToXML(iniData));
				
				tsegcUsuario.setIdEstatus(idEstatus);
				tsegcUsuario.setUsuarioModificacion(USER_NAME_SPML);
				tsegcUsuario.setFechaModificacion(new Date());
				
				spmlDao.updateUserSPML(tsegcUsuario, null);
				
				iniData.setFechaModificacion(tsegcUsuario.getFechaModificacion());
				iniData.setUsuarioModificacion(tsegcUsuario.getUsuarioModificacion());
				iniData.setIdEstatus(tsegcUsuario.getIdEstatus());
				
				bitacoraSoxVo.setObjetoFinal(bitacoraSoxBusiness.objectToXML(iniData));
				bitacoraSoxVo.setFechaOperacion(new Date());
				bitacoraSoxVo.setFolioSua("");
				bitacoraSoxVo.setIdAccion(IBitacoraSoxBusiness.DROP);
				bitacoraSoxVo.setIdUsuario(ID_USER_SPML);
				bitacoraSoxVo.setNumeroEmpleado(USER_NAME_SPML);
				
				bitacoraSoxBusiness.createBitacoraSox(bitacoraSoxVo);
			}else{
				throw new TransactionalOVITException(SpmlErrorEnum.ERROR_USER_EXT.getCodeError(), 
						SpmlErrorEnum.ERROR_USER_EXT.getMessageError());
			}
		} catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError()));
			logger.error("Error al ejecutar SpmlOviBusinesstImpl.updateUserStatus: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError(),
					ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError());
		}
		return 0;
	}
	
	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.business.ISpmlOvitBusiness#findUserSPMLbyEmplyeeNumber(java.lang.String)
	 */
	@Transactional(value = "transactionManagerOVITSPML", rollbackFor = Exception.class)
	@Override
	public InternalSpmlVo findUserSPMLbyEmplyeeNumber(String numeroEmpleado)
			throws TransactionalOVITException {
		logger.info("Ejecutando UserBusinessImpl.findUserSPMLbyEmplyeeNumber");
		try {
			UserSPMLDto userSPMLDto = spmlDao.findUserSPMLbyEmplyeeNumber(numeroEmpleado);
			InternalSpmlVo interUserVO = getMapper().map(userSPMLDto, InternalSpmlVo.class);
			return interUserVO;
		} catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar SpmlOviBusinesstImpl.findUserSPMLbyEmplyeeNumber: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),
					ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
	}
	
	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.spml.business.ISpmlOvitBusiness#findUsersSPML()
	 */
	@Transactional(value = "transactionManagerOVITSPML", rollbackFor = Exception.class)
	@Override
	public List<InternalSpmlVo> findUsersSPML() throws TransactionalOVITException {
		logger.info("Ejecutando UserBusinessImpl.findUsersSPML");
		try {
			bitacoraSoxBusiness.setSession(spmlDao.getSession());
			List<UserSPMLDto> lstUserSPMLDto = spmlDao.findUsersSPML();
			List<InternalSpmlVo> lstUserSPMLVo = getMapper().mapAsList(lstUserSPMLDto, InternalSpmlVo.class);
			return lstUserSPMLVo;
		} catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar SpmlOviBusinesstImpl.findUsersSPML: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),
					ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
	}
	
	
	private T7segoUsua getUsuarioMod(UserSPMLDto spmlDto, Map<String,String>userMap) throws TransactionalOVITException{
		T7segoUsua tsegcUsuario = null;
		try{
			
			if(spmlDto != null){
				tsegcUsuario = getMapper().map(spmlDto, T7segoUsua.class);
				
				if(userMap.containsKey(SpmlEnum.FIRSTNAME.getDescripcion())){
					tsegcUsuario.setNombre(userMap.get(SpmlEnum.FIRSTNAME.getDescripcion()));
				}
				if(userMap.containsKey(SpmlEnum.LASTNAME.getDescripcion())){
					tsegcUsuario.setApellidoPaterno(userMap.get(SpmlEnum.LASTNAME.getDescripcion()));
				}
				if(userMap.containsKey(SpmlEnum.MATERNO.getDescripcion())){
					tsegcUsuario.setApellidoMaterno(userMap.get(SpmlEnum.MATERNO.getDescripcion()));
				}
				
				tsegcUsuario.setFechaModificacion(new Date());
				tsegcUsuario.setUsuarioModificacion(USER_NAME_SPML);
				tsegcUsuario.setTsegcRol(new T7segcRol(spmlDto.getIdRol()));
				tsegcUsuario.setIdEstatus(STATUS_ACTIVE);
			
			}	
			
		}catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: ".concat(e.getMessage()));
			logger.error("Error al ejecutar SpmlOviBusinesstImpl.getUsuarioMod: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError(),
					ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError());
		}
		return tsegcUsuario;
	}
	
	
	private T7segoDatoUsuaInte getExternoMod(UserSPMLDto spmlDto, Map<String,String>userMap) throws TransactionalOVITException{
		T7segoDatoUsuaInte datosinterno = new T7segoDatoUsuaInte();
		try{
			datosinterno = getMapper().map(spmlDto, T7segoDatoUsuaInte.class);
			
			if(userMap.containsKey(SpmlEnum.CLAVEREGION.getDescripcion())){
				datosinterno.setIdRegion(userMap.get(SpmlEnum.CLAVEREGION.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.JEFE.getDescripcion())){
				datosinterno.setJefe(userMap.get(SpmlEnum.JEFE.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.CODIGOJEFE.getDescripcion())){
				datosinterno.setCodigoJefe(userMap.get(SpmlEnum.CODIGOJEFE.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.PUESTO.getDescripcion())){
				datosinterno.setPuesto(userMap.get(SpmlEnum.PUESTO.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.CODIGOPUESTO.getDescripcion())){
				datosinterno.setCodigoPuesto(userMap.get(SpmlEnum.CODIGOPUESTO.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.EMAIL.getDescripcion())){
				datosinterno.setCorreo(userMap.get(SpmlEnum.EMAIL.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.NUMEROEMPLEADO.getDescripcion())){
				datosinterno.setNumeroEmpleado(userMap.get(SpmlEnum.NUMEROEMPLEADO.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.PERFIL99.getDescripcion())){
				datosinterno.setIdRol(Integer.valueOf(userMap.get(SpmlEnum.PERFIL99.getDescripcion())));
			}
			if(userMap.containsKey(SpmlEnum.APELLIDOS.getDescripcion())){
				datosinterno.setApellidos(userMap.get(SpmlEnum.APELLIDOS.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.CENTCOST.getDescripcion())){
				datosinterno.setCentCost(userMap.get(SpmlEnum.CENTCOST.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.CLAVDEPTO.getDescripcion())){
				datosinterno.setClavDepto(userMap.get(SpmlEnum.CLAVDEPTO.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.CLAVDIRE.getDescripcion())){
				datosinterno.setClavDire(userMap.get(SpmlEnum.CLAVDIRE.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.CLAVGERE.getDescripcion())){
				datosinterno.setClavGere(userMap.get(SpmlEnum.CLAVGERE.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.CLAVSUBDIR.getDescripcion())){
				datosinterno.setClavSubdir(userMap.get(SpmlEnum.CLAVSUBDIR.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.DEPARTAMENTO.getDescripcion())){
				datosinterno.setDepartamento(userMap.get(SpmlEnum.DEPARTAMENTO.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.DESCANSO1.getDescripcion())){
				datosinterno.setDescanso1(userMap.get(SpmlEnum.DESCANSO1.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.DESCANSO2.getDescripcion())){
				datosinterno.setDescanso2(userMap.get(SpmlEnum.DESCANSO2.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.DIRECCION.getDescripcion())){
				datosinterno.setDireccion(userMap.get(SpmlEnum.DIRECCION.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.FECHAINGRESO.getDescripcion())){
				datosinterno.setFechaIngreso(userMap.get(SpmlEnum.FECHAINGRESO.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.FULLNAME.getDescripcion())){
				datosinterno.setFullname(userMap.get(SpmlEnum.FULLNAME.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.GERENCIA.getDescripcion())){
				datosinterno.setGerencia(userMap.get(SpmlEnum.GERENCIA.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.REGION.getDescripcion())){
				datosinterno.setRegion(userMap.get(SpmlEnum.REGION.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.SUBDIRECCION.getDescripcion())){
				datosinterno.setSubdireccion(userMap.get(SpmlEnum.SUBDIRECCION.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.SPMLTIPO.getDescripcion())){
				datosinterno.setSpmlTipo(userMap.get(SpmlEnum.SPMLTIPO.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.TURNO.getDescripcion())){
				datosinterno.setTurno(userMap.get(SpmlEnum.TURNO.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.UBICACION.getDescripcion())){
				datosinterno.setUbicacion(userMap.get(SpmlEnum.UBICACION.getDescripcion()));
			}
			if(userMap.containsKey(SpmlEnum.UNIVERSAL.getDescripcion())){
				datosinterno.setUniversal(userMap.get(SpmlEnum.UNIVERSAL.getDescripcion()));
			}
			
		}catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: ".concat(e.getMessage()));
			logger.error("Error al ejecutar SpmlOviBusinesstImpl.getExternoMod: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError(),
					ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError());
		}
		return datosinterno;
	}
	

}

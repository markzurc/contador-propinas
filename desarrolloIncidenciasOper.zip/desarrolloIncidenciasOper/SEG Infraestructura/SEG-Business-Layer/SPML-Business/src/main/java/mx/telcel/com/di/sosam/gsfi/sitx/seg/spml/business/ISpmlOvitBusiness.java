package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.vo.InternalSpmlVo;

import com.telcel.dwi.spml2.server.resource.User;

/**
 * <h2> ISpmlOvitBusiness </h2>
 * <p>
 * 		ISpmlOvitBusiness interface class which contains the next methods.
 * </p>
 * 
 * @author chcastro
 * @author hhernanm
 * @version 1.0
 * @since May 2015
 *
 */
public interface ISpmlOvitBusiness {

	int STATUS_ACTIVE = 0;
	int STATUS_LOCKED = 1;
	int STATUS_DROP = 2;
	int STATUS_NEW = 3;
	int STATUS_RESET = 4;
	String USER_NAME_SPML = "SPML";
	int ID_USER_SPML = 1;
	
	
	/**
	 * <h3> createUserSPML </h3>
	 * <p>
	 * 		Method  that is used for SPML in order to create an internal 
	 * 		user in the application. If the user exists in the application 
	 * 		the method updates its information and activates.
	 * </p>
	 * 
	 * @author chcastro
	 * @author hhernanm
	 * @param {@link InternalSpmlVo}
	 * @throws TransactionalOVITException
	 */
	void createUserSPML(InternalSpmlVo interUserSPMLVo)throws TransactionalOVITException;
	
	
	/**
	 * <h3> updateUserSPML </h3>
	 * <p>
	 * 		Method that is used for SPML in order to update the information 
	 * 		of an existing internal user.
	 * </p>
	 * 
	 * @author chcastro
	 * @author hhernanm
	 * @param {@link User}
	 * @throws TransactionalOVITException
	 */
	void updateUserSPML(User user)throws TransactionalOVITException;
	
	
	/**
	 * <h3> updateUserStatus </h3>
	 * <p>
	 * 		Method that is used for SPML in order to enable or disable an
	 * 		internal user.
	 * </p>
	 * 
	 * @author chcastro
	 * @author hhernanm
	 * @param idEstatus
	 * @param numeroEmpleado
	 * @return
	 * @throws TransactionalOVITException
	 */
	int updateUserStatus(Integer idEstatus, String numeroEmpleado)throws TransactionalOVITException;
	
	
	/**
	 * <h3> findUserSPMLbyEmplyeeNumber </h3>
	 * <p>
	 * 		Method that is used for SPML in order to find an internal user 
	 * 		into the application.
	 * </p>
	 * 
	 * @author chcastro
	 * @author hhernanm
	 * @param {@link String numeroEmpleado}
	 * @return {@link InternalSpmlVo}
	 * @throws TransactionalOVITException
	 */
	InternalSpmlVo findUserSPMLbyEmplyeeNumber(String numeroEmpleado)throws TransactionalOVITException;
	
	
	/**
	 * <h3> findUsersSPML </h3>
	 * <p>
	 * 		Method that is used for SPML in order to find all the internal
	 * 		users into the application.
	 * </p>
	 * 
	 * @author chcastro
	 * @author hhernanm
	 * @return {@link List} <{@link InternalSpmlVo}>
	 * @throws TransactionalOVITException
	 */
	List<InternalSpmlVo> findUsersSPML()throws TransactionalOVITException;
	
		
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.vo;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * <h1>UserSPMLVo</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 14/05/2015
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder={"idUsuario", "numeroEmpleado", "nombre", "apellidoPaterno", "apellidoMaterno", 
					"correo", "idRegion", "codigoPuesto", "puesto", "idRol",  
					"codigoJefe", "jefe", "rfc", "idEstatus", 
					"fechaCreacion", "usuarioCreacion", "fechaModificacion", "usuarioModificacion"})
public class UserSPMLVo implements Serializable {

	private static final long serialVersionUID = -5869635634006194313L;
	
	@XmlElement(name = "idUsuario", nillable=true)
	private Integer idUsuario;
	@XmlElement(name = "numeroEmpleado", nillable=true)
	private String numeroEmpleado;
	@XmlElement(name = "nombre", nillable=true)
	private String nombre;
	@XmlElement(name = "apellidoPaterno", nillable=true)
	private String apellidoPaterno;
	@XmlElement(name = "apellidoMaterno", nillable=true)
	private String apellidoMaterno;
	@XmlElement(name = "correo", nillable=true)
	private String correo;

	@XmlElement(name = "idRegion", nillable=true)
	private String idRegion;
	@XmlElement(name = "codigoPuesto", nillable=true)
	private String codigoPuesto;
	@XmlElement(name = "puesto", nillable=true)
	private String puesto;
	@XmlElement(name = "idRol", nillable=true)
	private Integer idRol;
		
	@XmlElement(name = "codigoJefe", nillable=true)
	private String codigoJefe;
	@XmlElement(name = "jefe", nillable=true)
	private String jefe;	
	@XmlElement(name = "rfc", nillable=true)
	private String rfc;
	@XmlElement(name = "idEstatus", nillable=true)
	private Integer idEstatus;
	
	@XmlElement(name = "fechaCreacion", nillable=true)
	private Date fechaCreacion;
	@XmlElement(name = "usuarioCreacion", nillable=true)
	private String usuarioCreacion;
	@XmlElement(name = "fechaModificacion", nillable=true)
	private Date fechaModificacion;
	@XmlElement(name = "usuarioModificacion", nillable=true)
	private String usuarioModificacion;
	
	
	public UserSPMLVo() {
		super();
	}


	/**
	 * @param idUsuario
	 * @param numeroEmpleado
	 * @param nombre
	 * @param apellidoPaterno
	 * @param apellidoMaterno
	 * @param correo
	 * @param idRegion
	 * @param codigoPuesto
	 * @param puesto
	 * @param idRol
	 * @param codigoJefe
	 * @param jefe
	 * @param rfc
	 * @param idEstatus
	 * @param fechaCreacion
	 * @param usuarioCreacion
	 * @param fechaModificacion
	 * @param usuarioModificacion
	 */
	public UserSPMLVo(Integer idUsuario, String numeroEmpleado, String nombre,
			String apellidoPaterno, String apellidoMaterno, String correo,
			String idRegion, String codigoPuesto, String puesto, Integer idRol,
			String codigoJefe, String jefe, String rfc, Integer idEstatus,
			Date fechaCreacion, String usuarioCreacion, Date fechaModificacion,
			String usuarioModificacion) {
		super();
		this.idUsuario = idUsuario;
		this.numeroEmpleado = numeroEmpleado;
		this.nombre = nombre;
		this.apellidoPaterno = apellidoPaterno;
		this.apellidoMaterno = apellidoMaterno;
		this.correo = correo;
		this.idRegion = idRegion;
		this.codigoPuesto = codigoPuesto;
		this.puesto = puesto;
		this.idRol = idRol;
		this.codigoJefe = codigoJefe;
		this.jefe = jefe;
		this.rfc = rfc;
		this.idEstatus = idEstatus;
		this.fechaCreacion = fechaCreacion;
		this.usuarioCreacion = usuarioCreacion;
		this.fechaModificacion = fechaModificacion;
		this.usuarioModificacion = usuarioModificacion;
	}


	public UserSPMLVo(Integer idUsuario, String numeroEmpleado, String nombre,
			String apellidoPaterno, String apellidoMaterno, String correo,
			String idRegion, String codigoPuesto, String puesto, Integer idRol,
			String codigoJefe, String jefe, Date fechaCreacion,
			String usuarioCreacion) {
		super();
		this.idUsuario = idUsuario;
		this.numeroEmpleado = numeroEmpleado;
		this.nombre = nombre;
		this.apellidoPaterno = apellidoPaterno;
		this.apellidoMaterno = apellidoMaterno;
		this.correo = correo;
		this.idRegion = idRegion;
		this.codigoPuesto = codigoPuesto;
		this.puesto = puesto;
		this.idRol = idRol;
		this.codigoJefe = codigoJefe;
		this.jefe = jefe;
		this.fechaCreacion = fechaCreacion;
		this.usuarioCreacion = usuarioCreacion;
	}


	/**
	 * @return the idUsuario
	 */
	public Integer getIdUsuario() {
		return idUsuario;
	}


	/**
	 * @param idUsuario the idUsuario to set
	 */
	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}


	/**
	 * @return the numeroEmpleado
	 */
	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}


	/**
	 * @param numeroEmpleado the numeroEmpleado to set
	 */
	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}


	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}


	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	/**
	 * @return the apellidoPaterno
	 */
	public String getApellidoPaterno() {
		return apellidoPaterno;
	}


	/**
	 * @param apellidoPaterno the apellidoPaterno to set
	 */
	public void setApellidoPaterno(String apellidoPaterno) {
		this.apellidoPaterno = apellidoPaterno;
	}


	/**
	 * @return the apellidoMaterno
	 */
	public String getApellidoMaterno() {
		return apellidoMaterno;
	}


	/**
	 * @param apellidoMaterno the apellidoMaterno to set
	 */
	public void setApellidoMaterno(String apellidoMaterno) {
		this.apellidoMaterno = apellidoMaterno;
	}


	/**
	 * @return the correo
	 */
	public String getCorreo() {
		return correo;
	}


	/**
	 * @param correo the correo to set
	 */
	public void setCorreo(String correo) {
		this.correo = correo;
	}


	/**
	 * @return the idRegion
	 */
	public String getIdRegion() {
		return idRegion;
	}


	/**
	 * @param idRegion the idRegion to set
	 */
	public void setIdRegion(String idRegion) {
		this.idRegion = idRegion;
	}


	/**
	 * @return the codigoPuesto
	 */
	public String getCodigoPuesto() {
		return codigoPuesto;
	}


	/**
	 * @param codigoPuesto the codigoPuesto to set
	 */
	public void setCodigoPuesto(String codigoPuesto) {
		this.codigoPuesto = codigoPuesto;
	}


	/**
	 * @return the puesto
	 */
	public String getPuesto() {
		return puesto;
	}


	/**
	 * @param puesto the puesto to set
	 */
	public void setPuesto(String puesto) {
		this.puesto = puesto;
	}


	/**
	 * @return the idRol
	 */
	public Integer getIdRol() {
		return idRol;
	}


	/**
	 * @param idRol the idRol to set
	 */
	public void setIdRol(Integer idRol) {
		this.idRol = idRol;
	}


	/**
	 * @return the codigoJefe
	 */
	public String getCodigoJefe() {
		return codigoJefe;
	}


	/**
	 * @param codigoJefe the codigoJefe to set
	 */
	public void setCodigoJefe(String codigoJefe) {
		this.codigoJefe = codigoJefe;
	}


	/**
	 * @return the jefe
	 */
	public String getJefe() {
		return jefe;
	}


	/**
	 * @param jefe the jefe to set
	 */
	public void setJefe(String jefe) {
		this.jefe = jefe;
	}


	/**
	 * @return the fechaCreacion
	 */
	public Date getFechaCreacion() {
		return fechaCreacion;
	}


	/**
	 * @param fechaCreacion the fechaCreacion to set
	 */
	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}


	/**
	 * @return the usuarioCreacion
	 */
	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}


	/**
	 * @param usuarioCreacion the usuarioCreacion to set
	 */
	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	/**
	 * @return the rfc
	 */
	public String getRfc() {
		return rfc;
	}

	/**
	 * @param rfc the rfc to set
	 */
	public void setRfc(String rfc) {
		this.rfc = rfc;
	}

	/**
	 * @return the idEstatus
	 */
	public Integer getIdEstatus() {
		return idEstatus;
	}

	/**
	 * @param idEstatus the idEstatus to set
	 */
	public void setIdEstatus(Integer idEstatus) {
		this.idEstatus = idEstatus;
	}

	/**
	 * @return the fechaModificacion
	 */
	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	/**
	 * @param fechaModificacion the fechaModificacion to set
	 */
	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	/**
	 * @return the usuarioModificacion
	 */
	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}

	/**
	 * @param usuarioModificacion the usuarioModificacion to set
	 */
	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserSPMLVo [idUsuario=");
		builder.append(idUsuario);
		builder.append(", numeroEmpleado=");
		builder.append(numeroEmpleado);
		builder.append(", nombre=");
		builder.append(nombre);
		builder.append(", apellidoPaterno=");
		builder.append(apellidoPaterno);
		builder.append(", apellidoMaterno=");
		builder.append(apellidoMaterno);
		builder.append(", correo=");
		builder.append(correo);
		builder.append(", idRegion=");
		builder.append(idRegion);
		builder.append(", codigoPuesto=");
		builder.append(codigoPuesto);
		builder.append(", puesto=");
		builder.append(puesto);
		builder.append(", idRol=");
		builder.append(idRol);
		builder.append(", codigoJefe=");
		builder.append(codigoJefe);
		builder.append(", jefe=");
		builder.append(jefe);
		builder.append(", rfc=");
		builder.append(rfc);
		builder.append(", idEstatus=");
		builder.append(idEstatus);
		builder.append(", fechaCreacion=");
		builder.append(fechaCreacion);
		builder.append(", usuarioCreacion=");
		builder.append(usuarioCreacion);
		builder.append(", fechaModificacion=");
		builder.append(fechaModificacion);
		builder.append(", usuarioModificacion=");
		builder.append(usuarioModificacion);
		builder.append("]");
		return builder.toString();
	}
}

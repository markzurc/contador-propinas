package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.vo;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder={"folioSua", "universal",  "apellidos", "fullname",
		"fechaIngreso", "region", "turno", "ubicacion", "descanso1", "descanso2", 
		"centCost", "spmlTipo", "tipoUsuarioIdm", "estatusIdm", "estatusRh",
		"empresa", "clavDire", "direccion", "clavSubdir", "subdireccion", 
		"clavGere", "gerencia", "clavDepto", "departamento", 
		"mov1Idm" , "mov2Idm", "mov3Idm", "mov4Idm", "mov5Idm",
		 "excepcion" })
public class InternalSpmlVo extends UserSPMLVo implements Serializable{

	private static final long serialVersionUID = -8644890329240139707L;

	// nuevos campos spml
	@XmlElement(name = "folioSua", nillable = true)
	private String folioSua;
	@XmlElement(name = "universal", nillable = true)
	private String universal;
	@XmlElement(name = "apellidos", nillable = true)
	private String apellidos;
	@XmlElement(name = "fullname", nillable = true)
	private String fullname;
	@XmlElement(name = "fechaIngreso", nillable = true)
	private String fechaIngreso;
	@XmlElement(name = "region", nillable = true)
	private String region;

	@XmlElement(name = "turno", nillable = true)
	private String turno;
	@XmlElement(name = "ubicacion", nillable = true)
	private String ubicacion;
	@XmlElement(name = "descanso1", nillable = true)
	private String descanso1;
	@XmlElement(name = "descanso2", nillable = true)
	private String descanso2;
	
	@XmlElement(name = "centCost", nillable = true)
	private String centCost;
	@XmlElement(name = "spmlTipo", nillable = true)
	private String spmlTipo;
	@XmlElement(name = "tipoUsuarioIdm", nillable = true)
	private String tipoUsuarioIdm;
	@XmlElement(name = "estatusIdm", nillable = true)
	private String estatusIdm;
	@XmlElement(name = "estatusRh", nillable = true)
	private String estatusRh;
	
	@XmlElement(name = "empresa", nillable = true)
	private String empresa;
	@XmlElement(name = "clavDire", nillable = true)
	private String clavDire;
	@XmlElement(name = "direccion", nillable = true)
	private String direccion;
	@XmlElement(name = "clavSubdir", nillable = true)
	private String clavSubdir;
	@XmlElement(name = "subdireccion", nillable = true)
	private String subdireccion;
	
	@XmlElement(name = "clavGere", nillable = true)
	private String clavGere;
	@XmlElement(name = "gerencia", nillable = true)
	private String gerencia;
	@XmlElement(name = "clavDepto", nillable = true)
	private String clavDepto;
	@XmlElement(name = "departamento", nillable = true)
	private String departamento;
	
	@XmlElement(name = "mov1Idm", nillable = true)
	private String mov1Idm;
	@XmlElement(name = "mov2Idm", nillable = true)
	private String mov2Idm;
	@XmlElement(name = "mov3Idm", nillable = true)
	private String mov3Idm;
	@XmlElement(name = "mov4Idm", nillable = true)
	private String mov4Idm;
	@XmlElement(name = "mov5Idm", nillable = true)
	private String mov5Idm;

	@XmlElement(name = "excepcion", nillable = true)
	private String excepcion;

	public InternalSpmlVo(){
	}
	
	public InternalSpmlVo(Integer idUsuario, String numeroEmpleado,
			String nombre, String apellidoPaterno, String apellidoMaterno,
			String correo, String idRegion, String codigoPuesto, String puesto,
			Integer idRol, String codigoJefe, String jefe, Date fechaCreacion,
			String usuarioCreacion) {
		super(idUsuario, numeroEmpleado, nombre, apellidoPaterno, apellidoMaterno,
				correo, idRegion, codigoPuesto, puesto, idRol, codigoJefe, jefe,
				fechaCreacion, usuarioCreacion);
	}

	public InternalSpmlVo(Integer idUsuario, String numeroEmpleado,
			String nombre, String apellidoPaterno, String apellidoMaterno,
			String correo, String idRegion, String codigoPuesto, String puesto,
			Integer idRol, String codigoJefe, String jefe, Date fechaCreacion,
			String usuarioCreacion, String folioSua, String universal,
			String apellidos, String fullname, String fechaIngreso,
			String region, String turno, String ubicacion, String descanso1,
			String descanso2, String centCost, String spmlTipo,
			String tipoUsuarioIdm, String estatusIdm, String estatusRh,
			String empresa, String clavDire, String direccion,
			String clavSubdir, String subdireccion, String clavGere,
			String gerencia, String clavDepto, String departamento,
			String mov1Idm, String mov2Idm, String mov3Idm, String mov4Idm,
			String mov5Idm, String excepcion) {
		super(idUsuario, numeroEmpleado, nombre, apellidoPaterno,
				apellidoMaterno, correo, idRegion, codigoPuesto, puesto, idRol,
				codigoJefe, jefe, fechaCreacion, usuarioCreacion);
		this.folioSua = folioSua;
		this.universal = universal;
		this.apellidos = apellidos;
		this.fullname = fullname;
		this.fechaIngreso = fechaIngreso;
		this.region = region;
		this.turno = turno;
		this.ubicacion = ubicacion;
		this.descanso1 = descanso1;
		this.descanso2 = descanso2;
		this.centCost = centCost;
		this.spmlTipo = spmlTipo;
		this.tipoUsuarioIdm = tipoUsuarioIdm;
		this.estatusIdm = estatusIdm;
		this.estatusRh = estatusRh;
		this.empresa = empresa;
		this.clavDire = clavDire;
		this.direccion = direccion;
		this.clavSubdir = clavSubdir;
		this.subdireccion = subdireccion;
		this.clavGere = clavGere;
		this.gerencia = gerencia;
		this.clavDepto = clavDepto;
		this.departamento = departamento;
		this.mov1Idm = mov1Idm;
		this.mov2Idm = mov2Idm;
		this.mov3Idm = mov3Idm;
		this.mov4Idm = mov4Idm;
		this.mov5Idm = mov5Idm;
		this.excepcion = excepcion;
	}

	/**
	 * @return the folioSua
	 */
	public String getFolioSua() {
		return folioSua;
	}

	/**
	 * @param folioSua the folioSua to set
	 */
	public void setFolioSua(String folioSua) {
		this.folioSua = folioSua;
	}

	/**
	 * @return the universal
	 */
	public String getUniversal() {
		return universal;
	}

	/**
	 * @param universal the universal to set
	 */
	public void setUniversal(String universal) {
		this.universal = universal;
	}

	/**
	 * @return the apellidos
	 */
	public String getApellidos() {
		return apellidos;
	}

	/**
	 * @param apellidos the apellidos to set
	 */
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	/**
	 * @return the fullname
	 */
	public String getFullname() {
		return fullname;
	}

	/**
	 * @param fullname the fullname to set
	 */
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	/**
	 * @return the fechaIngreso
	 */
	public String getFechaIngreso() {
		return fechaIngreso;
	}

	/**
	 * @param fechaIngreso the fechaIngreso to set
	 */
	public void setFechaIngreso(String fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}

	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}

	/**
	 * @param region the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}

	/**
	 * @return the empresa
	 */
	public String getEmpresa() {
		return empresa;
	}

	/**
	 * @param empresa the empresa to set
	 */
	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	/**
	 * @return the clavDire
	 */
	public String getClavDire() {
		return clavDire;
	}

	/**
	 * @param clavDire the clavDire to set
	 */
	public void setClavDire(String clavDire) {
		this.clavDire = clavDire;
	}

	/**
	 * @return the direccion
	 */
	public String getDireccion() {
		return direccion;
	}

	/**
	 * @param direccion the direccion to set
	 */
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	/**
	 * @return the clavSubdir
	 */
	public String getClavSubdir() {
		return clavSubdir;
	}

	/**
	 * @param clavSubdir the clavSubdir to set
	 */
	public void setClavSubdir(String clavSubdir) {
		this.clavSubdir = clavSubdir;
	}

	/**
	 * @return the subdireccion
	 */
	public String getSubdireccion() {
		return subdireccion;
	}

	/**
	 * @param subdireccion the subdireccion to set
	 */
	public void setSubdireccion(String subdireccion) {
		this.subdireccion = subdireccion;
	}

	/**
	 * @return the clavGere
	 */
	public String getClavGere() {
		return clavGere;
	}

	/**
	 * @param clavGere the clavGere to set
	 */
	public void setClavGere(String clavGere) {
		this.clavGere = clavGere;
	}

	/**
	 * @return the gerencia
	 */
	public String getGerencia() {
		return gerencia;
	}

	/**
	 * @param gerencia the gerencia to set
	 */
	public void setGerencia(String gerencia) {
		this.gerencia = gerencia;
	}

	/**
	 * @return the clavDepto
	 */
	public String getClavDepto() {
		return clavDepto;
	}

	/**
	 * @param clavDepto the clavDepto to set
	 */
	public void setClavDepto(String clavDepto) {
		this.clavDepto = clavDepto;
	}

	/**
	 * @return the departamento
	 */
	public String getDepartamento() {
		return departamento;
	}

	/**
	 * @param departamento the departamento to set
	 */
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	/**
	 * @return the turno
	 */
	public String getTurno() {
		return turno;
	}

	/**
	 * @param turno the turno to set
	 */
	public void setTurno(String turno) {
		this.turno = turno;
	}

	/**
	 * @return the ubicacion
	 */
	public String getUbicacion() {
		return ubicacion;
	}

	/**
	 * @param ubicacion the ubicacion to set
	 */
	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}

	/**
	 * @return the descanso1
	 */
	public String getDescanso1() {
		return descanso1;
	}

	/**
	 * @param descanso1 the descanso1 to set
	 */
	public void setDescanso1(String descanso1) {
		this.descanso1 = descanso1;
	}

	/**
	 * @return the descanso2
	 */
	public String getDescanso2() {
		return descanso2;
	}

	/**
	 * @param descanso2 the descanso2 to set
	 */
	public void setDescanso2(String descanso2) {
		this.descanso2 = descanso2;
	}

	/**
	 * @return the centCost
	 */
	public String getCentCost() {
		return centCost;
	}

	/**
	 * @param centCost the centCost to set
	 */
	public void setCentCost(String centCost) {
		this.centCost = centCost;
	}

	/**
	 * @return the spmlTipo
	 */
	public String getSpmlTipo() {
		return spmlTipo;
	}

	/**
	 * @param spmlTipo the spmlTipo to set
	 */
	public void setSpmlTipo(String spmlTipo) {
		this.spmlTipo = spmlTipo;
	}

	/**
	 * @return the tipoUsuarioIdm
	 */
	public String getTipoUsuarioIdm() {
		return tipoUsuarioIdm;
	}

	/**
	 * @param tipoUsuarioIdm the tipoUsuarioIdm to set
	 */
	public void setTipoUsuarioIdm(String tipoUsuarioIdm) {
		this.tipoUsuarioIdm = tipoUsuarioIdm;
	}

	/**
	 * @return the estatusIdm
	 */
	public String getEstatusIdm() {
		return estatusIdm;
	}

	/**
	 * @param estatusIdm the estatusIdm to set
	 */
	public void setEstatusIdm(String estatusIdm) {
		this.estatusIdm = estatusIdm;
	}

	/**
	 * @return the estatusRh
	 */
	public String getEstatusRh() {
		return estatusRh;
	}

	/**
	 * @param estatusRh the estatusRh to set
	 */
	public void setEstatusRh(String estatusRh) {
		this.estatusRh = estatusRh;
	}

	/**
	 * @return the mov1Idm
	 */
	public String getMov1Idm() {
		return mov1Idm;
	}

	/**
	 * @param mov1Idm the mov1Idm to set
	 */
	public void setMov1Idm(String mov1Idm) {
		this.mov1Idm = mov1Idm;
	}

	/**
	 * @return the mov2Idm
	 */
	public String getMov2Idm() {
		return mov2Idm;
	}

	/**
	 * @param mov2Idm the mov2Idm to set
	 */
	public void setMov2Idm(String mov2Idm) {
		this.mov2Idm = mov2Idm;
	}

	/**
	 * @return the mov3Idm
	 */
	public String getMov3Idm() {
		return mov3Idm;
	}

	/**
	 * @param mov3Idm the mov3Idm to set
	 */
	public void setMov3Idm(String mov3Idm) {
		this.mov3Idm = mov3Idm;
	}

	/**
	 * @return the mov4Idm
	 */
	public String getMov4Idm() {
		return mov4Idm;
	}

	/**
	 * @param mov4Idm the mov4Idm to set
	 */
	public void setMov4Idm(String mov4Idm) {
		this.mov4Idm = mov4Idm;
	}

	/**
	 * @return the mov5Idm
	 */
	public String getMov5Idm() {
		return mov5Idm;
	}

	/**
	 * @param mov5Idm the mov5Idm to set
	 */
	public void setMov5Idm(String mov5Idm) {
		this.mov5Idm = mov5Idm;
	}

	/**
	 * @return the excepcion
	 */
	public String getExcepcion() {
		return excepcion;
	}

	/**
	 * @param excepcion the excepcion to set
	 */
	public void setExcepcion(String excepcion) {
		this.excepcion = excepcion;
	}
	
	

}

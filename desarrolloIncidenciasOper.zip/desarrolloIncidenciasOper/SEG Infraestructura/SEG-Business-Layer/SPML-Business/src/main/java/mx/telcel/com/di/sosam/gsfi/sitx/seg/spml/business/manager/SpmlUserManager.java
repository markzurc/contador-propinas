package mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.manager;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.IBitacoraSoxBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.vo.BitacoraSoxVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.spring.context.ApplicationContextProvider;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.ISpmlOvitBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.ISpmlValidations;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.enums.SpmlEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.enums.SpmlErrorEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.enums.SpmlLogEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.exception.SpmlOvitException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.to.UserSpmlTo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.util.SpmlUtil;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.vo.FoundUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.vo.FoundUsersList;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.vo.InternalSpmlVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.spml.business.vo.UserSPMLVo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import com.telcel.dwi.spml2.server.Spml2ServerException;
import com.telcel.dwi.spml2.server.resource.ResourceConnector;
import com.telcel.dwi.spml2.server.resource.User;

/**
 * <h2> SpmlUserManager </h2>
 * <p>
 * 		The implementation class of {@link ResourceConnector} interface.
 * </p>
 * 
 * @author hhernanm
 * @version 1.0
 * @since May 2015
 *
 */

@Service("spmlUserManager")
public class SpmlUserManager  implements ResourceConnector, Serializable{

	
	private static final long serialVersionUID = -7982242550022623215L;
	private static Logger logger = LogManager.getLogger(SpmlUserManager.class);
		
	private ApplicationContext applicationContext = null;
	private ISpmlOvitBusiness spmlOvit;
	private ISpmlValidations spmlValidations;
	private IBitacoraSoxBusiness bitacoraSox;
	
	private static final String SPML = "SPML";
	
	public SpmlUserManager() {
		super();
	}
	

	/*
	 * (non-Javadoc)
	 * @see com.telcel.dwi.spml2.server.resource.ResourceConnector#addUser(com.telcel.dwi.spml2.server.resource.User)
	 */
	@Override
	public void addUser(final User user) throws Spml2ServerException {
		logger.info("Creando usuario");
		
        final Map<String, String> userMap = user.getAttributes();
		init();
		
		try {
			        
            this.spmlValidations.validateMap(user.getAttributes());
			String numEmpleado = this.spmlValidations.validateNumEmployment(user.getUserId());
			String nombre = this.spmlValidations.validateFistName(userMap.get(SpmlEnum.FIRSTNAME.getDescripcion()));
			String aPaterno = this.spmlValidations.validateLastName(userMap.get(SpmlEnum.LASTNAME.getDescripcion()));
			String region = this.spmlValidations.validateRegion(userMap.get(SpmlEnum.CLAVEREGION.getDescripcion()));
			Integer rol = this.spmlValidations.validateRole(userMap.get(SpmlEnum.PERFIL99.getDescripcion()));
			
			InternalSpmlVo userVo = new InternalSpmlVo();
			userVo =SpmlUtil.getSpmlMap(userMap);
			userVo.setNombre(nombre);
			userVo.setApellidoPaterno(aPaterno);
			userVo.setIdRol(rol);
			userVo.setNumeroEmpleado(numEmpleado);
			userVo.setIdRegion(region);
			
			this.spmlOvit.createUserSPML(userVo);
			
		} catch(SpmlOvitException | TransactionalOVITException e){		
			logger.error(SpmlErrorEnum.ERROR_SIGNUP.getMessageError());
			
			if(e instanceof SpmlOvitException){
				((SpmlOvitException)e).setCodeError(SpmlErrorEnum.ERROR_SIGNUP.getCodeError());
				((SpmlOvitException)e).setMessage(SpmlErrorEnum.ERROR_SIGNUP.getMessageError());
				String error = ((SpmlOvitException)e).toStringError();
				user.getAttributes().put(SpmlLogEnum.EXEPCION.getDescripcion(),error);
				saveBitacoraSox(user,IBitacoraSoxBusiness.ERROR_CREATE);
				throw new Spml2ServerException(((SpmlOvitException)e).toStringError());
			
			}else if(e instanceof TransactionalOVITException){
				SpmlOvitException ex = new SpmlOvitException(SpmlErrorEnum.ERROR_SIGNUP.getCodeError(), 
												SpmlErrorEnum.ERROR_SIGNUP.getMessageError(), 
												 e.toString());
				user.getAttributes().put(SpmlLogEnum.EXEPCION.getDescripcion(), ex.toStringError());
				saveBitacoraSox(user,IBitacoraSoxBusiness.ERROR_CREATE);
				throw new Spml2ServerException(ex.toString());
			}	
			
		}
	}

	
	
	/*
	 * (non-Javadoc)
	 * @see com.telcel.dwi.spml2.server.resource.ResourceConnector#deleteUser(java.lang.String)
	 */
	@Override
	public void deleteUser(final String userId) throws Spml2ServerException {
		logger.info("Eliminando usuario");
		init();
		try{
			String employee = this.spmlValidations.validateNumEmployment(userId);
			this.spmlOvit.updateUserStatus(ISpmlOvitBusiness.STATUS_DROP, employee);
		
		}catch (SpmlOvitException | TransactionalOVITException e) {
			logger.error(String.format(SpmlErrorEnum.ERROR_DELETE.getMessageError(),userId));
			
			if(e instanceof Spml2ServerException){
				((SpmlOvitException)e).setCodeError(SpmlErrorEnum.ERROR_DELETE.getCodeError());
				((SpmlOvitException)e).setMessage(String.format(SpmlErrorEnum.ERROR_DELETE.getMessageError(),
																userId));	
				String error = ((SpmlOvitException)e).toStringError();
				
				User user = new User(userId, new HashMap<String,String>());
				user.getAttributes().put(SpmlLogEnum.EXEPCION.getDescripcion(),error);
				saveBitacoraSox(user,IBitacoraSoxBusiness.ERROR_DELETE);
				throw new Spml2ServerException(((SpmlOvitException)e).toStringError());
				
			}else if(e instanceof TransactionalOVITException){
				SpmlOvitException ex = new SpmlOvitException(SpmlErrorEnum.ERROR_DELETE.getCodeError(), 
											String.format(SpmlErrorEnum.ERROR_DELETE.getMessageError(),userId), 
											e.toString());
				User user = new User(userId, new HashMap<String,String>());
				user.getAttributes().put(SpmlLogEnum.EXEPCION.getDescripcion(), ex.toStringError());
				saveBitacoraSox(user,IBitacoraSoxBusiness.ERROR_DELETE);
				throw new SpmlOvitException(e.toString());
			}
		}
	}

	
	
	/*
	 * (non-Javadoc)
	 * @see com.telcel.dwi.spml2.server.resource.ResourceConnector#disableUser(java.lang.String)
	 */
	@Override
	public void disableUser(String userId) throws Spml2ServerException {
		logger.info("Deshabilitando usuario");
		deleteUser(userId);
	}
	
	
	
	/*
	 * (non-Javadoc)
	 * @see com.telcel.dwi.spml2.server.resource.ResourceConnector#enableUser(java.lang.String)
	 */
	@Override
	public void enableUser(String userId) throws Spml2ServerException {
		logger.info("Habilitando usuario");
		init();
		try{
			String employee = this.spmlValidations.validateNumEmployment(userId);
			this.spmlOvit.updateUserStatus(ISpmlOvitBusiness.STATUS_ACTIVE, employee);
		
		}catch(Spml2ServerException | TransactionalOVITException e){
			logger.error(String.format(SpmlErrorEnum.ERROR_ENABLE.getMessageError(),userId));

			if(e instanceof Spml2ServerException){
				((SpmlOvitException)e).setCodeError(SpmlErrorEnum.ERROR_ENABLE.getCodeError());
				((SpmlOvitException)e).setMessage(String.format(SpmlErrorEnum.ERROR_ENABLE.getMessageError(),
																userId));	
				String error = ((SpmlOvitException)e).toStringError();
				
				User user = new User(userId, new HashMap<String,String>());
				user.getAttributes().put(SpmlLogEnum.EXEPCION.getDescripcion(),error);
				saveBitacoraSox(user,IBitacoraSoxBusiness.ERROR_ENABLE);
				throw new Spml2ServerException(((SpmlOvitException)e).toStringError());
				
			}else if(e instanceof TransactionalOVITException){
				SpmlOvitException ex = new SpmlOvitException(SpmlErrorEnum.ERROR_ENABLE.getCodeError(), 
											String.format(SpmlErrorEnum.ERROR_ENABLE.getMessageError(),userId), 
											e.toString());
				User user = new User(userId, new HashMap<String,String>());
				user.getAttributes().put(SpmlLogEnum.EXEPCION.getDescripcion(), ex.toStringError());
				saveBitacoraSox(user,IBitacoraSoxBusiness.ERROR_ENABLE);
				throw new SpmlOvitException(e.toString());
			}
		}
	}
	
	
		
	/*
	 * (non-Javadoc)
	 * @see com.telcel.dwi.spml2.server.resource.ResourceConnector#listUsers()
	 */
	@Override
	public List<User> listUsers() throws Spml2ServerException {
		logger.info("Lista de usuario");
		List<User> listUsers = null;
		init();
		try{
			List<InternalSpmlVo>  interUserVo = null;
			Map<String,String> mapUser = null;
			FoundUsersList foundUsersList = null;
			
			interUserVo= this.spmlOvit.findUsersSPML();
			
			if(interUserVo.size()!=0){
				listUsers = new ArrayList<User>();
				foundUsersList = new FoundUsersList();
				foundUsersList.setUsers(new ArrayList<FoundUserVo>());
				
				for (UserSPMLVo aux : interUserVo) {
					mapUser = new HashMap<String, String>();
					mapUser = SpmlUtil.mapSpmlTransformer(SpmlUtil.voToUser(aux));
					User user = new User(aux.getNumeroEmpleado(), mapUser);
					listUsers.add(user);
					
					FoundUserVo userVo = new FoundUserVo(aux.getNumeroEmpleado(), aux.getNombre(), 
												aux.getApellidoPaterno(), aux.getApellidoMaterno());
					foundUsersList.getUsers().add(userVo);
				}
				
				BitacoraSoxVo bitacoraSox = new BitacoraSoxVo();
				bitacoraSox.setFechaOperacion(new Date());
				bitacoraSox.setNumeroEmpleado(SPML);
				bitacoraSox.setIdUsuario(ISpmlOvitBusiness.ID_USER_SPML);
				bitacoraSox.setIdAccion(IBitacoraSoxBusiness.SELCT);
				bitacoraSox.setObjetoInicial(this.bitacoraSox.objectToXML(foundUsersList));
				this.bitacoraSox.createBitacoraSox(bitacoraSox);
				
			}else{
				SpmlOvitException ex = new SpmlOvitException(SpmlErrorEnum.ERROR_EMPTY_LIST.getCodeError(),
												SpmlErrorEnum.ERROR_EMPTY_LIST.getMessageError(), null);
				logger.error(ex.toStringError());
				mapUser = new HashMap<String, String>();
				mapUser.put(SpmlLogEnum.EXEPCION.getDescripcion(), ex.toStringError());
				User user = new User(null, mapUser);
				saveBitacoraSox(user,IBitacoraSoxBusiness.ERROR_LIST);
				throw ex;
			}
			
		}catch (SpmlOvitException | TransactionalOVITException e) {
			logger.error(SpmlErrorEnum.ERROR_LIST.getMessageError());
			
			if(e instanceof SpmlOvitException){
				if(((SpmlOvitException)e).getCodeError()==null){
						((SpmlOvitException)e).setCodeError(SpmlErrorEnum.ERROR_LIST.getCodeError());
						((SpmlOvitException)e).setMessage(SpmlErrorEnum.ERROR_LIST.getMessageError());
						String error = ((SpmlOvitException)e).toStringError();
						User user = new User(null, new HashMap<String,String>());
						user.getAttributes().put(SpmlLogEnum.EXEPCION.getDescripcion(),error);
						saveBitacoraSox(user,IBitacoraSoxBusiness.ERROR_LIST);
				}
				
				throw new Spml2ServerException(((SpmlOvitException)e).toStringError());
					
			}else if(e instanceof TransactionalOVITException){
				SpmlOvitException ex = new SpmlOvitException(SpmlErrorEnum.ERROR_LIST.getCodeError(), 
												SpmlErrorEnum.ERROR_LIST.getMessageError(),e.toString());
				User user = new User(null, new HashMap<String,String>());
				user.getAttributes().put(SpmlLogEnum.EXEPCION.getDescripcion(), ex.toStringError());
				saveBitacoraSox(user,IBitacoraSoxBusiness.ERROR_LIST);
				throw new Spml2ServerException(ex.toString());
			}
		}
		
		return listUsers;
	}
	
	
	
	/*
	 * (non-Javadoc)
	 * @see com.telcel.dwi.spml2.server.resource.ResourceConnector#lookupUser(java.lang.String)
	 */
	@Override
	public User lookupUser(String userId) throws Spml2ServerException{
		logger.info("lookup de usuario");
		init();
		User user = null;
		try{
			InternalSpmlVo interUserVo = null;
			String employee = this.spmlValidations.validateNumEmployment(userId);
			interUserVo = this.spmlOvit.findUserSPMLbyEmplyeeNumber(employee);
		
			if(interUserVo != null){
				Map<String,String> mapUser = new HashMap<String, String>();
				mapUser = SpmlUtil.mapSpmlTransformer(SpmlUtil.voToUser(interUserVo));
				user = new User(interUserVo.getNumeroEmpleado(), mapUser);
				saveBitacoraSox(user,IBitacoraSoxBusiness.SELCT);
				
			}else{
				SpmlOvitException ex = new SpmlOvitException(SpmlErrorEnum.USUARIO_DOES_NOT_EXISTS.getCodeError(),
											String.format(SpmlErrorEnum.USUARIO_DOES_NOT_EXISTS.getMessageError(), userId),
											null);
				logger.error(ex.toStringError());
	
				Map<String, String> mapUser = new HashMap<String, String>();
				mapUser.put(SpmlLogEnum.EXEPCION.getDescripcion(), ex.toStringError());
				user = new User(userId, mapUser);
				saveBitacoraSox(user,IBitacoraSoxBusiness.ERROR_SEARCH);	
				throw ex;
			}
			
		}catch(SpmlOvitException | TransactionalOVITException e){
			logger.error(String.format(SpmlErrorEnum.ERROR_SEARCH.getMessageError(),userId));
			
			if(e instanceof SpmlOvitException){
				
				if(((SpmlOvitException)e).getCodeError()==null){
					((SpmlOvitException)e).setCodeError(SpmlErrorEnum.ERROR_SEARCH.getCodeError());
					((SpmlOvitException)e).setMessage(String.format(
														SpmlErrorEnum.ERROR_SEARCH.getMessageError(),userId));
					String error = ((SpmlOvitException)e).toStringError();
					user = new User(userId, new HashMap<String,String>());
					user.getAttributes().put(SpmlLogEnum.EXEPCION.getDescripcion(),error);
					saveBitacoraSox(user,IBitacoraSoxBusiness.ERROR_SEARCH);
				}				
				
				throw new Spml2ServerException(((SpmlOvitException)e).toStringError());
				
			}else if(e instanceof TransactionalOVITException){
				SpmlOvitException ex = new SpmlOvitException(SpmlErrorEnum.ERROR_SEARCH.getCodeError(), 
						String.format(SpmlErrorEnum.ERROR_SEARCH.getMessageError(),userId), 
						 e.toString());
				user = new User(userId, new HashMap<String,String>());
				user.getAttributes().put(SpmlLogEnum.EXEPCION.getDescripcion(), ex.toStringError());
				saveBitacoraSox(user,IBitacoraSoxBusiness.ERROR_SEARCH);
				throw new Spml2ServerException(ex.toString());
			}
			
		}
		return user;
	}

	
	
	/*
	 * (non-Javadoc)
	 * @see com.telcel.dwi.spml2.server.resource.ResourceConnector#modifyUser(com.telcel.dwi.spml2.server.resource.User)
	 */
	@Override
	public void modifyUser(User user) throws Spml2ServerException {
		logger.info("Modificacion de usuario");
		final Map<String, String> userMap = user.getAttributes();
		init();
		
		try {
			this.spmlValidations.validateNumEmployment(user.getUserId());
			this.spmlValidations.validateMapModify(userMap);
			this.spmlOvit.updateUserSPML(user);
			
		}catch(Spml2ServerException | TransactionalOVITException e){
			logger.error(String.format(SpmlErrorEnum.ERROR_MODIFY.getMessageError(),
											userMap.get(SpmlEnum.NUMEROEMPLEADO.getDescripcion())));
			
			if(e instanceof Spml2ServerException){
				((SpmlOvitException)e).setCodeError(SpmlErrorEnum.ERROR_MODIFY.getCodeError());
				((SpmlOvitException)e).setMessage(String.format(SpmlErrorEnum.ERROR_MODIFY.getMessageError(),
															userMap.get(SpmlEnum.NUMEROEMPLEADO.getDescripcion())));
				String error = ((SpmlOvitException)e).toStringError();
				user.getAttributes().put(SpmlLogEnum.EXEPCION.getDescripcion(),error);
				saveBitacoraSox(user,IBitacoraSoxBusiness.ERROR_MODIFY);
				throw new Spml2ServerException(((SpmlOvitException)e).toStringError());
				
			}else if(e instanceof TransactionalOVITException){
				SpmlOvitException ex = new SpmlOvitException(SpmlErrorEnum.ERROR_MODIFY.getCodeError(), 
												String.format(SpmlErrorEnum.ERROR_MODIFY.getMessageError(),
																userMap.get(SpmlEnum.NUMEROEMPLEADO.getDescripcion())), 
												e.toString());
				user.getAttributes().put(SpmlLogEnum.EXEPCION.getDescripcion(), ex.toStringError());
				saveBitacoraSox(user,IBitacoraSoxBusiness.ERROR_MODIFY);
				throw new Spml2ServerException(ex.toString());
			}	
		}
	}
	
	
	
	/**
	 * Unsupported Operations
	 */
	
	/*
	 * (non-Javadoc)
	 * @see com.telcel.dwi.spml2.server.resource.ResourceConnector#changePassword(java.lang.String, java.lang.String)
	 */
	@Override
	public void changePassword(String arg0, String arg1) throws Spml2ServerException {
		logger.info("Operacion no soportada");
		throw new UnsupportedOperationException();
	}

	
	/*
	 * (non-Javadoc)
	 * @see com.telcel.dwi.spml2.server.resource.ResourceConnector#changePassword(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public void changePassword(String arg0, String arg1, String arg2) throws Spml2ServerException {
		logger.info("Operacion no soportada");
		throw new UnsupportedOperationException();
	}

	
	/*
	 * (non-Javadoc)
	 * @see com.telcel.dwi.spml2.server.resource.ResourceConnector#expirePassword(java.lang.String)
	 */
	@Override
	public void expirePassword(String arg0) throws Spml2ServerException {
		logger.info("Operacion no soportada");
		throw new UnsupportedOperationException();
	}

	
	/*
	 * (non-Javadoc)
	 * @see com.telcel.dwi.spml2.server.resource.ResourceConnector#login(java.lang.String, java.lang.String)
	 */
	@Override
	public String login(String arg0, String arg1) throws Spml2ServerException {
		logger.info("Operacion no soportada");
		throw new UnsupportedOperationException();
	}

	
	/*
	 * (non-Javadoc)
	 * @see com.telcel.dwi.spml2.server.resource.ResourceConnector#resetPassword(java.lang.String)
	 */
	@Override
	public String resetPassword(String arg0) throws Spml2ServerException {
		logger.info("Operacion no soportada");
		throw new UnsupportedOperationException();
	}

	
	/*
	 * (non-Javadoc)
	 * @see com.telcel.dwi.spml2.server.resource.ResourceConnector#validateSession(java.lang.String)
	 */
	@Override
	public void validateSession(String arg0) throws Spml2ServerException {
		logger.info("Operacion no soportada");
		throw new UnsupportedOperationException();
	}
	

	private void init(){
		if (this.applicationContext == null) {
			this.applicationContext = ApplicationContextProvider
					.getApplicationContext();
			if (this.applicationContext != null) {
				this.spmlOvit = (ISpmlOvitBusiness) this.applicationContext
						.getBean("spmlOvit");
				this.spmlValidations = (ISpmlValidations)this.applicationContext
						.getBean("spmlValidations");
				this.bitacoraSox = (IBitacoraSoxBusiness)this.applicationContext
						.getBean("bitacoraSox");
			}
		}
	}
	
	
	private void saveBitacoraSox(User user, int action){
		try {
			UserSpmlTo userSpmlTo = new UserSpmlTo(user);
			BitacoraSoxVo soxVo = new BitacoraSoxVo();
			soxVo.setIdUsuario(1);
			soxVo.setNumeroEmpleado(SPML);
			soxVo.setFolioSua(user.getAttributes().get(SpmlEnum.FOLIOSUA.getDescripcion()));
			soxVo.setFechaOperacion(new Date());
			soxVo.setIdAccion(action);
			String objInicial = this.bitacoraSox.objectToXML(userSpmlTo);
			soxVo.setObjetoInicial(objInicial);
			this.bitacoraSox.createBitacoraSox(soxVo);
		} catch (TransactionalOVITException e) {
			logger.error("Error en el guardado de bitacora sox - datos SPML erroneos: " + e);
		}
		
	}
	
}

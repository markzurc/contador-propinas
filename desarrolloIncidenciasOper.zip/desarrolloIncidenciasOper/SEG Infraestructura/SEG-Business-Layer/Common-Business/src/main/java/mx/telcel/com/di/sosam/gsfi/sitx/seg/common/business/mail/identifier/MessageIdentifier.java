package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.identifier;

/**
 * 
 * 
 * <h1>MessageIdentifier</h1>
 * <p>
 * Identifiers for the message
 * </p>
 * 
 * @author chcastro
 * @version 1.0
 * @since 17/07/2015
 */
public enum MessageIdentifier {
	NUEVO_USUARIO,
	REINICIAR_PASSWORD
}

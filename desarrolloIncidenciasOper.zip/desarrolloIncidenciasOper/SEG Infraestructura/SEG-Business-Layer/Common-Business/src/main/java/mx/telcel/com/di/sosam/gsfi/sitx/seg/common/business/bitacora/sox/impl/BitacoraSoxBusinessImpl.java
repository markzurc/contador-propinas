package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.impl;

import java.io.Serializable;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.IBitacoraSoxBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.vo.BitacoraSoxVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.error.ErrorSEGWeb;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.OVITUtils;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.exception.ValidationOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.mapper.MapperCustomFactory;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dao.IBitacoraSoxDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dto.BitacoraSoxDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segbBita;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * 
 * <h1>BitacoraSoxImpl</h1>
 * <p>
 * Implementation of the methods corresponding to the interface IBitacoraSoxBusiness
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 11/05/2015
 */

@Service("bitacoraSox")
@Scope("prototype")
public class BitacoraSoxBusinessImpl extends MapperCustomFactory implements IBitacoraSoxBusiness, Serializable {
	
	private static final long serialVersionUID = -2110046818945218916L;

	private static final Logger logger = LogManager.getLogger(BitacoraSoxBusinessImpl.class);
	
	@Autowired()
	@Qualifier("bitacoraSoxDao")
	private IBitacoraSoxDao bitacoraSoxDao;
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public void createBitacoraSox(BitacoraSoxVo bitacoraSoxVo)
			throws TransactionalOVITException {
		logger.info("Ejecutando BitacoraSoxImpl.createBitacoraSox");
		try{

			String xmlInicio = "";
			String xmlFin = "";
			if(bitacoraSoxVo.getObjetoInicial() != null){
				xmlInicio = bitacoraSoxVo.getObjetoInicial();
			}
			
			if(bitacoraSoxVo.getObjetoFinal() != null){
				xmlFin = bitacoraSoxVo.getObjetoFinal();
			}
			logger.info("Validando objeto BitacoraSoxVo.");
			validateVo(bitacoraSoxVo);
			T7segbBita tsegcBitacoraSox = getMapper().map(bitacoraSoxVo, T7segbBita.class);
			tsegcBitacoraSox.setDatoInicial(xmlInicio);
			tsegcBitacoraSox.setDatoFinal(xmlFin);
			bitacoraSoxDao.createBitacoraSox(tsegcBitacoraSox);
			bitacoraSoxVo.setIdBitacora(tsegcBitacoraSox.getIdBitacora());
		}catch(Exception e){
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E01_ERROR_INSERT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E01_ERROR_INSERT.getMessageError()));
			logger.error(e.getMessage());
			logger.error("Error al ejecutar BitacoraSoxImpl.createBitacoraSox: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E01_ERROR_INSERT.getCodeError(),
					ErrorSEGWeb.E01_ERROR_INSERT.getMessageError());
		}
	}
	
	@Override
	public Session getSession() {
		return bitacoraSoxDao.getSession();
	}

	@Override
	public void setSession(Session session) {
		bitacoraSoxDao.setSession(session);		
	}
	
	@Override
	public <T> String objectToXML(T object) {
		 
        try {
            JAXBContext context = JAXBContext.newInstance(object.getClass());
            Marshaller m = context.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            StringWriter sw = new StringWriter();
            m.marshal(object, sw);
            return sw.toString();
        } catch (JAXBException e) {
            logger.error("Error al ejecutar el metodo objectToXML:"+e);           
        }
        return null;
    }
	
	@Override
	public <T> T xmlToObject(String xml, Class<T> objectClass) {
        try {
            JAXBContext context = JAXBContext.newInstance(objectClass);
            Unmarshaller un = context.createUnmarshaller();
            StringReader sr = new StringReader(xml);
            @SuppressWarnings("unchecked")
			T object = (T) un.unmarshal(sr);
            return object;
        } catch (JAXBException e) {
        	logger.error("Error al ejecutar el metodo xmlToObject:"+e);
        }
        return null;
    }
	
	/**
	 * Validate if the object has the minimun data nesesary.
	 * @param objectValidate {@link T} - Object to validate
	 * @throws ValidationOVITException
	 */
	private <T> void validateVo(T objectValidate) throws ValidationOVITException{
		Set<ConstraintViolation<T>> externalDataVoViolations = getValidator().validate(objectValidate);
		if(!OVITUtils.isEmptyList(externalDataVoViolations)){
			for(ConstraintViolation<T> tempViolation : externalDataVoViolations){
				logger.error("Error al validar BitacoraSoxVo:".concat(tempViolation.getMessage()));
			}
			throw new ValidationOVITException(ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getCodeError(),
					ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getMessageError());
		}
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public Integer getNumberOfElements(Integer idUsuario)
			throws TransactionalOVITException {
		logger.info("Ejecutando BitacoraSoxImpl.createBitacoraSox");
		try {
			return bitacoraSoxDao.getNumberOfElements(idUsuario);
		} catch(Exception e){
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar el metodo getNumberOfElements: "+e);
			throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),
					ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<BitacoraSoxVo> getContentPage(Integer idUsuario,
			Integer sizePage, Integer pageNomber)
			throws TransactionalOVITException {
		logger.info("Ejecutando BitacoraSoxImpl.createBitacoraSox");
		try {
			List<BitacoraSoxDto> lstBitacoraSoxs = bitacoraSoxDao.getContentPage(idUsuario, sizePage, pageNomber);
			return getMapper().mapAsList(lstBitacoraSoxs, BitacoraSoxVo.class);
		} catch(Exception e){
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar el metodo getContentPage: "+e);
			throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),
					ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
	}
}

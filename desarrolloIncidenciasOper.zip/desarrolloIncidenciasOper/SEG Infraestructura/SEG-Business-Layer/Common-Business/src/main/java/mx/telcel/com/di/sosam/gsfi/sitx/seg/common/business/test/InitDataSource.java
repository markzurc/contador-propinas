package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.test;

import java.sql.SQLException;

import javax.naming.NamingException;

import oracle.jdbc.pool.OracleConnectionPoolDataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.springframework.mock.jndi.SimpleNamingContextBuilder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.impl.SendMailBusinessImpl;


/**
 * 
 * 
 * <h1>InitDataSource</h1>
 * <p>
 * Class whit the configuration for the database, this configuration is used for the tests.
 * </p>
 * 
 * @author chcastro
 * @version 1.0
 * @since 17/07/2015
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:spring/application-config-test.xml"})
public class InitDataSource {
	
	
	private static final Logger logger = LogManager.getLogger(SendMailBusinessImpl.class);
	
	/**
	 * This method is executed before of the test start
	 */
	@BeforeClass
	public static void initDataSource(){
		try {
	        SimpleNamingContextBuilder builder = new SimpleNamingContextBuilder();

	        OracleConnectionPoolDataSource ds = new OracleConnectionPoolDataSource();
	        ds.setURL("jdbc:oracle:thin:@10.191.34.207:4207:ICT");
	        ds.setUser("svovi02");
	        ds.setPassword("sV0v1#oZ");           

	        builder.bind("jndi/OVIT_DB_APP", ds);
	        
	        ds = new OracleConnectionPoolDataSource();
	        ds.setURL("jdbc:oracle:thin:@10.191.34.207:4207:ICT");
	        ds.setUser("svspm01");
	        ds.setPassword("sVsPm1ol"); 
	        
	        builder.bind("jndi/OVIT_DB_SPML", ds);
	        
	        builder.activate();
	    }catch (SQLException e) {
			logger.error("Error al conectar a la base de ICT: " + e);
		} catch (NamingException ex) {
			logger.error("Error al conectar a la base de ICT: " + ex);
	    }
		
	}
	
	
}

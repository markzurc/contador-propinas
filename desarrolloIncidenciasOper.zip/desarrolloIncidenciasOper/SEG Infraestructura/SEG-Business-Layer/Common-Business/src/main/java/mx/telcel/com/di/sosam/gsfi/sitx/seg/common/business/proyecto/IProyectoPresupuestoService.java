package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.proyecto;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegdSoliArch;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.proyecto.dto.ProyectoPresupuestoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.proyecto.dto.TipoSolicitudDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SoliArchDto;

public interface IProyectoPresupuestoService {

	public List<SoliArchDto> getArchivos(String folio, String tipo);

	public boolean crearProyectoPresupuesto(ProyectoPresupuestoDto proyecto);

	public boolean updateEstadoSolicitud(String folio, String estatus);

	public boolean guardarArchivo(T3SegdSoliArch archivo);

	public List<ProyectoPresupuestoDto> getDatosProyectoPorFolio(String folio);

	public boolean atenderProyectoPresupuesto(ProyectoPresupuestoDto proyecto);

	public boolean rechazarProyectoPresupuesto(ProyectoPresupuestoDto proyecto);

	public boolean corregirProyectoPresupuesto(ProyectoPresupuestoDto proyecto);

	public boolean eliminarArchivo(SoliArchDto archivo);

	public List<TipoSolicitudDto> getDatosTipoSolicitud();

	public boolean solicitarAdecuacionRecuperacion(ProyectoPresupuestoDto proyecto);

	public String consultaIdEstadoBitacora(String folio);

}

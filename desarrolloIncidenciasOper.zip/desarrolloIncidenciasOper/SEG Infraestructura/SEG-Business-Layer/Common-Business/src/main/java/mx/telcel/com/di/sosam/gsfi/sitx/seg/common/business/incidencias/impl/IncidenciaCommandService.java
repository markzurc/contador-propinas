package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.impl;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.IIncidenciaService.AdjuntoUi;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.T3SINB_INCI_MOVI;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.T3SINO_INCI;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaBitacoraDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaDao;

@Service
public class IncidenciaCommandService {

	private static final Logger log = LoggerFactory.getLogger(IncidenciaCommandService.class);

	private static final long ESTATUS_CREADA = 1L;
	private static final long ESTATUS_EN_ATENCION = 2L;
	private static final long ESTATUS_RECHAZADA = 3L;
	private static final long ESTATUS_FINALIZADA = 4L;

	private static final long RESP_CONCESIONARIO = 1L;
	private static final long RESP_MANTENIMIENTO = 2L;

	

	private static final long DEF_MAX_BYTES = 10L * 1024L * 1024L;

	@Autowired
	private IIncidenciaDao incidenciaDao;

	@Autowired
	private IIncidenciaBitacoraDao bitacoraDao;

	@Autowired
	private IncidenciaQueryService incidenciaQueryService;

	@Autowired
	private IncidenciaAdjuntosService incidenciaAdjuntosService;

	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	public Long crearIncidencia(String sitioCodigo, String tipo, String descripcion, List<AdjuntoUi> adjuntos,
			String usuarioCreacion, String correoUsuarioCreacion, String concesionarioCreacion) {

		validarAlta(sitioCodigo, tipo, descripcion, adjuntos);
		incidenciaQueryService.validarSitioActivo(sitioCodigo);
		Long idIncidencia = obtenerSiguienteIdIncidenciaConBloqueo();
		T3SINO_INCI T3SINO_INCI = new T3SINO_INCI();

		T3SINO_INCI.setId(idIncidencia);
		T3SINO_INCI.setFolio(generarFolioIncidencia(idIncidencia));
		T3SINO_INCI.setIdSitio(sitioCodigo.trim());
		T3SINO_INCI.setIdConcesionario(valorSeguro(concesionarioCreacion));
		T3SINO_INCI.setIdTipoIncidencia(mapTipoEntradaAId(tipo));
		T3SINO_INCI.setIdEstatusIncidencia(ESTATUS_CREADA);
		T3SINO_INCI.setIdResponsabilidad(RESP_CONCESIONARIO);
		T3SINO_INCI.setDescripcion(descripcion.trim());
		T3SINO_INCI.setOrigenAlta("I");
		T3SINO_INCI.setNombreReporta(valorSeguro(usuarioCreacion));
		T3SINO_INCI.setCorreoReporta(valorSeguro(correoUsuarioCreacion));
		T3SINO_INCI.setUsuarioAlta(valorSeguro(usuarioCreacion));
		Date ahora = new Date();
		T3SINO_INCI.setFechaAlta(ahora);
		T3SINO_INCI.setFechaUltimoMovimiento(ahora);
		T3SINO_INCI.setFechaUltimaModificacion(ahora);

		incidenciaDao.persist(T3SINO_INCI);
		insertarMovimientoBitacora(idIncidencia, ESTATUS_CREADA, RESP_CONCESIONARIO, "C", valorSeguro(usuarioCreacion),
				null, null);

		if (adjuntos != null && !adjuntos.isEmpty()) {
			incidenciaAdjuntosService.guardarAdjuntosIncidenciaAlta(idIncidencia, adjuntos, valorSeguro(usuarioCreacion));
		}
		return idIncidencia;
	}

	@Transactional
	public void validarAlta(String sitioCodigo, String tipo, String descripcion, List<AdjuntoUi> adjuntos) {
		if (isBlank(sitioCodigo))
			throw new IllegalArgumentException("El sitio es obligatorio.");
		if (isBlank(tipo))
			throw new IllegalArgumentException("El tipo de T3SINO_INCI es obligatorio.");
		if (isBlank(descripcion))
			throw new IllegalArgumentException("La descripci�n es obligatoria.");

		if (adjuntos == null || adjuntos.isEmpty()) {
			throw new IllegalArgumentException("Debe adjuntar al menos un archivo PDF como evidencia.");
		}

		long total = 0L;
		for (AdjuntoUi adjunto : adjuntos) {
			if (adjunto == null)
				continue;
			incidenciaAdjuntosService.validarAdjunto(adjunto.getNombre(), null, adjunto.getTamanio());
			total += adjunto.getTamanio();
		}

		if (total > incidenciaAdjuntosService.obtenerMaxBytesAdjunto()) {
			throw new IllegalArgumentException(
					"El total de evidencias no debe exceder " + (DEF_MAX_BYTES / (1024 * 1024)) + " MB.");
		}
	}

	@Transactional
	public void avanzarIncidencia(Long idIncidencia, String accion, String comentario, Long idUsuarioMovimiento) {
		if (idIncidencia == null)
			throw new IllegalArgumentException("idIncidencia es obligatorio.");
		if (isBlank(accion))
			throw new IllegalArgumentException("La acci�n es obligatoria.");

		T3SINO_INCI T3SINO_INCI = incidenciaDao.findById(idIncidencia);
		if (T3SINO_INCI == null)
			throw new IllegalArgumentException("No existe la T3SINO_INCI " + idIncidencia);

		Long estatusActual = T3SINO_INCI.getIdEstatusIncidencia();
		if (estatusActual == null)
			throw new IllegalStateException("La T3SINO_INCI no tiene estatus actual.");

		if (ESTATUS_FINALIZADA == estatusActual || ESTATUS_RECHAZADA == estatusActual) {
			throw new IllegalStateException("La T3SINO_INCI est� cerrada y no permite cambios.");
		}

		Long nuevoEstatus = mapAccionAEstatusId(accion);
		if (nuevoEstatus == null)
			throw new IllegalArgumentException("Acci�n no reconocida: " + accion);

		if (ESTATUS_CREADA == estatusActual && ESTATUS_FINALIZADA == nuevoEstatus) {
			throw new IllegalStateException("Una T3SINO_INCI CREADA debe pasar primero a EN ATENCI�N.");
		}
		if (ESTATUS_EN_ATENCION == estatusActual && ESTATUS_RECHAZADA == nuevoEstatus) {
			throw new IllegalStateException("No es posible rechazar una T3SINO_INCI EN ATENCI�N.");
		}

		Long nuevaResponsabilidad = resolverResponsabilidadPorEstatus(nuevoEstatus);

		T3SINO_INCI.setIdEstatusIncidencia(nuevoEstatus);
		T3SINO_INCI.setIdResponsabilidad(nuevaResponsabilidad);
		T3SINO_INCI.setFechaUltimoMovimiento(new Date());

		if (idUsuarioMovimiento != null) {
			String nombreOperador = incidenciaDao.obtenerNombreCompletoUsuarioPorId(idUsuarioMovimiento.intValue());

			if (nombreOperador != null && !nombreOperador.isEmpty()) {
				T3SINO_INCI.setUsuarioUltimaModificacion(nombreOperador);
			} else {
				T3SINO_INCI.setUsuarioUltimaModificacion(String.valueOf(idUsuarioMovimiento));
			}
		}
		T3SINO_INCI.setFechaUltimaModificacion(new Date());

		incidenciaDao.merge(T3SINO_INCI);

		String operadorMovimiento = resolverNombreOperadorMovimiento(idUsuarioMovimiento);

		if (isBlank(operadorMovimiento) && idUsuarioMovimiento != null) {
			operadorMovimiento = String.valueOf(idUsuarioMovimiento);
		}

		insertarMovimientoBitacora(idIncidencia, nuevoEstatus, nuevaResponsabilidad, "M", operadorMovimiento,
				valorSeguro(comentario), mapEstatusIdAClave(estatusActual));
	}

	@Transactional
	public Long crearIncidenciaExternaCargaMasiva(String sitioCodigo, String tipo, String descripcion,
			String usuarioCreacion, String correoUsuarioCreacion, String concesionarioCreacion, String estatusInicial) {

		if (isBlank(sitioCodigo))
			throw new IllegalArgumentException("El sitio es obligatorio.");
		if (isBlank(tipo))
			throw new IllegalArgumentException("El tipo es obligatorio.");
		if (isBlank(descripcion))
			throw new IllegalArgumentException("La descripci�n es obligatoria.");
		if (isBlank(usuarioCreacion))
			throw new IllegalArgumentException("El nombre es obligatorio.");
		if (isBlank(estatusInicial))
			throw new IllegalArgumentException("El estatus es obligatorio.");

		incidenciaQueryService.validarSitioActivo(sitioCodigo);

		Long idIncidencia = obtenerSiguienteIdIncidenciaConBloqueo();
		Long idEstatus = mapEstatusEntradaAId(estatusInicial);
		if (idEstatus == null)
			throw new IllegalArgumentException("Estatus inicial no reconocido: " + estatusInicial);

		T3SINO_INCI T3SINO_INCI = new T3SINO_INCI();
		T3SINO_INCI.setId(idIncidencia);
		T3SINO_INCI.setFolio(generarFolioIncidencia(idIncidencia));
		T3SINO_INCI.setIdSitio(sitioCodigo.trim());
		T3SINO_INCI.setIdConcesionario(valorSeguro(concesionarioCreacion));
		T3SINO_INCI.setIdTipoIncidencia(mapTipoEntradaAId(tipo));
		T3SINO_INCI.setIdEstatusIncidencia(idEstatus);
		T3SINO_INCI.setIdResponsabilidad(resolverResponsabilidadPorEstatus(idEstatus));
		T3SINO_INCI.setDescripcion(descripcion.trim());
		T3SINO_INCI.setOrigenAlta("M");
		T3SINO_INCI.setNombreReporta(valorSeguro(usuarioCreacion));
		T3SINO_INCI.setCorreoReporta(valorSeguro(correoUsuarioCreacion));
		T3SINO_INCI.setUsuarioAlta(valorSeguro(usuarioCreacion));

		Date ahora = new Date();
		T3SINO_INCI.setFechaAlta(ahora);
		T3SINO_INCI.setFechaUltimoMovimiento(ahora);
		T3SINO_INCI.setFechaUltimaModificacion(ahora);

		incidenciaDao.persist(T3SINO_INCI);

		insertarMovimientoBitacora(idIncidencia, idEstatus, T3SINO_INCI.getIdResponsabilidad(), "C",
				valorSeguro(usuarioCreacion), "CARGA MASIVA: T3SINO_INCI creada", null);
		return idIncidencia;
	}

	@Transactional
	public String generarFolioIncidencia(Long idIncidencia) {
		if (idIncidencia == null)
			return null;
		return String.format("IN-%06d", idIncidencia.longValue());
	}

	private Long obtenerSiguienteIdIncidenciaConBloqueo() {
		bloquearTabla("BDDSEG01.T3SINO_INCI");
		return incidenciaDao.obtenerSiguienteId();
	}

	private Long obtenerSiguienteIdMovimientoConBloqueo() {
		bloquearTabla("BDDSEG01.T3SINB_INCI_MOVI");
		return bitacoraDao.obtenerSiguienteId();
	}

	private void bloquearTabla(String tabla) {
		if (entityManager == null)
			return;
		try {
			entityManager.createNativeQuery("LOCK TABLE " + tabla + " IN EXCLUSIVE MODE").executeUpdate();
		} catch (Exception ex) {
			log.warn("No fue posible aplicar LOCK TABLE sobre {}", tabla, ex);
		}
	}

	private void insertarMovimientoBitacora(Long idIncidencia, Long idEstatus, Long idResponsabilidad,
			String perfilMovimiento, String usuarioMovimiento, String comentario, String estatusAnteriorClave) {

		Long idMovimiento = obtenerSiguienteIdMovimientoConBloqueo();

		T3SINB_INCI_MOVI mov = new T3SINB_INCI_MOVI();
		mov.setId(idMovimiento);
		mov.setIdIncidencia(idIncidencia);
		mov.setIdEstatusIncidencia(idEstatus);
		mov.setIdResponsabilidad(idResponsabilidad);

		mov.setPerfilMovimiento(isBlank(perfilMovimiento) ? "M" : perfilMovimiento.trim());
		mov.setUsuarioMovimiento(isBlank(usuarioMovimiento) ? "SYSTEM" : usuarioMovimiento.trim());
		mov.setFechaEvento(new Date());

		mov.setComentario(isBlank(comentario) ? null : comentario);

		boolean esAlta = (idEstatus != null && idEstatus.longValue() == ESTATUS_CREADA && isBlank(estatusAnteriorClave));
		mov.setEvento(esAlta ? "ALTA" : "CAMBIO_ESTATUS");

		mov.setEstatusAnterior(estatusAnteriorClave);
		mov.setEstatusNuevo(mapEstatusIdAClave(idEstatus));

		bitacoraDao.persist(mov);
	}

	private boolean isBlank(String s) {
		return s == null || s.trim().isEmpty();
	}

	private String valorSeguro(String s) {
		return (s == null) ? "" : s.trim();
	}

	private Long mapAccionAEstatusId(String accion) {
		String a = accion.trim().toUpperCase();
		if (a.contains("RECHAZ"))
			return ESTATUS_RECHAZADA;
		if (a.contains("ATEN"))
			return ESTATUS_EN_ATENCION;
		if (a.contains("FINAL"))
			return ESTATUS_FINALIZADA;
		return null;
	}

	private Long mapEstatusEntradaAId(String estatus) {
		if (isBlank(estatus))
			return null;
		String e = estatus.trim().toUpperCase();
		if (e.contains("CREAD"))
			return ESTATUS_CREADA;
		if (e.contains("ATEN"))
			return ESTATUS_EN_ATENCION;
		if (e.contains("RECHAZ"))
			return ESTATUS_RECHAZADA;
		if (e.contains("FINAL"))
			return ESTATUS_FINALIZADA;
		return null;
	}

	private String mapEstatusIdAClave(Long idEstatus) {
		if (idEstatus == null)
			return null;
		long v = idEstatus.longValue();
		if (v == ESTATUS_CREADA)
			return "CREADA";
		if (v == ESTATUS_EN_ATENCION)
			return "EN ATENCI�N";
		if (v == ESTATUS_RECHAZADA)
			return "RECHAZADA";
		if (v == ESTATUS_FINALIZADA)
			return "FINALIZADA";
		return String.valueOf(v);
	}

	private Long resolverResponsabilidadPorEstatus(Long idEstatusNuevo) {
		if (idEstatusNuevo == null) {
			return RESP_MANTENIMIENTO;
		}

		if (idEstatusNuevo.longValue() == ESTATUS_CREADA) {
			return RESP_CONCESIONARIO;
		}

		return RESP_MANTENIMIENTO;
	}

	private Long mapTipoEntradaAId(String tipo) {
	    Long idTipo = incidenciaQueryService.obtenerIdTipoIncidenciaDesdeCatalogo(tipo);

	    if (idTipo == null) {
	        throw new IllegalArgumentException("Tipo de incidencia no existe en cat�logo T3SINC_INCI_TIPO: " + tipo);
	    }

	    return idTipo;
	}


	private String resolverNombreOperadorMovimiento(Long idUsuarioMovimiento) {
		if (idUsuarioMovimiento == null)
			return null;
		try {
			String nombre = incidenciaDao.obtenerNombreCompletoUsuarioPorId(idUsuarioMovimiento.intValue());
			return (nombre != null && !nombre.trim().isEmpty()) ? nombre.trim() : null;
		} catch (Exception ex) {
			return null;
		}
	}
}

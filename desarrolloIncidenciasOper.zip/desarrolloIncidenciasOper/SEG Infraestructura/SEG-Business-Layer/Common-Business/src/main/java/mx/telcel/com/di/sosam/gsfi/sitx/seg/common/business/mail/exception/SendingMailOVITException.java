package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.exception;

/**
 * 
 * <h1>SendingMailOVITException</h1>
 * <p>
 * Exception thrown for "OVIT" system when exist a error when sending e-mail.
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 04/05/2015
 *
 */
public class SendingMailOVITException extends Exception {

	private static final long serialVersionUID = 1848601303912063645L;
	
	private String messageError;
	private String codeMessage;
	
	
	/**
	 * Constructor.
	 * @author chcastro
	 * @param codeMessage {@link String} - Code Error
	 * @param messageError {@link String} - Message Error
	 */
	public SendingMailOVITException(String codeMessage, String messageError) {
		super();
		this.messageError = messageError;
		this.codeMessage = codeMessage;
	}
	
	/**
	 * @author chcastro
	 * @return the messageError
	 */
	public String getMessageError() {
		return messageError;
	}
	/**
	 * @author chcastro
	 * @param messageError the messageError to set
	 */
	public void setMessageError(String messageError) {
		this.messageError = messageError;
	}
	/**
	 * @author chcastro
	 * @return the codeMessage
	 */
	public String getCodeMessage() {
		return codeMessage;
	}
	/**
	 * @author chcastro
	 * @param codeMessage the codeMessage to set
	 */
	public void setCodeMessage(String codeMessage) {
		this.codeMessage = codeMessage;
	}
	
	 

}

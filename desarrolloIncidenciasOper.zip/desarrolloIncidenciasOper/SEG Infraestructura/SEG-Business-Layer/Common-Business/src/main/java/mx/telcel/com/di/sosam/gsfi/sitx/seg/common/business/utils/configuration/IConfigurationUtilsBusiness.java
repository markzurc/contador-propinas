package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.utils.session.ISession;


/**
 * 
 * <h1>IConfigurationUtilsBusiness</h1>
 * <p>
 * Interface with the methods for obtain or modify the configuration parameters the OViT
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 17/04/2015
 *
 */
public interface IConfigurationUtilsBusiness  extends ISession{
	
	/**
	 * Obtain the information about the a parameter with the identifier and the name of the parameter.
	 * @author chcastro
	 * @param identificador {@link String} - Identifier of the parameter
	 * @param nombreParametro {@link String} - Name of the parameter
	 * @return {@link ConfigurationUtilsVo} - Parameter information
	 * @throws TransactionalOVITException
	 */
	ConfigurationUtilsVo getConstantOfDataBase(String identificador, String nombreParametro) throws TransactionalOVITException;
	
	/**
	 * Obtain the information about the a parameter with the identifier.
	 * @author chcastro
	 * @param identificador {@link Enum}
	 * @return {@link ConfigurationUtilsVo} - Parameter information
	 * @throws TransactionalOVITException
	 */
	ConfigurationUtilsVo getConstantOfDataBase(Enum<?> identificador) throws TransactionalOVITException;
	
	/**
	 * Obtain a list of information about the parameters, only need the identifier
	 * @param {@link String} identificador
	 * @return {@link List}<{@link ConfigurationUtilsVo}>
	 * @throws TransactionalOVITException
	 */
	List<ConfigurationUtilsVo> getListConstantOfDataBase(String identificador) throws TransactionalOVITException;
	
	/**
	 * Update the information a the parameter
	 * @param configurationUtilsVo {@link ConfigurationUtilsVo}
	 * @throws TransactionalOVITException
	 */
	void updateConfiguration(ConfigurationUtilsVo configurationUtilsVo) throws TransactionalOVITException;
	
	/**
	 * Refresh the list of the parameters.
	 * @throws TransactionalOVITException
	 */
	void getConstantOfDataBase() throws TransactionalOVITException;
}

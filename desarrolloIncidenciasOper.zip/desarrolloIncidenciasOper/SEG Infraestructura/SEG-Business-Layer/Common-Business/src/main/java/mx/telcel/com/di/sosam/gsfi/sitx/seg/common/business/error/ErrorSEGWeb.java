package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.error;

/**
 * <h1>ErrorOVITWeb</h1>
 * <p>
 * Enum containing existing system errors.
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 30/03/2015
 *
 */
public enum ErrorSEGWeb {
	MSG_ERROR("ERROR","Error %s cause by %s"),
	E01_ERROR_INSERT("E01","Error al ejecutar el alta en base de datos."),
	E02_ERROR_UPDATE("E02","Error al ejecutar update en base de datos."),
	E03_ERROR_SELECT("E03","Error al ejecutar consulta en base de datos."),
	E04_ERROR_VALIDATION_DATA("E04","Los datos ingresados son erroneos."),
	E05_ERROR_ENVIAR_CORREO("E05","Problemas al enviar el correo favor de validar los datos."),
	E06_ERROR_USUARIO_ROL("E06","USUARIO INCORRECTO. CONTACTE A SU ADMINISTRADOR."),
	E07_ERROR_CALL_SP("E07","Error al ejecutar el SP."),
	E08_ERROR_IMAGEN("E08","Error al obtener imagen web."),
	E09_ERROR_MOD_USER("E09","Los datos ingresados son erroneos o el usuario no existe");
	
	
	
	String codeError;
	String messageError;
	
	/**
	 * @author chcastro
	 * @param codeError {@link String} - Code Error
	 * @param messageError {@link String} - Message Error
	 */
	ErrorSEGWeb(String codeError, String messageError) {
		this.messageError = messageError;
		this.codeError = codeError;
	}

	/**
	 * @author chcastro
	 * @return the codeError
	 */
	public String getCodeError() {
		return codeError;
	}

	/**
	 * @author chcastro
	 * @return the messageError
	 */
	public String getMessageError() {
		return messageError;
	}
}

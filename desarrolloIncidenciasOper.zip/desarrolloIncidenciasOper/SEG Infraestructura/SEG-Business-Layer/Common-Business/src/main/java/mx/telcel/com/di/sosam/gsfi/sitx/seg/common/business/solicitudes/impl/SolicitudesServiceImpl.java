package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.solicitudes.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.solicitudes.ISolicitudesService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.mapper.MapperCustomFactory;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ArchSoliDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.CInfoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.InfoSoliDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ServicioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SoliArchDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SolicitudDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dao.ISolicitudesServiciosDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dto.AccionAvanceDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dto.GraficaDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dto.TranEstaInfDto;

@Service("consultaServiciosServiceImpl")
@Scope("prototype")
public class SolicitudesServiceImpl  extends MapperCustomFactory implements ISolicitudesService {
	
	@Autowired
	@Qualifier("consultaServiciosDao")
	private ISolicitudesServiciosDao consultaServiciosDao;

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public boolean getSitioConSolicitud(SitioDto parametroSitio,String grupoOperador) {//posible eliminacion
		return consultaServiciosDao.getSitioConSolicitud(parametroSitio, grupoOperador);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<ServicioDto> getListaServicios() {
		return consultaServiciosDao.listaServicios();
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public String getGpoOperUsuById(String idUsuario) {
		return consultaServiciosDao.getGpoOperUsuById(idUsuario);
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<CInfoDto> getInfoReq() {
		return consultaServiciosDao.getInfoReq();

	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public SolicitudDto generaSolicitud(SolicitudDto generaSoliDto) throws Exception{
		return consultaServiciosDao.generaSolicitud(generaSoliDto);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public void generaSolicitudInfo(SolicitudDto solicitudDto) {
		consultaServiciosDao.generaSolicitudInfo(solicitudDto);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public void generaSolicitudArch(List<SoliArchDto> archSoliDto) {
		consultaServiciosDao.generaSolicitudArch(archSoliDto);
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<GraficaDto> getDatosGrafica(String idEstado) {
		return consultaServiciosDao.getDatosGrafica(idEstado);
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<TranEstaInfDto> getDatosTransicion(String idEstado, Integer idRol) {
		return consultaServiciosDao.getDatosTransicion(idEstado, idRol);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public SolicitudDto getSitioConSolicitudCrea(SitioDto parametroSitio,String grupoOperador) { //add
		return consultaServiciosDao.getSitioConSolicitudCrea(parametroSitio, grupoOperador);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public SolicitudDto getSitioConSolicitudConsulta(SitioDto parametroSitio) { //add
		return consultaServiciosDao.getSitioConSolicitudConsulta(parametroSitio);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public InfoSoliDto getInfoConSolicitudConsulta(SitioDto parametroSitio) { //add
		return consultaServiciosDao.getInfoConSolicitudConsulta(parametroSitio);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<AccionAvanceDto> getListaAcciones() { //add
		return consultaServiciosDao.getListaAcciones();
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<SoliArchDto> getLstArchSoli(SitioDto parametroSitio, List<String> tipoDocumentos) { //add
		return consultaServiciosDao.getLstArchSoli(parametroSitio, tipoDocumentos);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public boolean updateSolicitud(SitioDto sitioDTO, String transicion) { //add
		 return consultaServiciosDao.updateSolicitud(sitioDTO, transicion);		
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public boolean updateSolicitudInfo(SitioDto sitioDTO, String info) { //add
		 return consultaServiciosDao.updateSolicitudInfo(sitioDTO, info);		
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public boolean updateSolicitudArch(List<SoliArchDto> lstArchFinal, SitioDto sitioDTO) { //add
		 return consultaServiciosDao.updateSolicitudArch(lstArchFinal, sitioDTO);		
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public String getNombreUsu(Integer idUsuario) {
		return consultaServiciosDao.getNombreUsu(idUsuario);
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public int getCountSolicitudInf(String folio) {
		return consultaServiciosDao.getCountSolicitudInf(folio);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public String getIdAccion(String accion) {
		return consultaServiciosDao.getIdAccion(accion);
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details;

import java.io.Serializable;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * 
 * <h1>UserDetailsVo</h1>
 * <p>
 * </p>
 * 
 * @author chcastro
 * @version 1.0
 * @since 17/07/2015
 */
@XmlRootElement
public class UserDetailsVo implements Serializable{

	private static final long serialVersionUID = -5006453787579733533L;
	
	private Integer idUsuario;
	private String numeroEmpleado;
	private String nombre;
	private String apellidoPaterno;
	private String apellidoMaterno;
	private Integer idTipoUsuario;
	private String tipoUsuarioNombre;
	private Integer idEstatus;
	private String estatusNombre;
	private Integer idRol;
	private String rolNombre;
	private String correo;
	private Integer estatusLogin;
	private Integer idRolInterno;
	private Map<String, String> componentes;
	private String vistaRedireccion;
	
	public UserDetailsVo() {
	}

	/**
	 * @author chcastro
	 * @param idUsuario
	 * @param numeroEmpleado
	 * @param nombre
	 * @param apellidoPaterno
	 * @param apellidoMaterno
	 * @param idTipoUsuario
	 * @param tipoUsuarioNombre
	 * @param idEstatus
	 * @param estatusNombre
	 * @param idRol
	 * @param rolNombre
	 * @param correo
	 * @param estatusLogin
	 */
	public UserDetailsVo(Integer idUsuario, String numeroEmpleado,
			String nombre, String apellidoPaterno, String apellidoMaterno,
			Integer idTipoUsuario, String tipoUsuarioNombre, Integer idEstatus,
			String estatusNombre, Integer idRol, String rolNombre,
			String correo, Integer estatusLogin, Integer idRolInterno, Map<String, String> componentes, String vistaRedireccion, String corOvitUser) {
		super();
		this.idUsuario = idUsuario;
		this.numeroEmpleado = numeroEmpleado;
		this.nombre = nombre;
		this.apellidoPaterno = apellidoPaterno;
		this.apellidoMaterno = apellidoMaterno;
		this.idTipoUsuario = idTipoUsuario;
		this.tipoUsuarioNombre = tipoUsuarioNombre;
		this.idEstatus = idEstatus;
		this.estatusNombre = estatusNombre;
		this.idRol = idRol;
		this.rolNombre = rolNombre;
		this.correo = correo;
		this.estatusLogin = estatusLogin;
		this.idRolInterno = idRolInterno;
		this.componentes = componentes;
		this.vistaRedireccion = vistaRedireccion;
	}

	/**
	 * @author chcastro
	 * @return the idUsuario
	 */
	@XmlElement(nillable = true)
	public Integer getIdUsuario() {
		return idUsuario;
	}

	/**
	 * @author chcastro
	 * @param idUsuario the idUsuario to set
	 */
	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	/**
	 * @author chcastro
	 * @return the numeroEmpleado
	 */
	@XmlElement(nillable = true)
	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}

	/**
	 * @author chcastro
	 * @param numeroEmpleado the numeroEmpleado to set
	 */
	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	/**
	 * @author chcastro
	 * @return the nombre
	 */
	@XmlElement(nillable = true)
	public String getNombre() {
		return nombre;
	}

	/**
	 * @author chcastro
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @author chcastro
	 * @return the apellidoPaterno
	 */
	@XmlElement(nillable = true)
	public String getApellidoPaterno() {
		return apellidoPaterno;
	}

	/**
	 * @author chcastro
	 * @param apellidoPaterno the apellidoPaterno to set
	 */
	public void setApellidoPaterno(String apellidoPaterno) {
		this.apellidoPaterno = apellidoPaterno;
	}

	/**
	 * @author chcastro
	 * @return the apellidoMaterno
	 */
	@XmlElement(nillable = true)
	public String getApellidoMaterno() {
		return apellidoMaterno;
	}

	/**
	 * @author chcastro
	 * @param apellidoMaterno the apellidoMaterno to set
	 */
	public void setApellidoMaterno(String apellidoMaterno) {
		this.apellidoMaterno = apellidoMaterno;
	}

	/**
	 * @author chcastro
	 * @return the idTipoUsuario
	 */
	@XmlElement(nillable = true)
	public Integer getIdTipoUsuario() {
		return idTipoUsuario;
	}

	/**
	 * @author chcastro
	 * @param idTipoUsuario the idTipoUsuario to set
	 */
	public void setIdTipoUsuario(Integer idTipoUsuario) {
		this.idTipoUsuario = idTipoUsuario;
	}

	/**
	 * @author chcastro
	 * @return the tipoUsuarioNombre
	 */
	@XmlElement(nillable = true)
	public String getTipoUsuarioNombre() {
		return tipoUsuarioNombre;
	}

	/**
	 * @author chcastro
	 * @param tipoUsuarioNombre the tipoUsuarioNombre to set
	 */
	public void setTipoUsuarioNombre(String tipoUsuarioNombre) {
		this.tipoUsuarioNombre = tipoUsuarioNombre;
	}

	/**
	 * @author chcastro
	 * @return the idEstatus
	 */
	@XmlElement(nillable = true)
	public Integer getIdEstatus() {
		return idEstatus;
	}

	/**
	 * @author chcastro
	 * @param idEstatus the idEstatus to set
	 */
	public void setIdEstatus(Integer idEstatus) {
		this.idEstatus = idEstatus;
	}

	/**
	 * @author chcastro
	 * @return the estatusNombre
	 */
	@XmlElement(nillable = true)
	public String getEstatusNombre() {
		return estatusNombre;
	}

	/**
	 * @author chcastro
	 * @param estatusNombre the estatusNombre to set
	 */
	public void setEstatusNombre(String estatusNombre) {
		this.estatusNombre = estatusNombre;
	}

	/**
	 * @author chcastro
	 * @return the idRol
	 */
	@XmlElement(nillable = true)
	public Integer getIdRol() {
		return idRol;
	}

	/**
	 * @author chcastro
	 * @param idRol the idRol to set
	 */
	public void setIdRol(Integer idRol) {
		this.idRol = idRol;
	}

	/**
	 * @author chcastro
	 * @return the rolNombre
	 */
	@XmlElement(nillable = true)
	public String getRolNombre() {
		return rolNombre;
	}

	/**
	 * @author chcastro
	 * @param rolNombre the rolNombre to set
	 */
	public void setRolNombre(String rolNombre) {
		this.rolNombre = rolNombre;
	}

	/**
	 * @author chcastro
	 * @return the correo
	 */
	@XmlElement(nillable = true)
	public String getCorreo() {
		return correo;
	}

	/**
	 * @author chcastro
	 * @param correo the correo to set
	 */
	public void setCorreo(String correo) {
		this.correo = correo;
	}

	/**
	 * @author chcastro
	 * @return the estatusLogin
	 */
	@XmlElement(nillable = true)
	public Integer getEstatusLogin() {
		return estatusLogin;
	}

	/**
	 * @author chcastro
	 * @param estatusLogin the estatusLogin to set
	 */
	public void setEstatusLogin(Integer estatusLogin) {
		this.estatusLogin = estatusLogin;
	}
	
	/**
	 * @author chcastro
	 * @return the idRolInterno
	 */
	@XmlElement(nillable = true)
	public Integer getIdRolInterno() {
		return idRolInterno;
	}

	/**
	 * @author chcastro
	 * @param idRolInterno the idRolInterno to set
	 */
	public void setIdRolInterno(Integer idRolInterno) {
		this.idRolInterno = idRolInterno;
	}
	
	@XmlElement(nillable = true)
	public Map<String, String> getComponentes() {
		return componentes;
	}

	public void setComponentes(Map<String, String> componentes) {
		this.componentes = componentes;
	}
	
	@XmlElement(nillable = true)
	public String getVistaRedireccion() {
		return vistaRedireccion;
	}

	public void setVistaRedireccion(String vistaRedireccion) {
		this.vistaRedireccion = vistaRedireccion;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idUsuario == null) ? 0 : idUsuario.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserDetailsVo other = (UserDetailsVo) obj;
		if (idUsuario == null) {
			if (other.idUsuario != null)
				return false;
		} else if (!idUsuario.equals(other.idUsuario))
			return false;
		return true;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UserDetailsVo [idUsuario=" + idUsuario + ", numeroEmpleado=" + numeroEmpleado + ", nombre=" + nombre
				+ ", apellidoPaterno=" + apellidoPaterno + ", apellidoMaterno=" + apellidoMaterno + ", idTipoUsuario="
				+ idTipoUsuario + ", tipoUsuarioNombre=" + tipoUsuarioNombre + ", idEstatus=" + idEstatus
				+ ", estatusNombre=" + estatusNombre + ", idRol=" + idRol + ", rolNombre=" + rolNombre + ", correo="
				+ correo + ", estatusLogin=" + estatusLogin + ", idRolInterno=" + idRolInterno + ", componentes="
				+ componentes + ", vistaRedireccion=" + vistaRedireccion + "]";
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.mapper;

import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * 
 * <h1>MapperFactoryOVIT/h1>
 * <p>
 * Cass that provides objects for mapping beans of OVIT system
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 27/03/2015
 *
 */

@Component
@Qualifier("mapperFactoryOVIT")
@Scope("prototype")
public class MapperFactoryOVIT implements FactoryBean<MapperFactory>{
	@Override
	public MapperFactory getObject() throws Exception {
		return new DefaultMapperFactory.Builder().build();
	}

	@Override
	public Class<?> getObjectType() {
		return MapperFactory.class;
	}

	@Override
	public boolean isSingleton() {
		return true;
	}
}

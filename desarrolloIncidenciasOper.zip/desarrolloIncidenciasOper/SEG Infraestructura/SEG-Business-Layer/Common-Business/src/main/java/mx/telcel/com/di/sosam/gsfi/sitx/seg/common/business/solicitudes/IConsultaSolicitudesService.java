package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.solicitudes;

import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ConsultaSolicitudesDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SolicitudDto;

public interface IConsultaSolicitudesService {
	
	public ConsultaSolicitudesDTO getSolicitudes(Integer idUsuario,Integer tipoUsuario,Integer idRol);
	
	public void toExcel(XSSFWorkbook hssfWorkbook, List<SolicitudDto> userList);
	
}

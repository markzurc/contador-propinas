package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias;

import java.io.IOException;
import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.IncidenciaAdjunto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.IncidenciaBitacora;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaGestionDto;

/**
 * Service del Módulo de Incidencias.
 *
 * Flujo funcional:
 * - Concesionario crea incidencia interna.
 * - Mantenimiento la atiende / rechaza / finaliza.
 *
 * Persistencia:
 * - Incidencias y bitácora se persisten en BD (Oracle).
 * - IDs se generan en Java por MAX+1 (no hay secuencias).
 * - Evidencias PDF permanecen en mock de filesystem (por ahora).
 */
public interface IIncidenciaService {

    /**
     * UI helper: representa un archivo adjunto cargado desde PrimeFaces.
     */
    class AdjuntoUi {
        private String nombre;
        private long tamanio;
        private byte[] bytes;

        public AdjuntoUi(String nombre, long tamanio, byte[] bytes) {
            this.nombre = nombre;
            this.tamanio = tamanio;
            this.bytes = bytes;
        }

        public String getNombre() { return nombre; }
        public long getTamanio() { return tamanio; }
        public byte[] getBytes() { return bytes; }
    }

    List<?> listarSitiosSuscritosParaAltaIncidencia(String concesionarioUsuario);

    Long crearIncidencia(String sitioCodigo,
                         String tipo,
                         String descripcion,
                         List<AdjuntoUi> adjuntos,
                         String usuarioCreacion,
                         String correoUsuarioCreacion,
                         String concesionarioCreacion);

    void validarAlta(String sitioCodigo,
                     String tipo,
                     String descripcion,
                     List<AdjuntoUi> adjuntos);

    void avanzarIncidencia(Long idIncidencia,
                           String accion,
                           String comentario,
                           Long idUsuarioMovimiento);

    void validarAdjunto(String nombre, String contentType, long size);

    List<IncidenciaAdjunto> obtenerAdjuntosIncidencia(Long idIncidencia);

    List<?> listarSitiosEnOperacionVisibles();

    List<String> catalogoTiposIncidencia();

    long obtenerMaxBytesAdjunto();

    String generarFolioIncidencia(Long idIncidencia);

    int obtenerMaxArchivos();

    String obtenerRegexExtensiones();

    String obtenerFormatosHumanos();

    List<IncidenciaGestionDto> buscarIncidenciasMantenimiento(String folio,
                                                              String sitioId,
                                                              String estatus);

    List<IncidenciaGestionDto> buscarIncidenciasConcesionario(String folio,
                                                              String sitioId,
                                                              String estatus,
                                                              String concesionario);

    List<IncidenciaBitacora> obtenerBitacoraIncidencia(Long idIncidencia);

    void eliminarEvidenciaIncidencia(Long idIncidencia,
                                     String rutaRelativa,
                                     Long idUsuarioMovimiento) throws IOException;

    void adjuntarEvidenciaIncidencia(Long idIncidencia,
                                     AdjuntoUi adjunto,
                                     Long idUsuarioMovimiento) throws IOException;

    Long crearIncidenciaExternaCargaMasiva(String sitioCodigo,
                                          String tipo,
                                          String descripcion,
                                          String usuarioCreacion,
                                          String correoUsuarioCreacion,
                                          String concesionarioCreacion,
                                          String estatusInicial);

}

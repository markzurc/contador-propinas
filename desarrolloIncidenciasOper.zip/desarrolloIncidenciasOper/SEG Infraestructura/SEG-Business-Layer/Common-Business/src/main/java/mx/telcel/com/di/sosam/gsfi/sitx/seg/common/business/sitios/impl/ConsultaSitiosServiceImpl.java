package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.IConsultaSitiosService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.mapper.MapperCustomFactory;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.IConsultaSitiosDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.FiltroSitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ServicioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;

@Service("consultaSitiosServiceImpl")
@Scope("prototype")
public class ConsultaSitiosServiceImpl  extends MapperCustomFactory implements IConsultaSitiosService {
	
	@Autowired
	@Qualifier("consultaSitiosDao")
	private IConsultaSitiosDao consultaSitiosDao;

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<SitioDto> getListaSitios() {
		return consultaSitiosDao.getListaSitios();
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<FiltroSitioDto> getDatosFiltro() {
		return consultaSitiosDao.getDatosFiltro();
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<SitioDto> getListaSitiosFiltros(FiltroSitioDto filtro) {
		return consultaSitiosDao.getListaSitiosFiltros(filtro);
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<ServicioDto> getListaServicios() {
		return consultaSitiosDao.getListaServicios();
	}

}

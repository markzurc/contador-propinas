package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.impl;

import static ch.lambdaj.Lambda.having;
import static ch.lambdaj.Lambda.on;
import static ch.lambdaj.Lambda.select;
import static ch.lambdaj.Lambda.sort;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.error.ErrorSEGWeb;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.impl.SendMailBusinessImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.OVITUtils;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.mapper.MapperCustomFactory;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcPara;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.utils.configuration.dao.IConfigurationUtilsDao;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hamcrest.Matchers;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * 
 * <h1>ConfigurationUtilsBusinessImpl</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 17/04/2015
 *
 */
@Service("configurationtUtilsBusiness")
@Scope("prototype")
public class ConfigurationUtilsBusinessImpl extends MapperCustomFactory
		implements IConfigurationUtilsBusiness {

	private List<ConfigurationUtilsVo> lstConfigUtilsVo;

	@Autowired
	@Qualifier("configurationtUtilsDao")
	private IConfigurationUtilsDao configurationUtilsDao;

	private static final Logger logger = LogManager.getLogger(ConfigurationUtilsBusinessImpl.class);
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public void getConstantOfDataBase() throws TransactionalOVITException {
		logger.info("Ejecutando ConfigurationUtilsBusinessImpl.getConstantOfDataBase");
		try {
			List<T7segcPara> lstTsegcConfiguracions = configurationUtilsDao
					.getConstantOfDataBase();
			if (OVITUtils.isEmptyList(lstTsegcConfiguracions)) {
				logger.info("La consulta no regreso resultados.");
			}
			lstConfigUtilsVo = getMapper().mapAsList(lstTsegcConfiguracions, ConfigurationUtilsVo.class);
		} catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: "
					.concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ")
					.concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar ConfigurationUtilsBusinessImpl.getConstantOfDataBase: " + e );
			throw new TransactionalOVITException(
					ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),
					ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public ConfigurationUtilsVo getConstantOfDataBase(String identificador, String nombreParametro) throws TransactionalOVITException {
		if(OVITUtils.isEmptyList(lstConfigUtilsVo)){
			getConstantOfDataBase();
		}
		List<ConfigurationUtilsVo> tempList = select(lstConfigUtilsVo, having(
				on(ConfigurationUtilsVo.class).getIdentificador(),
				Matchers.equalTo(identificador)).and(having(on(ConfigurationUtilsVo.class).getNombreParametro(),
						Matchers.equalTo(nombreParametro))));
		
		if(OVITUtils.isEmptyList(tempList)){
			return null;
		}
		return tempList.get(0);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public ConfigurationUtilsVo getConstantOfDataBase(Enum<?> identificador)
			throws TransactionalOVITException {
		return getConstantOfDataBase(identificador.getClass().getSimpleName(), identificador.name());
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public List<ConfigurationUtilsVo> getListConstantOfDataBase(
			String identificador) throws TransactionalOVITException {
		if(OVITUtils.isEmptyList(lstConfigUtilsVo)){
			getConstantOfDataBase();
		}
		List<ConfigurationUtilsVo> tempList = select(lstConfigUtilsVo, having(
				on(ConfigurationUtilsVo.class).getIdentificador(),
				Matchers.equalTo(identificador)));
		
		if(OVITUtils.isEmptyList(tempList)){
			return null;
		}
		
		tempList = sort(tempList, on(ConfigurationUtilsVo.class).getIdParametro());
		
		return tempList;
	}

	/**
	 * Obtain the complete list of the parameters
	 * @author chcastro
	 * @return {@link List}<{@link ConfigurationUtilsVo}> the lstConfigUtilsVo
	 * @throws TransactionalOVITException 
	 */
	public List<ConfigurationUtilsVo> getLstConfigUtilsVo() throws TransactionalOVITException {
		if(OVITUtils.isEmptyList(lstConfigUtilsVo)){
			getConstantOfDataBase();
		}
		return lstConfigUtilsVo;
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public void updateConfiguration(ConfigurationUtilsVo configurationUtilsVo) throws TransactionalOVITException{
		logger.info("ConfigurationUtilsBusinessImpl.updateConfiguration");
		Set<ConstraintViolation<ConfigurationUtilsVo>> configUtilViolations = getValidator().validate(configurationUtilsVo);
		if(!OVITUtils.isEmptyList(configUtilViolations)){
			for(ConstraintViolation<ConfigurationUtilsVo> tempViolation : configUtilViolations){
				logger.error("Error al validar UserVO: ".concat(tempViolation.getMessage()));
			}
			throw new TransactionalOVITException(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError(),
					ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError());
		}
		try{
			T7segcPara configuracion = getMapper().map(configurationUtilsVo, T7segcPara.class);
			configurationUtilsDao.updateConfiguration(configuracion);
		}catch(Exception e){
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError()));
			logger.error("Error al ejecutar ConfigurationUtilsBusinessImpl.updateConfiguration: " + e );
			throw new TransactionalOVITException(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError(),
					ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError());
		}
	}

	@Override
	public Session getSession() {
		return configurationUtilsDao.getSession();
	}

	@Override
	public void setSession(Session session) {
		configurationUtilsDao.setSession(session);
	}

}

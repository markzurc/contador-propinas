package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.visitaTecnica.impl;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.impl.SendMailBusinessImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.visitaTecnica.IVisitaTecnicaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegcHerrVistTecn;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegcPersVistTecn;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegdSoliArch;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3segoVisiTecnSoli;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SoliArchDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.visitaTecnica.dao.IVisitaTecnicaDao;

@Service
public class VisitaTecnicaServiceImpl implements IVisitaTecnicaService {

	private static final Logger LOGGER = LogManager.getLogger(SendMailBusinessImpl.class);
	
	@Autowired
	private IVisitaTecnicaDao visitaDao;

	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public boolean solicitarVisitaTecnica(T3segoVisiTecnSoli visitaTecnica,String transicion,
			List<T3SegcPersVistTecn> listPersonal,
			List<T3SegcHerrVistTecn> listHerramientas,
			List<T3SegdSoliArch> archivosAdjuntos,
			Integer accion,
			List<T3SegcPersVistTecn> listPersonalVisitaEliminado,
			List<T3SegcHerrVistTecn> listHerramientaVisitaEliminado,
			List<SoliArchDto> listArchivosEliminados
			)  {
		try {
			visitaDao.actualizarSolicitud(visitaTecnica.getIdFolio(), transicion);
			visitaDao.guardarVisitaTecnica(visitaTecnica);
			guardarPersonal(listPersonal);
			guardarHerramientas(listHerramientas);
			guardarArchivos(archivosAdjuntos);

			if(accion.equals(ConfigOvitIdentifierEnum.TipoAccionVisitaTecnica.CORRECCION.getTipoAccion())) {
				eliminarPersonal(listPersonalVisitaEliminado);
				eliminarHerramientas(listHerramientaVisitaEliminado);
				eliminarAlchivo(listArchivosEliminados);
			}
			return true;
		} catch (Exception e) {
			LOGGER.error("Error al guardarVisitaTecnica  " + e.getMessage());
			return false;
		}	
	}

	public void guardarPersonal(List<T3SegcPersVistTecn> listPersonal) {
		for(T3SegcPersVistTecn p:listPersonal) {
			visitaDao.guardarPersonal(p);
		}
	}

	public void guardarHerramientas(List<T3SegcHerrVistTecn> listHerramientas) {
		for(T3SegcHerrVistTecn h:listHerramientas) {
			visitaDao.guardarHerramienta(h);
		}
	}
	public void guardarArchivos(List<T3SegdSoliArch> archivos) {
		for(T3SegdSoliArch archivo:archivos) {
			visitaDao.guardarArchivo(archivo);
		}
	}

	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public List<T3SegcPersVistTecn> getPersonal(String folioSolicitud,String grupoOperador) {
		return visitaDao.getPersonal(folioSolicitud, grupoOperador);
	}



	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)

	public List<T3SegcHerrVistTecn> getHerramientas(String folioSolicitud, String grupoOperador) {
		return visitaDao.getHerramientas(folioSolicitud, grupoOperador);
	}



	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public List<SoliArchDto> getArchivos(String folioSolicitud, Integer idSeccion, String descripcion) {
		return visitaDao.getArchivos(folioSolicitud, idSeccion, descripcion);
	}

	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public T3segoVisiTecnSoli getSolicitudVisita(String folioSolicitud) {
		return visitaDao.getSolicitudVisita(folioSolicitud);
	}


	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public boolean avanzarSolicitudVisita(T3segoVisiTecnSoli solicitudVisita,String transicion,Integer idUsuario) {
		try {
			solicitudVisita.setUsuarioModificacion(idUsuario);
			solicitudVisita.setFechaModificacion(new Date());
			visitaDao.guardarVisitaTecnica(solicitudVisita);
			visitaDao.actualizarSolicitud(solicitudVisita.getIdFolio(), transicion);
			return true;
		} catch (Exception e) {
			LOGGER.error("Error al guardarVisitaTecnica  " + e.getMessage());
			return false;
		}	

	}

	

	public void eliminarPersonal(List<T3SegcPersVistTecn> listPersonal) {
		for(T3SegcPersVistTecn p:listPersonal) {
			visitaDao.eliminarPersonal(p);
		}
	}

	public void eliminarHerramientas(List<T3SegcHerrVistTecn> listHerramientas) {
		for(T3SegcHerrVistTecn h:listHerramientas) {
			visitaDao.eliminarHerramienta(h);
			
		}
	}
	
	public void eliminarAlchivo(List<SoliArchDto> listachivosEliminado) {
		for(SoliArchDto a:listachivosEliminado) {
			visitaDao.eliminarArchivo(a.getIdArchivo());
		}
	}

	@Override
	public boolean guardarArchivo(T3SegdSoliArch archivo) {
		try {
			
		visitaDao.guardarArchivo(archivo);
		return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public List<String> getTipoHerramientas() {
		return visitaDao.getTipoHerramientas();
	}
	
	
}

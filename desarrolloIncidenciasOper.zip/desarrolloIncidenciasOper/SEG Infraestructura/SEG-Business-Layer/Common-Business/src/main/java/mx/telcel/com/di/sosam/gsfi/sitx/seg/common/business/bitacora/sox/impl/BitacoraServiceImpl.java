package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.impl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.IBitacoraService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dao.IBitacoraDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dto.BitacoraDto;

@Service("bitacoraServiceImpl")
@Scope("prototype")
public class BitacoraServiceImpl implements IBitacoraService{
	
	@Autowired
	@Qualifier("bitacoraDao")
	private IBitacoraDao bitacoraDao;

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public boolean insertaBitacora(BitacoraDto bitacoraDto) {
		return bitacoraDao.insertaBitacora(bitacoraDto);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<BitacoraDto> obtenerAcciones(String idSoli) {
		return bitacoraDao.obtenerAcciones(idSoli);
	}

}

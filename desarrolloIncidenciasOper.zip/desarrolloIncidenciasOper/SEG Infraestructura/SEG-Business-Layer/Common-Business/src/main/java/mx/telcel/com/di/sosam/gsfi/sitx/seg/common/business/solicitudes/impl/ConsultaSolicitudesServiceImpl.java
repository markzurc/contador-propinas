package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.solicitudes.impl;
import java.util.List;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
 
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.solicitudes.IConsultaSolicitudesService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum.TipoUsuarioSoliitud;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ConsultaSolicitudesDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SolicitudDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dao.IConsultaSolicitudesDao;
@Service
public class ConsultaSolicitudesServiceImpl implements IConsultaSolicitudesService {

	@Autowired
	private  IConsultaSolicitudesDao iConsultaSolicitudesDao;
	
	private int index=0;
	public static final int INDEX0=0;
	public static final int INDEX1=1;
	public static final int INDEX2=2;
	public static final int INDEX3=3;
	public static final int INDEX4=4;
	public static final int INDEX5=5;
	public static final int INDEX6=6;
	public static final int INDEX7=7;
	public static final int INDEX8=8;
	public static final int INDEX9=9;
	public static final int INDEX10=10;
	public static final int INDEX11=11;
	public static final String FONT_EXCELL="Century Gothic";
	public static final short FONT_SIZE=10;
	public static final short FONT_SIZE_8=8;
	static XSSFColor level1 =new XSSFColor(new java.awt.Color(15,36,62));
    static XSSFColor level2 =new XSSFColor(new java.awt.Color(33,89,103));
    static XSSFColor level3 =new XSSFColor(new java.awt.Color(49,134,155));
    static XSSFColor level4 =new XSSFColor(new java.awt.Color(146,205,220));
    static XSSFColor level5 =new XSSFColor(new java.awt.Color(255,255,255));
    
    XSSFCellStyle styleDerecho = null;
	
	public static final Map<Integer,XSSFColor> STYLE_LEVELS= new HashMap<Integer,XSSFColor>();
	static{
		STYLE_LEVELS.put(INDEX1,level1);
		STYLE_LEVELS.put(INDEX2,level2);
		STYLE_LEVELS.put(INDEX3,level3);
		STYLE_LEVELS.put(INDEX4,level4);
		STYLE_LEVELS.put(INDEX0,level5);
	}
	
	private static String[] columNamesUser={"Folio","ID Sitio","Nombre Sitio","Concesionario","Pendiente por","Estatus","Usuario Creaci�n", "Fecha Creaci�n"};	
	
	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public ConsultaSolicitudesDTO getSolicitudes(Integer idUsuario, Integer tipoUsuario, Integer idRol) {
	    ConsultaSolicitudesDTO consulta = new ConsultaSolicitudesDTO();

	    // Caso 1: Usuario interno - obtiene todas las solicitudes
	    if (TipoUsuarioSoliitud.INTERNO.getTipoUsuario().equals(tipoUsuario)) {
	        consulta.setListSolicitudes(iConsultaSolicitudesDao.getListaSolicitudes(null, idRol));
	        return consulta;
	    }

	    // Caso 2: Usuario externo - validar si el rol pertenece a un grupo de operadores
	    Boolean perteneceAGrupoOperador = iConsultaSolicitudesDao.getValidarOperador(idRol);
	    if (perteneceAGrupoOperador == null) {
	        consulta.setMensajeError("El rol del usuario no se encuentra en ning�n grupo.");
	        return consulta;
	    }

	    if (perteneceAGrupoOperador) {
	        Integer operadorUsuario = iConsultaSolicitudesDao.getOperadorUsuario(idUsuario);
	        if (operadorUsuario == null) {
	            consulta.setMensajeError("No se encontr� el grupo operador del usuario.");
	            return consulta;
	        }
	        consulta.setListSolicitudes(iConsultaSolicitudesDao.getListaSolicitudes(operadorUsuario, idRol));
	    } else {
	        consulta.setListSolicitudes(iConsultaSolicitudesDao.getListaSolicitudes(null, idRol));
	    }

	    return consulta;
	}

	@Override
	public void toExcel(XSSFWorkbook hssfWorkbook, List<SolicitudDto> userList) {
		XSSFSheet sheet = hssfWorkbook.createSheet("Reporte Gesti�n de Solicitudes");
		sheet.setDisplayGridlines(false);
		sheet.setPrintGridlines(false);
		XSSFCellStyle headerStyle = getLevelStyle(hssfWorkbook, INDEX1);
		headerStyle.setAlignment(HorizontalAlignment.CENTER);
		
		XSSFCellStyle campoStyle = getLevelStyle(hssfWorkbook, INDEX5);
		campoStyle.setBorderBottom(CellStyle.BORDER_THIN);
		campoStyle.setBorderLeft(CellStyle.BORDER_THIN);
		campoStyle.setBorderRight(CellStyle.BORDER_THIN);
		campoStyle.setBorderTop(CellStyle.BORDER_THIN);
		
		//Estilo para el borde derecho
		styleDerecho = getLevelStyle(hssfWorkbook,INDEX2);
		styleDerecho.setBorderRight(CellStyle.BORDER_THIN);
		styleDerecho.setRightBorderColor(IndexedColors.BLACK.getIndex());
		styleDerecho.setBorderTop(CellStyle.BORDER_THIN);
		styleDerecho.setTopBorderColor(IndexedColors.WHITE.getIndex());
		
		XSSFCellStyle fechaHoraStyle = getLevelStyle(hssfWorkbook, INDEX5);
		fechaHoraStyle.setBorderBottom(CellStyle.BORDER_THIN);
		fechaHoraStyle.setBorderLeft(CellStyle.BORDER_THIN);
		fechaHoraStyle.setBorderRight(CellStyle.BORDER_THIN);
		fechaHoraStyle.setBorderTop(CellStyle.BORDER_THIN);
		DataFormat fechaFormat = hssfWorkbook.createDataFormat();
		fechaHoraStyle.setDataFormat(fechaFormat.getFormat("dd/MM/yyyy HH:mm:ss AM/PM")); // Formato: 23/06/2025
																							// 14:30:00
		// APPs
		insertaCell(sheet, INDEX0, INDEX0, "Reporte Gesti�n de Solicitudes", headerStyle);
		sheet.addMergedRegion(new CellRangeAddress(INDEX0, INDEX0, 0, 7));

		index = 1;
		addColumnsNames(sheet, index++, getLevelStyle(hssfWorkbook, INDEX2), columNamesUser);
		for (SolicitudDto reportUserVo : userList) {
			insertaCell(sheet, index, INDEX0, formatFolio(reportUserVo.getFolio()), campoStyle);
			insertaCell(sheet, index, INDEX1, reportUserVo.getSitio(), campoStyle);
			insertaCell(sheet, index, INDEX2, reportUserVo.getNombre(), campoStyle);
			insertaCell(sheet, index, INDEX3, reportUserVo.getConcesionario(), campoStyle);
			insertaCell(sheet, index, INDEX4, reportUserVo.getPendiente(), campoStyle);
			insertaCell(sheet, index, INDEX5, reportUserVo.getEstatus(), campoStyle);
			insertaCell(sheet, index, INDEX6, reportUserVo.getSolicitante(), campoStyle);
			insertaCell(sheet, index, INDEX7, formatFecha(reportUserVo.getFechaSol()), fechaHoraStyle);
			index++;
		}
		
		ajustarTodasColumnas(sheet, 8, index);
	}

	// common
	private void insertaCell(XSSFSheet sheet, int rowIndex, int column, String value, XSSFCellStyle style) {
		XSSFRow commonRow = sheet.getRow(rowIndex);
		if (commonRow == null) {
			commonRow = sheet.createRow(rowIndex);
		}
 
		XSSFCell nombre = commonRow.createCell(column);
		nombre.setCellValue(value);
		sheet.autoSizeColumn(column);
		nombre.setCellStyle(style);

	}

	// common
	private void addColumnsNames(XSSFSheet sheet, int position, XSSFCellStyle style, String[] titles) {
		int column = INDEX0;
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setRightBorderColor(IndexedColors.WHITE.getIndex());
		style.setBorderTop(CellStyle.BORDER_THIN);
		style.setTopBorderColor(IndexedColors.WHITE.getIndex());
		for (String titleColumn : titles) {
			if (column == 7) {
				insertaCell(sheet, position, column, titleColumn, styleDerecho);
			}else {
				insertaCell(sheet, position, column, titleColumn, style);
			}
			column += 1;
						
		}

	}

	public String formatFolio(String folio){
		return "SI-"+String.format("%06d", Integer.parseInt(folio));
	}
	
	public String formatFecha(String fecha){
		String[] fechaformat=fecha.split("\\-");
		return fechaformat[1];
	}

	public static XSSFCellStyle getLevelStyle(XSSFWorkbook hssfWorkbook,int level){
		XSSFCellStyle style = hssfWorkbook.createCellStyle();
		XSSFFont fontH = hssfWorkbook.createFont();
		fontH.setFontName(FONT_EXCELL); 
		fontH.setFontHeightInPoints(FONT_SIZE);
		if(STYLE_LEVELS.containsKey(level)){
			style.setFillForegroundColor(STYLE_LEVELS.get(level));
			fontH.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			fontH.setColor(IndexedColors.WHITE.getIndex());
		}else{
			style.setFillForegroundColor(STYLE_LEVELS.get(INDEX0));
			fontH.setColor(IndexedColors.BLACK.getIndex());
		}
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style.setFont(fontH);
 
		return style;
	}
	
	private void ajustarTodasColumnas(XSSFSheet sheet, int numColumnas, int numFilas) {
	    for (int col = 0; col < numColumnas; col++) {
	        int anchoMax = 0;
	        String textoMayus = "";
	        for (int fila = 1; fila < numFilas; fila++) {
	            XSSFRow row = sheet.getRow(fila);
	            if (row != null) {
	                XSSFCell cell = row.getCell(col);
	                if (cell != null && !cell.getStringCellValue().isEmpty()) {	                    
	                	String texto = cell.getStringCellValue();
	                	if (texto.length() > anchoMax) {
	                		anchoMax  = texto.length();	
	                		textoMayus = texto;
						}
	                }
	            }
	        }
	        if (textoMayus.matches("^[A-Z\\s]+$")) {
	        	sheet.setColumnWidth(col, (anchoMax + 3) * 300);
				
			}else {
				sheet.setColumnWidth(col, (anchoMax + 3) * 256);
			}
	    }
	}
}

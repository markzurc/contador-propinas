package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.elementosPantalla.impl;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.elementosPantalla.IElementosPantallaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dao.IElementosPantallaDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ConfiguracionElementoEditableDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ElementosPantallaDTO;

@Service
public class ElementosPantallaServiceImpl  implements IElementosPantallaService{

	 @Autowired
	 private IElementosPantallaDao elementosPantallaDao;
	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public List<ElementosPantallaDTO> getElementosPermitidosPantalla(String flujo,
	        Integer idRolUsuario, Map<String, Integer> valoresAvalidar) {
		try {
	    List<ElementosPantallaDTO> listaElementos = elementosPantallaDao.getElementosPantalla(flujo, idRolUsuario);
	    if(valoresAvalidar==null) {
	    	return new ArrayList<ElementosPantallaDTO>();
	    }
	    for (ElementosPantallaDTO elementoPantalla : listaElementos) {
	        // Solo procesamos elementos visibles
	        if (elementoPantalla.isVisible()) {
	            // Obtener las configuraciones de validaci�n para el elemento
	            List<ConfiguracionElementoEditableDTO> listValidacionEdicion = 
	                elementosPantallaDao.getConfiguracionEditableElemento(elementoPantalla.getIdElementoPantalla());

	            // Verificamos que haya configuraciones de validaci�n disponibles
	            if (listValidacionEdicion != null && !listValidacionEdicion.isEmpty()) {
	                boolean esEditable = true;  // es editable hasta que se demuestre lo contrario

	                // Iteramos sobre cada configuraci�n de validaci�n
	                for (ConfiguracionElementoEditableDTO config : listValidacionEdicion) {
	                    // Verificar si la validaci�n tiene un campo correspondiente en los valores a validar
	                    if (valoresAvalidar.containsKey(config.getNombreCampo())) {
	                        Integer campoValidar = valoresAvalidar.get(config.getNombreCampo());

	                        // Comprobar si el campo pasa la validaci�n de acuerdo al tipo de validaci�n
	                        boolean permiteEdicion = esElementoEditable(config.getIdTipoValidacion(), 
	                                config.getValoresEsperado(), campoValidar);

	                        // Si alguna validaci�n falla, el elemento no es editable
	                        if (!permiteEdicion) {
	                            esEditable = false;
	                            break; 
	                        }
	                    }
	                }
	                elementoPantalla.setEditable(esEditable);
	            }else {
	                elementoPantalla.setEditable(true);//si es visible y no hay configuracion de edicion por default sera editable
	 	            	
	            }
	        }
	    }

	    return listaElementos;
		 } catch (Exception e) {
		       return new ArrayList<ElementosPantallaDTO>();
		  }
	}

	
	public boolean esElementoEditable(Integer tipoValidacion,String valoresEsperados,Integer campoValidar) {
		try {
			
			List<String> listValue = new ArrayList<String>(Arrays.asList(valoresEsperados.split(",")));
			List<Integer> valoresEsperadosList = new ArrayList<Integer>();
			for (String s : listValue) {
				valoresEsperadosList.add(Integer.parseInt(s));
			}
			 // Realizamos la validaci�n seg�n el tipo de validaci�n
	        switch (tipoValidacion) {
	            case 1: // IN: El campo debe estar en los valores esperados
	                return valoresEsperadosList.contains(campoValidar);
	                
	            case 2: // Mayor o igual
	                return !valoresEsperadosList.isEmpty() && campoValidar >= valoresEsperadosList.get(0);

	            case 3: // Menor o igual
	                return !valoresEsperadosList.isEmpty() && campoValidar <=valoresEsperadosList.get(0) ;
 
	            default:
	                return false;  // Para tipos de validaci�n no definidos, retornamos false
	        }
	    } catch (Exception e) {
	        return false;
	    }
	}

}

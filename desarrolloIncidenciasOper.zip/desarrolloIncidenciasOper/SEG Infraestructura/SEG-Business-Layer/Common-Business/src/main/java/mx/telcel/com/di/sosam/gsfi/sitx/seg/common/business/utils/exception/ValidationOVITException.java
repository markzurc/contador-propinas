package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.exception;

public class ValidationOVITException extends Exception {

	private static final long serialVersionUID = 1848601303912063645L;
	
	private String messageError;
	private String codeMessage;
	
	
	/**
	 * Constructor.
	 * 
	 * @param messageError
	 * @param codeMessage
	 */
	public ValidationOVITException(String codeMessage, String messageError) {
		super();
		this.messageError = messageError;
		this.codeMessage = codeMessage;
	}
	
	/**
	 * @return the messageError
	 */
	public String getMessageError() {
		return messageError;
	}
	/**
	 * @param messageError the messageError to set
	 */
	public void setMessageError(String messageError) {
		this.messageError = messageError;
	}
	/**
	 * @return the codeMessage
	 */
	public String getCodeMessage() {
		return codeMessage;
	}
	/**
	 * @param codeMessage the codeMessage to set
	 */
	public void setCodeMessage(String codeMessage) {
		this.codeMessage = codeMessage;
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.proyecto.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.proyecto.IProyectoPresupuestoService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegdSoliArch;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.proyecto.dao.IProyectoPresupuestoDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.proyecto.dto.ProyectoPresupuestoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.proyecto.dto.TipoSolicitudDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SoliArchDto;

@Service
public class ProyectoPresupuestoServiceImpl implements IProyectoPresupuestoService {
	
	@Autowired
	@Qualifier("proyectoPresupuestoDao")
	private IProyectoPresupuestoDao proyectoDao;
	
	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public List<SoliArchDto> getArchivos(String folioSolicitud, String tipoArchivo) {
		return proyectoDao.getArchivos(folioSolicitud, tipoArchivo);
	}

	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public boolean crearProyectoPresupuesto(ProyectoPresupuestoDto proyecto) {
		return proyectoDao.crearProyectoPresupuesto(proyecto);
	}

	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public boolean updateEstadoSolicitud(String folio, String estatus) {
		return proyectoDao.updateEstadoSolicitud(folio, estatus);
	}	
	
	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public boolean guardarArchivo(T3SegdSoliArch archivo) {
		return proyectoDao.guardarArchivo(archivo);
	}

	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public List<ProyectoPresupuestoDto> getDatosProyectoPorFolio(String folio) {
		return proyectoDao.getDatosProyectoPorFolio(folio);
	}

	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public boolean atenderProyectoPresupuesto(ProyectoPresupuestoDto proyecto) {
		return proyectoDao.atenderProyectoPresupuesto(proyecto);
	}

	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public boolean rechazarProyectoPresupuesto(ProyectoPresupuestoDto proyecto) {
		return proyectoDao.rechazarProyectoPresupuesto(proyecto);
	}

	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public boolean corregirProyectoPresupuesto(ProyectoPresupuestoDto proyecto) {
		return proyectoDao.corregirProyectoPresupuesto(proyecto);
	}

	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public boolean eliminarArchivo(SoliArchDto archivo) {
		return proyectoDao.eliminarArchivo(archivo);
	}

	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public List<TipoSolicitudDto> getDatosTipoSolicitud() {
		return proyectoDao.getDatosTipoSolicitud();
	}

	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public boolean solicitarAdecuacionRecuperacion(ProyectoPresupuestoDto proyecto) {
		return proyectoDao.solicitarAdecuacionRecuperacion(proyecto);
	}

	@Override
	@Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRED)
	public String consultaIdEstadoBitacora(String estatus) {
		return proyectoDao.consultaIdEstadoBitacora(estatus);
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils;

import java.util.List;
import java.util.Set;

/**
 * 
 * <h1>OVITUtils</h1>
 * <p>
 * Class that contains methods that run utilities used by the system OVIT
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 27/03/2015
 *
 */

public class OVITUtils {

	/**
	 * Method that validates that the list is empty, 
	 * if the list is null returns true if its size is 0 returns true, 
	 * otherwise return false
	 * 
	 * @param list {@link List}
	 * @return true/false
	 */
	public static boolean isEmptyList(List<?> list) {
		if (list == null)
			return true;
		if (list.size() <= 0)
			return true;
		return false;
	}
	
	/**
	 * Method that validates that the Set is empty, 
	 * if the Set is null returns true if its size is 0 returns true, 
	 * otherwise return false
	 * 
	 * @param set {@link Set}
	 * @return true/false
	 */
	public static boolean isEmptyList(Set<?> set) {
		if (set == null)
			return true;
		if (set.size() <= 0)
			return true;
		return false;
	}

	/**
	 *Method that validates that the string is not empty, 
	 *if the string is null returns true, if it is equal to "" returns true, 
	 *otherwise returns false
	 * 
	 * @param str {@link String} 
	 * @return true/false
	 */
	public static boolean isEmptyString(String str) {
		if (str == null)
			return true;
		if (str.equals(""))
			return true;
		return false;
	}

	public static String returnMesByInt(int mes) {
		switch (mes) {
		case 1:
			return "Enero";
		case 2:
			return "Febrero";
		case 3:
			return "Marzo";
		case 4:
			return "Abril";
		case 5:
			return "Mayo";
		case 6:
			return "Junio";
		case 7:
			return "Julio";
		case 8:
			return "Agosto";
		case 9:
			return "Septiembre";
		case 10:
			return "Octubre";
		case 11:
			return "Noviembre";
		case 12:
			return "Diciembre";
		default:
			return null;
		}
	}
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * 
 * <h1>ConfigurationUtilsVo</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 17/04/2015
 *
 */
@XmlRootElement
public class ConfigurationUtilsVo implements Serializable{

	private static final long serialVersionUID = 7272320923835179846L;
	
	private Integer idParametro;
	private String nombreParametro;
	private String identificador;
	private String descripcion;
	private String valor;
	private Integer activo;
	private Integer editable;
	private Integer idTipo;
	private String descripcionDetalle;
	
	public ConfigurationUtilsVo() {
	}
	
	/**
	 * @param idParametro
	 * @param nombreParametro
	 * @param identificador
	 * @param descripcion
	 * @param valor
	 * @param activo
	 * @param editable
	 * @param idTipo
	 * @param descripcionDetalle
	 */
	public ConfigurationUtilsVo(Integer idParametro, String nombreParametro,
			String identificador, String descripcion, String valor,
			Integer activo, Integer editable, Integer idTipo,
			String descripcionDetalle) {
		super();
		this.idParametro = idParametro;
		this.nombreParametro = nombreParametro;
		this.identificador = identificador;
		this.descripcion = descripcion;
		this.valor = valor;
		this.activo = activo;
		this.editable = editable;
		this.idTipo = idTipo;
		this.descripcionDetalle = descripcionDetalle;
	}



	/**
	 * @return the idParametro
	 */
	@NotNull
	@XmlElement(nillable = true)
	public Integer getIdParametro() {
		return idParametro;
	}
	/**
	 * @param idParametro the idParametro to set
	 */
	public void setIdParametro(Integer idParametro) {
		this.idParametro = idParametro;
	}
	/**
	 * @return the nombreParametro
	 */
	@NotNull
	@NotEmpty
	@XmlElement(nillable = true)
	public String getNombreParametro() {
		return nombreParametro;
	}
	/**
	 * @param nombreParametro the nombreParametro to set
	 */
	public void setNombreParametro(String nombreParametro) {
		this.nombreParametro = nombreParametro;
	}
	/**
	 * @return the identificador
	 */
	@NotNull
	@NotEmpty
	@XmlElement(nillable = true)
	public String getIdentificador() {
		return identificador;
	}
	/**
	 * @param identificador the identificador to set
	 */
	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}
	/**
	 * @return the descripcion
	 */
	@XmlElement(nillable = true)
	public String getDescripcion() {
		return descripcion;
	}
	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	/**
	 * @return the valor
	 */
	@NotNull
	@NotEmpty
	@XmlElement(nillable = true)
	public String getValor() {
		return valor;
	}
	/**
	 * @param valor the valor to set
	 */
	public void setValor(String valor) {
		this.valor = valor;
	}
	/**
	 * @return the activo
	 */
	@NotNull
	@XmlElement(nillable = true)
	public Integer getActivo() {
		return activo;
	}
	/**
	 * @param activo the activo to set
	 */
	public void setActivo(Integer activo) {
		this.activo = activo;
	}
	/**
	 * @return the editable
	 */
	@NotNull
	@XmlElement(nillable = true)
	public Integer getEditable() {
		return editable;
	}
	/**
	 * @param editable the editable to set
	 */
	public void setEditable(Integer editable) {
		this.editable = editable;
	}

	/**
	 * @return the idTipo
	 */
	@NotNull
	@XmlElement(nillable = true)
	public Integer getIdTipo() {
		return idTipo;
	}

	/**
	 * @param idTipo the idTipo to set
	 */
	public void setIdTipo(Integer idTipo) {
		this.idTipo = idTipo;
	}

	/**
	 * @return the descripcionDetalle
	 */
	@XmlElement(nillable = true)
	public String getDescripcionDetalle() {
		return descripcionDetalle;
	}

	/**
	 * @param descripcionDetalle the descripcionDetalle to set
	 */
	public void setDescripcionDetalle(String descripcionDetalle) {
		this.descripcionDetalle = descripcionDetalle;
	}
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.mapper;

import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

/**
 * 
 * <h1>MapperCustomFactory</h1>
 * <p>
 * Provides the object class to map bean
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 27/03/2015
 *
 */

public class MapperCustomFactory {
	private MapperFactory mapperFactory;
	private MapperFacade mapperFacade;
	private Validator validator;
	/**
	 * Provides the object class to map bean.
	 * 
	 * @param mapperFactory
	 */
	@Autowired
	@Qualifier("mapperFactoryOVIT")
    public void setMapperFactory(MapperFactory mapperFactory) {
        this.mapperFactory = mapperFactory;
    }

	/**
	 * Provides the object class to map bean
	 * @return the mapper
	 */
	public MapperFacade getMapper() {
		if(mapperFacade == null){
			mapperFacade = mapperFactory.getMapperFacade();
		}
		return  mapperFacade;
	}
	
	/**
	 * Provides the object class to validate bean
	 * @return
	 */
	public Validator getValidator() {
		if(validator == null){
			ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
			validator = factory.getValidator();
		}
		return validator;
	}
	

}

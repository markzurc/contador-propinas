package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * <h1>MessageVo</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 13/05/2015
 */
@XmlRootElement
public class MessageVo implements Serializable {

	private static final long serialVersionUID = 4952692366745166603L;
	
	private Integer idCorreo;
	private String nombreCorreo;
	private String valor;
	private String asunto;
	
	public MessageVo() {
	}

	/**
	 * @author chcastro
	 * @param idCorreo
	 * @param nombreCorreo
	 * @param valor
	 * @param asunto
	 */
	public MessageVo(Integer idCorreo, String nombreCorreo, String valor,
			String asunto) {
		super();
		this.idCorreo = idCorreo;
		this.nombreCorreo = nombreCorreo;
		this.valor = valor;
		this.asunto = asunto;
	}

	/**
	 * @author chcastro
	 * @return the idCorreo
	 */
	@XmlElement(nillable = true)
	public Integer getIdCorreo() {
		return idCorreo;
	}

	/**
	 * @author chcastro
	 * @param idCorreo the idCorreo to set
	 */
	public void setIdCorreo(Integer idCorreo) {
		this.idCorreo = idCorreo;
	}

	/**
	 * @author chcastro
	 * @return the nombreCorreo
	 */
	@XmlElement(nillable = true)
	public String getNombreCorreo() {
		return nombreCorreo;
	}

	/**
	 * @author chcastro
	 * @param nombreCorreo the nombreCorreo to set
	 */
	public void setNombreCorreo(String nombreCorreo) {
		this.nombreCorreo = nombreCorreo;
	}

	/**
	 * @author chcastro
	 * @return the valor
	 */
	@XmlElement(nillable = true)
	public String getValor() {
		return valor;
	}

	/**
	 * @author chcastro
	 * @param valor the valor to set
	 */
	public void setValor(String valor) {
		this.valor = valor;
	}

	/**
	 * @author chcastro
	 * @return the asunto
	 */
	@XmlElement(nillable = true)
	public String getAsunto() {
		return asunto;
	}

	/**
	 * @author chcastro
	 * @param asunto the asunto to set
	 */
	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}
	
}

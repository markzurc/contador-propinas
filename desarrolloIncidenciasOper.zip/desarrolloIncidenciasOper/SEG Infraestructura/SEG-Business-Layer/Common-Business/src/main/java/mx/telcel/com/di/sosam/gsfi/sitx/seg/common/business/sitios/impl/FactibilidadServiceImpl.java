package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.IConsultaSitiosService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.IFactibilidadService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.mapper.MapperCustomFactory;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.IConsultaSitiosDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.IFactibilidadDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.AntenaDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.FactibilidadDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.FiltroSitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ServicioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;

@Service("factibilidadServiceImpl")
@Scope("prototype")
public class FactibilidadServiceImpl  extends MapperCustomFactory implements IFactibilidadService {
	
	@Autowired
	@Qualifier("factibilidadDao")
	private IFactibilidadDao factibilidadDao;

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<FactibilidadDto> getFactibilidad() {
		return factibilidadDao.getFactibilidad();
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<AntenaDto> getAntenas(String idFacti) {
		return factibilidadDao.getAntenas(idFacti);
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<String> getTorres() {
		return factibilidadDao.getTorres();
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<String> getTipoAntenas() {
		return factibilidadDao.getTipoAntenas();
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public boolean crearSolicitud(FactibilidadDto factibilidadDto) {
		return factibilidadDao.crearSolicitud(factibilidadDto);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public boolean crearResultado(FactibilidadDto factibilidadDto) {
		return factibilidadDao.crearResultado(factibilidadDto);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public boolean actualizarMotivoRechazo(FactibilidadDto factibilidadDto) {
		return factibilidadDao.actualizarMotivoRechazo(factibilidadDto);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public boolean crearAntena(List<AntenaDto> antenaDto) {
		return factibilidadDao.crearAntena(antenaDto);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public boolean modificarSitioEstado(String idFolio, String estado) {
		return factibilidadDao.modificarSitioEstado(idFolio, estado);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<FactibilidadDto> getFacti(String idFacti) {
		return factibilidadDao.getFacti(idFacti);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public String getFactiPorFolio(String idFolio) {
		return factibilidadDao.getFactiPorFolio(idFolio);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public String getTorrePorId(String idTorre) {
		return factibilidadDao.getTorrePorId(idTorre);
	}
	
}

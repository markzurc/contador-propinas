package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.obra.impl;

import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.obra.IGestionObraCivilService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.mapper.MapperCustomFactory;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dao.IGestionObraCivilDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto.EstadoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto.MunicipioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.obra.dto.ObraCivilDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.FiltroSitioDto;

@Service("gestionObraCivilServiceImpl")
@Scope("prototype")
public class GestionObraCivilServiceImpl extends MapperCustomFactory implements IGestionObraCivilService {
	
	@Autowired
	@Qualifier("gestionObraCivilDao")
	private IGestionObraCivilDao gestionObraCivilDao;

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<ObraCivilDto> getListaObraCivil(FiltroSitioDto filtro) {
		SimpleDateFormat formatFecha = new SimpleDateFormat("dd/MM/yyyy");
		List<ObraCivilDto> listaObra = gestionObraCivilDao.getListaObraCivil(filtro);
		for (ObraCivilDto obraCivilDto : listaObra) {
			obraCivilDto.setFechaInicioStr(formatFecha.format(obraCivilDto.getFechaInicio()));
		}
		return listaObra;
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<String> getListaRegion() {
		return gestionObraCivilDao.getListaRegion();
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<EstadoDto> getListaEstado(String region) {
		return gestionObraCivilDao.getListaEstado(region);
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<MunicipioDto> getListaMunicipio(String region, String estado) {
		return gestionObraCivilDao.getListaMunicipio(region, estado);
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.vo;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * <h1>BitacoraSoxVo</h1>
 * <p>
 * BitacoraSoxVo
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 11/05/2015
 */
@XmlRootElement
public class BitacoraSoxVo implements Serializable {

	private static final long serialVersionUID = -2356293479731395150L;
	
	private Integer idBitacora;
	private Integer idUsuario;
	private String numeroEmpleado;
	private String folioSua;
	private Date fechaOperacion;
	private String objetoInicial;
	private String objetoFinal;
	private Integer idAccion;
	private String accionDescripcion;
	
	public BitacoraSoxVo() {
	}

	/**
	 * @author chcastro
	 * @param idBitacora
	 * @param idUsuario
	 * @param numeroEmpleado
	 * @param folioSua
	 * @param fechaOperacion
	 * @param objetoInicial
	 * @param objetoFinal
	 * @param idAccion
	 */
	public BitacoraSoxVo(Integer idBitacora, Integer idUsuario,
			String numeroEmpleado, String folioSua, Date fechaOperacion,
			String objetoInicial, String objetoFinal, Integer idAccion) {
		super();
		this.idBitacora = idBitacora;
		this.idUsuario = idUsuario;
		this.numeroEmpleado = numeroEmpleado;
		this.folioSua = folioSua;
		this.fechaOperacion = fechaOperacion;
		this.objetoInicial = objetoInicial;
		this.objetoFinal = objetoFinal;
		this.idAccion = idAccion;
	}

	/**
	 * @author chcastro
	 * @param idBitacora
	 * @param idUsuario
	 * @param numeroEmpleado
	 * @param folioSua
	 * @param fechaOperacion
	 * @param objetoInicial
	 * @param objetoFinal
	 * @param idAccion
	 * @param accionDescripcion
	 */
	public BitacoraSoxVo(Integer idBitacora, Integer idUsuario,
			String numeroEmpleado, String folioSua, Date fechaOperacion,
			String objetoInicial, String objetoFinal, Integer idAccion,
			String accionDescripcion) {
		super();
		this.idBitacora = idBitacora;
		this.idUsuario = idUsuario;
		this.numeroEmpleado = numeroEmpleado;
		this.folioSua = folioSua;
		this.fechaOperacion = fechaOperacion;
		this.objetoInicial = objetoInicial;
		this.objetoFinal = objetoFinal;
		this.idAccion = idAccion;
		this.accionDescripcion = accionDescripcion;
	}

	/**
	 * @author chcastro
	 * @return the idBitacora
	 */
	@XmlElement(nillable = true)
	public Integer getIdBitacora() {
		return idBitacora;
	}

	/**
	 * @author chcastro
	 * @param idBitacora the idBitacora to set
	 */
	public void setIdBitacora(Integer idBitacora) {
		this.idBitacora = idBitacora;
	}

	/**
	 * @author chcastro
	 * @return the idUsuario
	 */
	@XmlElement(nillable = true)
	public Integer getIdUsuario() {
		return idUsuario;
	}

	/**
	 * @author chcastro
	 * @param idUsuario the idUsuario to set
	 */
	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	/**
	 * @author chcastro
	 * @return the numeroEmpleado
	 */
	@XmlElement(nillable = true)
	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}

	/**
	 * @author chcastro
	 * @param numeroEmpleado the numeroEmpleado to set
	 */
	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	/**
	 * @author chcastro
	 * @return the folioSua
	 */
	@XmlElement(nillable = true)
	public String getFolioSua() {
		return folioSua;
	}

	/**
	 * @author chcastro
	 * @param folioSua the folioSua to set
	 */
	public void setFolioSua(String folioSua) {
		this.folioSua = folioSua;
	}

	/**
	 * @author chcastro
	 * @return the fechaOperacion
	 */
	@XmlElement(nillable = true)
	public Date getFechaOperacion() {
		return fechaOperacion;
	}

	/**
	 * @author chcastro
	 * @param fechaOperacion the fechaOperacion to set
	 */
	public void setFechaOperacion(Date fechaOperacion) {
		this.fechaOperacion = fechaOperacion;
	}

	/**
	 * @author chcastro
	 * @return the objetoInicial
	 */
	@XmlElement(nillable = true)
	public String getObjetoInicial() {
		return objetoInicial;
	}

	/**
	 * @author chcastro
	 * @param objetoInicial the objetoInicial to set
	 */
	public void setObjetoInicial(String objetoInicial) {
		this.objetoInicial = objetoInicial;
	}

	/**
	 * @author chcastro
	 * @return the objetoFinal
	 */
	@XmlElement(nillable = true)
	public String getObjetoFinal() {
		return objetoFinal;
	}

	/**
	 * @author chcastro
	 * @param objetoFinal the objetoFinal to set
	 */
	public void setObjetoFinal(String objetoFinal) {
		this.objetoFinal = objetoFinal;
	}

	/**
	 * @author chcastro
	 * @return the idAccion
	 */
	@XmlElement(nillable = true)
	public Integer getIdAccion() {
		return idAccion;
	}

	/**
	 * @author chcastro
	 * @param idAccion the idAccion to set
	 */
	public void setIdAccion(Integer idAccion) {
		this.idAccion = idAccion;
	}

	/**
	 * @author chcastro
	 * @return the accionDescripcion
	 */
	public String getAccionDescripcion() {
		return accionDescripcion;
	}

	/**
	 * @author chcastro
	 * @param accionDescripcion the accionDescripcion to set
	 */
	public void setAccionDescripcion(String accionDescripcion) {
		this.accionDescripcion = accionDescripcion;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BitacoraSoxVo [idBitacora=");
		builder.append(idBitacora);
		builder.append(", idUsuario=");
		builder.append(idUsuario);
		builder.append(", numeroEmpleado=");
		builder.append(numeroEmpleado);
		builder.append(", folioSua=");
		builder.append(folioSua);
		builder.append(", fechaOperacion=");
		builder.append(fechaOperacion);
		builder.append(", objetoInicial=");
		builder.append(objetoInicial);
		builder.append(", objetoFinal=");
		builder.append(objetoFinal);
		builder.append(", idAccion=");
		builder.append(idAccion);
		builder.append(", accionDescripcion=");
		builder.append(accionDescripcion);
		builder.append("]");
		return builder.toString();
	}	
}
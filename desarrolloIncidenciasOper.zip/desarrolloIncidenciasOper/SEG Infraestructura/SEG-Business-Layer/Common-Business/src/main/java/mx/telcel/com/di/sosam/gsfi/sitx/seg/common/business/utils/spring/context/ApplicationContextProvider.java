package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.spring.context;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * 
 * <h1>ApplicationContextProvider</h1>
 * <p>
 * Class for obtain the application Context
 * </p>
 * 
 * @author chcastro
 * @version 1.0
 * @since 20/07/2015
 */
public class ApplicationContextProvider implements ApplicationContextAware {
	
	private static ApplicationContext applicationContext = null;
	
	public static ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	@SuppressWarnings("static-access")
	public void setApplicationContext(ApplicationContext ctx) throws BeansException {
		this.applicationContext = ctx;
	}
}
package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.impl;

import java.sql.SQLException;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Properties;


import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.imageio.ImageIO;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.impl.BitacoraSoxBusinessImpl;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.error.ErrorSEGWeb;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.ISendMailBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.exception.SendingMailOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.vo.MessageVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.OVITUtils;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.mapper.MapperCustomFactory;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T7allcNoti;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.mail.dao.ISendMailDao;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * 
 * <h1>SendMail</h1>
 * <p>
 * 
 * </p>
 * 
 * @author chcastro
 * @version 1.0
 * @since 04/05/2015
 * 
 * @author hhernanm
 * @version 1.1 - Includes the implementation of getWebImage
 * 					method and the image attachment into the senMailTo method.
 *
 */

@Service("sendMailBusiness")
@Scope("prototype")
public class SendMailBusinessImpl extends MapperCustomFactory implements
		ISendMailBusiness {

	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;

	@Autowired
	@Qualifier("sendMailDao")
	private ISendMailDao sendMailDao;

	private static final Logger logger = LogManager.getLogger(SendMailBusinessImpl.class);

	@Override
	public void senMailTo(List<String> addressTo, List<String> addressCC,
			List<String> addressBCC, String subject, String message, 
			byte[]byteBanner, byte[]bytefooter)
			throws SendingMailOVITException {
		
		logger.info("Ejecutando SendMail.senMailTo");

		Properties mailProperties = null;
		List<ConfigurationUtilsVo> lstConfigurationUtilsVos;
		try {
			lstConfigurationUtilsVos = configurationUtilsBusiness
					.getListConstantOfDataBase(ConfigOvitIdentifierEnum.MAIL.class
							.getSimpleName());
			if (OVITUtils.isEmptyList(lstConfigurationUtilsVos)) {
				logger.error("La lista de destinatarios esta vacia.");
				throw new SendingMailOVITException(
						ErrorSEGWeb.E05_ERROR_ENVIAR_CORREO.getCodeError(),
						ErrorSEGWeb.E05_ERROR_ENVIAR_CORREO.getMessageError());
			}
			mailProperties = new Properties();
			for (ConfigurationUtilsVo tempConfigurationUtilsVo : lstConfigurationUtilsVos) {
				mailProperties.put(tempConfigurationUtilsVo.getDescripcion(),
						tempConfigurationUtilsVo.getValor());
			}

			Session mailSession = Session.getDefaultInstance(mailProperties);
			mailSession.setDebug(true);

			MimeMessage mimeMessage = new MimeMessage(mailSession);
			mimeMessage.setSubject(subject);
			String from = configurationUtilsBusiness.getConstantOfDataBase(
					ConfigOvitIdentifierEnum.MAIL.FROM).getValor();
			mimeMessage.setFrom(new InternetAddress(from));

			if (!OVITUtils.isEmptyList(addressTo)) {
				InternetAddress arrayInternetAddresses[] = new InternetAddress[addressTo
						.size()];
				for (int i = 0; i < arrayInternetAddresses.length; i++) {
					arrayInternetAddresses[i] = new InternetAddress(
							addressTo.get(i));
				}
				mimeMessage.addRecipients(Message.RecipientType.TO,
						arrayInternetAddresses);
			} else {
				logger.error("Lista TO vacia.");
			}

			if (!OVITUtils.isEmptyList(addressCC)) {
				InternetAddress arrayInternetAddresses[] = new InternetAddress[addressCC
						.size()];
				for (int i = 0; i < arrayInternetAddresses.length; i++) {
					arrayInternetAddresses[i] = new InternetAddress(
							addressCC.get(i));
				}
				mimeMessage.addRecipients(Message.RecipientType.CC,
						arrayInternetAddresses);
			}

			if (!OVITUtils.isEmptyList(addressBCC)) {
				InternetAddress arrayInternetAddresses[] = new InternetAddress[addressBCC
						.size()];
				for (int i = 0; i < arrayInternetAddresses.length; i++) {
					arrayInternetAddresses[i] = new InternetAddress(
							addressBCC.get(i));
				}
				mimeMessage.addRecipients(Message.RecipientType.BCC,
						arrayInternetAddresses);
			}

			MimeMultipart multipart = new MimeMultipart("related");
			BodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setContent(message, "text/html");
			multipart.addBodyPart(messageBodyPart);
		
			// IMAGEN BANER
			messageBodyPart = new MimeBodyPart();
			DataSource logoBanne = new ByteArrayDataSource(byteBanner, "image/png");
			messageBodyPart.setDataHandler(new DataHandler(logoBanne));
			messageBodyPart.setHeader("Content-ID", "<banner>");
			multipart.addBodyPart(messageBodyPart);
			
			//FOOTER
			messageBodyPart = new MimeBodyPart();
			DataSource logoFoot = new ByteArrayDataSource(bytefooter, "image/png");
			messageBodyPart.setDataHandler(new DataHandler(logoFoot));
			messageBodyPart.setHeader("Content-ID", "<footer>");
			multipart.addBodyPart(messageBodyPart);
			
			mimeMessage.setContent(multipart);

			Transport transport = mailSession.getTransport();
			transport.connect();
			transport.sendMessage(mimeMessage, mimeMessage.getAllRecipients());
			transport.close();
		} catch (Exception e) {
			StringBuilder sbError = new StringBuilder(
					"No se envio correo a los siguientes destinatarios: ");
			logger.error("Descripcion del Error: Codigo: "
					.concat(ErrorSEGWeb.E05_ERROR_ENVIAR_CORREO.getCodeError())
					.concat("Mensaje: ")
					.concat(ErrorSEGWeb.E05_ERROR_ENVIAR_CORREO
							.getMessageError()));
			logger.error("Error al ejecutar SendMailBusinessImpl.senMailTo: " + e);

			if (!OVITUtils.isEmptyList(addressTo)) {
				for (String tempEmail : addressTo) {
					sbError.append(tempEmail).append("/n");
				}
			}
			if (!OVITUtils.isEmptyList(addressCC)) {
				for (String tempEmail : addressCC) {
					sbError.append(tempEmail).append("/n");
				}
			}
			if (!OVITUtils.isEmptyList(addressBCC)) {
				for (String tempEmail : addressBCC) {
					sbError.append(tempEmail).append("/n");
				}
			}
			logger.error(sbError.toString());
			throw new SendingMailOVITException(
					ErrorSEGWeb.E05_ERROR_ENVIAR_CORREO.getCodeError(),
					ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError());
		}
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public MessageVo getMessage(String nameMessage)
			throws TransactionalOVITException {
		logger.info("Ejecutando SendMailBusiness.getMessage");
		MessageVo messageVo = null;
		try {
			T7allcNoti tcomcMensajes = sendMailDao.getMessage(nameMessage);
			messageVo = getMapper().map(tcomcMensajes, MessageVo.class);
		} catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: "
					.concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ")
					.concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar SendMailBusinessImpl.getMessage: " + e);
			throw new TransactionalOVITException(
					ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),
					ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
		
		return messageVo;
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public MessageVo getMessage(Enum<?> identificador)
			throws TransactionalOVITException {
		return getMessage(identificador.name());
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public MessageVo getNewUserMessage() throws TransactionalOVITException {
		try {
			MessageVo messageVo = null;
			T7allcNoti tcomcMensajes = sendMailDao.getNewUserMessage();
			if(tcomcMensajes != null){
				messageVo = getMapper().map(tcomcMensajes, MessageVo.class); 
			}
			return messageVo;
			
		} catch (SQLException e) {
			logger.error("Descripcion del Error: Codigo: "
					.concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ")
					.concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar SendMailBusinessImpl.getNewUserMessage: " + e);
			throw new TransactionalOVITException(
					ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),
					ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public MessageVo getResetPasswordMessage()
			throws TransactionalOVITException {
		try {
			MessageVo messageVo = null;
			T7allcNoti tcomcMensajes = sendMailDao.getResetPasswordMessage();
			if(tcomcMensajes != null){
				messageVo = getMapper().map(tcomcMensajes, MessageVo.class); 
			}
			return messageVo;
			
		} catch (SQLException e) {
			logger.error("Descripcion del Error: Codigo: "
					.concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ")
					.concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar SendMailBusinessImpl.getResetPasswordMessage: " + e);
			throw new TransactionalOVITException(
					ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),
					ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
	}

	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.ovit.common.business.mail.ISendMailBusiness#getWebImage(java.lang.String, java.lang.String)
	 */
	public byte[]  getWebImage(String srcImage, String imageType) throws MalformedURLException,IOException {
		logger.info("Ejecutando SendMail.getWebImage");
		byte[] imageInByte = null;
		try {
			URL url = new URL(srcImage);
			BufferedImage image =  ImageIO.read(url);
			
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageIO.write( image, imageType, baos );
			baos.flush();
			imageInByte = baos.toByteArray();
			baos.close();
		} catch (MalformedURLException e) {
			logger.error("Descripcion del Error: Codigo: "
					.concat(ErrorSEGWeb.E08_ERROR_IMAGEN.getCodeError())
					.concat("Mensaje: ")
					.concat(ErrorSEGWeb.E08_ERROR_IMAGEN.getMessageError()));
			logger.error("Error al ejecutar SendMailBusinessImpl.getWebImage: " + e);
			throw new MalformedURLException("Error: SendMail.getWebImage: "+ e.toString()+" cause by: " + e.getCause());
		} catch (IOException e) {
			logger.error("Descripcion del Error: Codigo: "
					.concat(ErrorSEGWeb.E08_ERROR_IMAGEN.getCodeError())
					.concat("Mensaje: ")
					.concat(ErrorSEGWeb.E08_ERROR_IMAGEN.getMessageError()));
			logger.error("Error al obtener imagen: " + e);
			throw new IOException("Error: SendMail.getWebImage: "+ e.toString()+" cause by: " + e.getCause());
		}
		return imageInByte;
		
	}
	
	@Override
	public org.hibernate.Session getSession() {
		return sendMailDao.getSession();
	}

	@Override
	public void setSession(org.hibernate.Session session) {
		sendMailDao.setSession(session);
	}

}

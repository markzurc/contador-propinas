package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.exception.SendingMailOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.vo.MessageVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.utils.session.ISession;

/**
 * 
 * <h1>ISendMail</h1>
 * <p>
 * 		The ISendMailBusiness interface which contains the next methods:
 * 		<br/>senMailTo
 * 		<br/>getMessage
 * 		<br/>getWebImage
 * 		<br/>getNewUserMessage
 * 		<br/>getResetPasswordMessage
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 30/04/2015
 * 
 * @author hhernanm
 * @version 1.1 - Includes the getWebImage method and update of senMailTo.
 * @since 16/07/2015
 *
 */
public interface ISendMailBusiness extends ISession{
	
	/**
	 * Send an Email to the address listed
	 * 
	 * @author chcastro
	 * @param addressTo {@link List}<{@link String}> - Address to send the Email 
	 * @param addressCC {@link List}<{@link String}> - Address for copy to send the Email
	 * @param addressBCC {@link List}<{@link String}> - Address hidden to send the Email
	 * @param subject {@link String} - Subject to send the message
	 * @param message {@link String} - Body of the message
	 * @param byteBanner byte[] - Array of bytes of the banner image
	 * @param bytefooter byte[] - Array of bytes of the footer image
	 * @throws SendingMailOVITException
	 */
	void senMailTo(List<String> addressTo, List<String> addressCC, 
			List<String> addressBCC, String subject, String message, 
			byte[]byteBanner, byte[]bytefooter) throws SendingMailOVITException;
	
	/**
	 * Obtain the information about the message from the data base.
	 * @author chcastro
	 * @param nameMessage {@link String} - Identifier of message
	 * @return {@link MessageVo}
	 * @throws TransactionalOVITException
	 */
	MessageVo getMessage(String nameMessage) throws TransactionalOVITException;
	
	/**
	 * Obtain the information about the message from the data base.
	 * @author chcastro
	 * @param identificador {@link Enum}
	 * @return {@link MessageVo}
	 * @throws TransactionalOVITException
	 */
	MessageVo getMessage(Enum<?> identificador) throws TransactionalOVITException;
	
	/**
	 * <h3>getWebImage</h3>
	 * <p>
	 * 		The method obtains an image from {@link URL} and returns the
	 * 		image in a byte array.
	 * </p>
	 * @author hhernanm
	 * @param {@link String } srcImage - the URL of the image
	 * @param {@link String} imageType - use to specify the type of the image, it could be an png, jpg, etc..
	 * @return {@link Byte} Array - the image in an Array of bytes
	 * @throws MalformedURLException
	 * @throws IOException
	 */
	byte[] getWebImage(String srcImage , String imageType) throws MalformedURLException,IOException;
	
	/**
	 * Obtain the information about the message from the data base.
	 * @author chcastro
	 * @return {@link MessageVo}
	 * @throws TransactionalOVITException
	 */
	MessageVo getNewUserMessage() throws TransactionalOVITException;
	
	/**
	 * Obtain the information about the message from the data base.
	 * @author chcastro
	 * @return {@link MessageVo}
	 * @throws TransactionalOVITException
	 */
	MessageVo getResetPasswordMessage() throws TransactionalOVITException;
}

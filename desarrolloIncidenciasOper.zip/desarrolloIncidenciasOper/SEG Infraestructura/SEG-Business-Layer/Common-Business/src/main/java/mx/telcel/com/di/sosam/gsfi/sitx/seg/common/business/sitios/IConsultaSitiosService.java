package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.FiltroSitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ServicioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;

public interface IConsultaSitiosService {

	public List<SitioDto> getListaSitios();

	public List<FiltroSitioDto> getDatosFiltro();

	public List<SitioDto> getListaSitiosFiltros(FiltroSitioDto filtro);

	public List<ServicioDto> getListaServicios();
	
}

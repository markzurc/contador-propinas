package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.solicitudes;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ArchSoliDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.CInfoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.InfoSoliDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ServicioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SoliArchDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SolicitudDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dto.AccionAvanceDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dto.GraficaDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.solicitudes.dto.TranEstaInfDto;

public interface ISolicitudesService {

	public boolean getSitioConSolicitud(SitioDto parametroSitio, String grupoOperador); //posible eliminacion
	
	public List<ServicioDto> getListaServicios();
	
	public String getGpoOperUsuById (String idUsuario);
	
	public List<CInfoDto> getInfoReq();
	
	public SolicitudDto generaSolicitud(SolicitudDto generaSoliDto) throws Exception;
	
	public void generaSolicitudInfo(SolicitudDto solicitudDto);

	public void generaSolicitudArch(List<SoliArchDto> lstArchFinal); //modified

	public List<GraficaDto> getDatosGrafica(String idEstado);

	public List<TranEstaInfDto> getDatosTransicion(String idEstado, Integer idRol);

	public SolicitudDto getSitioConSolicitudCrea(SitioDto parametroSitio, String grupoOperador); //add
	
	public SolicitudDto getSitioConSolicitudConsulta(SitioDto parametroSitio); //add
	
	public InfoSoliDto getInfoConSolicitudConsulta(SitioDto parametroSitio); //add
	
	public List<AccionAvanceDto> getListaAcciones(); //add
	
	public List<SoliArchDto> getLstArchSoli(SitioDto parametroSitio, List<String> tipoDocumentos); //add
	
	public boolean updateSolicitud (SitioDto sitioDTO, String transicion); //add
	
	public boolean updateSolicitudInfo (SitioDto sitioDTO, String info); //add
	
	public boolean updateSolicitudArch(List<SoliArchDto> lstArchFinal, SitioDto sitioDTO); //add
	
	public String getNombreUsu (Integer idUsuario);

	public int getCountSolicitudInf(String folio);
	
	public String getIdAccion(String accion);
	
}

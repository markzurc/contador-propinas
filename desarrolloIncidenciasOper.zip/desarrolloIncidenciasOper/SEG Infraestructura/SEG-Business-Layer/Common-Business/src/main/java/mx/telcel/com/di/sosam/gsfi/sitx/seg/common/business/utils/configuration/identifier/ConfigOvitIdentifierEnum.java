package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier;


/**
 * 
 * <h1>ConfigOvitIdentifierEnum</h1>
 * <p>
 * Contine the identifiers for the configuration parameters the OVIT
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 17/04/2015
 *
 */
public class ConfigOvitIdentifierEnum {
	
	public enum LDAP{
		ENDPOINT_LDAP,
		ID_APP,
		CLAVE_APP,
		BANDERA_SPML;
	}
	
	public enum PARAMETERS_SEG{
		NUM_CHAR_PASSWORD,
		NUM_PASS_NOT_REUSABLE,
		NUM_ATTEMPT_BLOQ,
		NUM_DAYS_MAX_INACT,
		REGX_PASSWORD,
		RESERVED_WORDS_PASSWORD,
		FLAG_ENCRYPT_PASSWORD,
		REGX_DESCRIPTION,
		FLAG_CHANGE_PASS,
		MIN_WRN_SESS_EXP,
		SESSION_TIME,
		SEG_VERSION,
		FLAG_CORREO,
		MAX_SIZE_MB_UPLOAD_FILE_ARCHFACT,
		MIN_LENGTH_MOTIVO_RECHAZO,
		CORREO_BCC,
		RUT_EJE_CONC,
		PROD_ENVIO_ORBI_WEB,
		CORREO_GRUPO_FINANZAS,
		RUTA_ARCHIVOS,
		RUTA_PROCESO_FACT,
		FECHA_ARCHIVOS,
		PASSWORD_ICT,
		PASSWORD_ICT2,
		USUARIO_ICT,
		USUARIO_ICT2,
		REGISTROS_BODS,
		DIAS_ESTA_DEPU,
		CORREO_ICT,
		ROL_USUARIOS_AUT_LLAMADAS,
		HOST_ICT,
		HOST_ICT2,
		USUARIO_PERMISOS_CARPETA,
		PASSWORD_PERMISOS_CARPETA,
		HOST_PERMISOS_CARPETA,
		RUT_FACT_TIMB,
		KEY_API_MAPS,
		RUTA_ARCHIVOS_USR,
		RUTA_ARCHIVOS_TMP,
		NUM_MAX_CONCESIONARIO,
		MAX_ADMIN_CONCESIONARIO,
		ACERCA_1,
		ACERCA_2,
		RUTA_ARCHIVOS_INF,
		RUTA_ARCHIVOS_ADJUNTOS_VISITA_TECNICA,
		RUTA_ARCHIVOS_PROYECTO_PRESUPUESTO,
		ESTADOS_PANEL_RESUL_FACTI
	}
	
	public enum MAIL{
		PASSWORD,
		SMTP_HOST,
		TRANSPORT_PROTOCOL,
		USER,
		FROM
	}
	
	public enum IMAGES_MAIL{
		IMG_BANNER,
		IMG_FOOTER
	}
	
	public enum TipoArchivo {
		//visita tecncia
		ARCHIVO_ADJUNTO_VISITA_TECNICA(1, "Solicitud visita tecnica"),
	    COPROBANTE_PAGO_VISITA_TECNICA(2, "Pago de confirmacion de vista tecnica"),
	    //colocacion
	    SOLICITUD_COLOCACION(1, "Verificacion colocacion"),
		VERIFICACION_COLOCACION(2, "Verificacion colocacion");
		
		private final int seccion;  
	    private final String descripcion; 

	    // Constructor para inicializar ambos valores
	    TipoArchivo(int seccion, String descripcion) {
	        this.seccion = seccion;
	        this.descripcion = descripcion;
	    }

		public int getSeccion() {
			return seccion;
		}

		public String getDescripcion() {
			return descripcion;
		}
	}
	   
	public enum TipoUsuarioSoliitud {
	    INTERNO(0);
	    private final Integer tipoUsuario; 
	    TipoUsuarioSoliitud(Integer tipoUsuario) {
	        this.tipoUsuario = tipoUsuario;
	    }
	    public Integer getTipoUsuario() {
	        return tipoUsuario;
	    }
	}
	public enum TipoAccionVisitaTecnica {
	    SOLICITUD(1),
	    CORRECCION(2);

	    private final int valor;

	    TipoAccionVisitaTecnica(int valor) {
	        this.valor = valor;
	    }

	    public int getTipoAccion() {
	        return valor;
	    }
	}

}


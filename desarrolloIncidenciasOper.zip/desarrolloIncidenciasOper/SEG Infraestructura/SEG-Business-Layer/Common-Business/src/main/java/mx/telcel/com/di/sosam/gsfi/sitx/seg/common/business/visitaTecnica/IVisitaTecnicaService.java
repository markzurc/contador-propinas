package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.visitaTecnica;
import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegcHerrVistTecn;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegcPersVistTecn;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3SegdSoliArch;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.common.T3segoVisiTecnSoli;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SoliArchDto;

public interface IVisitaTecnicaService {
	public boolean solicitarVisitaTecnica(T3segoVisiTecnSoli visitaTecnica,
										String transicion, 
										List<T3SegcPersVistTecn>listPersonal,
										List<T3SegcHerrVistTecn> listHerramientas,
										List<T3SegdSoliArch> archivosAdjuntos,	
										Integer accion,
										List<T3SegcPersVistTecn> listPersonalVisitaEliminado,
										List<T3SegcHerrVistTecn> listHerramientaVisitaEliminado,
										List<SoliArchDto> listArchivosEliminados);
										

	public List<T3SegcPersVistTecn> getPersonal(String folioSolicitud,String grupoOperador);
	
	public List<T3SegcHerrVistTecn> getHerramientas(String folioSolicitud,String grupoOperador);
	
	public List<SoliArchDto> getArchivos(String folioSolicitud,Integer idSeccion,String descripcion);

	public T3segoVisiTecnSoli getSolicitudVisita(String folioSolicitud);

	public boolean avanzarSolicitudVisita(T3segoVisiTecnSoli solicitudVisita,String transicio ,Integer idUsuario) ;


	public boolean guardarArchivo(T3SegdSoliArch archivo);
	
	public List<String> getTipoHerramientas();

	

	
}

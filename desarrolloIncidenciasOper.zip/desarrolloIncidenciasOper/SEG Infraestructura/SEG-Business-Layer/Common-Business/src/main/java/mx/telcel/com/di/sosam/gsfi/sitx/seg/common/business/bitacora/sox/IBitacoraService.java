package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.bitacora.sox.dto.BitacoraDto;

public interface IBitacoraService {

	public boolean insertaBitacora(BitacoraDto bitacoraDto);
	
	public List<BitacoraDto> obtenerAcciones(String idSoli);
}

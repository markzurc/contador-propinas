package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.IIncidenciaService.AdjuntoUi;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.T3SIND_INCI_ADJU;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaAdjuntoDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaAdjuntoDto;

@Service
public class IncidenciaAdjuntosService {

	private static final Logger log = LoggerFactory.getLogger(IncidenciaAdjuntosService.class);

	private static final long DEF_MAX_BYTES = 10L * 1024L * 1024L;
	private static final int DEF_MAX_ARCHIVOS = 10;
	private static final String DEF_ALLOW_TYPES = "/(\\.|\\/)(pdf)$/";
	private static final Pattern DEF_EXT_PATTERN = Pattern.compile("(?i).+\\.pdf$");
	private static final String DEF_EXT_HUMAN = "PDF";

	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;

	@Autowired
	private IIncidenciaAdjuntoDao incidenciaAdjuntoDao;

	@Autowired
	private IIncidenciaDao incidenciaDao;

	public void validarAdjunto(String nombre, String contentType, long size) {
		if (size <= 0)
			throw new IllegalArgumentException("Archivo vac�o o inv�lido.");
		if (size > obtenerMaxBytesAdjunto()) {
			throw new IllegalArgumentException("El archivo excede el tama�o m�ximo permitido.");
		}
		if (isBlank(nombre) || !DEF_EXT_PATTERN.matcher(nombre).matches()) {
			throw new IllegalArgumentException("Extensi�n no permitida en " + nombre + ". Formatos: " + DEF_EXT_HUMAN);
		}
	}

	@Transactional(readOnly = true)
	public List<IncidenciaAdjuntoDto> obtenerAdjuntosIncidencia(Long idIncidencia) {
		if (idIncidencia == null)
			return Collections.emptyList();
		try {
			List<T3SIND_INCI_ADJU> lista = incidenciaAdjuntoDao.findByIncidencia(idIncidencia);
			if (lista == null || lista.isEmpty())
				return Collections.emptyList();

			List<IncidenciaAdjuntoDto> dtos = new ArrayList<IncidenciaAdjuntoDto>();
			for (T3SIND_INCI_ADJU entidad : lista) {
				if (entidad == null)
					continue;
				IncidenciaAdjuntoDto dto = new IncidenciaAdjuntoDto();
				dto.setIdAdjunto(entidad.getIdAdjunto());
				dto.setNombreArchivo(entidad.getNombreArchivo());
				dto.setTamanioBytes(entidad.getTamanioBytes());
				dto.setRutaArchivo(entidad.getRutaArchivo());
				dtos.add(dto);
			}
			return dtos;
		} catch (Exception ex) {
			return Collections.emptyList();
		}
	}

	@Transactional
	public void adjuntarEvidenciaIncidencia(Long idIncidencia, AdjuntoUi adjunto, Long idUsuarioMovimiento)
			throws IOException {
		if (idIncidencia == null || adjunto == null)
			throw new IllegalArgumentException("Datos incompletos.");

		validarAdjunto(adjunto.getNombre(), null, adjunto.getTamanio());
		String rutaBase = obtenerRutaBaseDesdeBD();

		String folioIncidencia = generarFolioIncidencia(idIncidencia);
		String carpetaIncidencia = (folioIncidencia != null && !folioIncidencia.trim().isEmpty())
				? folioIncidencia.replace("IN-", "").trim()
				: String.valueOf(idIncidencia);

		String rutaCarpeta = rutaBase + carpetaIncidencia;

		File directorio = new File(rutaCarpeta);
		if (!directorio.exists()) {
			if (!directorio.mkdirs()) {
				throw new IOException("No se pudo crear directorio: " + rutaCarpeta);
			}
		}

		String nombreOriginal = new File(adjunto.getNombre()).getName();
		String nombreSeguro = sanitizarNombreArchivo(nombreOriginal);
		File archivoDestino = new File(directorio, nombreSeguro);

		if (archivoDestino.exists()) {
			String base = nombreSeguro;
			String ext = ".pdf";
			int punto = nombreSeguro.lastIndexOf('.');
			if (punto >= 0) {
				base = nombreSeguro.substring(0, punto);
				ext = nombreSeguro.substring(punto);
			}
			nombreSeguro = base + "_" + System.currentTimeMillis() + ext;
			archivoDestino = new File(directorio, nombreSeguro);
		}

		OutputStream out = null;
		try {
			out = new FileOutputStream(archivoDestino);
			out.write(adjunto.getBytes());
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
				}
			}
		}

		T3SIND_INCI_ADJU meta = new T3SIND_INCI_ADJU();
		Long idNuevo = incidenciaAdjuntoDao.obtenerSiguienteId();
		meta.setIdAdjunto(idNuevo);
		meta.setIdIncidencia(idIncidencia);
		meta.setNombreArchivo(nombreSeguro);
		meta.setRutaArchivo(rutaCarpeta);
		meta.setExtensionArchivo("pdf");
		meta.setTamanioBytes(adjunto.getTamanio());
		meta.setActivo("S");
		String nombreUsuarioAlta = "SYSTEM";
		if (idUsuarioMovimiento != null) {
			String nombreResuelto = resolverNombreOperadorMovimiento(idUsuarioMovimiento);
			if (nombreResuelto != null && !nombreResuelto.trim().isEmpty()) {
				nombreUsuarioAlta = nombreResuelto.trim();
			} else {
				nombreUsuarioAlta = String.valueOf(idUsuarioMovimiento);
			}
		}
		meta.setUsuarioAlta(nombreUsuarioAlta);
		meta.setFechaAlta(new Date());

		incidenciaAdjuntoDao.merge(meta);
	}

	@Transactional(readOnly = true)
	public byte[] leerBytesArchivo(String rutaDirectorio, String nombreArchivo) throws IOException {
		if (rutaDirectorio == null || nombreArchivo == null)
			return null;

		File file = new File(rutaDirectorio, nombreArchivo);
		if (!file.exists()) {
			throw new IOException("El archivo no existe en ruta: " + file.getAbsolutePath());
		}

		long length = file.length();
		if (length > Integer.MAX_VALUE)
			throw new IOException("Archivo demasiado grande");

		byte[] bytes = new byte[(int) length];
		int offset = 0;
		int numRead = 0;

		InputStream in = null;
		try {
			in = new FileInputStream(file);
			while (offset < bytes.length && (numRead = in.read(bytes, offset, bytes.length - offset)) >= 0) {
				offset += numRead;
			}
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
				}
			}
		}

		if (offset < bytes.length) {
			throw new IOException("No se pudo leer el archivo completo: " + file.getName());
		}
		return bytes;
	}

	@Transactional
	public void eliminarEvidenciaIncidencia(Long idIncidencia, String nombreArchivo, Long idUsuarioMovimiento) {
		T3SIND_INCI_ADJU entity = incidenciaAdjuntoDao.findActivoByIncidenciaAndNombre(idIncidencia, nombreArchivo);
		if (entity == null)
			throw new IllegalArgumentException("No encontrado.");

		entity.setActivo("N");
		entity.setUsuarioBaja((idUsuarioMovimiento != null) ? String.valueOf(idUsuarioMovimiento) : "SYSTEM");
		entity.setFechaBaja(new Date());
		incidenciaAdjuntoDao.merge(entity);

		try {
			File file = new File(entity.getRutaArchivo(), entity.getNombreArchivo());
			if (file.exists()) {
				file.delete();
			}
		} catch (Exception ex) {
			log.warn("No se pudo borrar archivo f�sico {}, solo baja l�gica.", nombreArchivo);
		}
	}

	public long obtenerMaxBytesAdjunto() {
		return DEF_MAX_BYTES;
	}

	public int obtenerMaxArchivos() {
		return DEF_MAX_ARCHIVOS;
	}

	public String obtenerRegexExtensiones() {
		return DEF_ALLOW_TYPES;
	}

	public String obtenerFormatosHumanos() {
		return DEF_EXT_HUMAN;
	}

	@Transactional
	public void guardarAdjuntosIncidenciaAlta(Long idIncidencia, List<AdjuntoUi> adjuntos, String usuarioAlta) {
		if (adjuntos == null || adjuntos.isEmpty())
			return;

		String rutaBase = obtenerRutaBaseDesdeBD();

		String folioIncidencia = generarFolioIncidencia(idIncidencia);

		String carpetaIncidencia = (folioIncidencia != null && !folioIncidencia.trim().isEmpty())
				? folioIncidencia.replace("IN-", "").trim()
				: String.valueOf(idIncidencia);

		String rutaCarpeta = rutaBase + carpetaIncidencia;

		File directorio = new File(rutaCarpeta);
		if (!directorio.exists()) {
			if (!directorio.mkdirs()) {
				throw new IllegalStateException(
						"No se pudo crear directorio de evidencias: " + directorio.getAbsolutePath());
			}
		}

		for (AdjuntoUi adj : adjuntos) {
			try {
				validarAdjunto(adj.getNombre(), null, adj.getTamanio());

				String nombreOriginal = new File(adj.getNombre()).getName();
				String nombreSeguro = sanitizarNombreArchivo(nombreOriginal);
				File archivoDestino = new File(directorio, nombreSeguro);

				if (archivoDestino.exists()) {
					String base = nombreSeguro;
					String ext = ".pdf";
					int punto = nombreSeguro.lastIndexOf('.');
					if (punto >= 0) {
						base = nombreSeguro.substring(0, punto);
						ext = nombreSeguro.substring(punto);
					}
					nombreSeguro = base + "_" + System.currentTimeMillis() + ext;
					archivoDestino = new File(directorio, nombreSeguro);
				}

				OutputStream out = null;
				try {
					out = new FileOutputStream(archivoDestino);
					out.write(adj.getBytes());
				} finally {
					if (out != null) {
						try {
							out.close();
						} catch (IOException e) {
						}
					}
				}

				T3SIND_INCI_ADJU meta = new T3SIND_INCI_ADJU();
				Long idNuevo = incidenciaAdjuntoDao.obtenerSiguienteId();
				meta.setIdAdjunto(idNuevo);
				meta.setIdIncidencia(idIncidencia);
				meta.setNombreArchivo(nombreSeguro);
				meta.setRutaArchivo(rutaCarpeta);
				meta.setExtensionArchivo("pdf");
				meta.setTamanioBytes(adj.getTamanio());
				meta.setActivo("S");
				meta.setUsuarioAlta(usuarioAlta);
				meta.setFechaAlta(new Date());

				incidenciaAdjuntoDao.merge(meta);

			} catch (Exception ex) {
				log.error("Error guardando adjunto alta id={}", idIncidencia, ex);
			}
		}
	}

	private String obtenerRutaBaseDesdeBD() {
		String rutaBase = "";
		try {
			ConfigurationUtilsVo config = configurationUtilsBusiness.getConstantOfDataBase("PARAMETERS_SEG",
					"RUTA_ARCHIVOS_INCIDENCIAS_SOLICITUDES");

			if (config != null && config.getValor() != null) {
				rutaBase = String.valueOf(config.getValor());
			}

		} catch (Exception e) {
			log.warn("No se pudo obtener ruta base de BD. Usando fallback.", e);
		}

		if (rutaBase == null || rutaBase.trim().isEmpty()) {
			rutaBase = "/seg/Incidencias/Solicitudes/";
		}

		rutaBase = rutaBase.trim();

		String sep = File.separator;
		if (rutaBase.indexOf('/') >= 0 && rutaBase.indexOf('\\') < 0) {
			sep = "/";
		} else if (rutaBase.startsWith("\\\\")) {
			sep = "\\";
		}

		if (!rutaBase.endsWith("/") && !rutaBase.endsWith("\\") && !rutaBase.endsWith(sep)) {
			rutaBase = rutaBase + sep;
		}

		return rutaBase;
	}

	private void validarRutaBaseFileSystem(String rutaBase) {

		if (rutaBase == null) {
			throw new IllegalStateException("Ruta base de filesystem null.");
		}

		String rutaNormalizada = rutaBase.trim();

		if (rutaNormalizada.startsWith(".") || rutaNormalizada.contains("..")) {
			throw new IllegalStateException("Ruta base inv�lida (relativa): " + rutaBase);
		}

		String osName = System.getProperty("os.name");
		boolean esWindows = (osName != null && osName.toLowerCase().contains("win"));

		if (esWindows) {
			if (!rutaNormalizada.startsWith("\\\\")) {
				throw new IllegalStateException(
						"RUTA_ARCHIVOS_INCIDENCIAS_SOLICITUDES inv�lida en Windows. Debe ser una ruta UNC (ej: \\\\servidor\\\\share\\\\...). Valor actual: "
								+ rutaBase);
			}
		} else {
			if (!rutaNormalizada.startsWith("/")) {
				throw new IllegalStateException(
						"RUTA_ARCHIVOS_INCIDENCIAS_SOLICITUDES inv�lida en Linux/Unix. Debe ser ruta absoluta (ej: /mnt/segfs/...). Valor actual: "
								+ rutaBase);
			}
		}
	}

	private String sanitizarNombreArchivo(String nombreOriginal) {
		String nombre = (nombreOriginal == null) ? "archivo.pdf" : nombreOriginal.trim();

		nombre = nombre.replace("\\", "_").replace("/", "_");
		nombre = nombre.replace("..", "_");
		nombre = nombre.replace(":", "_").replace("*", "_").replace("?", "_").replace("\"", "_").replace("<", "_")
				.replace(">", "_").replace("|", "_");

		nombre = nombre.replaceAll("\\s+", "_");

		if (!nombre.toLowerCase().endsWith(".pdf")) {
			nombre = nombre + ".pdf";
		}

		if (nombre.length() > 120) {
			String ext = ".pdf";
			String base = nombre.substring(0, 120 - ext.length());
			nombre = base + ext;
		}

		return nombre;
	}

	private boolean isBlank(String s) {
		return s == null || s.trim().isEmpty();
	}

	private String resolverNombreOperadorMovimiento(Long idUsuarioMovimiento) {
		if (idUsuarioMovimiento == null)
			return null;
		try {
			String nombre = incidenciaDao.obtenerNombreCompletoUsuarioPorId(idUsuarioMovimiento.intValue());
			return (nombre != null && !nombre.trim().isEmpty()) ? nombre.trim() : null;
		} catch (Exception ex) {
			return null;
		}
	}

	private String generarFolioIncidencia(Long idIncidencia) {
		if (idIncidencia == null)
			return null;
		return String.format("IN-%06d", idIncidencia.longValue());
	}
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios;

import java.util.Set;

public interface ISuscripcionSitioService {

    void registrarSuscripcion(String sitioId, String concesionario, String folioSolicitud);

    boolean existeSuscripcionActiva(String sitioId, String concesionario);

    Set<String> listarSitiosSuscritos(String concesionario);
}

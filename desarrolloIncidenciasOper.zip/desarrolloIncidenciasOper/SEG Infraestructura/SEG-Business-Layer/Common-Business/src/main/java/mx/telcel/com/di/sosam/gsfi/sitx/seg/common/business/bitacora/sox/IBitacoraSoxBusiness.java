package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.vo.BitacoraSoxVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.utils.session.ISession;

/**
 * 
 * <h1>IBitacoraSox</h1>
 * <p>
 * Interface containing methods for saving the log.
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 11/05/2015
 */
public interface IBitacoraSoxBusiness extends ISession{
	int CREATE = 0;
	int UPDATE = 1;
	int DROP = 2;
	int SELCT = 3;
	int ERROR_CREATE = 4;
	int ERROR_SEARCH = 5;
	int ERROR_MODIFY = 6;
	int ERROR_LIST = 7;
	int ERROR_DELETE = 8; 
	int ERROR_ENABLE = 9;
	int CREATE_FACT = 12;
	int CREATE_NOTACRED = 13;
	int CREATE_NOTACARG = 14;
	int CREATE_COMP_PAGO = 15;
	int EDIT_FACT = 16;
	int TIMB_FACT = 17;
	int CANCEL_FACT = 18;
	int CREATE_ABONO_PREP = 19;
		
	/**
	 * Method inserts a new log element in the database
	 * @author chcastro
	 * @param bitacoraSoxVo {@link BitacoraSoxVo} - Inserting object
	 * @throws TransactionalOVITException
	 */
	void createBitacoraSox(BitacoraSoxVo bitacoraSoxVo) throws TransactionalOVITException;
	
	/**
	 * Method for convert an object to String
	 * @author chcastro
	 * @param object {@link T} - Object to convert
	 * @return {@link String}
	 */
	<T> String objectToXML(T object);
	
	/**
	 * Method to convert an XML String to an Object.
	 * @author chcastro
	 * @param xml {@link String} - XML String to convert
	 * @param objectClass {@link Class}<{@link T}> Type of the object
	 * @return {@link T}
	 */
	<T> T xmlToObject(String xml, Class<T> objectClass);
	
	/**
	 * Method to obtain the number of elements of the user existing in the logs.
	 * @author chcastro
	 * @param idUsuario {@link Integer} - Identifier of the user
	 * @return {@link Integer} - Number of elements 
	 * @throws TransactionalOVITException
	 */
	Integer getNumberOfElements(Integer idUsuario) throws TransactionalOVITException;
	
	/**
	 * Obtain the content of a page given the page size and the page number.  
	 * @author chcastro
	 * @param idUsuario {@link Integer} - Identifier of the user
	 * @param sizePage {@link Integer} - Number of elements for a page
	 * @param pageNomber {@link Integer} - Page number to return
	 * @return {@link List}<{@link BitacoraSoxVo}>
	 * @throws TransactionalOVITException
	 */
	List<BitacoraSoxVo> getContentPage(Integer idUsuario, Integer sizePage, Integer pageNomber) throws TransactionalOVITException;
}

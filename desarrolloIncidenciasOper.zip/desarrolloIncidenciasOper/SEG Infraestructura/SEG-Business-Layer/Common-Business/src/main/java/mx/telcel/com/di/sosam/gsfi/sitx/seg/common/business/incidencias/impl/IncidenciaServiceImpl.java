package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.impl;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.IIncidenciaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.IIncidenciaService.AdjuntoUi;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaAdjuntoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaBitacoraDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaGestionDto;

@Service
@Transactional(rollbackFor = Exception.class) 
public class IncidenciaServiceImpl implements IIncidenciaService {

    @Autowired
    private IncidenciaQueryService incidenciaQueryService;

    @Autowired
    private IncidenciaCommandService incidenciaCommandService;

    @Autowired
    private IncidenciaAdjuntosService incidenciaAdjuntosService;

    @Override
    public List<?> listarSitiosSuscritosParaAltaIncidencia(String concesionarioUsuario) {
        return incidenciaQueryService.listarSitiosSuscritosParaAltaIncidencia(concesionarioUsuario);
    }

    @Override
    public Long crearIncidencia(String sitioCodigo, String tipo, String descripcion, List<AdjuntoUi> adjuntos,
            String usuarioCreacion, String correoUsuarioCreacion, String concesionarioCreacion) {
        return incidenciaCommandService.crearIncidencia(sitioCodigo, tipo, descripcion, adjuntos, usuarioCreacion,
                correoUsuarioCreacion, concesionarioCreacion);
    }

    @Override
    public void validarAlta(String sitioCodigo, String tipo, String descripcion, List<AdjuntoUi> adjuntos) {
        incidenciaCommandService.validarAlta(sitioCodigo, tipo, descripcion, adjuntos);
    }

    @Override
    public void avanzarIncidencia(Long idIncidencia, String accion, String comentario, Long idUsuarioMovimiento) {
        incidenciaCommandService.avanzarIncidencia(idIncidencia, accion, comentario, idUsuarioMovimiento);
    }

    @Override
    public void validarAdjunto(String nombre, String contentType, long size) {
        incidenciaAdjuntosService.validarAdjunto(nombre, contentType, size);
    }

    @Override
    public List<IncidenciaAdjuntoDto> obtenerAdjuntosIncidencia(Long idIncidencia) {
        return incidenciaAdjuntosService.obtenerAdjuntosIncidencia(idIncidencia);
    }

    @Override
    public List<?> listarSitiosEnOperacionVisibles() {
        return incidenciaQueryService.listarSitiosEnOperacionVisibles();
    }

    @Override
    public List<String> catalogoTiposIncidencia() {
        return incidenciaQueryService.catalogoTiposIncidencia();
    }

    @Override
    public long obtenerMaxBytesAdjunto() {
        return incidenciaAdjuntosService.obtenerMaxBytesAdjunto();
    }

    @Override
    public String generarFolioIncidencia(Long idIncidencia) {
        return incidenciaCommandService.generarFolioIncidencia(idIncidencia);
    }

    @Override
    public int obtenerMaxArchivos() {
        return incidenciaAdjuntosService.obtenerMaxArchivos();
    }

    @Override
    public String obtenerRegexExtensiones() {
        return incidenciaAdjuntosService.obtenerRegexExtensiones();
    }

    @Override
    public String obtenerFormatosHumanos() {
        return incidenciaAdjuntosService.obtenerFormatosHumanos();
    }

    @Override
    public List<IncidenciaGestionDto> buscarIncidenciasMantenimiento(String folio, String sitioId, String estatus) {
        return incidenciaQueryService.buscarIncidenciasMantenimiento(folio, sitioId, estatus);
    }

    @Override
    public List<IncidenciaGestionDto> buscarIncidenciasConcesionario(String folio, String sitioId, String estatus,
            String concesionario) {
        return incidenciaQueryService.buscarIncidenciasConcesionario(folio, sitioId, estatus, concesionario);
    }

    @Override
    public List<IncidenciaBitacoraDto> obtenerBitacoraIncidencia(Long idIncidencia) {
        return incidenciaQueryService.obtenerBitacoraIncidencia(idIncidencia);
    }

    @Override
    public void eliminarEvidenciaIncidencia(Long idIncidencia, String nombreArchivo, Long idUsuarioMovimiento)
            throws IOException {
        incidenciaAdjuntosService.eliminarEvidenciaIncidencia(idIncidencia, nombreArchivo, idUsuarioMovimiento);
    }

    @Override
    public void adjuntarEvidenciaIncidencia(Long idIncidencia, AdjuntoUi adjunto, Long idUsuarioMovimiento)
            throws IOException {
        incidenciaAdjuntosService.adjuntarEvidenciaIncidencia(idIncidencia, adjunto, idUsuarioMovimiento);
    }

    @Override
    public Long crearIncidenciaExternaCargaMasiva(String sitioCodigo, String tipo, String descripcion,
            String usuarioCreacion, String correoUsuarioCreacion, String concesionarioCreacion, String estatusInicial) {
        return incidenciaCommandService.crearIncidenciaExternaCargaMasiva(sitioCodigo, tipo, descripcion, usuarioCreacion,
                correoUsuarioCreacion, concesionarioCreacion, estatusInicial);
    }

    @Override
    public byte[] leerBytesArchivo(String rutaDirectorio, String nombreArchivo) throws IOException {
        return incidenciaAdjuntosService.leerBytesArchivo(rutaDirectorio, nombreArchivo);
    }

    @Override
    public String obtenerCorreoExternoPorUsuario(Integer idUsuario, Integer idRol) {
        return incidenciaQueryService.obtenerCorreoExternoPorUsuario(idUsuario, idRol);
    }
}

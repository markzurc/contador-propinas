package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.IIncidenciaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.ISuscripcionSitioService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.Incidencia;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.IncidenciaAdjunto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.IncidenciaBitacora;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaAdjuntoDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaBitacoraDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaGestionDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.port.ISitiosQueryPort;

@Service
@Transactional(rollbackFor = Exception.class)
public class IncidenciaServiceImpl implements IIncidenciaService {

	private static final Logger log = LoggerFactory.getLogger(IncidenciaServiceImpl.class);

	// Catálogos y Constantes
	private static final long ESTATUS_CREADA = 1L;
	private static final long ESTATUS_EN_ATENCION = 2L;
	private static final long ESTATUS_RECHAZADA = 3L;
	private static final long ESTATUS_FINALIZADA = 4L;

	private static final long RESP_CONCESIONARIO = 1L;
	private static final long RESP_MANTENIMIENTO = 2L;
	private static final long TIPO_INFRAESTRUCTURA_PASIVA = 1L;
	private static final long TIPO_SITIO = 2L;

	// Configuración Archivos
	private static final long DEF_MAX_BYTES = 10L * 1024L * 1024L;
	private static final int DEF_MAX_ARCHIVOS = 10;
	private static final String DEF_ALLOW_TYPES = "/(\\.|\\/)(pdf)$/";
	private static final Pattern DEF_EXT_PATTERN = Pattern.compile("(?i).+\\.pdf$");
	private static final String DEF_EXT_HUMAN = "PDF";
	private static final String FECHA_PATTERN = "dd/MM/yyyy HH:mm:ss";

	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;

	@Autowired
	private IIncidenciaDao incidenciaDao;

	@Autowired
	private IIncidenciaBitacoraDao bitacoraDao;

	@Autowired
	private ISitiosQueryPort sitiosPort;

	@Autowired(required = false)
	private ISuscripcionSitioService suscripcionSitioService;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private IIncidenciaAdjuntoDao incidenciaAdjuntoDao;

	// -------------------------------------------------------------------------
	// Alta
	// -------------------------------------------------------------------------

	@Override
	public Long crearIncidencia(String sitioCodigo, String tipo, String descripcion, List<AdjuntoUi> adjuntos,
			String usuarioCreacion, String correoUsuarioCreacion, String concesionarioCreacion) {

		validarAlta(sitioCodigo, tipo, descripcion, adjuntos);
		validarSitioActivo(sitioCodigo);

		Long idIncidencia = obtenerSiguienteIdIncidenciaConBloqueo();

		Incidencia incidencia = new Incidencia();
		incidencia.setId(idIncidencia);
		incidencia.setFolio(generarFolioIncidencia(idIncidencia));
		incidencia.setIdSitio(sitioCodigo.trim());
		incidencia.setIdConcesionario(valorSeguro(concesionarioCreacion));
		incidencia.setIdTipoIncidencia(mapTipoEntradaAId(tipo));
		incidencia.setIdEstatusIncidencia(ESTATUS_CREADA);

		// ✅ DISEÑO: en CREADA la responsabilidad es CONCESIONARIO (ID 1)
		incidencia.setIdResponsabilidad(RESP_CONCESIONARIO);

		incidencia.setDescripcion(descripcion.trim());

		incidencia.setOrigenAlta("I");
		incidencia.setNombreReporta(valorSeguro(usuarioCreacion));
		incidencia.setCorreoReporta(valorSeguro(correoUsuarioCreacion));
		incidencia.setUsuarioAlta(valorSeguro(usuarioCreacion));

		Date ahora = new Date();
		incidencia.setFechaAlta(ahora);
		incidencia.setFechaUltimoMovimiento(ahora);
		// incidencia.setUsuarioUltimaModificacion(valorSeguro(usuarioCreacion)); // COMENTADO para que nazca null
		incidencia.setFechaUltimaModificacion(ahora);

		incidenciaDao.persist(incidencia);

		// ✅ DISEÑO: Bitácora registra ID 1 (Concesionario)
		insertarMovimientoBitacora(idIncidencia, ESTATUS_CREADA, RESP_CONCESIONARIO, "C", valorSeguro(usuarioCreacion),
				null, // comentario vacío
				null // estatus anterior vacío
		);

		if (adjuntos != null && !adjuntos.isEmpty()) {
			guardarAdjuntosIncidenciaAlta(idIncidencia, adjuntos, valorSeguro(usuarioCreacion));
		}

		return idIncidencia;
	}

	@Override
	public void validarAlta(String sitioCodigo, String tipo, String descripcion, List<AdjuntoUi> adjuntos) {
		if (isBlank(sitioCodigo))
			throw new IllegalArgumentException("El sitio es obligatorio.");
		if (isBlank(tipo))
			throw new IllegalArgumentException("El tipo de incidencia es obligatorio.");
		if (isBlank(descripcion))
			throw new IllegalArgumentException("La descripción es obligatoria.");

		if (adjuntos == null || adjuntos.isEmpty()) {
			throw new IllegalArgumentException("Debe adjuntar al menos un archivo PDF como evidencia.");
		}

		long total = 0L;
		for (AdjuntoUi adjunto : adjuntos) {
			if (adjunto == null)
				continue;
			validarAdjunto(adjunto.getNombre(), null, adjunto.getTamanio());
			total += adjunto.getTamanio();
		}

		if (total > obtenerMaxBytesAdjunto()) {
			throw new IllegalArgumentException(
					"El total de evidencias no debe exceder " + (DEF_MAX_BYTES / (1024 * 1024)) + " MB.");
		}

		if (adjuntos.size() > obtenerMaxArchivos()) {
			throw new IllegalArgumentException("El máximo de evidencias permitidas es " + DEF_MAX_ARCHIVOS + ".");
		}
	}

	// -------------------------------------------------------------------------
	// Avance
	// -------------------------------------------------------------------------

	@Override
	public void avanzarIncidencia(Long idIncidencia, String accion, String comentario, Long idUsuarioMovimiento) {
		if (idIncidencia == null)
			throw new IllegalArgumentException("idIncidencia es obligatorio.");
		if (isBlank(accion))
			throw new IllegalArgumentException("La acción es obligatoria.");

		Incidencia incidencia = incidenciaDao.findById(idIncidencia);
		if (incidencia == null)
			throw new IllegalArgumentException("No existe la incidencia " + idIncidencia);

		Long estatusActual = incidencia.getIdEstatusIncidencia();
		if (estatusActual == null)
			throw new IllegalStateException("La incidencia no tiene estatus actual.");

		if (ESTATUS_FINALIZADA == estatusActual || ESTATUS_RECHAZADA == estatusActual) {
			throw new IllegalStateException("La incidencia está cerrada y no permite cambios.");
		}

		Long nuevoEstatus = mapAccionAEstatusId(accion);
		if (nuevoEstatus == null)
			throw new IllegalArgumentException("Acción no reconocida: " + accion);

		if (ESTATUS_CREADA == estatusActual && ESTATUS_FINALIZADA == nuevoEstatus) {
			throw new IllegalStateException("Una incidencia CREADA debe pasar primero a EN ATENCIÓN.");
		}
		if (ESTATUS_EN_ATENCION == estatusActual && ESTATUS_RECHAZADA == nuevoEstatus) {
			throw new IllegalStateException("No es posible rechazar una incidencia EN ATENCIÓN.");
		}

		Long nuevaResponsabilidad = resolverResponsabilidadPorEstatus(nuevoEstatus);

		incidencia.setIdEstatusIncidencia(nuevoEstatus);
		incidencia.setIdResponsabilidad(nuevaResponsabilidad);
		incidencia.setFechaUltimoMovimiento(new Date());

		if (idUsuarioMovimiento != null) {
			// CAMBIO: Buscamos nombre real
			String nombreOperador = incidenciaDao.obtenerNombreCompletoUsuarioPorId(idUsuarioMovimiento.intValue());
			
			if (nombreOperador != null && !nombreOperador.isEmpty()) {
				incidencia.setUsuarioUltimaModificacion(nombreOperador);
			} else {
				incidencia.setUsuarioUltimaModificacion(String.valueOf(idUsuarioMovimiento));
			}
		}
		incidencia.setFechaUltimaModificacion(new Date());

		incidenciaDao.merge(incidencia);

		String operadorMovimiento = resolverNombreOperadorMovimiento(idUsuarioMovimiento);

		if (isBlank(operadorMovimiento) && idUsuarioMovimiento != null) {
			operadorMovimiento = String.valueOf(idUsuarioMovimiento);
		}

		insertarMovimientoBitacora(
				idIncidencia,
				nuevoEstatus,
				nuevaResponsabilidad,
				"M",
				operadorMovimiento,
				valorSeguro(comentario),
				mapEstatusIdAClave(estatusActual));
	}

	// -------------------------------------------------------------------------
	// Catálogos y Consultas
	// -------------------------------------------------------------------------

	@Override
	@Transactional(readOnly = true)
	public List<?> listarSitiosEnOperacionVisibles() {
		return sitiosPort.listarSitiosVisiblesParaUsuario();
	}

	@Override
	@Transactional(readOnly = true)
	public List<?> listarSitiosSuscritosParaAltaIncidencia(String concesionarioUsuario) {
		List<?> sitiosVisibles = sitiosPort.listarSitiosVisiblesParaUsuario();
		if (sitiosVisibles == null || sitiosVisibles.isEmpty())
			return Collections.emptyList();
		if (isBlank(concesionarioUsuario) || suscripcionSitioService == null)
			return sitiosVisibles;

		Set<String> sitiosSuscritos = suscripcionSitioService.listarSitiosSuscritos(concesionarioUsuario.trim());
		if (sitiosSuscritos == null || sitiosSuscritos.isEmpty())
			return Collections.emptyList();

		Set<String> setSuscritos = new HashSet<String>(sitiosSuscritos);
		List<SitioDto> resultado = new ArrayList<SitioDto>();

		for (Object item : sitiosVisibles) {
			if (item instanceof SitioDto) {
				SitioDto sitio = (SitioDto) item;
				if (sitio != null && !isBlank(sitio.getSitio()) && setSuscritos.contains(sitio.getSitio())) {
					resultado.add(sitio);
				}
			}
		}
		return resultado;
	}

	@Override
	public List<String> catalogoTiposIncidencia() {
		List<String> lista = new ArrayList<String>();
		lista.add("Infraestructura Pasiva");
		lista.add("Sitio");
		return lista;
	}

	@Override
	@Transactional(readOnly = true)
	public List<IncidenciaGestionDto> buscarIncidenciasMantenimiento(String folio, String sitioId, String estatus) {
		List<Incidencia> incidencias = incidenciaDao.findAll();
		if (incidencias == null || incidencias.isEmpty())
			return Collections.emptyList();

		Map<String, String> mapaSitios = construirMapaNombreSitio();
		Long estatusIdFiltro = mapEstatusEntradaAId(estatus);
		List<IncidenciaGestionDto> resultado = new ArrayList<IncidenciaGestionDto>();

		for (Incidencia incidencia : incidencias) {
			if (incidencia == null)
				continue;
			if (!cumpleFiltroTexto(incidencia.getFolio(), folio))
				continue;
			if (!cumpleFiltroTexto(incidencia.getIdSitio(), sitioId))
				continue;
			if (estatusIdFiltro != null && (incidencia.getIdEstatusIncidencia() == null
					|| estatusIdFiltro.longValue() != incidencia.getIdEstatusIncidencia().longValue())) {
				continue;
			}
			resultado.add(construirDto(incidencia, mapaSitios));
		}
		return resultado;
	}

	@Override
	@Transactional(readOnly = true)
	public List<IncidenciaGestionDto> buscarIncidenciasConcesionario(String folio, String sitioId, String estatus,
			String concesionario) {
		if (isBlank(concesionario))
			return Collections.emptyList();

		List<Incidencia> incidencias = incidenciaDao.findAllByConcesionario(concesionario.trim());
		if (incidencias == null || incidencias.isEmpty())
			return Collections.emptyList();

		Map<String, String> mapaSitios = construirMapaNombreSitio();
		Long estatusIdFiltro = mapEstatusEntradaAId(estatus);
		List<IncidenciaGestionDto> resultado = new ArrayList<IncidenciaGestionDto>();

		for (Incidencia incidencia : incidencias) {
			if (incidencia == null)
				continue;
			if (!cumpleFiltroTexto(incidencia.getFolio(), folio))
				continue;
			if (!cumpleFiltroTexto(incidencia.getIdSitio(), sitioId))
				continue;
			if (estatusIdFiltro != null && (incidencia.getIdEstatusIncidencia() == null
					|| estatusIdFiltro.longValue() != incidencia.getIdEstatusIncidencia().longValue())) {
				continue;
			}
			resultado.add(construirDto(incidencia, mapaSitios));
		}
		return resultado;
	}

	@Override
	@Transactional(readOnly = true)
	public List<IncidenciaBitacora> obtenerBitacoraIncidencia(Long idIncidencia) {
		if (idIncidencia == null) {
			return Collections.emptyList();
		}

		List<IncidenciaBitacora> movimientos = bitacoraDao.findByIncidenciaId(idIncidencia);
		if (movimientos == null) {
			return Collections.emptyList();
		}

		for (IncidenciaBitacora movimiento : movimientos) {
			if (movimiento == null) {
				continue;
			}
			if (isBlank(movimiento.getEstatusNuevo())) {
				movimiento.setEstatusNuevo(mapEstatusIdAClave(movimiento.getIdEstatusIncidencia()));
			}
		}

		return movimientos;
	}

	// -------------------------------------------------------------------------
	// Gestión de Archivos
	// -------------------------------------------------------------------------

	@Override
	public void validarAdjunto(String nombre, String contentType, long size) {
		if (size <= 0)
			throw new IllegalArgumentException("Archivo vacío o inválido.");
		if (size > obtenerMaxBytesAdjunto()) {
			throw new IllegalArgumentException("El archivo excede el tamaño máximo permitido.");
		}
		if (isBlank(nombre) || !DEF_EXT_PATTERN.matcher(nombre).matches()) {
			throw new IllegalArgumentException("Extensión no permitida en " + nombre + ". Formatos: " + DEF_EXT_HUMAN);
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<IncidenciaAdjunto> obtenerAdjuntosIncidencia(Long idIncidencia) {
		if (idIncidencia == null)
			return Collections.emptyList();
		try {
			List<IncidenciaAdjunto> lista = incidenciaAdjuntoDao.findByIncidencia(idIncidencia);
			return (lista != null) ? lista : Collections.<IncidenciaAdjunto>emptyList();
		} catch (Exception ex) {
			log.error("Error consultando adjuntos BD incidencia {}", idIncidencia, ex);
			return Collections.emptyList();
		}
	}

	@Override
	public void adjuntarEvidenciaIncidencia(Long idIncidencia, AdjuntoUi adjunto, Long idUsuarioMovimiento)
			throws IOException {
		if (idIncidencia == null || adjunto == null)
			throw new IllegalArgumentException("Datos incompletos.");

		validarAdjunto(adjunto.getNombre(), null, adjunto.getTamanio());

		String rutaBase = obtenerRutaBaseDesdeBD();
		String rutaCarpeta = rutaBase + idIncidencia;

		File directorio = new File(rutaCarpeta);
		if (!directorio.exists()) {
			if (!directorio.mkdirs()) {
				throw new IOException("No se pudo crear directorio: " + rutaCarpeta);
			}
		}

		String nombreOriginal = new File(adjunto.getNombre()).getName();
		String nombreSeguro = sanitizarNombreArchivo(nombreOriginal);
		File archivoDestino = new File(directorio, nombreSeguro);

		if (archivoDestino.exists()) {
			String base = nombreSeguro;
			String ext = ".pdf";
			int punto = nombreSeguro.lastIndexOf('.');
			if (punto >= 0) {
				base = nombreSeguro.substring(0, punto);
				ext = nombreSeguro.substring(punto);
			}
			nombreSeguro = base + "_" + System.currentTimeMillis() + ext;
			archivoDestino = new File(directorio, nombreSeguro);
		}

		OutputStream out = null;
		try {
			out = new FileOutputStream(archivoDestino);
			out.write(adjunto.getBytes());
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
				}
			}
		}

		IncidenciaAdjunto meta = new IncidenciaAdjunto();
		Long idNuevo = incidenciaAdjuntoDao.obtenerSiguienteId();
		meta.setIdAdjunto(idNuevo);
		meta.setIdIncidencia(idIncidencia);
		meta.setNombreArchivo(nombreSeguro);
		meta.setRutaArchivo(rutaCarpeta);
		meta.setExtensionArchivo("pdf");
		meta.setTamanioBytes(adjunto.getTamanio());
		meta.setActivo("S");
		meta.setUsuarioAlta((idUsuarioMovimiento != null) ? String.valueOf(idUsuarioMovimiento) : "SYSTEM");
		meta.setFechaAlta(new Date());

		incidenciaAdjuntoDao.merge(meta);
	}

	@Override
	public byte[] leerBytesArchivo(String rutaDirectorio, String nombreArchivo) throws IOException {
		if (rutaDirectorio == null || nombreArchivo == null)
			return null;

		File file = new File(rutaDirectorio + File.separator + nombreArchivo);
		if (!file.exists()) {
			throw new IOException("El archivo no existe en ruta: " + file.getAbsolutePath());
		}

		long length = file.length();
		if (length > Integer.MAX_VALUE)
			throw new IOException("Archivo demasiado grande");

		byte[] bytes = new byte[(int) length];
		int offset = 0;
		int numRead = 0;

		InputStream in = null;
		try {
			in = new FileInputStream(file);
			while (offset < bytes.length && (numRead = in.read(bytes, offset, bytes.length - offset)) >= 0) {
				offset += numRead;
			}
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
				}
			}
		}

		if (offset < bytes.length) {
			throw new IOException("No se pudo leer el archivo completo: " + file.getName());
		}
		return bytes;
	}

	@Override
	public void eliminarEvidenciaIncidencia(Long idIncidencia, String nombreArchivo, Long idUsuarioMovimiento) {
		IncidenciaAdjunto entity = incidenciaAdjuntoDao.findActivoByIncidenciaAndNombre(idIncidencia, nombreArchivo);
		if (entity == null)
			throw new IllegalArgumentException("No encontrado.");

		entity.setActivo("N");
		entity.setUsuarioBaja((idUsuarioMovimiento != null) ? String.valueOf(idUsuarioMovimiento) : "SYSTEM");
		entity.setFechaBaja(new Date());
		incidenciaAdjuntoDao.merge(entity);

		try {
			File file = new File(entity.getRutaArchivo() + File.separator + entity.getNombreArchivo());
			if (file.exists()) {
				file.delete();
			}
		} catch (Exception ex) {
			log.warn("No se pudo borrar archivo físico {}, solo baja lógica.", nombreArchivo);
		}
	}

	// -------------------------------------------------------------------------
	// Carga Masiva
	// -------------------------------------------------------------------------

	@Override
	public Long crearIncidenciaExternaCargaMasiva(String sitioCodigo, String tipo, String descripcion,
			String usuarioCreacion, String correoUsuarioCreacion, String concesionarioCreacion, String estatusInicial) {

		if (isBlank(sitioCodigo))
			throw new IllegalArgumentException("El sitio es obligatorio.");
		if (isBlank(tipo))
			throw new IllegalArgumentException("El tipo es obligatorio.");
		if (isBlank(descripcion))
			throw new IllegalArgumentException("La descripción es obligatoria.");
		if (isBlank(usuarioCreacion))
			throw new IllegalArgumentException("El nombre es obligatorio.");
		if (isBlank(estatusInicial))
			throw new IllegalArgumentException("El estatus es obligatorio.");

		validarSitioActivo(sitioCodigo);

		Long idIncidencia = obtenerSiguienteIdIncidenciaConBloqueo();
		Long idEstatus = mapEstatusEntradaAId(estatusInicial);
		if (idEstatus == null)
			throw new IllegalArgumentException("Estatus inicial no reconocido: " + estatusInicial);

		Incidencia incidencia = new Incidencia();
		incidencia.setId(idIncidencia);
		incidencia.setFolio(generarFolioIncidencia(idIncidencia));
		incidencia.setIdSitio(sitioCodigo.trim());
		incidencia.setIdConcesionario(valorSeguro(concesionarioCreacion));
		incidencia.setIdTipoIncidencia(mapTipoEntradaAId(tipo));
		incidencia.setIdEstatusIncidencia(idEstatus);
		incidencia.setIdResponsabilidad(resolverResponsabilidadPorEstatus(idEstatus));
		incidencia.setDescripcion(descripcion.trim());
		incidencia.setOrigenAlta("M");
		incidencia.setNombreReporta(valorSeguro(usuarioCreacion));
		incidencia.setCorreoReporta(valorSeguro(correoUsuarioCreacion));
		incidencia.setUsuarioAlta(valorSeguro(usuarioCreacion));

		Date ahora = new Date();
		incidencia.setFechaAlta(ahora);
		incidencia.setFechaUltimoMovimiento(ahora);
		// incidencia.setUsuarioUltimaModificacion(valorSeguro(usuarioCreacion));
		incidencia.setFechaUltimaModificacion(ahora);

		incidenciaDao.persist(incidencia);

		insertarMovimientoBitacora(idIncidencia, idEstatus, incidencia.getIdResponsabilidad(), "C",
				valorSeguro(usuarioCreacion), "CARGA MASIVA: Incidencia creada", null);

		return idIncidencia;
	}

	// -------------------------------------------------------------------------
	// Métodos Auxiliares
	// -------------------------------------------------------------------------

	private void guardarAdjuntosIncidenciaAlta(Long idIncidencia, List<AdjuntoUi> adjuntos, String usuarioAlta) {
		if (adjuntos == null || adjuntos.isEmpty())
			return;

		String rutaBase = obtenerRutaBaseDesdeBD();
		String rutaCarpeta = rutaBase + idIncidencia;

		File directorio = new File(rutaCarpeta);
		if (!directorio.exists()) {
			directorio.mkdirs();
		}

		for (AdjuntoUi adj : adjuntos) {
			try {
				validarAdjunto(adj.getNombre(), null, adj.getTamanio());

				String nombreOriginal = new File(adj.getNombre()).getName();
				String nombreSeguro = sanitizarNombreArchivo(nombreOriginal);
				File archivoDestino = new File(directorio, nombreSeguro);

				if (archivoDestino.exists()) {
					String base = nombreSeguro;
					String ext = ".pdf";
					int punto = nombreSeguro.lastIndexOf('.');
					if (punto >= 0) {
						base = nombreSeguro.substring(0, punto);
						ext = nombreSeguro.substring(punto);
					}
					nombreSeguro = base + "_" + System.currentTimeMillis() + ext;
					archivoDestino = new File(directorio, nombreSeguro);
				}

				OutputStream out = null;
				try {
					out = new FileOutputStream(archivoDestino);
					out.write(adj.getBytes());
				} finally {
					if (out != null) {
						try {
							out.close();
						} catch (IOException e) {
						}
					}
				}

				IncidenciaAdjunto meta = new IncidenciaAdjunto();
				Long idNuevo = incidenciaAdjuntoDao.obtenerSiguienteId();
				meta.setIdAdjunto(idNuevo);
				meta.setIdIncidencia(idIncidencia);
				meta.setNombreArchivo(nombreSeguro);
				meta.setRutaArchivo(rutaCarpeta);
				meta.setExtensionArchivo("pdf");
				meta.setTamanioBytes(adj.getTamanio());
				meta.setActivo("S");
				meta.setUsuarioAlta(usuarioAlta);
				meta.setFechaAlta(new Date());

				incidenciaAdjuntoDao.merge(meta);
			} catch (Exception ex) {
				log.error("Error guardando adjunto alta id={}", idIncidencia, ex);
			}
		}
	}

	private String obtenerRutaBaseDesdeBD() {
		String rutaBase = "";
		try {
			ConfigurationUtilsVo config = configurationUtilsBusiness.getConstantOfDataBase("PARAMETERS_SEG",
					"RUTA_ARCHIVOS_INF");
			if (config != null && config.getValor() != null) {
				rutaBase = String.valueOf(config.getValor());
			}
		} catch (Exception e) {
			log.warn("No se pudo obtener ruta base de BD. Usando fallback.", e);
		}

		if (rutaBase == null || rutaBase.trim().isEmpty()) {
			rutaBase = "/seg/Incidencias/Solicitudes";
		}

		if (!rutaBase.endsWith(File.separator) && !rutaBase.endsWith("/")) {
			rutaBase += File.separator;
		}
		return rutaBase + "Incidencias" + File.separator;
	}

	private String sanitizarNombreArchivo(String nombreOriginal) {
		String nombre = (nombreOriginal != null) ? nombreOriginal.trim() : "evidencia.pdf";
		nombre = nombre.replace("\\", "/");
		if (nombre.contains("/")) {
			nombre = nombre.substring(nombre.lastIndexOf('/') + 1);
		}
		nombre = nombre.replaceAll("[^a-zA-Z0-9._-]", "_");
		if (!nombre.toLowerCase().endsWith(".pdf")) {
			nombre = nombre + ".pdf";
		}
		return nombre;
	}

	private Long obtenerSiguienteIdIncidenciaConBloqueo() {
		bloquearTabla("BDDSEG01.T3SINO_INCI");
		return incidenciaDao.obtenerSiguienteId();
	}

	private Long obtenerSiguienteIdMovimientoConBloqueo() {
		bloquearTabla("BDDSEG01.T3SINB_INCI_MOVI");
		return bitacoraDao.obtenerSiguienteId();
	}

	private void bloquearTabla(String tabla) {
		if (entityManager == null)
			return;
		try {
			entityManager.createNativeQuery("LOCK TABLE " + tabla + " IN EXCLUSIVE MODE").executeUpdate();
		} catch (Exception ex) {
			log.warn("No fue posible aplicar LOCK TABLE sobre {}", tabla, ex);
		}
	}

	private void insertarMovimientoBitacora(Long idIncidencia, Long idEstatus, Long idResponsabilidad,
			String perfilMovimiento, String usuarioMovimiento, String comentario, String estatusAnteriorClave) {

		Long idMovimiento = obtenerSiguienteIdMovimientoConBloqueo();

		IncidenciaBitacora mov = new IncidenciaBitacora();
		mov.setId(idMovimiento);
		mov.setIdIncidencia(idIncidencia);
		mov.setIdEstatusIncidencia(idEstatus);
		mov.setIdResponsabilidad(idResponsabilidad);

		mov.setPerfilMovimiento(isBlank(perfilMovimiento) ? "M" : perfilMovimiento.trim());
		mov.setUsuarioMovimiento(isBlank(usuarioMovimiento) ? "SYSTEM" : usuarioMovimiento.trim());
		mov.setFechaEvento(new Date());

		// ✅ DISEÑO: si no hay comentario, queda vacío (null)
		mov.setComentario(isBlank(comentario) ? null : comentario);

		// ✅ evento más correcto
		boolean esAlta = (idEstatus != null && idEstatus.longValue() == ESTATUS_CREADA
				&& isBlank(estatusAnteriorClave));
		mov.setEvento(esAlta ? "ALTA" : "CAMBIO_ESTATUS");

		mov.setEstatusAnterior(estatusAnteriorClave);
		mov.setEstatusNuevo(mapEstatusIdAClave(idEstatus));

		bitacoraDao.persist(mov);
	}

	private boolean isBlank(String s) {
		return s == null || s.trim().isEmpty();
	}

	private String valorSeguro(String s) {
		return (s == null) ? "" : s.trim();
	}

	@Override
	public long obtenerMaxBytesAdjunto() {
		return DEF_MAX_BYTES;
	}

	@Override
	public int obtenerMaxArchivos() {
		return DEF_MAX_ARCHIVOS;
	}

	@Override
	public String obtenerRegexExtensiones() {
		return DEF_ALLOW_TYPES;
	}

	@Override
	public String obtenerFormatosHumanos() {
		return DEF_EXT_HUMAN;
	}

	@Override
	public String generarFolioIncidencia(Long idIncidencia) {
		if (idIncidencia == null)
			return null;
		return String.format("IN-%06d", idIncidencia.longValue());
	}

	private Long mapAccionAEstatusId(String accion) {
		String a = accion.trim().toUpperCase();
		if (a.contains("RECHAZ"))
			return ESTATUS_RECHAZADA;
		if (a.contains("ATEN"))
			return ESTATUS_EN_ATENCION;
		if (a.contains("FINAL"))
			return ESTATUS_FINALIZADA;
		return null;
	}

	private Long mapEstatusEntradaAId(String estatus) {
		if (isBlank(estatus))
			return null;
		String e = estatus.trim().toUpperCase();
		if (e.contains("CREAD"))
			return ESTATUS_CREADA;
		if (e.contains("ATEN"))
			return ESTATUS_EN_ATENCION;
		if (e.contains("RECHAZ"))
			return ESTATUS_RECHAZADA;
		if (e.contains("FINAL"))
			return ESTATUS_FINALIZADA;
		return null;
	}

	private String mapEstatusIdAClave(Long idEstatus) {
		if (idEstatus == null)
			return null;
		long v = idEstatus.longValue();
		if (v == ESTATUS_CREADA)
			return "CREADA";
		if (v == ESTATUS_EN_ATENCION)
			return "EN ATENCIÓN";
		if (v == ESTATUS_RECHAZADA)
			return "RECHAZADA";
		if (v == ESTATUS_FINALIZADA)
			return "FINALIZADA";
		return String.valueOf(v);
	}

	private Long resolverResponsabilidadPorEstatus(Long idEstatusNuevo) {
		if (idEstatusNuevo == null) {
			return RESP_MANTENIMIENTO; // Fallback
		}

		// REGLA BD: Si es CREADA -> Responsabilidad ID 1 (Concesionario)
		// Aunque visualmente el "Pendiente" sea de Mtto, el dueño del registro es Concesionario
		if (idEstatusNuevo.longValue() == ESTATUS_CREADA) {
			return RESP_CONCESIONARIO;
		}

		// Para todo lo demás (Atención, Fin, etc) -> Mantenimiento (ID 2)
		return RESP_MANTENIMIENTO;
	}

	private Long mapTipoEntradaAId(String tipo) {
		if (isBlank(tipo))
			return TIPO_INFRAESTRUCTURA_PASIVA;
		String t = tipo.trim().toUpperCase();
		if (t.contains("SITIO"))
			return TIPO_SITIO;
		return TIPO_INFRAESTRUCTURA_PASIVA;
	}

	private String mapTipoIdAEtiqueta(Long idTipo) {
		if (idTipo == null)
			return null;
		if (idTipo == TIPO_SITIO)
			return "Sitio";
		if (idTipo == TIPO_INFRAESTRUCTURA_PASIVA)
			return "Infraestructura Pasiva";
		return String.valueOf(idTipo);
	}

	private void validarSitioActivo(String sitioCodigo) {
		try {
			if (sitiosPort != null && !sitiosPort.existeYActivo(sitioCodigo.trim())) {
				throw new IllegalArgumentException("El sitio no existe o no se encuentra activo.");
			}
		} catch (IllegalArgumentException ex) {
			throw ex;
		} catch (Exception ex) {
			log.warn("Validación sitio fallida.", ex);
		}
	}

	private IncidenciaGestionDto construirDto(Incidencia incidencia, Map<String, String> mapaSitios) {
		IncidenciaGestionDto dto = new IncidenciaGestionDto();

		dto.setIdIncidencia(incidencia.getId());
		dto.setFolio(incidencia.getFolio());
		dto.setIdSitio(incidencia.getIdSitio());

		String nombreSitio = (mapaSitios != null) ? mapaSitios.get(incidencia.getIdSitio()) : null;
		dto.setNombreSitio(!isBlank(nombreSitio) ? nombreSitio : incidencia.getIdSitio());

		dto.setConcesionario(incidencia.getIdConcesionario());

		// 1. ESTATUS (Texto para mostrar)
		dto.setEstatus(mapEstatusIdAClave(incidencia.getIdEstatusIncidencia()));

		// 2. PENDIENTE POR (Calculado con ID para precisión absoluta)
		dto.setPendientePor(resolverPendientePorId(incidencia.getIdEstatusIncidencia()));

		dto.setTipo(mapTipoIdAEtiqueta(incidencia.getIdTipoIncidencia()));
		dto.setDescripcion(incidencia.getDescripcion());

		if (incidencia.getFechaAlta() != null) {
			dto.setFechaCreacion(new SimpleDateFormat(FECHA_PATTERN).format(incidencia.getFechaAlta()));
		}

		String usuario = !isBlank(incidencia.getNombreReporta()) ? incidencia.getNombreReporta()
				: incidencia.getUsuarioAlta();
		dto.setUsuarioCreacion(!isBlank(usuario) ? usuario : "USUARIO DESCONOCIDO");
		dto.setCorreoUsuarioCreacion(
				!isBlank(incidencia.getCorreoReporta()) ? incidencia.getCorreoReporta() : "");

		return dto;
	}

	private boolean cumpleFiltroTexto(String valor, String filtro) {
		if (isBlank(filtro))
			return true;
		if (valor == null)
			return false;
		return valor.contains(filtro.trim());
	}

	private Map<String, String> construirMapaNombreSitio() {
		Map<String, String> mapa = new HashMap<String, String>();
		try {
			List<?> sitios = sitiosPort.listarSitiosVisiblesParaUsuario();
			if (sitios != null) {
				for (Object item : sitios) {
					if (item instanceof SitioDto) {
						SitioDto s = (SitioDto) item;
						if (s != null && !isBlank(s.getSitio()))
							mapa.put(s.getSitio(), s.getNombre());
					}
				}
			}
		} catch (Exception e) {
			log.warn("Error mapa sitios", e);
		}
		return mapa;
	}

	// Método Legacy (se mantiene por compatibilidad si algo lo usa, pero se actualiza el texto)
	private String calcularPendientePor(String estatus) {
		if (estatus == null)
			return "-";
		String e = estatus.trim().toUpperCase();
		
		// CAMBIO: Si está CREADA o EN ATENCIÓN -> Mantenimiento
		if ("CREADA".equals(e) || e.contains("ATEN")) {
			return "Mantenimiento";
		}
		
		return "-";
	}

	// NUEVO Método: Determina "Pendiente Por" basado en el ID del estatus
	private String resolverPendientePorId(Long idEstatus) {
		if (idEstatus == null) {
			return "-";
		}

		long id = idEstatus.longValue();

		// ID 1 (Creada) o ID 2 (En Atención) -> Pendiente: Mantenimiento
		if (id == ESTATUS_CREADA || id == ESTATUS_EN_ATENCION) {
			return "Mantenimiento";
		}

		// ID 3 (Rechazada) o ID 4 (Finalizada) -> Fin del flujo
		return "-";
	}

	@Override
	@Transactional(readOnly = true)
	public String obtenerCorreoExternoPorUsuario(Integer idUsuario, Integer idRol) {
		return incidenciaDao.obtenerCorreoExternoPorUsuario(idUsuario, idRol);
	}

	private String resolverNombreOperadorMovimiento(Long idUsuarioMovimiento) {
		if (idUsuarioMovimiento == null) {
			return null;
		}

		try {
			return incidenciaDao.obtenerNombreCompletoUsuarioPorId(idUsuarioMovimiento.intValue());
		} catch (Exception ex) {
			log.warn("No se pudo resolver nombre de operador para idUsuario={}", idUsuarioMovimiento, ex);
			return null;
		}
	}

}
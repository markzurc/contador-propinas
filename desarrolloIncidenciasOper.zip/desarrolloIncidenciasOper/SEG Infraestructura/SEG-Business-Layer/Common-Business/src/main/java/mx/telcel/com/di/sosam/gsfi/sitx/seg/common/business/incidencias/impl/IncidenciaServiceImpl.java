	package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.impl;
	
	import java.io.IOException;
	import java.nio.file.Files;
	import java.nio.file.Path;
	import java.nio.file.Paths;
	import java.nio.file.StandardOpenOption;
	import java.time.LocalDateTime;
	import java.time.format.DateTimeFormatter;
	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;
	import java.util.regex.Pattern;
	
	import org.slf4j.Logger;
	import org.slf4j.LoggerFactory;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;
	import org.springframework.transaction.annotation.Transactional;
	
	import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.IIncidenciaService;
	import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.IIncidenciaService.AdjuntoUi;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.ISuscripcionSitioService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.Incidencia;
	import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.IncidenciaAdjunto;
	import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.IncidenciaBitacora;
	import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaAdjuntoDao;
	import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaBitacoraDao;
	import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaDao;
	import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaGestionDto;
	import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;
	import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.port.ISitiosQueryPort;
	
	@Service
	@Transactional(rollbackFor = Exception.class)
	public class IncidenciaServiceImpl implements IIncidenciaService {
	
		private static final Logger log = LoggerFactory.getLogger(IncidenciaServiceImpl.class);
	
		@Autowired
		private IIncidenciaDao incidenciaDao;
		@Autowired
		private IIncidenciaBitacoraDao bitacoraDao;
		@Autowired(required = false)
		private IIncidenciaAdjuntoDao adjuntoDao;
		@Autowired
		private ISitiosQueryPort sitiosPort;
		@Autowired(required = false)
		private ISuscripcionSitioService suscripcionSitioService;
		
		private static final long DEF_MAX_BYTES = 10L * 1024L * 1024L;
		private static final int DEF_MAX_ARCHIVOS = 10; 
		private static final String DEF_ALLOW_TYPES = "/(\\.|\\/)(pdf)$/";
		private static final Pattern DEF_EXT_PATTERN = Pattern.compile("(?i).+\\.pdf$");
		private static final String DEF_EXT_HUMAN = "PDF";
		private static final String DEF_RUTA_BASE = "C:/Users/mcruzcas/OneDrive - NTT DATA EMEAL/Desktop/documentacion Seg Telcel";
		private static final DateTimeFormatter FECHA_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
		private static final AtomicLong MOCK_SEQ_BIT = new AtomicLong(1L);
		private static final boolean MODO_MOCK = true;
		private static final List<Incidencia> MOCK_INCIDENCIAS = Collections.synchronizedList(new ArrayList<Incidencia>());
		private static final List<IncidenciaAdjunto> MOCK_ADJUNTOS = Collections.synchronizedList(new ArrayList<IncidenciaAdjunto>());
		private static final List<IncidenciaBitacora> MOCK_BITACORA = Collections.synchronizedList(new ArrayList<IncidenciaBitacora>());
		private static final AtomicLong MOCK_SEQ = new AtomicLong(1L);
		
		
		
		
		
	
		@Override
		public Long crearIncidencia(String sitioCodigo, String tipo, String descripcion, List<AdjuntoUi> adjuntos,
				String usuarioCreacion, String correoUsuarioCreacion, String concesionarioCreacion) {
	
			validarAlta(sitioCodigo, tipo, descripcion, adjuntos);
	
			if (MODO_MOCK) {
				long id = MOCK_SEQ.getAndIncrement();
	
				Incidencia inc = new Incidencia();
				inc.setId(id);
				inc.setSitioId(sitioCodigo);
				inc.setTipo(tipo);
				inc.setDescripcion(descripcion);
				inc.setEstatus("CREADA");
				inc.setCreadaFecha(LocalDateTime.now());
				inc.setFolio(generarFolioMock(id));
				inc.setUsuarioCreacion(usuarioCreacion);
				inc.setCorreoUsuarioCreacion(correoUsuarioCreacion);
				inc.setConcesionario(concesionarioCreacion);
	
				MOCK_INCIDENCIAS.add(inc);
	
				IncidenciaBitacora bit = new IncidenciaBitacora();
				bit.setId(MOCK_SEQ_BIT.getAndIncrement());
	
				bit.setIncidencia(inc);
				bit.setEvento("ALTA");
				bit.setDescripcion("-");
				bit.setFechaEvento(LocalDateTime.now());
				bit.setEstatusAnt(null);
				bit.setEstatusNuevo("CREADA");
	
				bit.setUsuarioId(null);
				MOCK_BITACORA.add(bit);
	
				if (adjuntos != null && !adjuntos.isEmpty()) {
	
					Path carpeta = Paths.get(DEF_RUTA_BASE, String.valueOf(inc.getId()));
					try {
						Files.createDirectories(carpeta);
					} catch (IOException e) {
						log.warn("[MOCK] No se pudo crear el directorio de adjuntos {}", carpeta, e);
					}
	
					for (AdjuntoUi a : adjuntos) {
						try {
	
							validarAdjunto(a.getNombre(), null, a.getTamanio());
	
							Path destino = carpeta.resolve(a.getNombre());
							Files.write(destino, a.getBytes(), StandardOpenOption.CREATE,
									StandardOpenOption.TRUNCATE_EXISTING);
	
							IncidenciaAdjunto adj = new IncidenciaAdjunto();
							adj.setIncidencia(inc);
							adj.setNombre(a.getNombre());
							adj.setTamanioBytes(a.getTamanio());
							adj.setRuta("/" + inc.getId() + "/" + a.getNombre());
							adj.setExtension(obtenerExtension(a.getNombre()));
							adj.setCargadoPorId(1L);
							adj.setCargadoFecha(LocalDateTime.now());
	
							MOCK_ADJUNTOS.add(adj);
	
							log.info("[MOCK] Se guardó adjunto de incidencia {} en {}", inc.getId(), destino);
						} catch (Exception ex) {
							log.error("[MOCK] Error al procesar adjunto {} para incidencia {}", a.getNombre(), inc.getId(),
									ex);
						}
					}
				} else {
					log.info("[MOCK] Incidencia {} sin adjuntos", inc.getId());
				}
	
				return inc.getId();
			}
	
			Incidencia inc = new Incidencia();
			inc.setSitioId(sitioCodigo);
			inc.setTipo(tipo);
			inc.setDescripcion(descripcion);
			inc.setEstatus("CREADA");
			inc.setCreadaFecha(LocalDateTime.now());
			inc.setUsuarioCreacion(usuarioCreacion);
			inc.setCorreoUsuarioCreacion(correoUsuarioCreacion);
			inc.setConcesionario(concesionarioCreacion);
	
			incidenciaDao.persist(inc);
	
			inc.setFolio(generarFolioMock(inc.getId()));
			incidenciaDao.merge(inc);
	
			IncidenciaBitacora bit = new IncidenciaBitacora();
			bit.setIncidencia(inc);
			bit.setEvento("ALTA");
			bit.setDescripcion("Alta de incidencia");
			bit.setFechaEvento(LocalDateTime.now());
			bit.setEstatusAnt(null);
			bit.setEstatusNuevo("CREADA");
	
			bit.setUsuarioId(null);
	
			bitacoraDao.persist(bit);
	
			if (adjuntos != null && !adjuntos.isEmpty()) {
				Path carpeta = Paths.get(DEF_RUTA_BASE, String.valueOf(inc.getId()));
				try {
					Files.createDirectories(carpeta);
				} catch (IOException e) {
					log.warn("No se pudo crear el directorio de adjuntos {}", carpeta, e);
				}
	
				for (AdjuntoUi a : adjuntos) {
					validarAdjunto(a.getNombre(), null, a.getTamanio());
	
					Path destino = carpeta.resolve(a.getNombre());
					try {
						Files.write(destino, a.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
					} catch (IOException ex) {
						throw new IllegalStateException("No fue posible guardar el archivo: " + a.getNombre(), ex);
					}
	
					IncidenciaAdjunto adj = new IncidenciaAdjunto();
					adj.setIncidencia(inc);
					adj.setNombre(a.getNombre());
					adj.setTamanioBytes(a.getTamanio());
					adj.setRuta("/" + inc.getId() + "/" + a.getNombre());
					adj.setExtension(obtenerExtension(a.getNombre()));
					adj.setCargadoPorId(1L);
					adj.setCargadoFecha(LocalDateTime.now());
	
					adjuntoDao.persist(adj);
				}
			}
	
			return inc.getId();
		}
	
		@Override
		public void validarAlta(String sitioCodigo, String tipo, String descripcion, List<AdjuntoUi> adjuntos) {
	
			if (sitioCodigo == null || sitioCodigo.trim().isEmpty()) {
				throw new IllegalArgumentException("El sitio es obligatorio.");
			}
			if (tipo == null || tipo.trim().isEmpty()) {
				throw new IllegalArgumentException("El tipo de incidencia es obligatorio.");
			}
			if (descripcion == null || descripcion.trim().isEmpty()) {
				throw new IllegalArgumentException("La descripción es obligatoria.");
			}
	
			if (adjuntos == null || adjuntos.isEmpty()) {
				throw new IllegalArgumentException(
						"Debe adjuntar al menos un archivo PDF como evidencia de la incidencia.");
			}
	
	
			long total = 0L;
			for (AdjuntoUi a : adjuntos) {
				if (a == null) {
					continue;
				}
				validarAdjunto(a.getNombre(), null, a.getTamanio());
				total += a.getTamanio();
			}
	
			long maxTotal = obtenerMaxBytesAdjunto(); // 10MB (total permitido en ALTA)
			if (total > maxTotal) {
				throw new IllegalArgumentException(
				        "El total de evidencias no debe exceder " + (maxTotal / (1024 * 1024)) + " MB.");
	
			}
	
		}
	
		@Override
		public Long crearIncidenciaExternaCargaMasiva(String sitioCodigo, String tipo, String descripcion,
				String usuarioCreacion, String correoUsuarioCreacion, String concesionarioCreacion, String estatusInicial) {
	
			if (sitioCodigo == null || sitioCodigo.trim().isEmpty())
				throw new IllegalArgumentException("El sitio es obligatorio.");
			if (tipo == null || tipo.trim().isEmpty())
				throw new IllegalArgumentException("El tipo de incidencia es obligatorio.");
			if (descripcion == null || descripcion.trim().isEmpty())
				throw new IllegalArgumentException("La descripción es obligatoria.");
			if (usuarioCreacion == null || usuarioCreacion.trim().isEmpty())
				throw new IllegalArgumentException("El nombre de quien reporta es obligatorio.");
			if (correoUsuarioCreacion == null || correoUsuarioCreacion.trim().isEmpty())
				throw new IllegalArgumentException("El correo de quien reporta es obligatorio.");
			if (concesionarioCreacion == null || concesionarioCreacion.trim().isEmpty())
				throw new IllegalArgumentException("El concesionario es obligatorio.");
			if (estatusInicial == null || estatusInicial.trim().isEmpty())
				throw new IllegalArgumentException("El estatus es obligatorio.");
	
			if (!MODO_MOCK) {
				throw new UnsupportedOperationException("Carga masiva externa no implementada en modo NO-MOCK.");
			}
			
	
			long id = MOCK_SEQ.getAndIncrement();
	
			Incidencia inc = new Incidencia();
			inc.setId(id);
			inc.setSitioId(sitioCodigo.trim());
			inc.setTipo(tipo.trim());
			inc.setDescripcion(descripcion.trim());
	
			inc.setEstatus(estatusInicial.trim().toUpperCase());
	
			inc.setCreadaFecha(LocalDateTime.now());
			inc.setFolio(generarFolioMock(id));
	
			inc.setUsuarioCreacion(usuarioCreacion.trim());
			inc.setCorreoUsuarioCreacion(correoUsuarioCreacion.trim());
			inc.setConcesionario(concesionarioCreacion.trim());
	
			MOCK_INCIDENCIAS.add(inc);
	
			IncidenciaBitacora bit = new IncidenciaBitacora();
			bit.setId(MOCK_SEQ_BIT.getAndIncrement());
	
			bit.setIncidencia(inc);
			bit.setEvento("CARGA MASIVA");
			bit.setDescripcion("-");
			bit.setFechaEvento(LocalDateTime.now());
			bit.setEstatusAnt(null);
			bit.setEstatusNuevo(inc.getEstatus());
			bit.setUsuarioId(null);
			MOCK_BITACORA.add(bit);
	
			return inc.getId();
		}
	
		@Override
		public void validarAdjunto(String nombre, String contentType, long size) {
			if (size <= 0) {
				throw new IllegalArgumentException("Archivo vacío o inválido.");
			}
			if (size > obtenerMaxBytesAdjunto()) {
				long maxMb = obtenerMaxBytesAdjunto() / 1024 / 1024;
				throw new IllegalArgumentException("El archivo no debe exceder " + maxMb + " MB.");
			}
			if (isBlank(nombre) || !DEF_EXT_PATTERN.matcher(nombre).matches()) {
				throw new IllegalArgumentException("Extensión no permitida en " + nombre + ". Formatos: " + DEF_EXT_HUMAN);
			}
		}
	
		@Override
		public List<?> listarSitiosEnOperacionVisibles() {
			return sitiosPort.listarSitiosVisiblesParaUsuario();
		}
	
		@Override
		public List<String> catalogoTiposIncidencia() {
			List<String> lista = new ArrayList<String>();
			lista.add("Infraestructura Pasiva");
			lista.add("Sitio");
			return lista;
		}
	
		@Override
		public long obtenerMaxBytesAdjunto() {
			return DEF_MAX_BYTES;
		}
	
		@Override
		public int obtenerMaxArchivos() {
			return DEF_MAX_ARCHIVOS;
		}
	
		@Override
		public String obtenerRegexExtensiones() {
			return DEF_ALLOW_TYPES;
		}
	
		@Override
		public String obtenerFormatosHumanos() {
			return DEF_EXT_HUMAN;
		}
		
		@Override
		public String generarFolioIncidencia(Long idIncidencia) {
		    if (idIncidencia == null) {
		        return null;
		    }
		    return generarFolioMock(idIncidencia.longValue());
		}

	
		@Override
		public List<IncidenciaGestionDto> buscarIncidenciasMantenimiento(String folio, String sitioId, String estatus) {
	
			if (MODO_MOCK) {
	
				List<IncidenciaGestionDto> resultado = new ArrayList<IncidenciaGestionDto>();
	
				List<?> listaSitios = null;
				try {
					if (sitiosPort != null) {
						listaSitios = sitiosPort.listarSitiosVisiblesParaUsuario();
					}
				} catch (Exception e) {
					log.error("Error al consultar servicio de sitios (MOCK)", e);
				}
	
				for (Incidencia inc : MOCK_INCIDENCIAS) {
	
					if (folio != null && !folio.trim().isEmpty()
							&& (inc.getFolio() == null || !inc.getFolio().contains(folio.trim()))) {
						continue;
					}
					if (sitioId != null && !sitioId.trim().isEmpty()
							&& (inc.getSitioId() == null || !inc.getSitioId().contains(sitioId.trim()))) {
						continue;
					}
					if (estatus != null && !estatus.trim().isEmpty()
							&& (inc.getEstatus() == null || !inc.getEstatus().equalsIgnoreCase(estatus.trim()))) {
						continue;
					}
	
					IncidenciaGestionDto dto = new IncidenciaGestionDto();
					dto.setIdIncidencia(inc.getId());
					dto.setFolio(inc.getFolio());
					dto.setIdSitio(inc.getSitioId());
					dto.setEstatus(inc.getEstatus());
					dto.setCorreoUsuarioCreacion(inc.getCorreoUsuarioCreacion());
					dto.setTipo(inc.getTipo());
					dto.setDescripcion(inc.getDescripcion());
	
					if (inc.getCreadaFecha() != null) {
						dto.setFechaCreacion(inc.getCreadaFecha().format(FECHA_FORMAT));
					}
	
					DatosSitioEncontrado datosSitio = buscarDetallesSitio(listaSitios, inc.getSitioId());
					if (datosSitio.nombre != null && !datosSitio.nombre.trim().isEmpty()) {
						dto.setNombreSitio(datosSitio.nombre);
					} else {
						dto.setNombreSitio(inc.getSitioId());
					}
	
					dto.setConcesionario(soloNombreConcesionario(inc.getConcesionario()));
	
					if (inc.getUsuarioCreacion() != null && !inc.getUsuarioCreacion().trim().isEmpty()) {
	
						dto.setUsuarioCreacion(inc.getUsuarioCreacion());
	
					} else {
						dto.setUsuarioCreacion("USUARIO DESCONOCIDO");
						dto.setCorreoUsuarioCreacion("");
					}
	
					if (inc.getCorreoUsuarioCreacion() != null && !inc.getCorreoUsuarioCreacion().trim().isEmpty()) {
						dto.setCorreoUsuarioCreacion(inc.getCorreoUsuarioCreacion());
					} else {
						dto.setCorreoUsuarioCreacion("");
					}
	
					dto.setPendientePor(calcularPendientePor(inc.getEstatus()));
	
					resultado.add(dto);
				}
	
				log.debug("MOCK buscarIncidenciasMantenimiento() -> {} registros (solo mock)", resultado.size());
				return resultado;
			}
	
			List<?> listaSitios = null;
			try {
				if (sitiosPort != null) {
					listaSitios = sitiosPort.listarSitiosVisiblesParaUsuario();
				}
			} catch (Exception e) {
				log.error("Error al consultar servicio de sitios (REAL)", e);
			}
	
			List<Incidencia> entidades = incidenciaDao.findByFiltros(folio, sitioId, estatus);
			List<IncidenciaGestionDto> resultado = new ArrayList<IncidenciaGestionDto>();
	
			for (Incidencia inc : entidades) {
				IncidenciaGestionDto dto = new IncidenciaGestionDto();
				dto.setIdIncidencia(inc.getId());
				dto.setFolio(inc.getFolio());
				dto.setIdSitio(inc.getSitioId());
				dto.setEstatus(inc.getEstatus());
	
				dto.setTipo(inc.getTipo());
				dto.setDescripcion(inc.getDescripcion());
	
				if (inc.getCreadaFecha() != null) {
					dto.setFechaCreacion(inc.getCreadaFecha().format(FECHA_FORMAT));
				}
	
				DatosSitioEncontrado datosSitio = buscarDetallesSitio(listaSitios, inc.getSitioId());
				if (datosSitio.nombre != null && !datosSitio.nombre.trim().isEmpty()) {
					dto.setNombreSitio(datosSitio.nombre);
				} else {
					dto.setNombreSitio(inc.getSitioId());
				}
	
				dto.setConcesionario(inc.getConcesionario());
	
				if (inc.getUsuarioCreacion() != null && !inc.getUsuarioCreacion().trim().isEmpty()) {
					dto.setUsuarioCreacion(inc.getUsuarioCreacion());
					 dto.setCorreoUsuarioCreacion(inc.getUsuarioCreacion());
				} else {
					dto.setUsuarioCreacion("USUARIO DESCONOCIDO");
					dto.setCorreoUsuarioCreacion("");
				}
	
				if (inc.getCorreoUsuarioCreacion() != null && !inc.getCorreoUsuarioCreacion().trim().isEmpty()) {
					dto.setCorreoUsuarioCreacion(inc.getCorreoUsuarioCreacion());
				} else {
					dto.setCorreoUsuarioCreacion("");
				}
	
				dto.setPendientePor(calcularPendientePor(inc.getEstatus()));
	
				resultado.add(dto);
			}
	
			log.debug("buscarIncidenciasMantenimiento() -> {} registros (BD)", resultado.size());
			return resultado;
		}
	
		@Override
		@Transactional(readOnly = true)
		public List<IncidenciaGestionDto> buscarIncidenciasConcesionario(String folio, String sitioId, String estatus,
	
				String concesionario) {
	
			concesionario = (concesionario != null) ? concesionario.trim() : null;
			if (concesionario == null || concesionario.isEmpty()) {
				log.warn("buscarIncidenciasConcesionario(): concesionario vacío; se devuelve lista vacía.");
				return Collections.emptyList();
			}
	
			if (MODO_MOCK) {
				List<?> listaSitios = null;
				try {
					if (sitiosPort != null) {
						listaSitios = sitiosPort.listarSitiosVisiblesParaUsuario();
					}
				} catch (Exception e) {
					log.error("Error al consultar servicio de sitios (MOCK) [concesionario]", e);
				}
	
				List<IncidenciaGestionDto> resultado = new ArrayList<IncidenciaGestionDto>();
	
				for (Incidencia inc : MOCK_INCIDENCIAS) {
	
					if (concesionario != null && !concesionario.trim().isEmpty()) {
						String concEntidad = soloNombreConcesionario(inc.getConcesionario());
						if (concEntidad == null || !concEntidad.equalsIgnoreCase(concesionario.trim())) {
							continue;
						}
					}
	
					if (folio != null && !folio.trim().isEmpty()
							&& (inc.getFolio() == null || !inc.getFolio().contains(folio.trim()))) {
						continue;
					}
					if (sitioId != null && !sitioId.trim().isEmpty()
							&& (inc.getSitioId() == null || !inc.getSitioId().contains(sitioId.trim()))) {
						continue;
					}
					if (estatus != null && !estatus.trim().isEmpty()
							&& (inc.getEstatus() == null || !inc.getEstatus().equalsIgnoreCase(estatus.trim()))) {
						continue;
					}
	
					IncidenciaGestionDto dto = new IncidenciaGestionDto();
					dto.setIdIncidencia(inc.getId());
					dto.setFolio(inc.getFolio());
					dto.setIdSitio(inc.getSitioId());
					dto.setEstatus(inc.getEstatus());
					dto.setTipo(inc.getTipo());
					dto.setDescripcion(inc.getDescripcion());
	
					if (inc.getCreadaFecha() != null) {
						dto.setFechaCreacion(inc.getCreadaFecha().format(FECHA_FORMAT));
					}
	
					DatosSitioEncontrado datosSitio = buscarDetallesSitio(listaSitios, inc.getSitioId());
					if (datosSitio.nombre != null && !datosSitio.nombre.trim().isEmpty()) {
						dto.setNombreSitio(datosSitio.nombre);
					} else {
						dto.setNombreSitio(inc.getSitioId());
					}
	
					dto.setConcesionario(soloNombreConcesionario(inc.getConcesionario()));
	
					if (inc.getUsuarioCreacion() != null && !inc.getUsuarioCreacion().trim().isEmpty()) {
						dto.setUsuarioCreacion(inc.getUsuarioCreacion());
					} else {
						dto.setUsuarioCreacion("USUARIO DESCONOCIDO");
					}
	
					if (inc.getCorreoUsuarioCreacion() != null && !inc.getCorreoUsuarioCreacion().trim().isEmpty()) {
						dto.setCorreoUsuarioCreacion(inc.getCorreoUsuarioCreacion());
					} else {
						dto.setCorreoUsuarioCreacion("");
					}
	
					dto.setPendientePor(calcularPendientePor(inc.getEstatus()));
	
					resultado.add(dto);
				}
	
				log.debug("buscarIncidenciasConcesionario() MOCK -> {} registros", resultado.size());
				return resultado;
			}
	
			List<?> listaSitios = null;
			try {
				if (sitiosPort != null) {
					listaSitios = sitiosPort.listarSitiosVisiblesParaUsuario();
				}
			} catch (Exception e) {
				log.error("Error al consultar servicio de sitios (REAL) [concesionario]", e);
			}
	
			List<Incidencia> entidades = incidenciaDao.findByConcesionarioAndFiltros(concesionario, folio, sitioId,
					estatus);
	
			List<IncidenciaGestionDto> resultado = new ArrayList<IncidenciaGestionDto>();
	
			for (Incidencia inc : entidades) {
				IncidenciaGestionDto dto = new IncidenciaGestionDto();
				dto.setIdIncidencia(inc.getId());
				dto.setFolio(inc.getFolio());
				dto.setIdSitio(inc.getSitioId());
				dto.setEstatus(inc.getEstatus());
				dto.setTipo(inc.getTipo());
				dto.setDescripcion(inc.getDescripcion());
	
				if (inc.getCreadaFecha() != null) {
					dto.setFechaCreacion(inc.getCreadaFecha().format(FECHA_FORMAT));
				}
	
				DatosSitioEncontrado datosSitio = buscarDetallesSitio(listaSitios, inc.getSitioId());
				if (datosSitio.nombre != null && !datosSitio.nombre.trim().isEmpty()) {
					dto.setNombreSitio(datosSitio.nombre);
				} else {
					dto.setNombreSitio(inc.getSitioId());
				}
	
				dto.setConcesionario(soloNombreConcesionario(inc.getConcesionario()));
	
				if (inc.getUsuarioCreacion() != null && !inc.getUsuarioCreacion().trim().isEmpty()) {
					dto.setUsuarioCreacion(inc.getUsuarioCreacion());
				} else {
					dto.setUsuarioCreacion("USUARIO DESCONOCIDO");
				}
	
				if (inc.getCorreoUsuarioCreacion() != null && !inc.getCorreoUsuarioCreacion().trim().isEmpty()) {
					dto.setCorreoUsuarioCreacion(inc.getCorreoUsuarioCreacion());
				} else {
					dto.setCorreoUsuarioCreacion("");
				}
	
				dto.setPendientePor(calcularPendientePor(inc.getEstatus()));
	
				resultado.add(dto);
			}
	
			log.debug("buscarIncidenciasConcesionario() -> {} registros (BD)", resultado.size());
			return resultado;
		}
	
		@Override
		@Transactional(readOnly = true)
		public List<IncidenciaBitacora> obtenerBitacoraIncidencia(Long idIncidencia) {
			if (idIncidencia == null) {
				return Collections.emptyList();
			}
	
			if (MODO_MOCK) {
				List<IncidenciaBitacora> res = new ArrayList<IncidenciaBitacora>();
				for (IncidenciaBitacora b : MOCK_BITACORA) {
					if (b.getIncidencia() != null && b.getIncidencia().getId() != null
							&& b.getIncidencia().getId().equals(idIncidencia)) {
						res.add(b);
					}
				}
				return res;
			}
	
			return bitacoraDao.findByIncidencia(idIncidencia);
		}
	
		@Override
		public void avanzarIncidencia(Long idIncidencia, String accion, String comentario, Long idUsuarioMovimiento) {
	
			if (idIncidencia == null) {
				throw new IllegalArgumentException("idIncidencia es obligatorio");
			}
			if (accion == null || accion.trim().isEmpty()) {
				throw new IllegalArgumentException("La acción es obligatoria");
			}
	
			String nuevoEstatus = mapAccionAEstatus(accion);
	
			if (MODO_MOCK) {
				Incidencia incEncontrada = null;
				for (Incidencia inc : MOCK_INCIDENCIAS) {
					if (idIncidencia.equals(inc.getId())) {
						incEncontrada = inc;
						break;
					}
				}
				if (incEncontrada == null) {
					log.warn("[MOCK] No se encontró incidencia con id {}", idIncidencia);
					return;
				}
	
				String estatusAnt = incEncontrada.getEstatus();
				incEncontrada.setEstatus(nuevoEstatus);
	
				IncidenciaBitacora bit = new IncidenciaBitacora();
				bit.setIncidencia(incEncontrada);
				bit.setEvento("CAMBIO_ESTATUS");
				bit.setDescripcion(comentario != null ? comentario : "");
				bit.setFechaEvento(LocalDateTime.now());
				bit.setEstatusAnt(estatusAnt);
				bit.setEstatusNuevo(nuevoEstatus);
	
				if (idUsuarioMovimiento != null) {
					bit.setUsuarioId(idUsuarioMovimiento);
				} else {
					bit.setUsuarioId(null);
				}
	
				MOCK_BITACORA.add(bit);
				return;
			}
	
			Incidencia inc = incidenciaDao.findById(idIncidencia).orElse(null);
			if (inc == null) {
				log.warn("No se encontró incidencia con id {} (BD)", idIncidencia);
				return;
			}
	
			String estatusAnt = inc.getEstatus();
			inc.setEstatus(nuevoEstatus);
			incidenciaDao.merge(inc);
	
			IncidenciaBitacora bit = new IncidenciaBitacora();
			bit.setIncidencia(inc);
			bit.setEvento("CAMBIO_ESTATUS");
			bit.setDescripcion(comentario != null ? comentario : "");
			bit.setFechaEvento(LocalDateTime.now());
			bit.setEstatusAnt(estatusAnt);
			bit.setEstatusNuevo(nuevoEstatus);
	
			if (idUsuarioMovimiento != null) {
				bit.setUsuarioId(idUsuarioMovimiento);
			} else {
				bit.setUsuarioId(null);
			}
	
			bitacoraDao.persist(bit);
		}
	
		private String mapAccionAEstatus(String accion) {
			String a = accion.trim().toUpperCase();
			if (a.contains("RECHAZ")) {
				return "RECHAZADA";
			}
			if (a.contains("ATEN")) {
				return "EN ATENCIÓN";
			}
			if (a.contains("FINAL")) {
				return "FINALIZADA";
			}
			return a;
		}
	
		private String soloNombreConcesionario(String valor) {
			if (valor == null) {
				return null;
			}
			String v = valor.trim();
			if (v.isEmpty()) {
				return v;
			}
			int idx = v.indexOf(':');
			if (idx >= 0 && idx + 1 < v.length()) {
				return v.substring(idx + 1).trim();
			}
			return v;
		}
	
		private static String generarFolioMock(long id) {
			return String.format("IN-%06d", id);
		}
	
		private static boolean isBlank(String s) {
			return s == null || s.trim().isEmpty();
		}
	
		private String obtenerExtension(String nombre) {
			if (nombre == null)
				return null;
			int idx = nombre.lastIndexOf('.');
			if (idx == -1 || idx == nombre.length() - 1) {
				return null;
			}
			return nombre.substring(idx + 1);
		}
	
		@Override
		public void adjuntarEvidenciaIncidencia(Long idIncidencia, AdjuntoUi adjunto, Long idUsuarioMovimiento)
				throws IOException {
	
			if (idIncidencia == null) {
				throw new IllegalArgumentException("idIncidencia es obligatorio.");
			}
	
			if (adjunto == null) {
				throw new IllegalArgumentException("Adjunto es obligatorio.");
			}
			if (adjunto.getBytes() == null || adjunto.getBytes().length == 0) {
				throw new IllegalArgumentException("Archivo vacío o inválido.");
			}
			validarAdjunto(adjunto.getNombre(), null, adjunto.getTamanio());
	
			List<IncidenciaAdjunto> existentes = obtenerAdjuntosIncidencia(idIncidencia);
			int usados = (existentes != null) ? existentes.size() : 0;
			// OPCIONAL: límite total por incidencia = 10MB
			long totalExistente = 0L;
			if (existentes != null) {
				for (IncidenciaAdjunto a : existentes) {
					if (a != null && a.getTamanioBytes() != null)
						totalExistente += a.getTamanioBytes();
				}
			}
			long totalNuevo = totalExistente + adjunto.getTamanio();
			if (totalNuevo > obtenerMaxBytesAdjunto()) {
				throw new IllegalArgumentException("El tamaño total de evidencias excede 10 MB para la incidencia.");
			}
	
			if (usados >= obtenerMaxArchivos()) {
				throw new IllegalStateException("La incidencia ya cuenta con el máximo de archivos permitidos.");
			}
	
			// Sanitiza nombre para evitar rutas raras
			String nombreOriginal = (adjunto.getNombre() != null) ? adjunto.getNombre().trim() : "evidencia.pdf";
			String nombreSeguro = nombreOriginal.replace("\\", "/");
			if (nombreSeguro.contains("/")) {
				nombreSeguro = nombreSeguro.substring(nombreSeguro.lastIndexOf('/') + 1);
			}
			nombreSeguro = nombreSeguro.replaceAll("[^a-zA-Z0-9._-]", "_");
			if (!nombreSeguro.toLowerCase().endsWith(".pdf")) {
				nombreSeguro = nombreSeguro + ".pdf";
			}
	
			String extension = "pdf";
			int idx = nombreSeguro.lastIndexOf('.');
			if (idx >= 0 && idx + 1 < nombreSeguro.length()) {
				extension = nombreSeguro.substring(idx + 1).toLowerCase();
			}
	
			// Guarda en filesystem bajo la misma convención:
			// {DEF_RUTA_BASE}/{idIncidencia}/{archivo}
			Path carpeta = Paths.get(DEF_RUTA_BASE, String.valueOf(idIncidencia));
			Files.createDirectories(carpeta);
	
			Path destino = carpeta.resolve(nombreSeguro);
			if (Files.exists(destino)) {
				// agrega sufijo timestamp
				String base = nombreSeguro.replaceAll("(?i)\\.pdf$", "");
				String sufijo = "_" + System.currentTimeMillis();
				nombreSeguro = base + sufijo + ".pdf";
				destino = carpeta.resolve(nombreSeguro);
			}
	
			Files.write(destino, adjunto.getBytes(), StandardOpenOption.CREATE_NEW);
			String rutaRelativa = "/" + idIncidencia + "/" + nombreSeguro;
	
			if (MODO_MOCK) {
				Incidencia inc = null;
				for (Incidencia x : MOCK_INCIDENCIAS) {
					if (x != null && x.getId() != null && x.getId().equals(idIncidencia)) {
						inc = x;
						break;
					}
				}
				if (inc == null) {
					throw new IllegalArgumentException("No existe la incidencia (mock) con id=" + idIncidencia);
				}
	
				IncidenciaAdjunto ia = new IncidenciaAdjunto();
				// ia.setId(ID_SEQ_ADJ.getAndIncrement()); // eliminar
	
				ia.setIncidencia(inc);
				ia.setNombre(nombreSeguro);
				ia.setExtension(extension);
				ia.setTamanioBytes((long) adjunto.getBytes().length);
				ia.setRuta(rutaRelativa);
				ia.setCargadoPorId(idUsuarioMovimiento);
				ia.setCargadoFecha(LocalDateTime.now());
	
				MOCK_ADJUNTOS.add(ia);
				return;
			}
	
			// BD real
			Incidencia inc = incidenciaDao.findById(idIncidencia).orElse(null);
			if (inc == null) {
				throw new IllegalArgumentException("No existe la incidencia con id=" + idIncidencia);
			}
	
			IncidenciaAdjunto ia = new IncidenciaAdjunto();
			ia.setIncidencia(inc);
			ia.setNombre(nombreSeguro);
			ia.setExtension(extension);
			ia.setTamanioBytes((long) adjunto.getBytes().length);
			ia.setRuta(rutaRelativa);
			ia.setCargadoPorId(idUsuarioMovimiento);
			ia.setCargadoFecha(LocalDateTime.now());
	
			adjuntoDao.persist(ia);
		}
	
		
		
		
		@Override
		public void eliminarEvidenciaIncidencia(Long idIncidencia, String rutaRelativa, Long idUsuarioMovimiento) throws IOException {

		    if (idIncidencia == null) {
		        throw new IllegalArgumentException("idIncidencia es obligatorio.");
		    }
		    if (isBlank(rutaRelativa)) {
		        throw new IllegalArgumentException("rutaRelativa es obligatoria.");
		    }

		    final String rutaNorm = normalizarRuta(rutaRelativa);
		    final Path archivoAbs = resolverPathSeguroDesdeRuta(rutaNorm);

		    if (MODO_MOCK) {
		        IncidenciaAdjunto target = null;

		        synchronized (MOCK_ADJUNTOS) {
		            for (IncidenciaAdjunto a : MOCK_ADJUNTOS) {
		                if (a == null || a.getIncidencia() == null || a.getIncidencia().getId() == null) continue;

		                if (idIncidencia.equals(a.getIncidencia().getId())
		                        && rutaNorm.equals(normalizarRuta(a.getRuta()))) {
		                    target = a;
		                    break;
		                }
		            }
		            if (target == null) {
		                throw new IllegalArgumentException("No se encontró el adjunto (MOCK) para ruta=" + rutaNorm);
		            }
		            MOCK_ADJUNTOS.remove(target);
		        }

		        try {
		            Files.deleteIfExists(archivoAbs);
		        } catch (IOException ex) {
		            // En mock, no rompas flujo por falla de FS
		            log.warn("[MOCK] No se pudo borrar archivo físico {}", archivoAbs, ex);
		        }

		        return;
		    }

		    // REAL: busca el adjunto dentro de los adjuntos de la incidencia
		    List<IncidenciaAdjunto> adjuntos = adjuntoDao.findByIncidencia(idIncidencia);
		    IncidenciaAdjunto target = null;

		    if (adjuntos != null) {
		        for (IncidenciaAdjunto a : adjuntos) {
		            if (a == null) continue;
		            if (rutaNorm.equals(normalizarRuta(a.getRuta()))) {
		                target = a;
		                break;
		            }
		        }
		    }

		    if (target == null) {
		        throw new IllegalArgumentException("No se encontró el adjunto para la incidencia y ruta indicada.");
		    }

		    // 1) Borra archivo físico
		    Files.deleteIfExists(archivoAbs);

		    // 2) Borra registro BD
		    // Requiere que tu DAO tenga remove/delete (ver punto 3)
		    adjuntoDao.remove(target);

		    log.info("Evidencia eliminada: incidencia={} ruta={} user={}", idIncidencia, rutaNorm, idUsuarioMovimiento);
		}

		
		
		
		
		private String calcularPendientePor(String estatus) {
			if (estatus == null) {
				return "-";
			}
			String e = estatus.trim().toUpperCase();
			if ("CREADA".equals(e)) {
				return "Concesionario";
			}
			if ("EN_REVISION".equals(e) || "EN REVISIÓN".equals(e)) {
				return "Ingeniería";
			}
			if ("EN_MANTENIMIENTO".equals(e) || "EN MANTENIMIENTO".equals(e)) {
				return "Operación";
			}
			if ("CERRADA".equals(e) || "CERRADO".equals(e)) {
				return "-";
			}
			if ("RECHAZADA".equals(e)) {
				return "Concesionario";
			}
			if ("EN ATENCIÓN".equals(e)) {
				return "Operación";
			}
			if ("FINALIZADA".equals(e)) {
				return "-";
			}
			return "-";
		}
	
		@SuppressWarnings("unused")
		private String calcularPendiente(String estatus) {
			return calcularPendientePor(estatus);
		}
	
		private static class DatosSitioEncontrado {
			String nombre;
			String concesionario;
		}
	
		@Override
		@Transactional(readOnly = true)
		public List<IncidenciaAdjunto> obtenerAdjuntosIncidencia(Long idIncidencia) {
			if (idIncidencia == null) {
				return Collections.emptyList();
			}
	
			if (MODO_MOCK) {
				List<IncidenciaAdjunto> res = new ArrayList<>();
				for (IncidenciaAdjunto a : MOCK_ADJUNTOS) {
					if (a != null && a.getIncidencia() != null && idIncidencia.equals(a.getIncidencia().getId())) {
						res.add(a);
					}
				}
				return res;
			}
	
			return adjuntoDao.findByIncidencia(idIncidencia);
		}
	
		@SuppressWarnings("unchecked")
		private DatosSitioEncontrado buscarDetallesSitio(Object listaSitios, String sitioId) {
			DatosSitioEncontrado datos = new DatosSitioEncontrado();
			if (listaSitios == null || !(listaSitios instanceof List) || sitioId == null) {
				return datos;
			}
	
			try {
				for (SitioDto dto : (List<SitioDto>) listaSitios) {
					if (dto != null && sitioId.equals(dto.getSitio())) {
						datos.nombre = dto.getNombre();
						datos.concesionario = dto.getConcesionario();
						break;
					}
				}
			} catch (ClassCastException e) {
				log.error("Error al castear lista de sitios", e);
			}
	
			return datos;
		}
		private String normalizarRuta(String ruta) {
		    if (ruta == null) return null;
		    String r = ruta.trim().replace("\\", "/");
		    if (!r.startsWith("/")) r = "/" + r;
		    return r;
		}

		private Path resolverPathSeguroDesdeRuta(String rutaNormalizada) {
		    // rutaNormalizada: "/{id}/{archivo.pdf}"
		    String rel = rutaNormalizada.startsWith("/") ? rutaNormalizada.substring(1) : rutaNormalizada;

		    Path base = Paths.get(DEF_RUTA_BASE).toAbsolutePath().normalize();
		    Path abs = base.resolve(rel).toAbsolutePath().normalize();

		    // Prevención de path traversal
		    if (!abs.startsWith(base)) {
		        throw new IllegalArgumentException("Ruta inválida para el adjunto.");
		    }
		    return abs;
		}
		
		@Override
		public List<?> listarSitiosSuscritosParaAltaIncidencia(String concesionarioUsuario) {

		    List<?> sitiosVisibles = listarSitiosEnOperacionVisibles();

		    if (isBlank(concesionarioUsuario)) {
		        // Si no hay concesionario (por ejemplo mantenimiento), no filtramos.
		        return sitiosVisibles;
		    }

		    if (suscripcionSitioService == null) {
		        log.warn("SuscripciónSitioService no disponible. Se retorna catálogo sin filtrado.");
		        return sitiosVisibles;
		    }

		    Set<String> sitiosSuscritos = suscripcionSitioService.listarSitiosSuscritos(concesionarioUsuario);

		    if (sitiosSuscritos == null || sitiosSuscritos.isEmpty()) {
		        // Concesionario sin suscripciones: en Alta debe quedar vacío.
		        return new ArrayList<Object>();
		    }

		    List<Object> sitiosFiltrados = new ArrayList<Object>();

		    for (Object sitioCandidato : sitiosVisibles) {
		        String sitioIdCandidato = extraerSitioId(sitioCandidato);
		        if (sitioIdCandidato == null) {
		            continue;
		        }

		        String sitioIdNormalizado = sitioIdCandidato.trim().toUpperCase();
		        if (sitiosSuscritos.contains(sitioIdNormalizado)) {
		            sitiosFiltrados.add(sitioCandidato);
		        }
		    }

		    return sitiosFiltrados;
		}

		private String extraerSitioId(Object sitioCandidato) {
		    if (sitioCandidato == null) {
		        return null;
		    }

		    // Caso típico: SitioDto
		    if (sitioCandidato instanceof SitioDto) {
		        return ((SitioDto) sitioCandidato).getSitio();
		    }

		    // Fallback defensivo por reflexión (si regresan otro DTO con getSitio())
		    try {
		        java.lang.reflect.Method metodoGetSitio = sitioCandidato.getClass().getMethod("getSitio");
		        Object valor = metodoGetSitio.invoke(sitioCandidato);
		        return (valor == null) ? null : String.valueOf(valor);
		    } catch (Exception ex) {
		        return null;
		    }
		}

	}

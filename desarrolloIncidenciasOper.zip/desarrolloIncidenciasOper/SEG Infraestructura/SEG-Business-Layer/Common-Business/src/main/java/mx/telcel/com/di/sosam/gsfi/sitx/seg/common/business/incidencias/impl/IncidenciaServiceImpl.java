package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
// --- CAMBIO: Imports de Date ---
import java.util.Date;
import java.text.SimpleDateFormat;
// -----------------------------
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.IIncidenciaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.ISuscripcionSitioService;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.Incidencia;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.IncidenciaAdjunto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.IncidenciaBitacora;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaBitacoraDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaGestionDto;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.port.ISitiosQueryPort;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaAdjuntoDao;

@Service
@Transactional(rollbackFor = Exception.class)
public class IncidenciaServiceImpl implements IIncidenciaService {

    private static final Logger log = LoggerFactory.getLogger(IncidenciaServiceImpl.class);

    // Catálogos
    private static final long ESTATUS_CREADA = 1L;
    private static final long ESTATUS_EN_ATENCION = 2L;
    private static final long ESTATUS_RECHAZADA = 3L;
    private static final long ESTATUS_FINALIZADA = 4L;

    private static final long RESP_CONCESIONARIO = 1L;
    private static final long RESP_MANTENIMIENTO = 2L;

    private static final long TIPO_INFRAESTRUCTURA_PASIVA = 1L;
    private static final long TIPO_SITIO = 2L;

    // Config
    private static final long DEF_MAX_BYTES = 10L * 1024L * 1024L;
    private static final int DEF_MAX_ARCHIVOS = 10;
    private static final String DEF_ALLOW_TYPES = "/(\\.|\\/)(pdf)$/";
    private static final Pattern DEF_EXT_PATTERN = Pattern.compile("(?i).+\\.pdf$");
    private static final String DEF_EXT_HUMAN = "PDF";
    
    // --- CAMBIO: Formato de fecha para Date ---
    private static final String FECHA_PATTERN = "dd/MM/yyyy HH:mm:ss";

    // Mock filesystem
    private static final String DEF_FS_BASE_PATH = "/seg/Incidencias/Solicitudes";
    private final Map<Long, List<IncidenciaAdjunto>> mockAdjuntosPorIncidencia = Collections.synchronizedMap(new HashMap<Long, List<IncidenciaAdjunto>>());
    private final Path fsBasePath = resolverBaseAdjuntos();
    private final boolean mockArchivos = resolverModoMock(fsBasePath);

    @Autowired
    private IIncidenciaDao incidenciaDao;

    @Autowired
    private IIncidenciaBitacoraDao bitacoraDao;

    @Autowired
    private ISitiosQueryPort sitiosPort;

    @Autowired(required = false)
    private ISuscripcionSitioService suscripcionSitioService;

    @PersistenceContext
    private EntityManager entityManager;
    @Autowired
    private IIncidenciaAdjuntoDao incidenciaAdjuntoDao;

    // -------------------------------------------------------------------------
    // Alta
    // -------------------------------------------------------------------------

    @Override
    public Long crearIncidencia(String sitioCodigo,
                               String tipo,
                               String descripcion,
                               List<AdjuntoUi> adjuntos,
                               String usuarioCreacion,
                               String correoUsuarioCreacion,
                               String concesionarioCreacion) {

        validarAlta(sitioCodigo, tipo, descripcion, adjuntos);
        validarSitioActivo(sitioCodigo);

        // 1) Crear incidencia (BD)
        Long idIncidencia = obtenerSiguienteIdIncidenciaConBloqueo();

        Incidencia incidencia = new Incidencia();
        incidencia.setId(idIncidencia);
        incidencia.setFolio(generarFolioIncidencia(idIncidencia));
        incidencia.setIdSitio(sitioCodigo.trim());
        incidencia.setIdConcesionario(valorSeguro(concesionarioCreacion));
        incidencia.setIdTipoIncidencia(mapTipoEntradaAId(tipo));
        incidencia.setIdEstatusIncidencia(ESTATUS_CREADA);
        incidencia.setIdResponsabilidad(RESP_MANTENIMIENTO);
        incidencia.setDescripcion(descripcion.trim());

        incidencia.setOrigenAlta("I");
        incidencia.setNombreReporta(valorSeguro(usuarioCreacion));
        incidencia.setCorreoReporta(valorSeguro(correoUsuarioCreacion));
        incidencia.setUsuarioAlta(valorSeguro(usuarioCreacion));

        // --- CAMBIO: Usar Date ---
        Date ahora = new Date();
        incidencia.setFechaAlta(ahora);
        incidencia.setFechaUltimoMovimiento(ahora);
        incidencia.setUsuarioUltimaModificacion(valorSeguro(usuarioCreacion));
        incidencia.setFechaUltimaModificacion(ahora);

        incidenciaDao.persist(incidencia);

        // 2) Insertar bitácora inicial (BD)
        insertarMovimientoBitacora(
                idIncidencia,
                ESTATUS_CREADA,
                RESP_MANTENIMIENTO,
                "C",
                valorSeguro(usuarioCreacion),
                "ALTA: Incidencia creada",
                null
        );

        // 3) Evidencias
        if (adjuntos != null && !adjuntos.isEmpty()) {
        	guardarAdjuntosIncidenciaAlta(idIncidencia, adjuntos, valorSeguro(usuarioCreacion));
        }

        return idIncidencia;
    }

    @Override
    public void validarAlta(String sitioCodigo, String tipo, String descripcion, List<AdjuntoUi> adjuntos) {
        if (isBlank(sitioCodigo)) throw new IllegalArgumentException("El sitio es obligatorio.");
        if (isBlank(tipo)) throw new IllegalArgumentException("El tipo de incidencia es obligatorio.");
        if (isBlank(descripcion)) throw new IllegalArgumentException("La descripción es obligatoria.");

        if (adjuntos == null || adjuntos.isEmpty()) {
            throw new IllegalArgumentException("Debe adjuntar al menos un archivo PDF como evidencia de la incidencia.");
        }

        long total = 0L;
        for (int i = 0; i < adjuntos.size(); i++) {
            AdjuntoUi adjunto = adjuntos.get(i);
            if (adjunto == null) continue;
            validarAdjunto(adjunto.getNombre(), null, adjunto.getTamanio());
            total += adjunto.getTamanio();
        }

        long maxTotal = obtenerMaxBytesAdjunto();
        if (total > maxTotal) {
            throw new IllegalArgumentException("El total de evidencias no debe exceder " + (maxTotal / (1024 * 1024)) + " MB.");
        }

        if (adjuntos.size() > obtenerMaxArchivos()) {
            throw new IllegalArgumentException("El máximo de evidencias permitidas es " + obtenerMaxArchivos() + ".");
        }
    }

    // -------------------------------------------------------------------------
    // Avance
    // -------------------------------------------------------------------------

    @Override
    public void avanzarIncidencia(Long idIncidencia,
                                  String accion,
                                  String comentario,
                                  Long idUsuarioMovimiento) {

        if (idIncidencia == null) throw new IllegalArgumentException("idIncidencia es obligatorio.");
        if (isBlank(accion)) throw new IllegalArgumentException("La acción es obligatoria.");

        Incidencia incidencia = incidenciaDao.findById(idIncidencia);
        if (incidencia == null) throw new IllegalArgumentException("No existe la incidencia con id=" + idIncidencia);

        Long estatusActual = incidencia.getIdEstatusIncidencia();
        if (estatusActual == null) throw new IllegalStateException("La incidencia no tiene estatus actual.");

        if (ESTATUS_FINALIZADA == estatusActual.longValue() || ESTATUS_RECHAZADA == estatusActual.longValue()) {
            throw new IllegalStateException("La incidencia ya se encuentra cerrada y no permite cambios.");
        }

        Long nuevoEstatus = mapAccionAEstatusId(accion);
        if (nuevoEstatus == null) throw new IllegalArgumentException("Acción no reconocida: " + accion);

        if (ESTATUS_CREADA == estatusActual.longValue() && ESTATUS_FINALIZADA == nuevoEstatus.longValue()) {
            throw new IllegalStateException("Una incidencia en estado CREADA debe pasar primero a EN ATENCIÓN.");
        }
        if (ESTATUS_EN_ATENCION == estatusActual.longValue() && ESTATUS_RECHAZADA == nuevoEstatus.longValue()) {
            throw new IllegalStateException("No es posible rechazar una incidencia que ya se encuentra EN ATENCIÓN.");
        }

        Long nuevaResponsabilidad = resolverResponsabilidadPorEstatus(nuevoEstatus);

        incidencia.setIdEstatusIncidencia(nuevoEstatus);
        incidencia.setIdResponsabilidad(nuevaResponsabilidad);
        
        // --- CAMBIO: Usar new Date() ---
        incidencia.setFechaUltimoMovimiento(new Date());

        if (idUsuarioMovimiento != null) {
            incidencia.setUsuarioUltimaModificacion(String.valueOf(idUsuarioMovimiento.longValue()));
        }
        incidencia.setFechaUltimaModificacion(new Date());

        incidenciaDao.merge(incidencia);

        String usuarioMovimiento = (idUsuarioMovimiento != null) ? String.valueOf(idUsuarioMovimiento.longValue()) : "SYSTEM";

        insertarMovimientoBitacora(
                idIncidencia,
                nuevoEstatus,
                nuevaResponsabilidad,
                "M",
                usuarioMovimiento,
                comentario,
                mapEstatusIdAClave(estatusActual)
        );
    }

    // -------------------------------------------------------------------------
    // Catálogos
    // -------------------------------------------------------------------------

    @Override
    @Transactional(readOnly = true)
    public List<?> listarSitiosEnOperacionVisibles() {
        return sitiosPort.listarSitiosVisiblesParaUsuario();
    }

    @Override
    @Transactional(readOnly = true)
    public List<?> listarSitiosSuscritosParaAltaIncidencia(String concesionarioUsuario) {
        List<?> sitiosVisibles = sitiosPort.listarSitiosVisiblesParaUsuario();
        if (sitiosVisibles == null || sitiosVisibles.isEmpty()) return Collections.emptyList();

        if (isBlank(concesionarioUsuario) || suscripcionSitioService == null) return sitiosVisibles;

        Set<String> sitiosSuscritos = suscripcionSitioService.listarSitiosSuscritos(concesionarioUsuario.trim());
        if (sitiosSuscritos == null || sitiosSuscritos.isEmpty()) return Collections.emptyList();

        Set<String> setSuscritos = new HashSet<String>(sitiosSuscritos);
        List<SitioDto> resultado = new ArrayList<SitioDto>();

        for (int i = 0; i < sitiosVisibles.size(); i++) {
            Object item = sitiosVisibles.get(i);
            if (!(item instanceof SitioDto)) continue;
            SitioDto sitio = (SitioDto) item;
            if (sitio != null && !isBlank(sitio.getSitio()) && setSuscritos.contains(sitio.getSitio())) {
                resultado.add(sitio);
            }
        }
        return resultado;
    }

    @Override
    public List<String> catalogoTiposIncidencia() {
        List<String> lista = new ArrayList<String>();
        lista.add("Infraestructura Pasiva");
        lista.add("Sitio");
        return lista;
    }

    @Override
    public long obtenerMaxBytesAdjunto() { return DEF_MAX_BYTES; }

    @Override
    public int obtenerMaxArchivos() { return DEF_MAX_ARCHIVOS; }

    @Override
    public String obtenerRegexExtensiones() { return DEF_ALLOW_TYPES; }

    @Override
    public String obtenerFormatosHumanos() { return DEF_EXT_HUMAN; }

    @Override
    public String generarFolioIncidencia(Long idIncidencia) {
        if (idIncidencia == null) return null;
        return String.format("IN-%06d", idIncidencia.longValue());
    }

    // -------------------------------------------------------------------------
    // Consultas
    // -------------------------------------------------------------------------

    @Override
    @Transactional(readOnly = true)
    public List<IncidenciaGestionDto> buscarIncidenciasMantenimiento(String folio, String sitioId, String estatus) {
        List<Incidencia> incidencias = incidenciaDao.findAll();
        if (incidencias == null || incidencias.isEmpty()) return Collections.emptyList();

        Map<String, String> mapaSitios = construirMapaNombreSitio();
        Long estatusIdFiltro = mapEstatusEntradaAId(estatus);
        List<IncidenciaGestionDto> resultado = new ArrayList<IncidenciaGestionDto>();

        for (int i = 0; i < incidencias.size(); i++) {
            Incidencia incidencia = incidencias.get(i);
            if (incidencia == null) continue;
            if (!cumpleFiltroTexto(incidencia.getFolio(), folio)) continue;
            if (!cumpleFiltroTexto(incidencia.getIdSitio(), sitioId)) continue;
            if (estatusIdFiltro != null && (incidencia.getIdEstatusIncidencia() == null || estatusIdFiltro.longValue() != incidencia.getIdEstatusIncidencia().longValue())) {
                continue;
            }
            resultado.add(construirDto(incidencia, mapaSitios));
        }
        return resultado;
    }

    @Override
    @Transactional(readOnly = true)
    public List<IncidenciaGestionDto> buscarIncidenciasConcesionario(String folio, String sitioId, String estatus, String concesionario) {
        if (isBlank(concesionario)) return Collections.emptyList();

        List<Incidencia> incidencias = incidenciaDao.findAllByConcesionario(concesionario.trim());
        if (incidencias == null || incidencias.isEmpty()) return Collections.emptyList();

        Map<String, String> mapaSitios = construirMapaNombreSitio();
        Long estatusIdFiltro = mapEstatusEntradaAId(estatus);
        List<IncidenciaGestionDto> resultado = new ArrayList<IncidenciaGestionDto>();

        for (int i = 0; i < incidencias.size(); i++) {
            Incidencia incidencia = incidencias.get(i);
            if (incidencia == null) continue;
            if (!cumpleFiltroTexto(incidencia.getFolio(), folio)) continue;
            if (!cumpleFiltroTexto(incidencia.getIdSitio(), sitioId)) continue;
            if (estatusIdFiltro != null && (incidencia.getIdEstatusIncidencia() == null || estatusIdFiltro.longValue() != incidencia.getIdEstatusIncidencia().longValue())) {
                continue;
            }
            resultado.add(construirDto(incidencia, mapaSitios));
        }
        return resultado;
    }

    // -------------------------------------------------------------------------
    // Bitácora
    // -------------------------------------------------------------------------

    @Override
    @Transactional(readOnly = true)
    public List<IncidenciaBitacora> obtenerBitacoraIncidencia(Long idIncidencia) {
        if (idIncidencia == null) return Collections.emptyList();
        List<IncidenciaBitacora> movimientos = bitacoraDao.findByIncidenciaId(idIncidencia);
        if (movimientos == null || movimientos.isEmpty()) return Collections.emptyList();

        for (int i = 0; i < movimientos.size(); i++) {
            IncidenciaBitacora mov = movimientos.get(i);
            if (mov == null) continue;
            mov.setEvento("MOVIMIENTO");
            mov.setEstatusNuevo(mapEstatusIdAClave(mov.getIdEstatusIncidencia()));
        }
        return movimientos;
    }

    // -------------------------------------------------------------------------
    // Evidencias (Mock)
    // -------------------------------------------------------------------------

    @Override
    public void validarAdjunto(String nombre, String contentType, long size) {
        if (size <= 0) throw new IllegalArgumentException("Archivo vacío o inválido.");
        if (size > obtenerMaxBytesAdjunto()) {
            long maxMb = obtenerMaxBytesAdjunto() / 1024 / 1024;
            throw new IllegalArgumentException("El archivo no debe exceder " + maxMb + " MB.");
        }
        if (isBlank(nombre) || !DEF_EXT_PATTERN.matcher(nombre).matches()) {
            throw new IllegalArgumentException("Extensión no permitida en " + nombre + ". Formatos: " + DEF_EXT_HUMAN);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<IncidenciaAdjunto> obtenerAdjuntosIncidencia(Long idIncidencia) {
        if (idIncidencia == null) return Collections.emptyList();

        if (!mockArchivos) {
            try {
                List<IncidenciaAdjunto> lista = incidenciaAdjuntoDao.findByIncidencia(idIncidencia);
                return (lista != null) ? lista : Collections.<IncidenciaAdjunto>emptyList();
            } catch (Exception ex) {
                log.error("Error consultando adjuntos en BD para incidencia {}", idIncidencia, ex);
                return Collections.emptyList();
            }
        }

        List<IncidenciaAdjunto> lista = mockAdjuntosPorIncidencia.get(idIncidencia);
        if (lista == null) return Collections.emptyList();

        List<IncidenciaAdjunto> copia = new ArrayList<IncidenciaAdjunto>();
        synchronized (lista) {
            for (int i = 0; i < lista.size(); i++) {
                IncidenciaAdjunto a = lista.get(i);
                if (a != null) copia.add(a);
            }
        }
        return copia;
    }

    @Override
    public void adjuntarEvidenciaIncidencia(Long idIncidencia, AdjuntoUi adjunto, Long idUsuarioMovimiento) throws IOException {
        if (idIncidencia == null) throw new IllegalArgumentException("idIncidencia es obligatorio.");
        if (adjunto == null) throw new IllegalArgumentException("Adjunto es obligatorio.");
        if (adjunto.getBytes() == null || adjunto.getBytes().length == 0) throw new IllegalArgumentException("Archivo vacío o inválido.");

        validarAdjunto(adjunto.getNombre(), null, adjunto.getTamanio());

        // Límites (cuenta lo existente)
        List<IncidenciaAdjunto> existentes = obtenerAdjuntosIncidencia(idIncidencia);
        int usados = (existentes != null) ? existentes.size() : 0;
        long totalExistente = 0L;
        if (existentes != null) {
            for (int i = 0; i < existentes.size(); i++) {
                IncidenciaAdjunto a = existentes.get(i);
                if (a != null && a.getTamanioBytes() != null) totalExistente += a.getTamanioBytes();
            }
        }

        long totalNuevo = totalExistente + adjunto.getTamanio();
        if (totalNuevo > obtenerMaxBytesAdjunto()) throw new IllegalArgumentException("El tamaño total de evidencias excede 10 MB.");
        if (usados >= obtenerMaxArchivos()) throw new IllegalStateException("La incidencia ya cuenta con el máximo de archivos permitidos.");

        // Carpeta por incidencia (ID_INCI)
        Path carpeta = obtenerCarpetaIncidencia(idIncidencia);
        Files.createDirectories(carpeta);

        String nombreSeguro = sanitizarNombreArchivo(adjunto.getNombre());
        nombreSeguro = resolverNombreUnicoSiExiste(carpeta, nombreSeguro);

        Path destino = carpeta.resolve(nombreSeguro);
        Files.write(destino, adjunto.getBytes(), StandardOpenOption.CREATE_NEW);

        String usuAlta = (idUsuarioMovimiento != null) ? String.valueOf(idUsuarioMovimiento.longValue()) : "SYSTEM";

        if (mockArchivos) {
            IncidenciaAdjunto meta = new IncidenciaAdjunto();
            meta.setIdIncidencia(idIncidencia);
            meta.setNombreArchivo(nombreSeguro);
            meta.setRutaArchivo(carpeta.toString());
            meta.setExtensionArchivo("pdf");
            meta.setTamanioBytes(Long.valueOf(adjunto.getTamanio()));
            meta.setActivo("S");
            meta.setUsuarioAlta(usuAlta);
            meta.setFechaAlta(new Date());
            agregarAdjuntoMock(idIncidencia, meta);
            return;
        }

        // REAL: Persistir metadatos en Oracle
        IncidenciaAdjunto meta = new IncidenciaAdjunto();
        meta.setIdIncidencia(idIncidencia);
        meta.setNombreArchivo(nombreSeguro);
        meta.setRutaArchivo(carpeta.toString());
        meta.setExtensionArchivo("pdf");
        meta.setTamanioBytes(Long.valueOf(adjunto.getTamanio()));
        meta.setActivo("S");
        meta.setUsuarioAlta(usuAlta);
        meta.setFechaAlta(new Date());

        incidenciaAdjuntoDao.persist(meta);
    }

    @Override
    public void eliminarEvidenciaIncidencia(Long idIncidencia, String rutaRelativa, Long idUsuarioMovimiento) throws IOException {
        if (idIncidencia == null) throw new IllegalArgumentException("idIncidencia es obligatorio.");
        if (isBlank(rutaRelativa)) throw new IllegalArgumentException("rutaRelativa es obligatoria.");

        // Interpretar rutaRelativa como: "/algo/algo/nombre.pdf" o solo "nombre.pdf"
        String rutaNorm = normalizarRuta(rutaRelativa);
        String nombre = rutaNorm;
        if (nombre.contains("/")) nombre = nombre.substring(nombre.lastIndexOf('/') + 1);

        if (mockArchivos) {
            List<IncidenciaAdjunto> lista = mockAdjuntosPorIncidencia.get(idIncidencia);
            if (lista == null) throw new IllegalArgumentException("No se encontró el adjunto (MOCK).");
            boolean eliminado = false;
            synchronized (lista) {
                for (int i = 0; i < lista.size(); i++) {
                    IncidenciaAdjunto a = lista.get(i);
                    if (a != null && nombre.equals(a.getNombreArchivo())) {
                        // borrar físico
                        Path p = Paths.get(a.getRutaArchivo(), a.getNombreArchivo());
                        try { Files.deleteIfExists(p); } catch (IOException ex) { log.warn("No se pudo borrar archivo {}", p, ex); }
                        lista.remove(i);
                        eliminado = true;
                        break;
                    }
                }
            }
            if (!eliminado) throw new IllegalArgumentException("No se encontró el adjunto (MOCK).");
            return;
        }

        IncidenciaAdjunto entity = incidenciaAdjuntoDao.findActivoByIncidenciaAndNombre(idIncidencia, nombre);
        if (entity == null) throw new IllegalArgumentException("No se encontró el adjunto en BD.");

        // Baja lógica
        entity.setActivo("N");
        entity.setUsuarioBaja((idUsuarioMovimiento != null) ? String.valueOf(idUsuarioMovimiento.longValue()) : "SYSTEM");
        entity.setFechaBaja(new Date());
        incidenciaAdjuntoDao.merge(entity);

        // Borrar físico (si negocio lo permite; si no, comenta esta parte)
        Path path = Paths.get(entity.getRutaArchivo(), entity.getNombreArchivo());
        try { Files.deleteIfExists(path); } catch (IOException ex) { log.warn("No se pudo borrar archivo {}", path, ex); }
    }

    // -------------------------------------------------------------------------
    // Carga Masiva
    // -------------------------------------------------------------------------

    @Override
    public Long crearIncidenciaExternaCargaMasiva(String sitioCodigo,
                                                  String tipo,
                                                  String descripcion,
                                                  String usuarioCreacion,
                                                  String correoUsuarioCreacion,
                                                  String concesionarioCreacion,
                                                  String estatusInicial) {

        if (isBlank(sitioCodigo)) throw new IllegalArgumentException("El sitio es obligatorio.");
        if (isBlank(tipo)) throw new IllegalArgumentException("El tipo de incidencia es obligatorio.");
        if (isBlank(descripcion)) throw new IllegalArgumentException("La descripción es obligatoria.");
        if (isBlank(usuarioCreacion)) throw new IllegalArgumentException("El nombre de quien reporta es obligatorio.");
        if (isBlank(correoUsuarioCreacion)) throw new IllegalArgumentException("El correo de quien reporta es obligatorio.");
        if (isBlank(concesionarioCreacion)) throw new IllegalArgumentException("El concesionario es obligatorio.");
        if (isBlank(estatusInicial)) throw new IllegalArgumentException("El estatus es obligatorio.");

        validarSitioActivo(sitioCodigo);

        Long idIncidencia = obtenerSiguienteIdIncidenciaConBloqueo();
        Long idEstatus = mapEstatusEntradaAId(estatusInicial);
        if (idEstatus == null) throw new IllegalArgumentException("Estatus inicial no reconocido: " + estatusInicial);

        Incidencia incidencia = new Incidencia();
        incidencia.setId(idIncidencia);
        incidencia.setFolio(generarFolioIncidencia(idIncidencia));
        incidencia.setIdSitio(sitioCodigo.trim());
        incidencia.setIdConcesionario(valorSeguro(concesionarioCreacion));
        incidencia.setIdTipoIncidencia(mapTipoEntradaAId(tipo));
        incidencia.setIdEstatusIncidencia(idEstatus);
        incidencia.setIdResponsabilidad(resolverResponsabilidadPorEstatus(idEstatus));
        incidencia.setDescripcion(descripcion.trim());

        incidencia.setOrigenAlta("I");
        incidencia.setNombreReporta(valorSeguro(usuarioCreacion));
        incidencia.setCorreoReporta(valorSeguro(correoUsuarioCreacion));
        incidencia.setUsuarioAlta(valorSeguro(usuarioCreacion));

        // --- CAMBIO: new Date() ---
        Date ahora = new Date();
        incidencia.setFechaAlta(ahora);
        incidencia.setFechaUltimoMovimiento(ahora);
        incidencia.setUsuarioUltimaModificacion(valorSeguro(usuarioCreacion));
        incidencia.setFechaUltimaModificacion(ahora);

        incidenciaDao.persist(incidencia);

        insertarMovimientoBitacora(
                idIncidencia,
                idEstatus,
                incidencia.getIdResponsabilidad(),
                "C",
                valorSeguro(usuarioCreacion),
                "CARGA MASIVA: Incidencia creada",
                null
        );

        return idIncidencia;
    }

    // -------------------------------------------------------------------------
    // Helpers BD
    // -------------------------------------------------------------------------

    private Long obtenerSiguienteIdIncidenciaConBloqueo() {
        bloquearTabla("BDDSEG01.T3SINO_INCI");
        return incidenciaDao.obtenerSiguienteId();
    }

    private Long obtenerSiguienteIdMovimientoConBloqueo() {
        bloquearTabla("BDDSEG01.T3SINB_INCI_MOVI");
        return bitacoraDao.obtenerSiguienteId();
    }

    private void bloquearTabla(String tabla) {
        if (entityManager == null) return;
        try {
            entityManager.createNativeQuery("LOCK TABLE " + tabla + " IN EXCLUSIVE MODE").executeUpdate();
        } catch (Exception ex) {
            log.warn("No fue posible aplicar LOCK TABLE sobre {} (se continuará con MAX+1 sin lock).", tabla, ex);
        }
    }

    private void insertarMovimientoBitacora(Long idIncidencia,
                                            Long idEstatus,
                                            Long idResponsabilidad,
                                            String perfilMovimiento,
                                            String usuarioMovimiento,
                                            String comentario,
                                            String estatusAnteriorClave) {

        Long idMovimiento = obtenerSiguienteIdMovimientoConBloqueo();

        IncidenciaBitacora mov = new IncidenciaBitacora();
        mov.setId(idMovimiento);
        mov.setIdIncidencia(idIncidencia);
        mov.setIdEstatusIncidencia(idEstatus);
        mov.setIdResponsabilidad(idResponsabilidad);
        mov.setPerfilMovimiento(isBlank(perfilMovimiento) ? "M" : perfilMovimiento.trim());
        mov.setUsuarioMovimiento(isBlank(usuarioMovimiento) ? "SYSTEM" : usuarioMovimiento.trim());
        
        // --- CAMBIO: new Date() ---
        mov.setFechaEvento(new Date());
        
        mov.setComentario(isBlank(comentario) ? "-" : comentario);

        mov.setEvento("CAMBIO_ESTATUS");
        mov.setEstatusAnterior(estatusAnteriorClave);
        mov.setEstatusNuevo(mapEstatusIdAClave(idEstatus));

        bitacoraDao.persist(mov);
    }

    // -------------------------------------------------------------------------
    // Helpers Mapping
    // -------------------------------------------------------------------------

    private Long mapAccionAEstatusId(String accion) {
        String a = accion.trim().toUpperCase();
        if (a.contains("RECHAZ")) return Long.valueOf(ESTATUS_RECHAZADA);
        if (a.contains("ATEN")) return Long.valueOf(ESTATUS_EN_ATENCION);
        if (a.contains("FINAL")) return Long.valueOf(ESTATUS_FINALIZADA);
        return null;
    }

    private Long mapEstatusEntradaAId(String estatus) {
        if (isBlank(estatus)) return null;
        String e = estatus.trim().toUpperCase();
        if (e.contains("CREAD")) return Long.valueOf(ESTATUS_CREADA);
        if (e.contains("ATEN")) return Long.valueOf(ESTATUS_EN_ATENCION);
        if (e.contains("RECHAZ")) return Long.valueOf(ESTATUS_RECHAZADA);
        if (e.contains("FINAL")) return Long.valueOf(ESTATUS_FINALIZADA);
        return null;
    }

    private String mapEstatusIdAClave(Long idEstatus) {
        if (idEstatus == null) return null;
        long v = idEstatus.longValue();
        if (v == ESTATUS_CREADA) return "CREADA";
        if (v == ESTATUS_EN_ATENCION) return "EN ATENCIÓN";
        if (v == ESTATUS_RECHAZADA) return "RECHAZADA";
        if (v == ESTATUS_FINALIZADA) return "FINALIZADA";
        return String.valueOf(v);
    }

    private Long resolverResponsabilidadPorEstatus(Long idEstatus) {
        if (idEstatus == null) return Long.valueOf(RESP_MANTENIMIENTO);
        long v = idEstatus.longValue();
        if (v == ESTATUS_RECHAZADA) return Long.valueOf(RESP_CONCESIONARIO);
        return Long.valueOf(RESP_MANTENIMIENTO);
    }

    private Long mapTipoEntradaAId(String tipo) {
        if (isBlank(tipo)) return Long.valueOf(TIPO_INFRAESTRUCTURA_PASIVA);
        String t = tipo.trim().toUpperCase();
        if (t.contains("SITIO")) return Long.valueOf(TIPO_SITIO);
        return Long.valueOf(TIPO_INFRAESTRUCTURA_PASIVA);
    }

    private String mapTipoIdAEtiqueta(Long idTipo) {
        if (idTipo == null) return null;
        if (idTipo.longValue() == TIPO_SITIO) return "Sitio";
        if (idTipo.longValue() == TIPO_INFRAESTRUCTURA_PASIVA) return "Infraestructura Pasiva";
        return String.valueOf(idTipo);
    }

    // -------------------------------------------------------------------------
    // Helpers DTO
    // -------------------------------------------------------------------------

    private IncidenciaGestionDto construirDto(Incidencia incidencia, Map<String, String> mapaSitios) {
        IncidenciaGestionDto dto = new IncidenciaGestionDto();
        dto.setIdIncidencia(incidencia.getId());
        dto.setFolio(incidencia.getFolio());
        dto.setIdSitio(incidencia.getIdSitio());

        String nombreSitio = null;
        if (mapaSitios != null && incidencia.getIdSitio() != null) {
            nombreSitio = mapaSitios.get(incidencia.getIdSitio());
        }
        dto.setNombreSitio(!isBlank(nombreSitio) ? nombreSitio : incidencia.getIdSitio());

        dto.setConcesionario(incidencia.getIdConcesionario());
        dto.setEstatus(mapEstatusIdAClave(incidencia.getIdEstatusIncidencia()));
        dto.setTipo(mapTipoIdAEtiqueta(incidencia.getIdTipoIncidencia()));
        dto.setDescripcion(incidencia.getDescripcion());

        if (incidencia.getFechaAlta() != null) {
           
            SimpleDateFormat sdf = new SimpleDateFormat(FECHA_PATTERN);
            dto.setFechaCreacion(sdf.format(incidencia.getFechaAlta()));
        }

        String usuarioCreacion = !isBlank(incidencia.getNombreReporta()) ? incidencia.getNombreReporta() : incidencia.getUsuarioAlta();
        dto.setUsuarioCreacion(!isBlank(usuarioCreacion) ? usuarioCreacion : "USUARIO DESCONOCIDO");
        dto.setCorreoUsuarioCreacion(!isBlank(incidencia.getCorreoReporta()) ? incidencia.getCorreoReporta() : "");
        dto.setPendientePor(calcularPendientePor(dto.getEstatus()));

        return dto;
    }

    private boolean cumpleFiltroTexto(String valorEntidad, String filtro) {
        if (isBlank(filtro)) return true;
        if (valorEntidad == null) return false;
        return valorEntidad.contains(filtro.trim());
    }

    private Map<String, String> construirMapaNombreSitio() {
        Map<String, String> mapa = new HashMap<String, String>();
        List<?> sitios = null;
        try {
            sitios = sitiosPort.listarSitiosVisiblesParaUsuario();
        } catch (Exception e) {
            log.warn("No fue posible obtener sitios visibles para usuario.", e);
            return mapa;
        }

        if (sitios == null || sitios.isEmpty()) return mapa;

        for (int i = 0; i < sitios.size(); i++) {
            Object item = sitios.get(i);
            if (!(item instanceof SitioDto)) continue;
            SitioDto sitio = (SitioDto) item;
            if (sitio != null && !isBlank(sitio.getSitio())) {
                mapa.put(sitio.getSitio(), sitio.getNombre());
            }
        }
        return mapa;
    }

    private String calcularPendientePor(String estatus) {
        if (estatus == null) return "-";
        String e = estatus.trim().toUpperCase();
        if ("CREADA".equals(e)) return "Concesionario";
        if ("RECHAZADA".equals(e)) return "Concesionario";
        if ("EN ATENCIÓN".equals(e) || "EN ATENCION".equals(e)) return "Operación";
        if ("FINALIZADA".equals(e)) return "-";
        return "-";
    }

    private void validarSitioActivo(String sitioCodigo) {
        try {
            if (sitiosPort != null && !sitiosPort.existeYActivo(sitioCodigo.trim())) {
                throw new IllegalArgumentException("El sitio no existe o no se encuentra activo.");
            }
        } catch (IllegalArgumentException ex) {
            throw ex;
        } catch (Exception ex) {
            log.warn("No fue posible validar existencia/estado del sitio mediante sitiosPort. Se continuará.", ex);
        }
    }

    // -------------------------------------------------------------------------
    // Helpers Mock Archivos
    // -------------------------------------------------------------------------

    private void guardarAdjuntosMock(Long idIncidencia, List<AdjuntoUi> adjuntos, String usuarioAlta) {
        if (!mockArchivos) throw new UnsupportedOperationException("Archivos en modo REAL aún no implementados.");
        if (adjuntos == null || adjuntos.isEmpty()) return;

        Path carpeta = Paths.get(DEF_FS_BASE_PATH, String.valueOf(idIncidencia));
        try {
            Files.createDirectories(carpeta);
        } catch (IOException e) {
            log.warn("[MOCK] No se pudo crear el directorio de adjuntos {}", carpeta, e);
        }

        for (int i = 0; i < adjuntos.size(); i++) {
            AdjuntoUi adjunto = adjuntos.get(i);
            if (adjunto == null) continue;

            try {
                validarAdjunto(adjunto.getNombre(), null, adjunto.getTamanio());
                String nombreSeguro = sanitizarNombreArchivo(adjunto.getNombre());
                Path destino = carpeta.resolve(nombreSeguro);

                Files.write(destino, adjunto.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);

                IncidenciaAdjunto meta = new IncidenciaAdjunto();
                meta.setNombreArchivo(nombreSeguro);
                meta.setRutaArchivo("/" + idIncidencia + "/" + nombreSeguro);
                meta.setTamanioBytes(Long.valueOf(adjunto.getTamanio()));
                meta.setUsuarioAlta(usuarioAlta);
                
                // --- CAMBIO: new Date() ---
                meta.setFechaAlta(new Date());

                agregarAdjuntoMock(idIncidencia, meta);

            } catch (Exception ex) {
                log.error("[MOCK] Error al procesar adjunto para incidencia {}", idIncidencia, ex);
            }
        }
    }

    private void agregarAdjuntoMock(Long idIncidencia, IncidenciaAdjunto meta) {
        if (idIncidencia == null || meta == null) return;
        List<IncidenciaAdjunto> lista = mockAdjuntosPorIncidencia.get(idIncidencia);
        if (lista == null) {
            lista = Collections.synchronizedList(new ArrayList<IncidenciaAdjunto>());
            mockAdjuntosPorIncidencia.put(idIncidencia, lista);
        }
        synchronized (lista) {
            lista.add(meta);
        }
    }

    private String sanitizarNombreArchivo(String nombreOriginal) {
        String nombre = (nombreOriginal != null) ? nombreOriginal.trim() : "evidencia.pdf";
        nombre = nombre.replace("\\", "/");
        if (nombre.contains("/")) {
            nombre = nombre.substring(nombre.lastIndexOf('/') + 1);
        }
        nombre = nombre.replaceAll("[^a-zA-Z0-9._-]", "_");
        if (!nombre.toLowerCase().endsWith(".pdf")) {
            nombre = nombre + ".pdf";
        }
        return nombre;
    }

    private String normalizarRuta(String ruta) {
        if (ruta == null) return null;
        String r = ruta.trim().replace("\\", "/");
        while (r.contains("//")) {
            r = r.replace("//", "/");
        }
        return r;
    }



    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    private String valorSeguro(String s) {
        return (s == null) ? "" : s.trim();
    }

    private static boolean leerFlagMockArchivos() {
        try {
            String valor = System.getProperty("incidencias.fs.base", "/seg/Incidencias/Solicitudes");
            if (valor == null) return true;
            valor = valor.trim().toLowerCase();
            if ("false".equals(valor) || "0".equals(valor) || "no".equals(valor)) return false;
            return true;
        } catch (Exception ex) {
            return true;
        }
    }
    
    
    private static Path resolverBaseAdjuntos() {
        String base = System.getProperty("incidencias.fs.base", DEF_FS_BASE_PATH);
        if (base == null || base.trim().isEmpty()) base = DEF_FS_BASE_PATH;
        return Paths.get(base.trim()).normalize();
    }

    private static boolean resolverModoMock(Path basePath) {
        // Si el admin lo define explícito, se respeta:
        String mock = System.getProperty("incidencias.fs.mock");
        if (mock != null) {
            String v = mock.trim().toLowerCase();
            return "true".equals(v) || "1".equals(v) || "si".equals(v) || "yes".equals(v);
        }

        // Si no está definido, intentamos usar REAL. Si no se puede crear/acceder, caemos a MOCK.
        try {
            Files.createDirectories(basePath);
            return false; // REAL por default
        } catch (Exception ex) {
            return true;  // fallback a MOCK
        }
    }

    private Path obtenerCarpetaIncidencia(Long idIncidencia) {
        Path carpeta = fsBasePath.resolve(String.valueOf(idIncidencia)).normalize();
        // Evita path traversal
        if (!carpeta.startsWith(fsBasePath)) throw new IllegalArgumentException("Ruta inválida de incidencia.");
        return carpeta;
    }

    private String resolverNombreUnicoSiExiste(Path carpeta, String nombreSeguro) {
        Path p = carpeta.resolve(nombreSeguro);
        if (!Files.exists(p)) return nombreSeguro;

        String base = nombreSeguro.replaceAll("(?i)\\.pdf$", "");
        String candidato = base + "_" + System.currentTimeMillis() + ".pdf";
        return candidato;
    }

    private Path resolverPathSeguroDesdeRuta(String rutaRelativa) {
        String ruta = normalizarRuta(rutaRelativa);
        while (ruta.startsWith("/")) ruta = ruta.substring(1);

        Path base = fsBasePath.normalize();
        Path target = base.resolve(ruta).normalize();
        if (!target.startsWith(base)) throw new IllegalArgumentException("Ruta inválida.");
        return target;
    }

    private void guardarAdjuntosIncidenciaAlta(Long idIncidencia, List<AdjuntoUi> adjuntos, String usuarioAlta) {
        if (adjuntos == null || adjuntos.isEmpty()) return;
        for (int i = 0; i < adjuntos.size(); i++) {
            AdjuntoUi a = adjuntos.get(i);
            if (a == null) continue;
            try {
                // En alta no tenemos idUsuario, guardamos el string recibido
                Path carpeta = obtenerCarpetaIncidencia(idIncidencia);
                Files.createDirectories(carpeta);

                validarAdjunto(a.getNombre(), null, a.getTamanio());

                String nombreSeguro = sanitizarNombreArchivo(a.getNombre());
                nombreSeguro = resolverNombreUnicoSiExiste(carpeta, nombreSeguro);

                Path destino = carpeta.resolve(nombreSeguro);
                Files.write(destino, a.getBytes(), StandardOpenOption.CREATE_NEW);

                if (mockArchivos) {
                    IncidenciaAdjunto meta = new IncidenciaAdjunto();
                    meta.setIdIncidencia(idIncidencia);
                    meta.setNombreArchivo(nombreSeguro);
                    meta.setRutaArchivo(carpeta.toString());
                    meta.setExtensionArchivo("pdf");
                    meta.setTamanioBytes(Long.valueOf(a.getTamanio()));
                    meta.setActivo("S");
                    meta.setUsuarioAlta(usuarioAlta);
                    meta.setFechaAlta(new Date());
                    agregarAdjuntoMock(idIncidencia, meta);
                } else {
                    IncidenciaAdjunto meta = new IncidenciaAdjunto();
                    meta.setIdIncidencia(idIncidencia);
                    meta.setNombreArchivo(nombreSeguro);
                    meta.setRutaArchivo(carpeta.toString());
                    meta.setExtensionArchivo("pdf");
                    meta.setTamanioBytes(Long.valueOf(a.getTamanio()));
                    meta.setActivo("S");
                    meta.setUsuarioAlta(usuarioAlta);
                    meta.setFechaAlta(new Date());
                    incidenciaAdjuntoDao.persist(meta);
                }

            } catch (Exception ex) {
                log.error("Error guardando adjunto en alta para incidencia {}", idIncidencia, ex);
            }
        }
    }

}
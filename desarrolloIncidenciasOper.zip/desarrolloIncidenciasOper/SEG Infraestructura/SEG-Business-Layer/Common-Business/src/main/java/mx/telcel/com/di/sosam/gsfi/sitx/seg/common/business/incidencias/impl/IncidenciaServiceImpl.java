package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.impl;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.Normalizer;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.incidencias.IIncidenciaService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.ISuscripcionSitioService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.Incidencia;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.IncidenciaAdjunto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.incidencias.IncidenciaBitacora;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaBitacoraDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dao.IIncidenciaDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.incidencias.dto.IncidenciaGestionDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SitioDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.port.ISitiosQueryPort;

@Service
@Transactional
public class IncidenciaServiceImpl implements IIncidenciaService {

    private static final Logger LOGGER = LoggerFactory.getLogger(IncidenciaServiceImpl.class);

    // ==========================
    // Catálogos (IDs fijos en BD)
    // ==========================
    private static final Long ESTATUS_CREADA = 1L;
    private static final Long ESTATUS_EN_ATENCION = 2L;
    private static final Long ESTATUS_RECHAZADA = 3L;
    private static final Long ESTATUS_FINALIZADA = 4L;

    private static final Long RESP_CONCESIONARIO = 1L;
    private static final Long RESP_MANTENIMIENTO = 2L;

    private static final Long TIPO_INFRAESTRUCTURA_PASIVA = 1L;
    private static final Long TIPO_SITIO = 2L;

    private static final String TEXTO_ESTATUS_CREADA = "CREADA";
    private static final String TEXTO_ESTATUS_EN_ATENCION = "EN ATENCIÓN";
    private static final String TEXTO_ESTATUS_RECHAZADA = "RECHAZADA";
    private static final String TEXTO_ESTATUS_FINALIZADA = "FINALIZADA";

    // ==========================
    // Archivos (mock aislado)
    // ==========================
    private static final long MAX_BYTES_ADJUNTO = 10L * 1024L * 1024L; // 10 MB
    private static final int MAX_ARCHIVOS = 5;
    private static final String EXT_PDF = ".pdf";
    private static final DateTimeFormatter FECHA_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss", Locale.ROOT);

    @Value("${seg.incidencias.mockArchivos:true}")
    private boolean mockArchivos;

    @Value("${seg.incidencias.adjuntos.baseDir:}")
    private String rutaBaseAdjuntosConfig;

    private Path rutaBaseAdjuntos;

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private IIncidenciaDao incidenciaDao;

    @Autowired
    private IIncidenciaBitacoraDao bitacoraDao;

    @Autowired
    private ISuscripcionSitioService suscripcionSitioService;

    @Autowired
    private ISitiosQueryPort sitiosPort;

    @PostConstruct
    private void init() {
        if (rutaBaseAdjuntosConfig != null && !rutaBaseAdjuntosConfig.trim().isEmpty()) {
            rutaBaseAdjuntos = Paths.get(rutaBaseAdjuntosConfig.trim());
        } else {
            rutaBaseAdjuntos = Paths.get(System.getProperty("java.io.tmpdir"), "seg-telcel", "incidencias", "adjuntos");
        }
        LOGGER.info("Incidencias: mockArchivos={}, rutaBaseAdjuntos={}", Boolean.valueOf(mockArchivos), rutaBaseAdjuntos.toAbsolutePath());
    }

    // ==========================================================
    // Sitios
    // ==========================================================

    @Override
    @Transactional(readOnly = true)
    public List<?> listarSitiosEnOperacionVisibles() {
        return sitiosPort.listarSitiosEnOperacion();
    }

    @Override
    @Transactional(readOnly = true)
    public List<?> listarSitiosSuscritosParaAltaIncidencia(String concesionarioUsuario) {

        List<SitioDto> sitiosEnOperacion = sitiosPort.listarSitiosEnOperacion();
        if (sitiosEnOperacion == null || sitiosEnOperacion.isEmpty()) {
            return Collections.emptyList();
        }

        if (isBlank(concesionarioUsuario)) {
            return sitiosEnOperacion;
        }

        Set<String> sitiosSuscritos = suscripcionSitioService.listarSitiosSuscritos(concesionarioUsuario.trim());
        if (sitiosSuscritos == null || sitiosSuscritos.isEmpty()) {
            return Collections.emptyList();
        }

        Set<String> setSuscritos = new HashSet<String>(sitiosSuscritos);
        List<SitioDto> resultado = new ArrayList<SitioDto>();

        for (int i = 0; i < sitiosEnOperacion.size(); i++) {
            SitioDto sitio = sitiosEnOperacion.get(i);
            if (sitio != null && sitio.getSitio() != null && setSuscritos.contains(sitio.getSitio())) {
                resultado.add(sitio);
            }
        }

        return resultado;
    }

    @Override
    public List<String> catalogoTiposIncidencia() {
        List<String> tipos = new ArrayList<String>();
        tipos.add("Infraestructura Pasiva");
        tipos.add("Sitio");
        return tipos;
    }

    // ==========================================================
    // Validaciones UI
    // ==========================================================

    @Override
    public void validarAdjunto(String nombre, String contentType, long size) {

        String nombreArchivo = (nombre != null) ? nombre.trim() : "";

        if (nombreArchivo.isEmpty()) {
            throw new IllegalArgumentException("El nombre del archivo es requerido.");
        }

        String nombreLower = nombreArchivo.toLowerCase(Locale.ROOT);
        if (!nombreLower.endsWith(EXT_PDF)) {
            throw new IllegalArgumentException("Solo se permiten evidencias en formato PDF.");
        }

        if (size <= 0L) {
            throw new IllegalArgumentException("El archivo está vacío.");
        }

        if (size > MAX_BYTES_ADJUNTO) {
            throw new IllegalArgumentException("El archivo excede el tamaño máximo permitido (10 MB).");
        }
    }

    @Override
    public void validarAlta(String sitioCodigo, String tipo, String descripcion, List<AdjuntoUi> adjuntos) {

        if (isBlank(sitioCodigo)) {
            throw new IllegalArgumentException("El sitio es requerido.");
        }

        String sitioTrim = sitioCodigo.trim();
        if (!sitiosPort.existeYActivo(sitioTrim)) {
            throw new IllegalArgumentException("El sitio no existe o no está activo.");
        }

        if (isBlank(tipo)) {
            throw new IllegalArgumentException("El tipo de incidencia es requerido.");
        }

        if (isBlank(descripcion)) {
            throw new IllegalArgumentException("La descripción es requerida.");
        }

        if (adjuntos == null || adjuntos.isEmpty()) {
            return;
        }

        if (adjuntos.size() > MAX_ARCHIVOS) {
            throw new IllegalArgumentException("Se excedió el número máximo de archivos permitidos (" + MAX_ARCHIVOS + ").");
        }

        for (int i = 0; i < adjuntos.size(); i++) {
            AdjuntoUi adjunto = adjuntos.get(i);
            if (adjunto == null) {
                throw new IllegalArgumentException("Adjunto inválido.");
            }
            validarAdjunto(adjunto.getNombre(), null, adjunto.getTamanio());
        }
    }

    @Override
    public long obtenerMaxBytesAdjunto() {
        return MAX_BYTES_ADJUNTO;
    }

    @Override
    public int obtenerMaxArchivos() {
        return MAX_ARCHIVOS;
    }

    @Override
    public String obtenerRegexExtensiones() {
        return "(?i).*\\.pdf$";
    }

    @Override
    public String obtenerFormatosHumanos() {
        return "PDF";
    }

    // ==========================================================
    // Alta (BD) + movimiento inicial (BD) + adjuntos (mock)
    // ==========================================================

    @Override
    public Long crearIncidencia(String sitioCodigo,
                               String tipo,
                               String descripcion,
                               List<AdjuntoUi> adjuntos,
                               String usuarioCreacion,
                               String correoUsuarioCreacion,
                               String concesionarioCreacion) {

        validarAlta(sitioCodigo, tipo, descripcion, adjuntos);

        if (isBlank(concesionarioCreacion)) {
            throw new IllegalArgumentException("El concesionario es requerido.");
        }

        String sitioTrim = sitioCodigo.trim();
        String concesionarioTrim = concesionarioCreacion.trim();

        validarSuscripcionConcesionarioSitio(concesionarioTrim, sitioTrim);

        lockTableExclusive("BDDSEG01.T3SINO_INCI");
        Long idIncidencia = incidenciaDao.obtenerSiguienteId();

        Incidencia incidencia = new Incidencia();
        incidencia.setId(idIncidencia);
        incidencia.setFolio(generarFolioIncidencia(idIncidencia));
        incidencia.setIdSitio(sitioTrim);
        incidencia.setIdConcesionario(concesionarioTrim);
        incidencia.setIdTipoIncidencia(resolverTipoIdDesdeUi(tipo));
        incidencia.setIdEstatusIncidencia(ESTATUS_CREADA);

        // Al crear: queda pendiente por Mantenimiento
        incidencia.setIdResponsabilidad(RESP_MANTENIMIENTO);

        incidencia.setDescripcion(descripcion.trim());

        // Compatibilidad con UI: usamos usuarioCreacion como "nombre reporta" y también como "usuario alta"
        incidencia.setNombreReporta(usuarioCreacion);
        incidencia.setCorreoReporta(correoUsuarioCreacion);
        incidencia.setUsuarioAlta(usuarioCreacion);

        incidencia.setUsuarioUltimaModificacion(usuarioCreacion);
        incidencia.setFechaUltimaModificacion(LocalDateTime.now());

        incidenciaDao.guardar(incidencia);

        // Movimiento inicial: evento ALTA (actor concesionario)
        insertarMovimientoBitacora(
                idIncidencia,
                ESTATUS_CREADA,
                RESP_CONCESIONARIO,
                "C",
                usuarioCreacion,
                descripcion
        );

        if (adjuntos != null && !adjuntos.isEmpty()) {
            guardarAdjuntosMock(idIncidencia, adjuntos);
        }

        return idIncidencia;
    }

    @Override
    public Long crearIncidenciaExternaCargaMasiva(String sitioCodigo,
                                                 String tipo,
                                                 String descripcion,
                                                 String usuarioCreacion,
                                                 String correoUsuarioCreacion,
                                                 String concesionarioCreacion,
                                                 String estatusInicial) {

        validarAlta(sitioCodigo, tipo, descripcion, Collections.<AdjuntoUi>emptyList());

        if (isBlank(concesionarioCreacion)) {
            throw new IllegalArgumentException("El concesionario es requerido.");
        }

        String sitioTrim = sitioCodigo.trim();
        String concesionarioTrim = concesionarioCreacion.trim();

        validarSuscripcionConcesionarioSitio(concesionarioTrim, sitioTrim);

        Long idEstatusInicial = resolverEstatusIdDesdeString(estatusInicial);
        if (idEstatusInicial == null) {
            idEstatusInicial = ESTATUS_CREADA;
        }

        lockTableExclusive("BDDSEG01.T3SINO_INCI");
        Long idIncidencia = incidenciaDao.obtenerSiguienteId();

        Incidencia incidencia = new Incidencia();
        incidencia.setId(idIncidencia);
        incidencia.setFolio(generarFolioIncidencia(idIncidencia));
        incidencia.setIdSitio(sitioTrim);
        incidencia.setIdConcesionario(concesionarioTrim);
        incidencia.setIdTipoIncidencia(resolverTipoIdDesdeUi(tipo));
        incidencia.setIdEstatusIncidencia(idEstatusInicial);

        // Pendiente por según estatus
        incidencia.setIdResponsabilidad(resolverResponsabilidadPorEstatus(idEstatusInicial));

        incidencia.setDescripcion(descripcion.trim());
        incidencia.setNombreReporta(usuarioCreacion);
        incidencia.setCorreoReporta(correoUsuarioCreacion);
        incidencia.setUsuarioAlta(usuarioCreacion);

        incidencia.setUsuarioUltimaModificacion(usuarioCreacion);
        incidencia.setFechaUltimaModificacion(LocalDateTime.now());

        incidenciaDao.guardar(incidencia);

        insertarMovimientoBitacora(
                idIncidencia,
                idEstatusInicial,
                RESP_CONCESIONARIO,
                "C",
                usuarioCreacion,
                descripcion
        );

        return idIncidencia;
    }

    @Override
    public String generarFolioIncidencia(Long idIncidencia) {
        if (idIncidencia == null) {
            return null;
        }
        return String.format(Locale.ROOT, "IN-%06d", idIncidencia);
    }

    // ==========================================================
    // Avance (BD) + bitácora (BD)
    // ==========================================================

    @Override
    public void avanzarIncidencia(Long idIncidencia,
                                  String accion,
                                  String comentario,
                                  Long idUsuarioMovimiento) {

        if (idIncidencia == null) {
            throw new IllegalArgumentException("El idIncidencia es requerido.");
        }
        if (isBlank(accion)) {
            throw new IllegalArgumentException("La acción es requerida.");
        }

        Incidencia incidencia = incidenciaDao.buscarPorId(idIncidencia);
        if (incidencia == null) {
            throw new IllegalArgumentException("No existe la incidencia con id=" + idIncidencia);
        }

        Long nuevoEstatus = resolverNuevoEstatusPorAccion(accion);
        Long nuevaResponsabilidad = resolverResponsabilidadPorEstatus(nuevoEstatus);

        incidencia.setIdEstatusIncidencia(nuevoEstatus);
        incidencia.setIdResponsabilidad(nuevaResponsabilidad);
        incidencia.setFechaUltimoMovimiento(LocalDateTime.now());

        if (idUsuarioMovimiento != null) {
            incidencia.setUsuarioUltimaModificacion(String.valueOf(idUsuarioMovimiento));
        }
        incidencia.setFechaUltimaModificacion(LocalDateTime.now());

        incidenciaDao.actualizar(incidencia);

        // Movimiento de mantenimiento (actor mantenimiento)
        insertarMovimientoBitacora(
                idIncidencia,
                nuevoEstatus,
                RESP_MANTENIMIENTO,
                "M",
                (idUsuarioMovimiento != null ? String.valueOf(idUsuarioMovimiento) : null),
                comentario
        );
    }

    private Long resolverNuevoEstatusPorAccion(String accionUi) {
        String accionNormalizada = normalizarClave(accionUi);

        if (accionNormalizada.contains("EN_ATENCION") || accionNormalizada.contains("ATENDER")) {
            return ESTATUS_EN_ATENCION;
        }
        if (accionNormalizada.contains("RECHAZAR")) {
            return ESTATUS_RECHAZADA;
        }
        if (accionNormalizada.contains("FINALIZAR")) {
            return ESTATUS_FINALIZADA;
        }

        throw new IllegalArgumentException("Acción inválida: " + accionUi);
    }

    private Long resolverResponsabilidadPorEstatus(Long idEstatus) {
        if (ESTATUS_RECHAZADA.equals(idEstatus) || ESTATUS_FINALIZADA.equals(idEstatus)) {
            return RESP_CONCESIONARIO;
        }
        return RESP_MANTENIMIENTO;
    }

    private void insertarMovimientoBitacora(Long idIncidencia,
                                            Long idEstatusIncidencia,
                                            Long idResponsabilidadMovimiento,
                                            String perfilMovimiento,
                                            String usuarioMovimiento,
                                            String comentario) {

        lockTableExclusive("BDDSEG01.T3SINB_INCI_MOVI");
        Long idMovimiento = bitacoraDao.obtenerSiguienteId();

        IncidenciaBitacora movimiento = new IncidenciaBitacora();
        movimiento.setId(idMovimiento);
        movimiento.setIdIncidencia(idIncidencia);
        movimiento.setIdEstatusIncidencia(idEstatusIncidencia);
        movimiento.setIdResponsabilidad(idResponsabilidadMovimiento);
        movimiento.setPerfilMovimiento(perfilMovimiento);
        movimiento.setUsuarioMovimiento(usuarioMovimiento);
        movimiento.setComentario(comentario);

        bitacoraDao.guardar(movimiento);
    }

    // ==========================================================
    // Consultas -> DTO (sin lazy)
    // ==========================================================

    @Override
    @Transactional(readOnly = true)
    public List<IncidenciaGestionDto> buscarIncidenciasMantenimiento(String folio,
                                                                     String sitioId,
                                                                     String estatus) {

        List<Incidencia> incidencias = incidenciaDao.buscarTodos();
        return filtrarYMapearIncidencias(incidencias, folio, sitioId, estatus);
    }

    @Override
    @Transactional(readOnly = true)
    public List<IncidenciaGestionDto> buscarIncidenciasConcesionario(String folio,
                                                                     String sitioId,
                                                                     String estatus,
                                                                     String concesionario) {

        if (isBlank(concesionario)) {
            return Collections.emptyList();
        }

        List<Incidencia> incidencias = incidenciaDao.buscarPorConcesionario(concesionario.trim());
        return filtrarYMapearIncidencias(incidencias, folio, sitioId, estatus);
    }

    private List<IncidenciaGestionDto> filtrarYMapearIncidencias(List<Incidencia> incidencias,
                                                                 String folio,
                                                                 String sitioId,
                                                                 String estatus) {

        if (incidencias == null || incidencias.isEmpty()) {
            return Collections.emptyList();
        }

        Long estatusFiltroId = resolverEstatusIdDesdeString(estatus);
        String folioFiltro = (isBlank(folio) ? null : folio.trim().toUpperCase(Locale.ROOT));
        String sitioFiltro = (isBlank(sitioId) ? null : sitioId.trim());

        Map<String, String> mapaNombreSitio = construirMapaNombreSitio();

        List<IncidenciaGestionDto> resultado = new ArrayList<IncidenciaGestionDto>();

        for (int i = 0; i < incidencias.size(); i++) {
            Incidencia incidencia = incidencias.get(i);
            if (incidencia == null) {
                continue;
            }

            if (folioFiltro != null) {
                String folioInc = (incidencia.getFolio() != null ? incidencia.getFolio().toUpperCase(Locale.ROOT) : "");
                if (!folioInc.contains(folioFiltro)) {
                    continue;
                }
            }

            if (sitioFiltro != null) {
                if (incidencia.getIdSitio() == null || !sitioFiltro.equals(incidencia.getIdSitio())) {
                    continue;
                }
            }

            if (estatusFiltroId != null) {
                if (incidencia.getIdEstatusIncidencia() == null || !estatusFiltroId.equals(incidencia.getIdEstatusIncidencia())) {
                    continue;
                }
            }

            resultado.add(toGestionDto(incidencia, mapaNombreSitio));
        }

        Collections.sort(resultado, new Comparator<IncidenciaGestionDto>() {
            @Override
            public int compare(IncidenciaGestionDto a, IncidenciaGestionDto b) {
                // Orden descendente por fechaCreacion (string), manteniendo estable si viene vacío
                String fa = (a != null && a.getFechaCreacion() != null) ? a.getFechaCreacion() : "";
                String fb = (b != null && b.getFechaCreacion() != null) ? b.getFechaCreacion() : "";
                return fb.compareTo(fa);
            }
        });

        return resultado;
    }

    private IncidenciaGestionDto toGestionDto(Incidencia incidencia, Map<String, String> mapaNombreSitio) {

        IncidenciaGestionDto dto = new IncidenciaGestionDto();

        dto.setIdIncidencia(incidencia.getId());
        dto.setFolio(incidencia.getFolio());

        dto.setIdSitio(incidencia.getIdSitio());
        dto.setNombreSitio(obtenerNombreSitio(mapaNombreSitio, incidencia.getIdSitio()));

        dto.setConcesionario(incidencia.getIdConcesionario());
        dto.setPendientePor(nombreResponsabilidad(incidencia.getIdResponsabilidad()));

        dto.setEstatus(nombreEstatus(incidencia.getIdEstatusIncidencia()));

        String usuarioCreacion = !isBlank(incidencia.getNombreReporta()) ? incidencia.getNombreReporta() : incidencia.getUsuarioAlta();
        dto.setUsuarioCreacion(usuarioCreacion);
        dto.setCorreoUsuarioCreacion(incidencia.getCorreoReporta());

        dto.setFechaCreacion(formatearFecha(incidencia.getFechaAlta()));

        dto.setTipo(nombreTipo(incidencia.getIdTipoIncidencia()));
        dto.setDescripcion(incidencia.getDescripcion());

        return dto;
    }

    private Map<String, String> construirMapaNombreSitio() {
        Map<String, String> mapa = new HashMap<String, String>();

        List<SitioDto> sitios = sitiosPort.listarSitiosVisiblesParaUsuario();
        if (sitios == null || sitios.isEmpty()) {
            return mapa;
        }

        for (int i = 0; i < sitios.size(); i++) {
            SitioDto sitio = sitios.get(i);
            if (sitio != null && sitio.getSitio() != null) {
                mapa.put(sitio.getSitio(), sitio.getNombre());
            }
        }

        return mapa;
    }

    private String obtenerNombreSitio(Map<String, String> mapaNombreSitio, String idSitio) {
        if (idSitio == null) {
            return "";
        }
        if (mapaNombreSitio == null) {
            return idSitio;
        }
        String nombre = mapaNombreSitio.get(idSitio);
        return (nombre != null ? nombre : idSitio);
    }

    private String formatearFecha(LocalDateTime fecha) {
        return (fecha != null ? fecha.format(FECHA_FORMATTER) : "");
    }

    // ==========================================================
    // Bitácora (lectura) -> enriquecimiento transitorio
    // ==========================================================

    @Override
    @Transactional(readOnly = true)
    public List<IncidenciaBitacora> obtenerBitacoraIncidencia(Long idIncidencia) {

        if (idIncidencia == null) {
            return Collections.emptyList();
        }

        List<IncidenciaBitacora> movimientos = bitacoraDao.buscarPorIncidenciaId(idIncidencia);
        if (movimientos == null || movimientos.isEmpty()) {
            return Collections.emptyList();
        }

        // Orden ASC para que el "primer movimiento" realmente sea ALTA (lo usa el Bean)
        Collections.sort(movimientos, new Comparator<IncidenciaBitacora>() {
            @Override
            public int compare(IncidenciaBitacora a, IncidenciaBitacora b) {
                LocalDateTime fa = (a != null ? a.getFechaEvento() : null);
                LocalDateTime fb = (b != null ? b.getFechaEvento() : null);

                if (fa == null && fb == null) return 0;
                if (fa == null) return -1;
                if (fb == null) return 1;
                return fa.compareTo(fb);
            }
        });

        String estatusAnterior = "";
        for (int i = 0; i < movimientos.size(); i++) {
            IncidenciaBitacora movimiento = movimientos.get(i);
            if (movimiento == null) {
                continue;
            }

            String estatusNuevo = nombreEstatus(movimiento.getIdEstatusIncidencia());
            movimiento.setEstatusAnterior(estatusAnterior);
            movimiento.setEstatusNuevo(estatusNuevo);

            if (i == 0) {
                movimiento.setEvento("ALTA");
            } else {
                movimiento.setEvento("ACTUALIZACION");
            }

            estatusAnterior = estatusNuevo;
        }

        return movimientos;
    }

    // ==========================================================
    // Evidencias (mock FS) - aislado por flag mockArchivos
    // ==========================================================

    @Override
    public void adjuntarEvidenciaIncidencia(Long idIncidencia, AdjuntoUi adjunto, Long idUsuarioMovimiento) throws IOException {

        if (idIncidencia == null) {
            throw new IllegalArgumentException("idIncidencia es obligatorio.");
        }
        if (adjunto == null) {
            throw new IllegalArgumentException("adjunto es obligatorio.");
        }

        validarAdjunto(adjunto.getNombre(), null, adjunto.getTamanio());

        // Validación de existencia en BD (incidencia real)
        Incidencia incidencia = incidenciaDao.buscarPorId(idIncidencia);
        if (incidencia == null) {
            throw new IllegalArgumentException("No existe la incidencia con id=" + idIncidencia);
        }

        if (!mockArchivos) {
            // Cuando exista filesystem real, aquí se conectará el componente real.
            return;
        }

        List<AdjuntoUi> adjuntos = new ArrayList<AdjuntoUi>();
        adjuntos.add(adjunto);
        guardarAdjuntosMock(idIncidencia, adjuntos);
    }

    @Override
    public void eliminarEvidenciaIncidencia(Long idIncidencia, String rutaRelativa, Long idUsuarioMovimiento) throws IOException {

        if (idIncidencia == null) {
            throw new IllegalArgumentException("idIncidencia es obligatorio.");
        }
        if (isBlank(rutaRelativa)) {
            throw new IllegalArgumentException("rutaRelativa es obligatoria.");
        }

        if (!mockArchivos) {
            return;
        }

        Path archivo = resolverPathSeguro(idIncidencia, rutaRelativa);
        Files.deleteIfExists(archivo);
    }

    @Override
    @Transactional(readOnly = true)
    public List<IncidenciaAdjunto> obtenerAdjuntosIncidencia(Long idIncidencia) {

        if (idIncidencia == null) {
            return Collections.emptyList();
        }
        if (!mockArchivos) {
            return Collections.emptyList();
        }

        Path carpeta = rutaBaseAdjuntos.resolve(String.valueOf(idIncidencia));
        if (!Files.exists(carpeta) || !Files.isDirectory(carpeta)) {
            return Collections.emptyList();
        }

        List<IncidenciaAdjunto> adjuntos = new ArrayList<IncidenciaAdjunto>();

        DirectoryStream<Path> stream = null;
        try {
            stream = Files.newDirectoryStream(carpeta, "*" + EXT_PDF);
            for (Path archivo : stream) {
                if (!Files.isRegularFile(archivo)) {
                    continue;
                }

                String nombre = archivo.getFileName().toString();
                String ruta = "/" + idIncidencia + "/" + nombre;
                long tamanio = Files.size(archivo);

                IncidenciaAdjunto adjunto = new IncidenciaAdjunto();
                // Para ser tolerantes a posibles variaciones del POJO (getNombre/getRuta vs getNombreArchivo/getRutaArchivo),
                // asignamos por reflexión a ambos nombres posibles.
                asignarPropiedadAdjunto(adjunto, "setNombre", String.class, nombre);
                asignarPropiedadAdjunto(adjunto, "setNombreArchivo", String.class, nombre);
                asignarPropiedadAdjunto(adjunto, "setRuta", String.class, ruta);
                asignarPropiedadAdjunto(adjunto, "setRutaArchivo", String.class, ruta);

                asignarPropiedadAdjunto(adjunto, "setTamanio", Long.class, Long.valueOf(tamanio));
                asignarPropiedadAdjunto(adjunto, "setTamanioBytes", Long.class, Long.valueOf(tamanio));

                // Campo "id" si existe en alguna versión
                asignarCampoAdjuntoSiExiste(adjunto, "id", UUID.randomUUID().toString());

                adjuntos.add(adjunto);
            }
        } catch (IOException ex) {
            LOGGER.warn("No se pudieron listar adjuntos de incidencia {}: {}", idIncidencia, ex.getMessage());
            return Collections.emptyList();
        } finally {
            if (stream != null) {
                try {
                    stream.close();
                } catch (IOException ignore) {
                    // ignore
                }
            }
        }

        Collections.sort(adjuntos, new Comparator<IncidenciaAdjunto>() {
            @Override
            public int compare(IncidenciaAdjunto a, IncidenciaAdjunto b) {
                String na = obtenerPropiedadStringAdjunto(a, "getNombre", "getNombreArchivo");
                String nb = obtenerPropiedadStringAdjunto(b, "getNombre", "getNombreArchivo");
                if (na == null) na = "";
                if (nb == null) nb = "";
                return na.compareToIgnoreCase(nb);
            }
        });

        return adjuntos;
    }

    private void guardarAdjuntosMock(Long idIncidencia, List<AdjuntoUi> adjuntos) throws IOException {

        if (adjuntos == null || adjuntos.isEmpty()) {
            return;
        }
        if (!mockArchivos) {
            return;
        }

        Path carpeta = rutaBaseAdjuntos.resolve(String.valueOf(idIncidencia));
        Files.createDirectories(carpeta);

        List<IncidenciaAdjunto> existentes = obtenerAdjuntosIncidencia(idIncidencia);
        int usados = (existentes != null ? existentes.size() : 0);
        if (usados + adjuntos.size() > MAX_ARCHIVOS) {
            throw new IllegalStateException("La incidencia excede el máximo de archivos permitidos (" + MAX_ARCHIVOS + ").");
        }

        for (int i = 0; i < adjuntos.size(); i++) {
            AdjuntoUi adjunto = adjuntos.get(i);
            if (adjunto == null) {
                continue;
            }

            validarAdjunto(adjunto.getNombre(), null, adjunto.getTamanio());

            String nombreSeguro = sanitizarNombreArchivo(adjunto.getNombre());
            Path destino = resolverDestinoSinColision(carpeta, nombreSeguro);

            Files.write(destino, adjunto.getBytes(), StandardOpenOption.CREATE_NEW);
        }
    }

    private Path resolverDestinoSinColision(Path carpeta, String nombreArchivo) {

        Path destino = carpeta.resolve(nombreArchivo);
        if (!Files.exists(destino)) {
            return destino;
        }

        String base = nombreArchivo;
        String extension = "";
        int idx = nombreArchivo.lastIndexOf('.');
        if (idx > 0) {
            base = nombreArchivo.substring(0, idx);
            extension = nombreArchivo.substring(idx);
        }

        for (int i = 1; i <= 999; i++) {
            Path candidato = carpeta.resolve(base + "_" + i + extension);
            if (!Files.exists(candidato)) {
                return candidato;
            }
        }

        return carpeta.resolve(base + "_" + UUID.randomUUID() + extension);
    }

    private String sanitizarNombreArchivo(String nombre) {

        String limpio = (nombre != null ? nombre.trim() : "archivo.pdf");
        limpio = limpio.replace("\\", "_").replace("/", "_");
        limpio = limpio.replace("..", "_");
        limpio = limpio.replaceAll("[\\r\\n\\t]", "_");
        limpio = limpio.replaceAll("[^a-zA-Z0-9._\\-\\s]", "_").trim();

        if (!limpio.toLowerCase(Locale.ROOT).endsWith(EXT_PDF)) {
            limpio = limpio + EXT_PDF;
        }

        if (limpio.isEmpty()) {
            limpio = "archivo" + EXT_PDF;
        }

        return limpio;
    }

    private Path resolverPathSeguro(Long idIncidencia, String rutaRelativa) {

        String ruta = rutaRelativa.replace("\\", "/").trim();
        while (ruta.startsWith("/")) {
            ruta = ruta.substring(1);
        }

        Path baseIncidencia = rutaBaseAdjuntos.resolve(String.valueOf(idIncidencia)).normalize();
        Path abs = baseIncidencia.resolve(ruta).normalize();

        if (!abs.startsWith(baseIncidencia)) {
            throw new IllegalArgumentException("Ruta inválida.");
        }

        return abs;
    }

    // ==========================================================
    // Helpers: tipo / estatus / responsabilidad
    // ==========================================================

    private Long resolverTipoIdDesdeUi(String tipoUi) {

        String tipoNormalizado = normalizarClave(tipoUi);

        if (esNumero(tipoNormalizado)) {
            long valor = Long.parseLong(tipoNormalizado);
            if (valor == 1L) return TIPO_INFRAESTRUCTURA_PASIVA;
            if (valor == 2L) return TIPO_SITIO;
        }

        if (tipoNormalizado.contains("INFRA")) {
            return TIPO_INFRAESTRUCTURA_PASIVA;
        }
        if (tipoNormalizado.contains("SITIO")) {
            return TIPO_SITIO;
        }

        throw new IllegalArgumentException("Tipo de incidencia inválido: " + tipoUi);
    }

    private Long resolverEstatusIdDesdeString(String estatusUi) {

        if (isBlank(estatusUi)) {
            return null;
        }

        String estatusNormalizado = normalizarClave(estatusUi);

        if (esNumero(estatusNormalizado)) {
            long valor = Long.parseLong(estatusNormalizado);
            if (valor >= 1L && valor <= 4L) {
                return Long.valueOf(valor);
            }
        }

        if (estatusNormalizado.contains("CREADA")) return ESTATUS_CREADA;
        if (estatusNormalizado.contains("EN_ATENCION") || estatusNormalizado.contains("ENATENCION")) return ESTATUS_EN_ATENCION;
        if (estatusNormalizado.contains("RECHAZADA")) return ESTATUS_RECHAZADA;
        if (estatusNormalizado.contains("FINALIZADA")) return ESTATUS_FINALIZADA;

        return null;
    }

    private String nombreEstatus(Long idEstatus) {
        if (ESTATUS_CREADA.equals(idEstatus)) return TEXTO_ESTATUS_CREADA;
        if (ESTATUS_EN_ATENCION.equals(idEstatus)) return TEXTO_ESTATUS_EN_ATENCION;
        if (ESTATUS_RECHAZADA.equals(idEstatus)) return TEXTO_ESTATUS_RECHAZADA;
        if (ESTATUS_FINALIZADA.equals(idEstatus)) return TEXTO_ESTATUS_FINALIZADA;
        return "";
    }

    private String nombreTipo(Long idTipo) {
        if (TIPO_INFRAESTRUCTURA_PASIVA.equals(idTipo)) return "Infraestructura Pasiva";
        if (TIPO_SITIO.equals(idTipo)) return "Sitio";
        return "";
    }

    private String nombreResponsabilidad(Long idResp) {
        if (RESP_CONCESIONARIO.equals(idResp)) return "Concesionario";
        if (RESP_MANTENIMIENTO.equals(idResp)) return "Mantenimiento";
        return "";
    }

    // ==========================================================
    // Concurrencia: lock pesimista para MAX+1 (Oracle)
    // ==========================================================

    private void lockTableExclusive(String tabla) {
        if (entityManager == null) {
            return;
        }
        if (isBlank(tabla)) {
            return;
        }
        try {
            entityManager.createNativeQuery("LOCK TABLE " + tabla + " IN EXCLUSIVE MODE").executeUpdate();
        } catch (Exception ex) {
            // No interrumpimos si no hay privilegio: MAX+1 seguirá funcionando, pero con menor robustez
            LOGGER.debug("No fue posible LOCK TABLE {}: {}", tabla, ex.getMessage());
        }
    }

    // ==========================================================
    // Suscripción Concesionario–Sitio
    // ==========================================================

    private void validarSuscripcionConcesionarioSitio(String concesionario, String sitio) {

        Set<String> sitiosSuscritos = suscripcionSitioService.listarSitiosSuscritos(concesionario);
        if (sitiosSuscritos == null || sitiosSuscritos.isEmpty()) {
            throw new IllegalArgumentException("El concesionario no tiene sitios suscritos.");
        }
        if (!sitiosSuscritos.contains(sitio)) {
            throw new IllegalArgumentException("El sitio no está suscrito para el concesionario.");
        }
    }

    // ==========================================================
    // Utilidades base
    // ==========================================================

    private boolean isBlank(String valor) {
        return valor == null || valor.trim().isEmpty();
    }

    private boolean esNumero(String valor) {
        if (valor == null || valor.isEmpty()) {
            return false;
        }
        for (int i = 0; i < valor.length(); i++) {
            if (!Character.isDigit(valor.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    private String normalizarClave(String valor) {
        if (valor == null) {
            return "";
        }
        String sinAcentos = Normalizer.normalize(valor, Normalizer.Form.NFD)
                .replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
        return sinAcentos.trim().toUpperCase(Locale.ROOT).replace(' ', '_');
    }

    // ==========================================================
    // Reflexión tolerante para variaciones de POJOs (adjuntos)
    // ==========================================================

    private void asignarPropiedadAdjunto(Object target, String setterName, Class<?> parameterType, Object value) {
        if (target == null || setterName == null) {
            return;
        }
        try {
            Method method = target.getClass().getMethod(setterName, parameterType);
            method.invoke(target, value);
        } catch (Exception ignore) {
            // ignore
        }
    }

    private void asignarCampoAdjuntoSiExiste(Object target, String fieldName, Object value) {
        if (target == null || fieldName == null) {
            return;
        }
        try {
            Field field = target.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(target, value);
        } catch (Exception ignore) {
            // ignore
        }
    }

    private String obtenerPropiedadStringAdjunto(Object target, String getterPrimario, String getterSecundario) {
        String valor = invocarGetterString(target, getterPrimario);
        if (valor != null) {
            return valor;
        }
        return invocarGetterString(target, getterSecundario);
    }

    private String invocarGetterString(Object target, String getterName) {
        if (target == null || getterName == null) {
            return null;
        }
        try {
            Method method = target.getClass().getMethod(getterName);
            Object value = method.invoke(target);
            return (value != null ? String.valueOf(value) : null);
        } catch (Exception ignore) {
            return null;
        }
    }
}

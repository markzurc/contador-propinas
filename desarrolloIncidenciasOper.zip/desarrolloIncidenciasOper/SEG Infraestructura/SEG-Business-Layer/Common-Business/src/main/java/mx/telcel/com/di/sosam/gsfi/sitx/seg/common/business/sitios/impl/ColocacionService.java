/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.impl;

import java.util.List;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.IColocacionService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.IColocacion;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ColocacionTablaEspacioPisoDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ColocacionTablaEspacioTorreDTO;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.ProgramaColocacionDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.SoliArchDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dto.VerificacionColocacionDto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author VI7FC37
 */
@Service("colocacionServiceImpl")
@Scope("prototype")
public class ColocacionService implements IColocacionService{
    @Autowired
    @Qualifier("colocacionDao")
    private IColocacion colocacionDao;
    
    
    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRES_NEW)
    @Override
    public boolean insertaPrincipalSolicitudColocacion(String folio, String calibreRF, String calibreMW, String superficie, String transformador, String observaciones, String observacionesTelcel){
        return colocacionDao.insertaPrincipalSolicitudColocacion(folio, calibreRF,calibreMW, superficie, transformador, observaciones, observacionesTelcel);
    }
    
    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRES_NEW)
    @Override
    public boolean actualizaPrincipalSolicitudColocacion(String folio, String calibreRF, String calibreMW, String superficie, String transformador, String observaciones, String observacionesTelcel){
        return colocacionDao.actualizaPrincipalSolicitudColocacion(folio, calibreRF, calibreMW, superficie, transformador, observaciones, observacionesTelcel);
    }

    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRES_NEW)
    @Override
    public boolean insertaSolicitudColocacionEspacioTorre(String string, List<ColocacionTablaEspacioTorreDTO> list) {
        return colocacionDao.insertaSolicitudColocacionEspacioTorre(string, list);
    }
    
    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRES_NEW)
    @Override
    public boolean actualizaSolicitudColocacionEspacioTorre(String folio, List<ColocacionTablaEspacioTorreDTO> listaEspacioTorre){
        return colocacionDao.actualizaSolicitudColocacionEspacioTorre(folio, listaEspacioTorre);
    }
    
    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRES_NEW)
    @Override
    public boolean eliminaSolicitudColocacionEspacioTorre(String folio, List<ColocacionTablaEspacioTorreDTO> listaEspacioTorre){
        return colocacionDao.eliminaSolicitudColocacionEspacioTorre(folio, listaEspacioTorre);
    }

    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRES_NEW)
    @Override
    public boolean insertaSolicitudColocacionEspacioPiso(String string, List<ColocacionTablaEspacioPisoDTO> list) {
        return colocacionDao.insertaSolicitudColocacionEspacioPiso(string, list);
    }
    
    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRES_NEW)
    @Override
    public boolean actualizaSolicitudColocacionEspacioPiso(String folio, List<ColocacionTablaEspacioPisoDTO> listaEspacioPiso){
        return colocacionDao.actualizaSolicitudColocacionEspacioPiso(folio, listaEspacioPiso);
    }
    
    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRES_NEW)
    @Override
    public boolean eliminarSolicitudColocacionEspacioPiso(String folio, List<ColocacionTablaEspacioPisoDTO> listaEspacioPiso){
        return colocacionDao.eliminarSolicitudColocacionEspacioPiso(folio, listaEspacioPiso);
    }

    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRES_NEW)
    @Override
    public boolean insertaArchivoEnTabla(String string, List<SoliArchDto> list) {
        return colocacionDao.insertaArchivoEnTabla(string, list);
    }
    
    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.NEVER)
    @Override
    public List<SoliArchDto> obtenerArchivoEnTabla(String folio, String ruta) {
        return colocacionDao.obtenerArchivoEnTabla(folio, ruta);
    }
    
    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.NEVER)
    @Override
    public List<ColocacionTablaEspacioTorreDTO> obtenerEspacioTorre(String folio){
        return colocacionDao.obtenerEspacioTorre(folio);
    }
    
    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.NEVER)
    @Override
    public List<ColocacionTablaEspacioPisoDTO> obtenerEspacioPiso(String folio){
        return colocacionDao.obtenerEspacioPiso(folio);
    }

    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.NEVER)
    @Override
    public String obtenerDatosSolicitudColocacion(String folio) {
        return colocacionDao.obtenerDatosSolicitudColocacion(folio);
    }

    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRES_NEW)
    @Override
    public boolean actualizaArchivoEnTabla(String folio, String ruta ,List<SoliArchDto> list) {
        return colocacionDao.actualizaArchivoEnTabla(folio, ruta ,list);
    }

    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRES_NEW)
    @Override
    public boolean eliminaArchivoEnTabla(String string, List<SoliArchDto> list) {
        return colocacionDao.eliminaArchivoEnTabla(string, list);
    }
    
    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.NEVER)
    @Override
    public String consultaExistenciaSolicitudColocacion(String folio){
        return colocacionDao.consultaExistenciaSolicitudColocacion(folio);
    }
    
    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRES_NEW)
    @Override
    public boolean insertaProgramaColocacion(List<ProgramaColocacionDto> list) {
        return colocacionDao.insertaProgramaColocacion(list);
    }
    
    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.NEVER)
    @Override
    public List<ProgramaColocacionDto> obtenerProgramaColocacion(String folio) {
        return colocacionDao.obtenerProgramaColocacion(folio);
    }
    
    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRES_NEW)
	@Override
	public boolean insertaVerificacionColocacion(VerificacionColocacionDto colocacion) {
		return colocacionDao.insertaVerificacionColocacion(colocacion);
	}

    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRES_NEW)
	@Override
	public List<VerificacionColocacionDto> consultaListaVerificacion(String folio) {
		return colocacionDao.consultaListaVerificacion(folio);
	}

    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRES_NEW)
	@Override
	public int consultaEstadoBitacora(String folio, String estatus) {
		return colocacionDao.consultaEstadoBitacora(folio, estatus);
	}

    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRES_NEW)
	@Override
	public boolean updateVerificacionColocacion(VerificacionColocacionDto colocacion) {
		return colocacionDao.updateVerificacionColocacion(colocacion);
	}

    @Transactional(value = "transactionManagerOVITAPP", propagation = Propagation.REQUIRES_NEW)
	@Override
	public boolean corregirVerificacionColocacion(VerificacionColocacionDto colocacion) {
		return colocacionDao.corregirVerificacionColocacion(colocacion);
	}
}

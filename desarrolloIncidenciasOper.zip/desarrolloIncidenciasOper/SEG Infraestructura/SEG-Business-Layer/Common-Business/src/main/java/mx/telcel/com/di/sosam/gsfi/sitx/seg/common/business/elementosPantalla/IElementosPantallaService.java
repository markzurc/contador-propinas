package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.elementosPantalla;
import java.util.List;
import java.util.Map;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.elementosPantalla.dto.ElementosPantallaDTO;

public interface IElementosPantallaService {

	public List<ElementosPantallaDTO> getElementosPermitidosPantalla(String flujo,
			Integer idRolUsuario,Map<String,Integer>valoresAvalidar);
}

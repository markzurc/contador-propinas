package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.impl;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.ISuscripcionSitioService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.ISuscripcionSitioDao;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class SuscripcionSitioServiceImpl implements ISuscripcionSitioService {

    private static final Logger LOGGER = LogManager.getLogger(SuscripcionSitioServiceImpl.class);

    /**
     * IMPORTANTE: para tu caso debe ir en FALSE para que use BD y persista.
     * El "mock" (memoria) se deja solo como fallback local.
     */
    private static final boolean USAR_ALMACEN_EN_MEMORIA = false;

    private static final Map<String, Set<String>> ALMACEN_SUSCRIPCIONES = new HashMap<String, Set<String>>();

    @Autowired
    private ISuscripcionSitioDao suscripcionSitioDao;

    @Override
    public void registrarSuscripcion(String sitioId, String concesionario, String folioSolicitud) {
        if (USAR_ALMACEN_EN_MEMORIA) {
            registrarSuscripcionMemoria(sitioId, concesionario);
            return;
        }

        String concesionarioNormalizado = normalizarConcesionario(concesionario);
        suscripcionSitioDao.registrarSuscripcion(folioSolicitud, concesionarioNormalizado, sitioId, new Date());
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
    public Set<String> listarSitiosSuscritos(String concesionarioIdentificador) {

        logger.info("SuscripcionSitioServiceImpl.listarSitiosSuscritos - INICIO - concesionarioIdentificador={}",
                concesionarioIdentificador);

        if (USAR_ALMACEN_EN_MEMORIA) {
            Set<String> sitiosEnMemoria = almacenEnMemoria.obtenerSitiosSuscritos(concesionarioIdentificador);
            int totalMemoria = (sitiosEnMemoria == null) ? 0 : sitiosEnMemoria.size();

            logger.info("SuscripcionSitioServiceImpl.listarSitiosSuscritos - MEMORIA - totalSitios={}", totalMemoria);
            return sitiosEnMemoria;
        }

        Set<String> sitiosSuscritos = suscripcionSitioDao.listarSitiosSuscritos(concesionarioIdentificador);
        int totalBd = (sitiosSuscritos == null) ? 0 : sitiosSuscritos.size();

        logger.info("SuscripcionSitioServiceImpl.listarSitiosSuscritos - BD - totalSitios={}", totalBd);

        return sitiosSuscritos;
    }


    @Override
    public boolean existeSuscripcion(String sitioId, String concesionario) {
        if (USAR_ALMACEN_EN_MEMORIA) {
            return existeSuscripcionMemoria(sitioId, concesionario);
        }

        String concesionarioNormalizado = normalizarConcesionario(concesionario);
        return suscripcionSitioDao.existeSuscripcion(concesionarioNormalizado, sitioId);
    }

    @Override
    public void cancelarSuscripcion(String sitioId, String concesionario) {
        if (USAR_ALMACEN_EN_MEMORIA) {
            cancelarSuscripcionMemoria(sitioId, concesionario);
            return;
        }

        String concesionarioNormalizado = normalizarConcesionario(concesionario);
        suscripcionSitioDao.cancelarSuscripcion(concesionarioNormalizado, sitioId, new Date());
    }

    private void registrarSuscripcionMemoria(String sitioId, String concesionario) {
        if (sitioId == null || concesionario == null) {
            return;
        }

        String key = normalizarConcesionario(concesionario);
        Set<String> sitios = ALMACEN_SUSCRIPCIONES.get(key);
        if (sitios == null) {
            sitios = new HashSet<String>();
            ALMACEN_SUSCRIPCIONES.put(key, sitios);
        }
        sitios.add(sitioId);

        LOGGER.info("Suscripción registrada en memoria. Concesionario: {}, Sitio: {}", key, sitioId);
    }

    private Set<String> listarSuscripcionesMemoria(String concesionario) {
        if (concesionario == null) {
            return Collections.emptySet();
        }
        String key = normalizarConcesionario(concesionario);
        Set<String> sitios = ALMACEN_SUSCRIPCIONES.get(key);
        return sitios == null ? Collections.<String>emptySet() : new HashSet<String>(sitios);
    }

    private boolean existeSuscripcionMemoria(String sitioId, String concesionario) {
        if (sitioId == null || concesionario == null) {
            return false;
        }
        String key = normalizarConcesionario(concesionario);
        Set<String> sitios = ALMACEN_SUSCRIPCIONES.get(key);
        return sitios != null && sitios.contains(sitioId);
    }

    private void cancelarSuscripcionMemoria(String sitioId, String concesionario) {
        if (sitioId == null || concesionario == null) {
            return;
        }
        String key = normalizarConcesionario(concesionario);
        Set<String> sitios = ALMACEN_SUSCRIPCIONES.get(key);
        if (sitios != null) {
            sitios.remove(sitioId);
        }
        LOGGER.info("Suscripción cancelada en memoria. Concesionario: {}, Sitio: {}", key, sitioId);
    }

    /**
     * Ejemplo:
     * - "1202:BUENOCELL." -> "1202"
     */
    private String normalizarConcesionario(String concesionario) {
        if (concesionario == null) {
            return null;
        }

        String valor = concesionario.trim();
        int separador = valor.indexOf(':');
        if (separador > 0) {
            String codigo = valor.substring(0, separador).trim();
            return codigo.isEmpty() ? valor : codigo;
        }

        if (valor.endsWith(".")) {
            valor = valor.substring(0, valor.length() - 1).trim();
        }

        return valor;
    }
}

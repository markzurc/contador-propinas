package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.impl;

import java.util.Collections;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.ISuscripcionSitioService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.ISuscripcionSitioDao;

@Service
@Transactional
public class SuscripcionSitioServiceImpl implements ISuscripcionSitioService {

    private static final Logger LOGGER = LoggerFactory.getLogger(SuscripcionSitioServiceImpl.class);

    @Autowired
    private ISuscripcionSitioDao suscripcionSitioDao;

    @Override
    public Set<String> listarSitiosSuscritos(String concesionarioIdentificador) {
        String concesionario = normalizarConcesionario(concesionarioIdentificador);

        LOGGER.info("[SUSC][SERVICE] listarSitiosSuscritos INICIO - concesionarioIdentificador={}, normalizado={}",
                concesionarioIdentificador, concesionario);

        if (concesionario == null || concesionario.isEmpty()) {
            LOGGER.warn("[SUSC][SERVICE] concesionario vacio, se regresa emptySet");
            return Collections.emptySet();
        }

        try {
            Set<String> sitios = suscripcionSitioDao.listarSitiosSuscritos(concesionario);
            int size = (sitios == null) ? 0 : sitios.size();

            LOGGER.info("[SUSC][SERVICE] listarSitiosSuscritos FIN - concesionario={}, sitios.size={}", concesionario, size);
            return (sitios == null) ? Collections.<String>emptySet() : sitios;

        } catch (Exception exception) {
            LOGGER.error("[SUSC][SERVICE] Error en listarSitiosSuscritos concesionarioIdentificador={}", concesionario, exception);
            throw exception;
        }
    }

    @Override
    public void registrarSuscripcion(String sitioId, String concesionarioIdentificador, String folioSolicitud) {
        String concesionario = normalizarConcesionario(concesionarioIdentificador);
        String sitioNormalizado = (sitioId == null) ? null : sitioId.trim();

        if (concesionario == null || concesionario.isEmpty()) {
            LOGGER.warn("[SUSC][SERVICE] registrarSuscripcion: concesionario vac�o. sitioId={}, folio={}", sitioId, folioSolicitud);
            return;
        }
        if (sitioNormalizado == null || sitioNormalizado.isEmpty()) {
            LOGGER.warn("[SUSC][SERVICE] registrarSuscripcion: sitioId vacio. concesionario={}, folio={}", concesionario, folioSolicitud);
            return;
        }
        String usuarioAlta = (folioSolicitud == null || folioSolicitud.trim().isEmpty())
                ? "SYSTEM"
                : folioSolicitud.trim();

        try {
            boolean yaExiste = suscripcionSitioDao.existeSuscripcionActiva(concesionario, sitioNormalizado);
            if (yaExiste) {
                LOGGER.info("[SUSC][SERVICE] registrarSuscripcion: ya existe activa. concesionario={}, sitioId={}, folio={}",
                        concesionario, sitioNormalizado, folioSolicitud);
                return;
            }

            suscripcionSitioDao.registrarSuscripcion(concesionario, sitioNormalizado, usuarioAlta);

            LOGGER.info("[SUSC][SERVICE] registrarSuscripcion OK. concesionario={}, sitioId={}, folio={}",
                    concesionario, sitioNormalizado, folioSolicitud);

        } catch (Exception exception) {
            LOGGER.error("[SUSC][SERVICE] registrarSuscripcion ERROR. concesionario={}, sitioId={}, folio={}",
                    concesionario, sitioNormalizado, folioSolicitud, exception);
            throw exception;
        }
    }

    @Override
    public boolean existeSuscripcionActiva(String sitioId, String concesionarioIdentificador) {
        String concesionario = normalizarConcesionario(concesionarioIdentificador);
        if (concesionario == null || concesionario.isEmpty()) {
            return false;
        }
        String sitioNormalizado = (sitioId == null) ? null : sitioId.trim();
        if (sitioNormalizado == null || sitioNormalizado.isEmpty()) {
            return false;
        }
        return suscripcionSitioDao.existeSuscripcionActiva(concesionario, sitioNormalizado);
    }

 
    private String normalizarConcesionario(String concesionarioIdentificador) {
        if (concesionarioIdentificador == null) return null;
        String value = concesionarioIdentificador.trim();
        if (value.contains(":")) {
            value = value.substring(0, value.indexOf(":")).trim();
        }
        
        if (value.endsWith(".")) {
            value = value.substring(0, value.length() - 1).trim();
        }
        return value;
    }
}

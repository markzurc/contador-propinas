package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.impl;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.ISuscripcionSitioService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.ISuscripcionSitioDao;

@Service
public class SuscripcionSitioServiceImpl implements ISuscripcionSitioService {

    private static final Logger log = LoggerFactory.getLogger(SuscripcionSitioServiceImpl.class);

    /**
     * Mientras no exista BDD de suscripciones (o el cliente no haya habilitado la relación),
     * el módulo opera con un almacén temporal en memoria.
     */
    private static final boolean USAR_ALMACEN_EN_MEMORIA = true;

    /**
     * Formato de clave en memoria: CONCESIONARIO|SITIO
     */
    private final Set<String> suscripcionesEnMemoria = new HashSet<String>();

    @Autowired
    private ISuscripcionSitioDao suscripcionSitioDao;

    @Override
    public void registrarSuscripcion(String sitioId, String concesionario, String folioSolicitud) {
        String sitioNormalizado = normalizarSitioId(sitioId);
        String concesionarioNormalizado = normalizarConcesionario(concesionario);

        if (sitioNormalizado == null || concesionarioNormalizado == null) {
            log.warn(
                "SuscripcionSitioServiceImpl.registrarSuscripcion - parámetros inválidos sitioId=[{}] concesionario=[{}] folio=[{}]",
                sitioId, concesionario, folioSolicitud
            );
            return;
        }

        if (USAR_ALMACEN_EN_MEMORIA) {
            suscripcionesEnMemoria.add(clave(concesionarioNormalizado, sitioNormalizado));
            return;
        }

        try {
            if (suscripcionSitioDao == null) {
                log.warn("SuscripcionSitioServiceImpl.registrarSuscripcion - suscripcionSitioDao es null. No se registra suscripción.");
                return;
            }

            // Firma del DAO (Common-Data):
            // registrarSuscripcion(String folioSolicitud, String concesionarioId, String sitioId, Date fechaSuscripcion)
            suscripcionSitioDao.registrarSuscripcion(folioSolicitud, concesionarioNormalizado, sitioNormalizado, new Date());

        } catch (Exception exception) {
            log.error("SuscripcionSitioServiceImpl.registrarSuscripcion - error registrando suscripción", exception);
        }
    }

    @Override
    public boolean existeSuscripcionActiva(String sitioId, String concesionario) {
        String sitioNormalizado = normalizarSitioId(sitioId);
        String concesionarioNormalizado = normalizarConcesionario(concesionario);

        if (sitioNormalizado == null || concesionarioNormalizado == null) {
            return false;
        }

        if (USAR_ALMACEN_EN_MEMORIA) {
            return suscripcionesEnMemoria.contains(clave(concesionarioNormalizado, sitioNormalizado));
        }

        try {
            if (suscripcionSitioDao == null) {
                return false;
            }

            // Firma del DAO (Common-Data): existeSuscripcion(String concesionarioId, String sitioId)
            return suscripcionSitioDao.existeSuscripcion(concesionarioNormalizado, sitioNormalizado);

        } catch (Exception exception) {
            log.error("SuscripcionSitioServiceImpl.existeSuscripcionActiva - error consultando suscripción", exception);
            return false;
        }
    }

    @Override
    public Set<String> listarSitiosSuscritos(String concesionario) {
        String concesionarioNormalizado = normalizarConcesionario(concesionario);
        Set<String> resultado = new HashSet<String>();

        if (concesionarioNormalizado == null) {
            return resultado;
        }

        if (USAR_ALMACEN_EN_MEMORIA) {
            for (String registro : suscripcionesEnMemoria) {
                if (registro == null) {
                    continue;
                }

                int separador = registro.indexOf('|');
                if (separador < 0) {
                    continue;
                }

                String concesionarioEnRegistro = registro.substring(0, separador);
                if (!concesionarioNormalizado.equals(concesionarioEnRegistro)) {
                    continue;
                }

                String sitioEnRegistro = registro.substring(separador + 1);
                if (sitioEnRegistro != null && !sitioEnRegistro.isEmpty()) {
                    resultado.add(sitioEnRegistro);
                }
            }
            return resultado;
        }

        try {
            if (suscripcionSitioDao == null) {
                return resultado;
            }

            // Firma del DAO (Common-Data): listarSitiosSuscritos(String concesionarioId)
            resultado.addAll(suscripcionSitioDao.listarSitiosSuscritos(concesionarioNormalizado));

        } catch (Exception exception) {
            log.error("SuscripcionSitioServiceImpl.listarSitiosSuscritos - error consultando sitios suscritos", exception);
        }

        return resultado;
    }

    private String normalizarSitioId(String sitioId) {
        if (sitioId == null) {
            return null;
        }
        String value = sitioId.trim();
        if (value.isEmpty()) {
            return null;
        }
        return value.toUpperCase();
    }

    private String normalizarConcesionario(String concesionario) {
        if (concesionario == null) {
            return null;
        }
        String value = concesionario.trim();
        if (value.isEmpty()) {
            return null;
        }
        return value.toUpperCase();
    }

    private String clave(String concesionario, String sitioId) {
        return concesionario + "|" + sitioId;
    }
}

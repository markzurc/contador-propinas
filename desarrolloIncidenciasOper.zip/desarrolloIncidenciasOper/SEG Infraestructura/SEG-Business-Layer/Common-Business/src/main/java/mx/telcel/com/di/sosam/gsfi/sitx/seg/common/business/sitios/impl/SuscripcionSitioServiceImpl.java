package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.impl;

import java.util.Collections;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.ISuscripcionSitioService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.ISuscripcionSitioDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.entity.SuscripcionSitio;

@Service
@Transactional
public class SuscripcionSitioServiceImpl implements ISuscripcionSitioService {

    private static final Logger LOGGER = LoggerFactory.getLogger(SuscripcionSitioServiceImpl.class);

    @Autowired
    private ISuscripcionSitioDao suscripcionSitioDao;

    @Override
    public Set<String> listarSitiosSuscritos(String concesionarioIdentificador) {
        String concesionario = normalizarConcesionario(concesionarioIdentificador);

        LOGGER.info("[SUSC][SERVICE] listarSitiosSuscritos INICIO - concesionarioIdentificador={}, normalizado={}",
                concesionarioIdentificador, concesionario);

        if (concesionario == null || concesionario.isEmpty()) {
            LOGGER.warn("[SUSC][SERVICE] concesionario vacío, se regresa emptySet");
            return Collections.emptySet();
        }

        try {
            Set<String> sitios = suscripcionSitioDao.listarSitiosSuscritos(concesionario);
            int size = (sitios == null) ? 0 : sitios.size();

            LOGGER.info("[SUSC][SERVICE] listarSitiosSuscritos FIN - concesionario={}, sitios.size={}", concesionario, size);
            return (sitios == null) ? Collections.<String>emptySet() : sitios;

        } catch (Exception ex) {
            LOGGER.error("[SUSC][SERVICE] Error en listarSitiosSuscritos concesionarioIdentificador={}", concesionario, ex);
            throw ex;
        }
    }

    @Override
    public void registrarSuscripcion(SuscripcionSitio entidad) {
        suscripcionSitioDao.registrarSuscripcion(entidad);
    }

    @Override
    public boolean existeSuscripcionActiva(String concesionarioIdentificador, String sitioId) {
        String concesionario = normalizarConcesionario(concesionarioIdentificador);
        return suscripcionSitioDao.existeSuscripcionActiva(concesionario, sitioId);
    }

    @Override
    public void cancelarTodasSuscripciones(String concesionarioIdentificador, String usuario) {
        String concesionario = normalizarConcesionario(concesionarioIdentificador);
        suscripcionSitioDao.cancelarTodasSuscripciones(concesionario, usuario);
    }

    /**
     * Importante:
     * - Mantener "018:PEGASO" tal cual (se usa contra SOL.GRUPO_OPERADOR y puede ser el valor real en BD).
     * - Solo limpia espacios y punto final si llegara a venir como "018:PEGASO."
     */
    private String normalizarConcesionario(String concesionarioIdentificador) {
        if (concesionarioIdentificador == null) {
            return null;
        }

        String value = concesionarioIdentificador.trim();
        if (value.endsWith(".")) {
            value = value.substring(0, value.length() - 1).trim();
        }
        return value;
    }
}

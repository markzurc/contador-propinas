package mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.impl;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.sitios.ISuscripcionSitioService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.sitios.dao.ISuscripcionSitioDao;

@Service("suscripcionSitioService")
public class SuscripcionSitioServiceImpl implements ISuscripcionSitioService {

    private static final Logger log = LoggerFactory.getLogger(SuscripcionSitioServiceImpl.class);

    /** HOY: true (almacén en memoria). MAÑANA: false (DAO/tabla). */
    private static final boolean USAR_ALMACEN_EN_MEMORIA = true;

    @Autowired(required = false)
    private ISuscripcionSitioDao suscripcionSitioDao;

    /** Operador (clave) -> Set(SITIO_ID). Clave puede ser ID o NOMBRE (o ambos). */
    private static final ConcurrentMap<String, Set<String>> SUSCRIPCIONES_POR_OPERADOR = new ConcurrentHashMap<String, Set<String>>();

    @Override
    public void registrarSuscripcion(String sitioId, String concesionario, String folioSolicitud) {
        String sitioNormalizado = normalizaSitio(sitioId);
        OperadorIdentidad operadorIdentidad = parseOperador(concesionario);

        if (isBlank(sitioNormalizado) || operadorIdentidad.isVacia()) {
            log.warn("Suscripción: parámetros incompletos sitioId={}, concesionario={}, folio={}",
                    sitioId, concesionario, folioSolicitud);
            return;
        }

        if (!USAR_ALMACEN_EN_MEMORIA) {
            if (suscripcionSitioDao == null) {
                log.warn("Suscripción: DAO no disponible y USAR_ALMACEN_EN_MEMORIA=false. No se registra.");
                return;
            }
            String clavePersistencia = operadorIdentidad.getClavePreferidaParaPersistencia();
            Timestamp fechaRegistro = Timestamp.valueOf(LocalDateTime.now());
            suscripcionSitioDao.registrarSuscripcion(sitioNormalizado, clavePersistencia, folioSolicitud, fechaRegistro);
            return;
        }

        registrarEnMemoria(operadorIdentidad.getOperadorId(), sitioNormalizado);
        registrarEnMemoria(operadorIdentidad.getOperadorNombre(), sitioNormalizado);

        log.info("[SUSCRIPCION] Registrada: operadorId={}, operadorNombre={}, sitio={}, folio={}",
                operadorIdentidad.getOperadorId(), operadorIdentidad.getOperadorNombre(), sitioNormalizado, folioSolicitud);
    }

    @Override
    public boolean existeSuscripcionActiva(String sitioId, String concesionario) {
        String sitioNormalizado = normalizaSitio(sitioId);
        OperadorIdentidad operadorIdentidad = parseOperador(concesionario);

        if (isBlank(sitioNormalizado) || operadorIdentidad.isVacia()) {
            return false;
        }

        if (!USAR_ALMACEN_EN_MEMORIA) {
            if (suscripcionSitioDao == null) {
                return false;
            }
            String clavePersistencia = operadorIdentidad.getClavePreferidaParaPersistencia();
            return suscripcionSitioDao.existeSuscripcionActiva(sitioNormalizado, clavePersistencia);
        }

        return existeEnMemoria(operadorIdentidad.getOperadorId(), sitioNormalizado)
                || existeEnMemoria(operadorIdentidad.getOperadorNombre(), sitioNormalizado);
    }

    @Override
    public Set<String> listarSitiosSuscritos(String concesionario) {
        OperadorIdentidad operadorIdentidad = parseOperador(concesionario);
        if (operadorIdentidad.isVacia()) {
            return Collections.emptySet();
        }

        if (!USAR_ALMACEN_EN_MEMORIA) {
            if (suscripcionSitioDao == null) {
                return Collections.emptySet();
            }
            String clavePersistencia = operadorIdentidad.getClavePreferidaParaPersistencia();
            return new HashSet<String>(suscripcionSitioDao.getSitiosSuscritosPorConcesionario(clavePersistencia));
        }

        Set<String> union = new HashSet<String>();
        agregarTodos(union, SUSCRIPCIONES_POR_OPERADOR.get(operadorIdentidad.getOperadorId()));
        agregarTodos(union, SUSCRIPCIONES_POR_OPERADOR.get(operadorIdentidad.getOperadorNombre()));

        return union.isEmpty() ? Collections.<String>emptySet() : Collections.unmodifiableSet(union);
    }

    private void registrarEnMemoria(String claveOperador, String sitioNormalizado) {
        if (isBlank(claveOperador)) {
            return;
        }

        Set<String> sitios = SUSCRIPCIONES_POR_OPERADOR.get(claveOperador);
        if (sitios == null) {
            Set<String> nuevoSet = crearSetConcurrente();
            Set<String> existente = SUSCRIPCIONES_POR_OPERADOR.putIfAbsent(claveOperador, nuevoSet);
            sitios = (existente != null) ? existente : nuevoSet;
        }

        sitios.add(sitioNormalizado);
    }

    private boolean existeEnMemoria(String claveOperador, String sitioNormalizado) {
        if (isBlank(claveOperador)) {
            return false;
        }
        Set<String> sitios = SUSCRIPCIONES_POR_OPERADOR.get(claveOperador);
        return sitios != null && sitios.contains(sitioNormalizado);
    }

    private void agregarTodos(Set<String> destino, Set<String> origen) {
        if (origen != null && !origen.isEmpty()) {
            destino.addAll(origen);
        }
    }

    private Set<String> crearSetConcurrente() {
        return Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
    }

    private String normalizaSitio(String sitioId) {
        return sitioId == null ? null : sitioId.trim().toUpperCase();
    }

    private OperadorIdentidad parseOperador(String valor) {
        if (valor == null) {
            return OperadorIdentidad.vacia();
        }

        String texto = valor.trim();
        if (texto.isEmpty()) {
            return OperadorIdentidad.vacia();
        }

        int indiceSeparador = texto.indexOf(':');
        if (indiceSeparador >= 0) {
            String operadorId = texto.substring(0, indiceSeparador).trim().toUpperCase();
            String operadorNombre = (indiceSeparador + 1 < texto.length())
                    ? texto.substring(indiceSeparador + 1).trim().toUpperCase()
                    : null;
            return new OperadorIdentidad(operadorId, operadorNombre);
        }

        // Sin ":" -> desconocido si es ID o nombre; lo tratamos como “clave única”
        String clave = texto.toUpperCase();
        return new OperadorIdentidad(clave, clave);
    }

    private boolean isBlank(String texto) {
        return texto == null || texto.trim().isEmpty();
    }

    private static class OperadorIdentidad {
        private final String operadorId;
        private final String operadorNombre;

        OperadorIdentidad(String operadorId, String operadorNombre) {
            this.operadorId = operadorId;
            this.operadorNombre = operadorNombre;
        }

        static OperadorIdentidad vacia() {
            return new OperadorIdentidad(null, null);
        }

        boolean isVacia() {
            return (operadorId == null || operadorId.trim().isEmpty())
                    && (operadorNombre == null || operadorNombre.trim().isEmpty());
        }

        String getOperadorId() {
            return operadorId;
        }

        String getOperadorNombre() {
            return operadorNombre;
        }

        String getClavePreferidaParaPersistencia() {
            // Preferimos ID si existe (más estable para BD)
            if (operadorId != null && !operadorId.trim().isEmpty() && !operadorId.equals(operadorNombre)) {
                return operadorId;
            }
            return operadorNombre;
        }
    }
}

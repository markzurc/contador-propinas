package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.spring.custom;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Controller;

/**
 * 
 * <h1>UserBasedAuthenticationSuccessHandler</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 29/04/2015
 *
 */
@Controller("acces")
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class UserBasedAuthenticationSuccessHandler implements
		AuthenticationSuccessHandler {
	
	private final String defaultTargetUrl;

	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;
	
	
	public UserBasedAuthenticationSuccessHandler(String defaultTargetUrl) {
		this.defaultTargetUrl = defaultTargetUrl;
	}
	
	@Override
	public void onAuthenticationSuccess(HttpServletRequest request,
			HttpServletResponse response, Authentication authentication)
			throws IOException, ServletException {
		int paramWarningSession=0;
		
		try{
		    ConfigurationUtilsVo configurationUtilsVo=configurationUtilsBusiness.getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.SESSION_TIME);
			paramWarningSession= 60*(Integer.parseInt(configurationUtilsVo.getValor())+1);
		}catch(Exception nfe){
			paramWarningSession=60*(5);
		}
		
		request.getSession().setMaxInactiveInterval(paramWarningSession);
		
		String redirectUrl = request.getContextPath() + defaultTargetUrl;
		
		response.sendRedirect(redirectUrl);

	}

}


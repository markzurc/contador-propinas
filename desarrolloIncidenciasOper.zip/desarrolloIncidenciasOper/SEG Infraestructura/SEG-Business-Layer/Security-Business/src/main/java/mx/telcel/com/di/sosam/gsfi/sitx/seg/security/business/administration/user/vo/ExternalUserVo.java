/**
 * 
 */
package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * <h1>ExternalUserVo</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 22/04/2015
 *
 */
@XmlRootElement
public class ExternalUserVo extends UserTypeVo implements Serializable {

	private static final long serialVersionUID = 6191179327160550593L;
	
	private UserVo userVo;
	private ExternalDataVo externalDataVo;
	
	/**
	 * 
	 */
	public ExternalUserVo() {
	}

	/**
	 * @param userVo
	 * @param externalDataVo
	 */
	public ExternalUserVo(UserVo userVo, ExternalDataVo externalDataVo) {
		super();
		this.userVo = userVo;
		this.externalDataVo = externalDataVo;
	}

	/**
	 * @return the userVo
	 */
	@XmlElement(nillable = true)
	public UserVo getUserVo() {
		return userVo;
	}

	/**
	 * @param userVo the userVo to set
	 */
	public void setUserVo(UserVo userVo) {
		this.userVo = userVo;
	}

	/**
	 * @return the externalDataVo
	 */
	@XmlElement(nillable = true)
	public ExternalDataVo getExternalDataVo() {
		return externalDataVo;
	}

	/**
	 * @param externalDataVo the externalDataVo to set
	 */
	public void setExternalDataVo(ExternalDataVo externalDataVo) {
		this.externalDataVo = externalDataVo;
	}
	
}

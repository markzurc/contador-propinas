package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.ldap.impl;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.ldap.ILdapService;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.ldap.mensajes.LdapMensajesEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.ldap.vo.LdapVO;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.telcel.gsa.dswi.test.Ldap;
import com.telcel.gsa.dswi.test.LdapPortProxy;
import com.telcel.gsa.dswi.test.LdapPortProxy.Descriptor;
import com.telcel.security.Crypt;

/**
 * Implement class of {@link ILdapService} interface.
 * 
 * @author hhernanm
 * @version 1.0
 * @since January 2015
 */

@Component
@Qualifier("ldapService")
public class LdapServiceImpl implements ILdapService {

	
	private Logger logger = LogManager.getLogger(LdapServiceImpl.class);
	
	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;
	
	
	public String authenticationAppLdap(String user, String password) {
		
		String respuesta = "";
		
		try{
			LdapVO ldapVO = this.getLdapProperties();
			if(ldapVO.getUrlLdap()!=null && ldapVO.getIdApp()!=null && ldapVO.getCve()!=null && ldapVO.getBandera()!=null){
				respuesta = this.LdapClient(user, password, ldapVO);
			}else{
				respuesta = "10|".concat(LdapMensajesEnum.LDAP_CONTACT_ADMIN.getDescripcion());
			}
		}catch (Exception e) {
			respuesta = "10|".concat(LdapMensajesEnum.LDAP_CONTACT_ADMIN.getDescripcion());
			logger.error("Error: " + e.toString()+" Cause by: "+e.getCause());
			logger.error("Error al ejecutar LdapServiceImpl.authenticationAppLdap: " + e);
		}
		
		return this.parserLdapResponseWeb(respuesta);
	}
	
	

	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.orbi.security.ldap.ILdapService#LdapClient(java.lang.String, java.lang.String, mx.com.telcel.inf.ds.sitx.orbi.security.ldap.vo.LdapVO)
	 */
	public String LdapClient(String numeroEmpleado, String password, LdapVO ldapVO) {
		String respuesta = "";
		
		if("TRUE".equalsIgnoreCase(ldapVO.getBandera())){
			try{
				LdapPortProxy ldapProxy = new LdapPortProxy();
				Crypt miCrypt = new Crypt(ldapVO.getIdApp());
				//se encripta la contrasenia
				String passwordEncryp = miCrypt.encrypt(password.getBytes());
				Descriptor descriptor = ldapProxy._getDescriptor();
				//se establece Endpoint a invocar
				descriptor.setEndpoint(ldapVO.getUrlLdap());
				Ldap ldap = descriptor.getProxy();
				//se realiza la solicitud de autenticacion con la cadena encriptada de password
				respuesta = ldap.autenticarUsuarioAppAES(numeroEmpleado, passwordEncryp, ldapVO.getIdApp(), ldapVO.getCve());
			}catch (Exception e){
				logger.error("Error: " + e.toString()+" Cause by: "+e.getCause());
				respuesta = "10|".concat(LdapMensajesEnum.LDAP_CONTACT_ADMIN.getDescripcion());
				logger.error("Error al ejecutar LdapServiceImpl.LdapClient: " + e);
			}
		}else if("FALSE".equalsIgnoreCase(ldapVO.getBandera())){
			respuesta = "1|".concat(numeroEmpleado);
		}else{
			respuesta = "10|".concat(LdapMensajesEnum.LDAP_CONTACT_ADMIN.getDescripcion());
		}		
		return respuesta;
	}

	
	/*
	 * (non-Javadoc)
	 * @see mx.com.telcel.inf.ds.sitx.orbi.security.ldap.ILdapService#parserLdapResponseWeb(java.lang.String)
	 */
	public String parserLdapResponseWeb(String ldapResponse) {
		StringBuilder result = new StringBuilder();
		int codRes=-1;
		
		String[] respSplit=ldapResponse.split("\\|");
		codRes=Integer.parseInt(respSplit[0]);
		
		switch(codRes){
			case 0: 
				result.append(LdapMensajesEnum.LDAP_NOT_AVAILABLE.getCodigo());
				result.append(": ");
				result.append(LdapMensajesEnum.LDAP_NOT_AVAILABLE.getDescripcion());
				break;
			case 1: 
				result.append("1: VALIDO");
				break;
			case 2: 
			result.append(LdapMensajesEnum.LDAP_PASS.getCodigo());
				result.append(": ");
				result.append(LdapMensajesEnum.LDAP_PASS.getDescripcion());
				break;
			case 3: 
				result.append(LdapMensajesEnum.LDAP_USER.getCodigo());
				result.append(": ");
				result.append(LdapMensajesEnum.LDAP_USER.getDescripcion());
				break;
			case 4: 
				result.append(LdapMensajesEnum.LDAP_INTENTOS.getCodigo());
				result.append(": ");
				result.append(LdapMensajesEnum.LDAP_INTENTOS.getDescripcion());
				break;
			case 5:
				result.append(LdapMensajesEnum.LDAP_BLOQUEADO.getCodigo());
				result.append(": ");
				result.append(LdapMensajesEnum.LDAP_BLOQUEADO.getDescripcion());
				break;
			case 6: 
				result.append(LdapMensajesEnum.LDAP_DESCONEXION.getCodigo());
				result.append(": ");
				result.append(LdapMensajesEnum.LDAP_DESCONEXION.getDescripcion());
				break;
			case 8: 
				result.append(LdapMensajesEnum.LDAP_BD.getCodigo());
				result.append(": ");
				result.append(LdapMensajesEnum.LDAP_BD.getDescripcion());
				break;
			case 9: 
				result.append(LdapMensajesEnum.LDAP_NO_EXIST_EAPP.getCodigo());
				result.append(": ");
				result.append(LdapMensajesEnum.LDAP_NO_EXIST_EAPP.getDescripcion());
				break;
			default:
				result.append(LdapMensajesEnum.LDAP_CONTACT_ADMIN.getCodigo());
				result.append(": ");
				result.append(LdapMensajesEnum.LDAP_CONTACT_ADMIN.getDescripcion());
				break;
		}
		logger.info(result.toString());
		return result.toString();
	}


	/**
	 * Method that gets the ldap parameters.
	 * @author hhernanm
	 * @return {@link LdapVO}
	 * @throws Exception 
	 * @throws IllegalArgumentException 
	 */
	private LdapVO getLdapProperties() throws IllegalArgumentException, Exception {
		LdapVO ldapVO = new LdapVO();
		
		ldapVO.setBandera(configurationUtilsBusiness.getConstantOfDataBase(ConfigOvitIdentifierEnum.LDAP.BANDERA_SPML).getValor());
		ldapVO.setCve(configurationUtilsBusiness.getConstantOfDataBase(ConfigOvitIdentifierEnum.LDAP.CLAVE_APP).getValor());
		ldapVO.setIdApp(configurationUtilsBusiness.getConstantOfDataBase(ConfigOvitIdentifierEnum.LDAP.ID_APP).getValor());
		ldapVO.setUrlLdap(configurationUtilsBusiness.getConstantOfDataBase(ConfigOvitIdentifierEnum.LDAP.ENDPOINT_LDAP).getValor());
		
		return ldapVO;
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * <h1>InternalUserVo</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 12/05/2015
 */

@XmlRootElement
public class InternalUserVo extends UserTypeVo implements Serializable{
	
	private static final long serialVersionUID = -1474892212658332027L;
	private UserVo userVo;
	private InternalDataVo internalDataVo;
	
	public InternalUserVo() {
	}
	
	/**
	 * @param userVo
	 * @param internalDataVo
	 */
	public InternalUserVo(UserVo userVo, InternalDataVo internalDataVo) {
		super();
		this.userVo = userVo;
		this.internalDataVo = internalDataVo;
	}
	
	/**
	 * @return the userVo
	 */
	@XmlElement(nillable = true)
	public UserVo getUserVo() {
		return userVo;
	}
	/**
	 * @param userVo the userVo to set
	 */
	public void setUserVo(UserVo userVo) {
		this.userVo = userVo;
	}
	/**
	 * @return the internalDataVo
	 */
	@XmlElement(nillable = true)
	public InternalDataVo getInternalDataVo() {
		return internalDataVo;
	}
	/**
	 * @param internalDataVo the internalDataVo to set
	 */
	public void setInternalDataVo(InternalDataVo internalDataVo) {
		this.internalDataVo = internalDataVo;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("InternalUserVo [userVo=");
		builder.append(userVo);
		builder.append(", internalDataVo=");
		builder.append(internalDataVo);
		builder.append("]");
		return builder.toString();
	}
}

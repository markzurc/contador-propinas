package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcRol;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolAclVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolApplicationVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolTypeVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolVo;

/**
 * 
 * <h1>IRolBusiness</h1>
 * <p>
 * Functions for business rol, this interface contains the methods to work with the rol.
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 30/03/2015
 *
 */

public interface IRolBusiness {
	
	/**
	 * Method used to create a new role in the database
	 * @param rolVo {@link RolVo}
	 * @param lstRolAclVos {@link List}<{@link RolAclVo}>
	 * @return
	 * @throws TransactionalOVITException
	 */
	RolVo createRol(RolVo rolVo, List<RolAclVo> lstRolAclVos) throws TransactionalOVITException;
	
	/**
	 * Method used to update a role in the database, 
	 * returns true if it is updated corect, if the object has errors returns false.
	 * @param rolVo {@link RolVo}
	 * @return {@link boolean}
	 * @throws TransactionalOVITException
	 */
	boolean updateRol(RolVo rolVo,  List<RolAclVo> lstRolAclVos) throws TransactionalOVITException;
	
	/**
	 * Performs a search using the object received as an example and returns a list of type "RolVo" object, 
	 * if the object  received is empty, returns all database objects.
	 * @param rolVo {@link RolVo}
	 * @return {@link List}<{@link RolVo}>
	 * @throws TransactionalOVITException
	 */
	List<RolVo> findByWithoutApplications(RolVo rolVo) throws TransactionalOVITException;
	
	/**
	 * Performs a search using the object received as an example and returns an object of type "RolAplicacionVo", 
	 * if the object received is empty, returns all database objects.
	 * @param rolVo {@link RolVo}
	 * @return {@link RolApplicationVo}
	 * @throws TransactionalOVITException
	 */
	RolApplicationVo findByWithApplications(RolVo rolVo) throws TransactionalOVITException;
	
	/**
	 * Performs a search using the idRol, idAplicacion and idComponente as an example and returns an object of 
	 * type "RolAplicacionVo", if the object received is empty, returns all database objects.
	 * @param idRol {@link Integer}
	 * @param idAplicacion {@link Integer}
	 * @param idComponente {@link Integer}
	 * @return {@link List}<{@link RolAclVo}>
	 * @throws TransactionalOVITException
	 */
	List<RolAclVo> findByRolAcl(Integer idRol, Integer idAplicacion) throws TransactionalOVITException;
	
	/**
	 * 
	 * @return
	 */
	List<RolTypeVo> getRoltype() throws TransactionalOVITException;
	
	/**
	 * 
	 * @param idRol
	 * @return
	 * @throws TransactionalOVITException
	 */
	boolean isInUse(Integer idRol) throws TransactionalOVITException;

	List<T7segcRol> getRoles();
	
	String getRoltype(Integer idRol) throws TransactionalOVITException;
}

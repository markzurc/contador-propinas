package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * <h1>ComponenteVo</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 09/04/2015
 *
 */
@XmlRootElement
public class ComponentVo implements Serializable{

	private static final long serialVersionUID = -2350232237649476869L;
	
	private Integer idComponente;
	private String flujo;
	private Integer idPadre;
	private String nombre;
	private String descripcion;
	private Integer idTipoComponente;
	private Integer idAplicacion;
	private String valorComponente;
	
	public ComponentVo() {
	}
	
	
	/**
	 * @param idComponente
	 * @param flujo
	 * @param idPadre
	 * @param nombre
	 * @param descripcion
	 * @param idTipoComponente
	 * @param idAplicacion
	 * @param valorComponente
	 */
	public ComponentVo(Integer idComponente, String flujo, Integer idPadre,
			String nombre, String descripcion, Integer idTipoComponente,
			Integer idAplicacion, String valorComponente) {
		super();
		this.idComponente = idComponente;
		this.flujo = flujo;
		this.idPadre = idPadre;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.idTipoComponente = idTipoComponente;
		this.idAplicacion = idAplicacion;
		this.valorComponente = valorComponente;
	}




	/**
	 * @return the idComponente
	 */
	@XmlElement(nillable = true)
	public Integer getIdComponente() {
		return idComponente;
	}

	/**
	 * @param idComponente the idComponente to set
	 */
	public void setIdComponente(Integer idComponente) {
		this.idComponente = idComponente;
	}

	/**
	 * @return the flujo
	 */
	@XmlElement(nillable = true)
	public String getFlujo() {
		return flujo;
	}

	/**
	 * @param flujo the flujo to set
	 */
	public void setFlujo(String flujo) {
		this.flujo = flujo;
	}

	/**
	 * @return the idPadre
	 */
	@XmlElement(nillable = true)
	public Integer getIdPadre() {
		return idPadre;
	}

	/**
	 * @param idPadre the idPadre to set
	 */
	public void setIdPadre(Integer idPadre) {
		this.idPadre = idPadre;
	}

	/**
	 * @return the nombre
	 */
	@XmlElement(nillable = true)
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the descripcion
	 */
	@XmlElement(nillable = true)
	public String getDescripcion() {
		return descripcion;
	}

	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	/**
	 * @return the tipo
	 */
	@XmlElement(nillable = true)
	public Integer getIdTipoComponente() {
		return idTipoComponente;
	}

	/**
	 * @param tipo the tipo to set
	 */
	public void setIdTipoComponente(Integer idTipoComponente) {
		this.idTipoComponente = idTipoComponente;
	}

	/**
	 * @return the idAplicacion
	 */
	@XmlElement(nillable = true)
	public Integer getIdAplicacion() {
		return idAplicacion;
	}

	/**
	 * @param idAplicacion the idAplicacion to set
	 */
	public void setIdAplicacion(Integer idAplicacion) {
		this.idAplicacion = idAplicacion;
	}


	/**
	 * @return the valorComponente
	 */
	public String getValorComponente() {
		return valorComponente;
	}


	/**
	 * @param valorComponente the valorComponente to set
	 */
	public void setValorComponente(String valorComponente) {
		this.valorComponente = valorComponente;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ComponentVo [idComponente=");
		builder.append(idComponente);
		builder.append(", flujo=");
		builder.append(flujo);
		builder.append(", idPadre=");
		builder.append(idPadre);
		builder.append(", nombre=");
		builder.append(nombre);
		builder.append(", descripcion=");
		builder.append(descripcion);
		builder.append(", idTipoComponente=");
		builder.append(idTipoComponente);
		builder.append(", idAplicacion=");
		builder.append(idAplicacion);
		builder.append(", valorComponente=");
		builder.append(valorComponente);
		builder.append("]");
		return builder.toString();
	}
	
	
	
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.ldap;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.ldap.vo.LdapVO;

/**
 * <h1>LDAP Service Interface</h1>
 * <p>
 * Interface class that has the methods used to authenticate
 * the ORBI users.
 * </p>
 * @author hhernanm
 * @version 1.0
 * @since January, 2015
 * 
 */

public interface ILdapService {
	
	/**
	 * Method that returns the result of LDAP authentication
	 * 
	 * @author hhernanm
	 * @param {@link String} user
	 * @param {@link String} password
	 * @return {@link String}
	 */
	String authenticationAppLdap(String user, String password);
	
	
	/**
	 * Method that connects to the LDAP service and gets the
	 * LDAP response.
	 * 
	 * @author hhernanm
	 * @param {@link String} numeroEmpleado
	 * @param {@link String} password
	 * @param {@link LdapVO}ldapVO
	 * @return {@link String}
	 */
	String LdapClient(String numeroEmpleado, String password, LdapVO ldapVO);
	
	
	/**
	 * Method that parses the LDAP response. 
	 * Returns the code and description of the error.
	 * 
	 * @author hhernanm
	 * @param {@link String}ldapResponse
	 * @return {@link String}
	 */
	String parserLdapResponseWeb(String ldapResponse);
	

}

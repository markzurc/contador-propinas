package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.spring.custom;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.authentication.AuthenticationDetailsSource;
import org.springframework.security.web.authentication.WebAuthenticationDetails;

/**
 * 
 * <h1>CustomWebAuthenticationDetailsSource</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 29/04/2015
 *
 */
public class CustomWebAuthenticationDetailsSource implements
		AuthenticationDetailsSource<HttpServletRequest, WebAuthenticationDetails> {

	@Override
	public WebAuthenticationDetails buildDetails(HttpServletRequest context) {
		return new CustomWebAuthenticationDetails(context);
	}

}

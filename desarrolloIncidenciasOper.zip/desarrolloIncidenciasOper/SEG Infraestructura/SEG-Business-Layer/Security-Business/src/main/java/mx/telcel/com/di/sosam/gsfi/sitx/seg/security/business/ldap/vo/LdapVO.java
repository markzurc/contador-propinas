package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.ldap.vo;

import java.io.Serializable;

public class LdapVO implements Serializable {

	private static final long serialVersionUID = -6550608793893852706L;
	
	private String urlLdap;
	private String idApp;
	private String cve;
	private String bandera;
	
	/**
	 * @return the urlLdap
	 */
	public String getUrlLdap() {
		return urlLdap;
	}
	/**
	 * @param urlLdap the urlLdap to set
	 */
	public void setUrlLdap(String urlLdap) {
		this.urlLdap = urlLdap;
	}
	/**
	 * @return the idApp
	 */
	public String getIdApp() {
		return idApp;
	}
	/**
	 * @param idApp the idApp to set
	 */
	public void setIdApp(String idApp) {
		this.idApp = idApp;
	}
	/**
	 * @return the clave
	 */
	public String getCve() {
		return cve;
	}
	/**
	 * @param clave the clave to set
	 */
	public void setCve(String cve) {
		this.cve = cve;
	}
	/**
	 * @return the bandera
	 */
	public String getBandera() {
		return bandera;
	}
	/**
	 * @param bandera the bandera to set
	 */
	public void setBandera(String bandera) {
		this.bandera = bandera;
	}
	
	

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.exception.SendingMailOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.application.thirdparty.request.ApplicationGenericRequest;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.email.vo.CorreoNotiVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.email.vo.CorreoPropVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rolaccion.vo.RolAccionVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ExternalUserFindVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ExternalUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.InternalUserFindVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.UserContraVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.DocumentoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.EstatusDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.OperadorDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.ReportUserDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.UserDetailsDto;

/**
 * 
 * <h1>IUsuarioBusiness</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 13/04/2015
 *
 */
public interface IUserBusiness {
	
	int USER_EXTERNAL_CORRECT_PASS = 0;
	int USER_LOCKED = 1;
	int USER_DROP = 2;
	int USER_EXTERNAL_NEW = 3;
	int USER_EXTERNAL_RESET = 4;
	int USER_EXTERNAL_WRONG_PASS = 5;
	int USER_INTERNAL = 6;
	int USER_NOT_FOUND = 7;
	int PASSWORD_CORRECT = 0;
	int PASSWORD_WRONG = 1;
	int PASSWORD_EXCEEDED = 2;
	int PASSWORD_SAME_ACTUAL = 3;
	int PASSWORD_NUM_VALIDATION = 4;
	int STATUS_ACTIVE = 0;
	int STATUS_LOCKED = 1;
	int STATUS_DROP = 2;
	int STATUS_NEW = 3;
	int STATUS_RESET = 4;
	int STATUS_EXPIRED = 6;
	int UPDATE_PASS_CORRECT = 0;
	ExternalUserVo createUser(ExternalUserVo userTypeVo, List<? super ApplicationGenericRequest> listRequest) throws TransactionalOVITException, SendingMailOVITException;
	void updateUser(ExternalUserVo userTypeVo) throws TransactionalOVITException;
	List<ReportUserVo> findAllReportUsers() throws TransactionalOVITException;
	List<ReportUserVo> findReportUsersConcesionario() throws TransactionalOVITException;
	ExternalUserFindVo findExternalUserById(Integer idUsuario) throws TransactionalOVITException;
	InternalUserFindVo findInternalUserById(Integer idUsuario) throws TransactionalOVITException;
	
	/**
	 * Method to update the user's password, use the following states:<br/>
	 * <br/>
	 * STATUS_ACTIVE = 0<br/>
	 * STATUS_LOCKED = 1<br/>
	 * STATUS_DROP = 2<br/>
	 * STATUS_NEW = 3<br/>
	 * STATUS_RESET = 4<br/>
	 * <br/>
	 * @param idUsuario
	 * @param password
	 * @param estatus
	 * @throws TransactionalOVITException
	 */
	int updatePassword(Integer idUsuario, String password, Integer estatus)throws TransactionalOVITException;
	
	/**
	 * Method to validate the user's password, returns the following states:<br/>
	 * PASSWORD_CORRECT = 0<br/>
	 * PASSWORD_WRONG = 1<br/>
	 * PASSWORD_EXCEEDED = 2<br/>
	 * <br/>
	 * @param idUsuario {@link Integer}
	 * @param password {@link String}
	 * @return {@link int}
	 * @throws TransactionalOVITException
	 */
	int validatePassword(Integer idUsuario, String password, String newPassword) throws TransactionalOVITException;
	
	/**
	 * Method to validate the user login, use the following states:<br/>
	 * <br/>
	 * USER_EXTERNAL_CORRECT_PASS = 0<br/>
	 * USER_LOCKED = 1, <br/>
	 * USER_DROP = 2,<br/>
	 * USER_EXTERNAL_NEW = 3,<br/>
	 * USER_EXTERNAL_RESET = 4,<br/>
	 * USER_EXTERNAL_WRONG_PASS = 5,<br/>
	 * USER_INTERNAL = 6<br/>
	 * <br/>
	 * @param userName
	 * @param password
	 * @return
	 * @throws TransactionalOVITException
	 */
	UserDetailsVo validateLogIn(String userName, String password)throws TransactionalOVITException;
	
	void resetPassword(Integer idUsuario) throws TransactionalOVITException, SendingMailOVITException;
	
	void updateStatus(Integer idUsuario, Integer idEstatus) throws TransactionalOVITException;
	
	void updateLoginDate(Integer idUsuario) throws TransactionalOVITException;
	
	UserContraVo obtainUserPasswordInfo(Integer idUsuario)  throws TransactionalOVITException;
	
	void updateUserApplicationList(List<? super ApplicationGenericRequest> listRequest) throws TransactionalOVITException;
	
	List<RolAccionVo> findRolAccionByRol(Integer rol) throws TransactionalOVITException;
	
	List<CorreoNotiVo> findAllCorrNotiByProd(Long producto) throws TransactionalOVITException;
	
	List<CorreoPropVo> findAllCorrProp() throws TransactionalOVITException;

	List<String> findAllCorrAuto(Long rolAutorizador) throws TransactionalOVITException;

	UserDetailsDto findUserdetailByEmpleado(String idEmpleado);

	List<String> getAllCorreoGrupoRol(List<Integer> grupoRol);

///////////////////////////////////

	boolean actualizarUsuarioAdmin(ReportUserDto reportUserDto, String pass);

	boolean altaUsuarioAdmin(ReportUserDto reportUserDto, String pass);
	
	boolean requiereCambioPass(String rol);

	boolean altaPass(ReportUserDto reportUserDto);

	boolean altaRolUsuario(ReportUserDto reportUserDto);

	boolean guardarDocumento(String ruta, String name, Integer idUsuario);

	boolean altaDocumento(String ruta, String name, Integer idUsuario);

	List<DocumentoDto> obtenerDocumentos(Integer idUsuario);

	List<OperadorDto> obtenerEmpresas();

	String obtenerOperadorUsuario(Integer idUsuario);

	List<EstatusDto> obtenerEstatus();

	boolean eliminarDoc(Integer idDoc);
	
	String idArchivosUsuario();
	
	List<ReportUserVo> getUsersConcesionarioByOp(String operadorUsuario) throws TransactionalOVITException;
	
	int getCountUsersConcesionarioByOp(String seleccionadoConcesionario);
	
	String getPassUser(int idUsuario);
	
	String getEstadoUser(int idUsuario);
	
}

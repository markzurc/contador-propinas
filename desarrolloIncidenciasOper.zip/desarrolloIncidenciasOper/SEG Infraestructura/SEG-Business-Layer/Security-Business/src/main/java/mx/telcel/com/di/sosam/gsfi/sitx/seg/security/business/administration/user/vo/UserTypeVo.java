package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * <h1>UserTypeVo</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 22/04/2015
 *
 */
@XmlRootElement
public class UserTypeVo {

}

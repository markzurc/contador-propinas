package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.email.vo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CorreoPropVo implements Serializable{

	private static final long serialVersionUID = 488301461952779933L;
	
	private String cve;
	private String valor;
	
	@NotNull
	@XmlElement(nillable = true)
	public String getCve() {
		return cve;
	}
	
	public void setCve(String cve) {
		this.cve = cve;
	}
	
	@NotNull
	@XmlElement(nillable = true)
	public String getValor() {
		return valor;
	}
	
	public void setValor(String valor) {
		this.valor = valor;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CorreoPropVo [cve=");
		builder.append(cve);
		builder.append(", valor=");
		builder.append(valor);
		builder.append("]");
		return builder.toString();
	}
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.validator.constraints.NotBlank;

/**
 * 
 * <h1>UsuarioVo</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 13/04/2015
 *
 */

@XmlRootElement
public class UserVo implements Serializable {

	private static final long serialVersionUID = -2160459392143856370L;
	
	private Integer idUsuario;
	private String nombre;
	private String apellidoPaterno;
	private String apellidoMaterno;
	private String rfc;
	private Integer idTipoUsuario;
	private Integer idEstatus;
	private Date fechaLogueo;
	private String contra;
	private Integer idRol;
	private Date fechaCreacion;
	private String usuarioCreacion;
	private Date fechaModificacion;
	private String usuarioModificacion;
	
	private String numeroEmpleado;
	
	/**
	 * @return the idUsuario
	 */ 
	@XmlElement(nillable = true)
	public Integer getIdUsuario() {
		return idUsuario;
	}
	/**
	 * @param idUsuario the idUsuario to set
	 */
	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}
	/**
	 * @return the nombre
	 */
	@NotNull
	@NotBlank
	@XmlElement(nillable = true)
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @return the apellidoPaterno
	 */
	@NotNull
	@NotBlank
	@XmlElement(nillable = true)
	public String getApellidoPaterno() {
		return apellidoPaterno;
	}
	/**
	 * @param apellidoPaterno the apellidoPaterno to set
	 */
	public void setApellidoPaterno(String apellidoPaterno) {
		this.apellidoPaterno = apellidoPaterno;
	}
	/**
	 * @return the apellidoMaterno
	 */
	@XmlElement(nillable = true)
	public String getApellidoMaterno() {
		return apellidoMaterno;
	}
	/**
	 * @param apellidoMaterno the apellidoMaterno to set
	 */
	public void setApellidoMaterno(String apellidoMaterno) {
		this.apellidoMaterno = apellidoMaterno;
	}
	/**
	 * @return the rfc
	 */
	@XmlElement(nillable = true)
	public String getRfc() {
		return rfc;
	}
	/**
	 * @param rfc the rfc to set
	 */
	public void setRfc(String rfc) {
		this.rfc = rfc;
	}
	/**
	 * @return the idTipoUsuario
	 */
	@NotNull
	@XmlElement(nillable = true)
	public Integer getIdTipoUsuario() {
		return idTipoUsuario;
	}
	/**
	 * @param idTipoUsuario the idTipoUsuario to set
	 */
	public void setIdTipoUsuario(Integer idTipoUsuario) {
		this.idTipoUsuario = idTipoUsuario;
	}
	/**
	 * @return the idEstatus
	 */
	@NotNull
	@XmlElement(nillable = true)
	public Integer getIdEstatus() {
		return idEstatus;
	}
	/**
	 * @param idEstatus the idEstatus to set
	 */
	public void setIdEstatus(Integer idEstatus) {
		this.idEstatus = idEstatus;
	}
	/**
	 * @return the fechaLogueo
	 */
	@XmlElement(nillable = true)
	public Date getFechaLogueo() {
		return fechaLogueo;
	}
	/**
	 * @param fechaLogueo the fechaLogueo to set
	 */
	public void setFechaLogueo(Date fechaLogueo) {
		this.fechaLogueo = fechaLogueo;
	}

	/**
	 * @return the idRol
	 */
	@NotNull
	@XmlElement(nillable = true)
	public Integer getIdRol() {
		return idRol;
	}
	/**
	 * @return the contra
	 */
	@XmlElement(nillable = true)
	public String getContra() {
		return contra;
	}
	/**
	 * @param contra the contra to set
	 */
	public void setContra(String contra) {
		this.contra = contra;
	}
	/**
	 * @param idRol the idRol to set
	 */
	public void setIdRol(Integer idRol) {
		this.idRol = idRol;
	}
	
	/**
	 * @return the fechaCreacion
	 */
	@XmlElement(nillable = true)
	public Date getFechaCreacion() {
		return fechaCreacion;
	}
	/**
	 * @param fechaCreacion the fechaCreacion to set
	 */
	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	/**
	 * @return the usuarioCreacion
	 */
	@XmlElement(nillable = true)
	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}
	/**
	 * @param usuarioCreacion the usuarioCreacion to set
	 */
	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}
	/**
	 * @return the fechaModificacion
	 */
	@XmlElement(nillable = true)
	public Date getFechaModificacion() {
		return fechaModificacion;
	}
	/**
	 * @param fechaModificacion the fechaModificacion to set
	 */
	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
	/**
	 * @return the usuarioModificacion
	 */
	@XmlElement(nillable = true)
	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}
	/**
	 * @param usuarioModificacion the usuarioModificacion to set
	 */
	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}
	
	/**
	 * @return the numeroEmpleado
	 */
	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}
	/**
	 * @param numeroEmpleado the numeroEmpleado to set
	 */
	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserVo [idUsuario=");
		builder.append(idUsuario);
		builder.append(", nombre=");
		builder.append(nombre);
		builder.append(", apellidoPaterno=");
		builder.append(apellidoPaterno);
		builder.append(", apellidoMaterno=");
		builder.append(apellidoMaterno);
		builder.append(", rfc=");
		builder.append(rfc);
		builder.append(", idTipoUsuario=");
		builder.append(idTipoUsuario);
		builder.append(", idEstatus=");
		builder.append(idEstatus);
		builder.append(", fechaLogueo=");
		builder.append(fechaLogueo);
		builder.append(", contra=");
		builder.append(contra);
		builder.append(", idRol=");
		builder.append(idRol);
		builder.append(", fechaCreacion=");
		builder.append(fechaCreacion);
		builder.append(", usuarioCreacion=");
		builder.append(usuarioCreacion);
		builder.append(", fechaModificacion=");
		builder.append(fechaModificacion);
		builder.append(", usuarioModificacion=");
		builder.append(usuarioModificacion);
		builder.append(", numeroEmpleado=");
		builder.append(numeroEmpleado);
		builder.append("]");
		return builder.toString();
	}
	
	
	
}

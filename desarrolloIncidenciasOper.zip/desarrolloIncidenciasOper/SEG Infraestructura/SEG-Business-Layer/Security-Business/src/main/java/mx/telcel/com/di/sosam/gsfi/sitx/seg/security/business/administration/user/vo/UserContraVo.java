package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * 
 * <h1>UserPasswordVo</h1>
 * <p>
 * </p>
 * 
 * @author chcastro
 * @version 1.0
 * @since 24/06/2015
 */

@XmlRootElement
public class UserContraVo implements Serializable {

	private static final long serialVersionUID = 6385643741825547809L;
	
	private Integer idUsuario;
	private String contra;
	private Date fechaCambioPassword;
	
	public UserContraVo() {
	}

	/**
	 * @param idUsuario
	 * @param password
	 * @param fechaCambioPassword
	 */
	public UserContraVo(Integer idUsuario, String contra,
			Date fechaCambioPassword) {
		super();
		this.idUsuario = idUsuario;
		this.contra = contra;
		this.fechaCambioPassword = fechaCambioPassword;
	}

	/**
	 * @return the idUsuario
	 */
	public Integer getIdUsuario() {
		return idUsuario;
	}

	/**
	 * @param idUsuario the idUsuario to set
	 */
	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	/**
	 * @return the password
	 */
	@XmlElement(nillable = true)
	public String getContra() {
		return contra;
	}

	/**
	 * @param password the password to set
	 */
	public void setContra(String contra) {
		this.contra = contra;
	}

	/**
	 * @return the fechaCambioPassword
	 */
	@XmlElement(nillable = true)
	public Date getFechaCambioPassword() {
		return fechaCambioPassword;
	}

	/**
	 * @param fechaCambioPassword the fechaCambioPassword to set
	 */
	public void setFechaCambioPassword(Date fechaCambioPassword) {
		this.fechaCambioPassword = fechaCambioPassword;
	}
	
}

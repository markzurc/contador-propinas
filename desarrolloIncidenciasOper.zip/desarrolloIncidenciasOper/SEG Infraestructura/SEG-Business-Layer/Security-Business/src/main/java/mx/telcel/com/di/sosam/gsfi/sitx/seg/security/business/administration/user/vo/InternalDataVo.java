package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * <h1>InternalDataVo</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 22/04/2015
 *
 */
@XmlRootElement
public class InternalDataVo implements Serializable{

	private static final long serialVersionUID = -6564594155297349081L;

	private String idRegion;
	private String jefe;
	private String codigoJefe;
	private String puesto;
	private String codigoPuesto;
	private String correo;
	private String numeroEmpleado;
	
	public InternalDataVo() {
	}
	
	/**
	 * @param numEmpleado
	 * @param idRegion
	 * @param jefe
	 * @param codigoJefe
	 * @param puesto
	 * @param codigoPuesto
	 * @param correo
	 */
	public InternalDataVo(String idRegion, String jefe,
			String codigoJefe, String puesto, String codigoPuesto,
			String correo) {
		super();
		this.idRegion = idRegion;
		this.jefe = jefe;
		this.codigoJefe = codigoJefe;
		this.puesto = puesto;
		this.codigoPuesto = codigoPuesto;
		this.correo = correo;
	}
	
	/**
	 * @return the idRegion
	 */
	@XmlElement(nillable = true)
	public String getIdRegion() {
		return idRegion;
	}
	/**
	 * @param idRegion the idRegion to set
	 */
	public void setIdRegion(String idRegion) {
		this.idRegion = idRegion;
	}
	/**
	 * @return the jefe
	 */
	@XmlElement(nillable = true)
	public String getJefe() {
		return jefe;
	}
	/**
	 * @param jefe the jefe to set
	 */
	public void setJefe(String jefe) {
		this.jefe = jefe;
	}
	/**
	 * @return the codigoJefe
	 */
	@XmlElement(nillable = true)
	public String getCodigoJefe() {
		return codigoJefe;
	}
	/**
	 * @param codigoJefe the codigoJefe to set
	 */
	public void setCodigoJefe(String codigoJefe) {
		this.codigoJefe = codigoJefe;
	}
	/**
	 * @return the puesto
	 */
	@XmlElement(nillable = true)
	public String getPuesto() {
		return puesto;
	}
	/**
	 * @param puesto the puesto to set
	 */
	public void setPuesto(String puesto) {
		this.puesto = puesto;
	}
	/**
	 * @return the codigoPuesto
	 */
	@XmlElement(nillable = true)
	public String getCodigoPuesto() {
		return codigoPuesto;
	}
	/**
	 * @param codigoPuesto the codigoPuesto to set
	 */
	public void setCodigoPuesto(String codigoPuesto) {
		this.codigoPuesto = codigoPuesto;
	}
	/**
	 * @return the correo
	 */
	@XmlElement(nillable = true)
	public String getCorreo() {
		return correo;
	}
	/**
	 * @param correo the correo to set
	 */
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	
	/**
	 * @return the numeroEmpleado
	 */
	@XmlElement(nillable = true)
	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}
	/**
	 * @param numeroEmpleado the numeroEmpleado to set
	 */
	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("InternalDataVo [idRegion=");
		builder.append(idRegion);
		builder.append(", jefe=");
		builder.append(jefe);
		builder.append(", codigoJefe=");
		builder.append(codigoJefe);
		builder.append(", puesto=");
		builder.append(puesto);
		builder.append(", codigoPuesto=");
		builder.append(codigoPuesto);
		builder.append(", correo=");
		builder.append(correo);
		builder.append(", numeroEmpleado=");
		builder.append(numeroEmpleado);
		builder.append("]");
		return builder.toString();
	}
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application;

import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ApplicationVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ComponentVo;

/**
 * 
 * <h1>IApplicationBusiness</h1>
 * <p>
 * Functions for business application, this interface contains the methods to work with the applications.
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 30/03/2015
 *
 */
public interface IApplicationBusiness {
	
	/**
	 * Performs a search using the object received as an example and returns a list of type "AplicacionVo" 
	 * object, if the object  received is empty, returns all database objects.
	 * @param applicationVo
	 * @return
	 * @throws TransactionalOVITException
	 */
	List<ApplicationVo> findByExample(ApplicationVo applicationVo) throws TransactionalOVITException;
	
	/**
	 * method that obtains the application components using application id
	 * @param idApplication
	 * @return
	 * @throws TransactionalOVITException
	 */
	List<ComponentVo> componentsForApplication(Integer idApplication) throws TransactionalOVITException;
}

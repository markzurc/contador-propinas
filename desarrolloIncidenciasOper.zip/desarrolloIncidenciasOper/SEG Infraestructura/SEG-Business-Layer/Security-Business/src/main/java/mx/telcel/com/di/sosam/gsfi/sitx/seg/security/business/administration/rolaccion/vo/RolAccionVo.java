package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rolaccion.vo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class RolAccionVo implements Serializable{
	
	private static final long serialVersionUID = 7055881266265195571L;

	private Integer rol;
	private Integer accion;
	private Integer estatus;
	
	@NotNull
	@XmlElement(nillable = true)
	public Integer getRol() {
		return rol;
	}
	
	public void setRol(Integer rol) {
		this.rol = rol;
	}
	
	@NotNull
	@XmlElement(nillable = true)
	public Integer getAccion() {
		return accion;
	}
	
	public void setAccion(Integer accion) {
		this.accion = accion;
	}
	
	@NotNull
	@XmlElement(nillable = true)
	public Integer getEstatus() {
		return estatus;
	}
	
	public void setEstatus(Integer estatus) {
		this.estatus = estatus;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RolAccionVo [rol=");
		builder.append(rol);
		builder.append(", accion=");
		builder.append(accion);
		builder.append(", estatus=");
		builder.append(estatus);
		builder.append("]");
		return builder.toString();
	}
	
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ApplicationVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolAclVo;

/**
 * 
 * <h1>ExternalUserFindVo</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 24/04/2015
 *
 */
@XmlRootElement
public class ExternalUserFindVo implements Serializable{

	private static final long serialVersionUID = 4054781689670621944L;
	
	private UserVo userVo;
	private ExternalDataVo externalDataUser;
	private InternalUserVo responsibleUser;
	private List<RolAclVo> rolAclVo;
	private List<ApplicationVo> applicationVo;
	
	public ExternalUserFindVo() {
	}

	/**
	 * @param userVo
	 * @param externalDataUser
	 * @param responsibleUser
	 * @param rolAclVo
	 * @param applicationVo
	 */
	public ExternalUserFindVo(UserVo userVo, ExternalDataVo externalDataUser,
			InternalUserVo responsibleUser, List<RolAclVo> rolAclVo,
			List<ApplicationVo> applicationVo) {
		super();
		this.userVo = userVo;
		this.externalDataUser = externalDataUser;
		this.responsibleUser = responsibleUser;
		this.rolAclVo = rolAclVo;
		this.applicationVo = applicationVo;
	}

	/**
	 * @return the userVo
	 */
	@XmlElement(nillable = true)
	public UserVo getUserVo() {
		return userVo;
	}

	/**
	 * @param userVo the userVo to set
	 */
	public void setUserVo(UserVo userVo) {
		this.userVo = userVo;
	}

	/**
	 * @return the externalDataUser
	 */
	@XmlElement(nillable = true)
	public ExternalDataVo getExternalDataUser() {
		return externalDataUser;
	}

	/**
	 * @param externalDataUser the externalDataUser to set
	 */
	public void setExternalDataUser(ExternalDataVo externalDataUser) {
		this.externalDataUser = externalDataUser;
	}

	/**
	 * @return the responsibleUser
	 */
	@XmlElement(nillable = true)
	public InternalUserVo getResponsibleUser() {
		return responsibleUser;
	}

	/**
	 * @param responsibleUser the responsibleUser to set
	 */
	public void setResponsibleUser(InternalUserVo responsibleUser) {
		this.responsibleUser = responsibleUser;
	}

	/**
	 * @return the rolAclVo
	 */
	@XmlElement(nillable = true)
	public List<RolAclVo> getRolAclVo() {
		return rolAclVo;
	}

	/**
	 * @param rolAclVo the rolAclVo to set
	 */
	public void setRolAclVo(List<RolAclVo> rolAclVo) {
		this.rolAclVo = rolAclVo;
	}

	/**
	 * @return the applicationVo
	 */
	@XmlElement(nillable = true)
	public List<ApplicationVo> getApplicationVo() {
		return applicationVo;
	}

	/**
	 * @param applicationVo the applicationVo to set
	 */
	public void setApplicationVo(List<ApplicationVo> applicationVo) {
		this.applicationVo = applicationVo;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ExternalUserFindVo [userVo=");
		builder.append(userVo);
		builder.append(", externalDataUser=");
		builder.append(externalDataUser);
		builder.append(", responsibleUser=");
		builder.append(responsibleUser);
		builder.append(", rolAclVo=");
		builder.append(rolAclVo);
		builder.append(", applicationVo=");
		builder.append(applicationVo);
		builder.append("]");
		return builder.toString();
	}
	
}

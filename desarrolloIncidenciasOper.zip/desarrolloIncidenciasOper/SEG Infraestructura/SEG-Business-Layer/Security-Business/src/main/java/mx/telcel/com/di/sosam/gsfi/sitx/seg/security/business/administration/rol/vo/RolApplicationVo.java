package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ApplicationVo;

/**
 * 
 * <h1>RolApplicationVo</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 13/05/2015
 */
public class RolApplicationVo implements Serializable{

	private static final long serialVersionUID = 5165346700741046679L;
	
	HashMap<RolVo,List<ApplicationVo>> rolAplicacion;
	
	public RolApplicationVo() {
	}

	public RolApplicationVo(HashMap<RolVo, List<ApplicationVo>> rolAplicacion) {
		super();
		this.rolAplicacion = rolAplicacion;
	}
	/**
	 * @return the rolAplicacion
	 */
	@XmlElement(nillable = true)
	public HashMap<RolVo, List<ApplicationVo>> getRolAplicacion() {
		return rolAplicacion;
	}

	/**
	 * @param rolAplicacion the rolAplicacion to set
	 */
	public void setRolAplicacion(HashMap<RolVo, List<ApplicationVo>> rolAplicacion) {
		this.rolAplicacion = rolAplicacion;
	}

}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.spring.custom;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.web.authentication.WebAuthenticationDetails;

/**
 * 
 * <h1>CustomWebAuthenticationDetails</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 29/04/2015
 *
 */
public class CustomWebAuthenticationDetails extends WebAuthenticationDetails {


	private static final long serialVersionUID = 8403494441986393088L;
	
	/**
	 * 
	 * @param request
	 */
	public CustomWebAuthenticationDetails(HttpServletRequest request) {
		super(request);
	}

}

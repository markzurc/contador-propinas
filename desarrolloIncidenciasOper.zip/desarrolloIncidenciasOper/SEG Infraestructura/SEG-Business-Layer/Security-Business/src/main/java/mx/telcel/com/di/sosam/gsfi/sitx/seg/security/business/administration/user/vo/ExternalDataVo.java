package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * <h1>ExternalDataVo</h1>
 * <p>
 * 
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 22/04/2015
 *
 */
@XmlRootElement
public class ExternalDataVo implements Serializable {
	
	private static final long serialVersionUID = -3798075230211290481L;
	private Integer idResponsable;
	private String correo;
	private String numeroEmpleado;
	/**
	 * 
	 */
	public ExternalDataVo() {
	}
	
	/**
	 * 
	 * @param idResponsable
	 * @param correo
	 * @param nombreUsuario
	 */
	public ExternalDataVo(Integer idResponsable, String correo) {
		super();
		this.idResponsable = idResponsable;
		this.correo = correo;
	}

	/**
	 * @return the idResponsable
	 */
	@NotNull
	@XmlElement(nillable = true)
	public Integer getIdResponsable() {
		return idResponsable;
	}

	/**
	 * @param idResponsable the idResponsable to set
	 */
	public void setIdResponsable(Integer idResponsable) {
		this.idResponsable = idResponsable;
	}

	/**
	 * @return the correo
	 */
	@XmlElement(nillable = true)
	public String getCorreo() {
		return correo;
	}

	/**
	 * @param correo the correo to set
	 */
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	
	/**
	 * @return the numeroEmpleado
	 */
	@XmlElement(nillable = true)
	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}
	/**
	 * @param numeroEmpleado the numeroEmpleado to set
	 */
	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ExternalDataVo [idResponsable=");
		builder.append(idResponsable);
		builder.append(", correo=");
		builder.append(correo);
		builder.append(", numeroEmpleado=");
		builder.append(numeroEmpleado);
		builder.append("]");
		return builder.toString();
	}
	
}

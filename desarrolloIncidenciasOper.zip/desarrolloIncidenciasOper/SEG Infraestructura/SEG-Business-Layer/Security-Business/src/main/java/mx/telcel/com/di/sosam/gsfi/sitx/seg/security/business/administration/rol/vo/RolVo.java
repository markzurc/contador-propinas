package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * <h1>RolVo</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 13/05/2015
 */
@XmlRootElement
public class RolVo implements Serializable {
	

	private static final long serialVersionUID = 652651546976176351L;

	private Integer idRol;
	private String nombre;
	private String descripcion;
	private Integer idTipoRol;
	private List<Integer> listIdAplicacion;
	private Integer idEstatus;
	
	public RolVo() {
	}
	
	/**
	 * 
	 * @param idRol
	 * @param nombre
	 * @param descripcion
	 * @param idTipoRol
	 */
	public RolVo(Integer idRol, String nombre, String descripcion, Integer idTipoRol) {
		super();
		this.idRol = idRol;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.idTipoRol = idTipoRol;
	}
	/**
	 * @return the idRol
	 */
	@XmlElement(nillable = true)
	public Integer getIdRol() {
		return idRol;
	}
	/**
	 * @param idRol the idRol to set
	 */
	public void setIdRol(Integer idRol) {
		this.idRol = idRol;
	}
	/**
	 * @return the nombre
	 */
	@XmlElement(nillable = true)
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @return the descripcion
	 */
	@XmlElement(nillable = true)
	public String getDescripcion() {
		return descripcion;
	}
	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	/**
	 * @return the tipo
	 */
	@XmlElement(nillable = true)
	public Integer getIdTipoRol() {
		return idTipoRol;
	}
	/**
	 * @param idTipoRol the tipo to set
	 */
	public void setIdTipoRol(Integer idTipoRol) {
		this.idTipoRol = idTipoRol;
	}

	/**
	 * @return the listIdAplicacion
	 */
	@XmlElement(nillable = true)
	public List<Integer> getListIdAplicacion() {
		return listIdAplicacion;
	}

	/**
	 * @param listIdAplicacion the listIdAplicacion to set
	 */
	public void setListIdAplicacion(List<Integer> listIdAplicacion) {
		this.listIdAplicacion = listIdAplicacion;
	}

	/**
	 * @return the idEstatus
	 */
	@XmlElement(nillable = true)
	public Integer getIdEstatus() {
		return idEstatus;
	}

	/**
	 * @param idEstatus the idEstatus to set
	 */
	public void setIdEstatus(Integer idEstatus) {
		this.idEstatus = idEstatus;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idRol == null) ? 0 : idRol.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RolVo other = (RolVo) obj;
		if (idRol == null) {
			if (other.idRol != null)
				return false;
		} else if (!idRol.equals(other.idRol))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "RolVo [idRol=" + idRol + ", nombre=" + nombre
				+ ", descripcion=" + descripcion + ", tipo=" + idTipoRol
				+ ", listIdAplicacion=" + listIdAplicacion + ", idEstatus="
				+ idEstatus + "]";
	}
	
	
	
	
}

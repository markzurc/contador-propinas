package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.ldap.mensajes;

public enum LdapMensajesEnum {
	
	LDAP_NOT_AVAILABLE("LDAP000","ERROR DE CONEXION LDAP. POR FAVOR, INTENTE MAS TARDE"),
	LDAP_PASS("LDAP002","PASSWORD INCORRECTO"),
	LDAP_USER("LDAP003","USUARIO INCORRECTO O INEXISTENTE"),
	LDAP_INTENTOS("LDAP004","NUMERO DE INTENTOS EXCEDIDO PARA EL PASSWORD"),
	LDAP_BLOQUEADO("LDAP005","ERROR DE LDAP 5. FAVOR DE CONTACTAR CON EL ADMINISTRADOR DEL SISTEMA"),
	LDAP_DESCONEXION("LDAP006","ERROR DE DESCONEXION LDAP. POR FAVOR, INTENTE MAS TARDE"),
	LDAP_BD("LDAP008","ERROR BASE DE DATOS. POR FAVOR, INTENTE MAS TARDE"),
	LDAP_NO_EXIST_EAPP("LDAP009","NO EXISTE APLICACION ASOCIADA. POR FAVOR, INTENTE NUEVAMENTE"),
	LDAP_CONTACT_ADMIN("LDAP010","FAVOR DE CONTACTAR CON EL ADMINISTRADOR DEL SISTEMA");
	
	
	private String codigo;
	private String descripcion;
	
	/**
	 * Constructor
	 * @param codigo
	 * @param descripcion
	 */
	private LdapMensajesEnum(String codigo, String descripcion){
		this.codigo = codigo;
		this.descripcion = descripcion;
	}

	/**
	 * @return the codigo
	 */
	public String getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}

	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	
	
	
}

package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.impl;

import java.util.ArrayList;
import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.error.ErrorSEGWeb;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.OVITUtils;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.mapper.MapperCustomFactory;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcApli;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.IApplicationBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ApplicationVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ComponentVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.application.dao.IApplicationDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.application.dao.dto.ComponentDto;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * 
 * <h1>ApplicationBussinesImpl</h1>
 * <p>
 * IAplicacionBusiness interface implementation.
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 31/03/2015
 *
 */

@Service("aplicacionBusiness")
@Scope("prototype")
public class ApplicationBussinesImpl extends MapperCustomFactory implements IApplicationBusiness {

	@Autowired
	@Qualifier("aplicacionDao")
	private IApplicationDao iApplicationDao;
	
	private Logger logger = LogManager.getLogger(ApplicationBussinesImpl.class);
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public List<ApplicationVo> findByExample(ApplicationVo applicationVo) throws TransactionalOVITException {

		T7segcApli tsegcApplication;
		
		logger.info("Ejecutando ApplicationBussinesImpl.findByExample");
		
		tsegcApplication = getMapper().map(applicationVo, T7segcApli.class);
		
		try{
			List<T7segcApli> lstTsegcApplication = null;
			List<ApplicationVo> lstApplicationVo = null;
			
			lstTsegcApplication = iApplicationDao.findBy(tsegcApplication);
			if(OVITUtils.isEmptyList(lstTsegcApplication)){
				return null;
			}
			lstApplicationVo = new ArrayList<ApplicationVo>(lstTsegcApplication.size());
			for(T7segcApli tsegcAplicacionTemp : lstTsegcApplication){
				ApplicationVo aplicacionVoTemp = getMapper().map(tsegcAplicacionTemp, ApplicationVo.class);
				lstApplicationVo.add(aplicacionVoTemp);
			}
			return lstApplicationVo;
		}catch(Exception e){
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejectuar ApplicationBussinesImpl.findByExample: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public List<ComponentVo> componentsForApplication(Integer idApplication) throws TransactionalOVITException {
		List<ComponentDto> lstComponentDtos;
		
		logger.info("Ejecutando ApplicationBussinesImpl.componentsForApplication");
		
		if(idApplication == null)
			return null;
		
		try {
			List<ComponentVo> lstComponentVo;
			lstComponentDtos = iApplicationDao.componentsForApplication(idApplication);
			if(OVITUtils.isEmptyList(lstComponentDtos)){
				return null;
			}
			lstComponentVo = getMapper().mapAsList(lstComponentDtos, ComponentVo.class);
			
			return lstComponentVo;
		} catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejectuar ApplicationBussinesImpl.componentsForApplication: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),
					ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
	}

}
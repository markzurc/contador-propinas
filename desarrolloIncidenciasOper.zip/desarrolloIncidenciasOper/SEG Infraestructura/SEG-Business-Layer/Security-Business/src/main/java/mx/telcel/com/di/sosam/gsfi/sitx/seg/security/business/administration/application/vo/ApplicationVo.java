package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * <h1>AplicacionVo</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 09/04/2015
 *
 */
@XmlRootElement
public class ApplicationVo implements Serializable{
	
	private static final long serialVersionUID = -7017866781519156566L;
	
	private Integer idAplicacion;
	private String nombre;
	private String descripcion;
	private String nombreBean;
	private Integer idEstatus;
	
	public ApplicationVo() {
	}
	
	public ApplicationVo(Integer idAplicacion, String nombre,
			String descripcion, String nombreBean) {
		super();
		this.idAplicacion = idAplicacion;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.nombreBean = nombreBean;
	}
	/**
	 * @return the idAplicacion
	 */
	@XmlElement(nillable = true)
	public Integer getIdAplicacion() {
		return idAplicacion;
	}
	/**
	 * @param idAplicacion the idAplicacion to set
	 */
	public void setIdAplicacion(Integer idAplicacion) {
		this.idAplicacion = idAplicacion;
	}
	/**
	 * @return the nombre
	 */
	@XmlElement(nillable = true)
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @return the descripcion
	 */
	@XmlElement(nillable = true)
	public String getDescripcion() {
		return descripcion;
	}
	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	/**
	 * @return the nombreBean
	 */
	@XmlElement(nillable = true)
	public String getNombreBean() {
		return nombreBean;
	}
	/**
	 * @param nombreBean the nombreBean to set
	 */
	public void setNombreBean(String nombreBean) {
		this.nombreBean = nombreBean;
	}
	
	/**
	 * @return the idEstatus
	 */
	@XmlElement(nillable = true)
	public Integer getIdEstatus() {
		return idEstatus;
	}

	/**
	 * @param idEstatus the idEstatus to set
	 */
	public void setIdEstatus(Integer idEstatus) {
		this.idEstatus = idEstatus;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idAplicacion == null) ? 0 : idAplicacion.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ApplicationVo other = (ApplicationVo) obj;
		if (idAplicacion == null) {
			if (other.idAplicacion != null)
				return false;
		} else if (!idAplicacion.equals(other.idAplicacion))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ApplicationVo [idAplicacion=");
		builder.append(idAplicacion);
		builder.append(", nombre=");
		builder.append(nombre);
		builder.append(", descripcion=");
		builder.append(descripcion);
		builder.append(", nombreBean=");
		builder.append(nombreBean);
		builder.append(", idEstatus=");
		builder.append(idEstatus);
		builder.append("]");
		return builder.toString();
	}
	
}

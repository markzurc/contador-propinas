
package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.external.authentication;

/**
 *
 * @author VI7FC37
 */
public interface IAuthenticationExternal {
    
    public String encriptarAcceso(String acceso);
    public String desencriptarAcceso(String textoExcriptado);
    public String validacionAcceso(String usuario, String acceso);
    public int consultaExistenciaUsuarioExterno(String usuario);
}

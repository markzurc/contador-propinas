package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.external.authentication.impl;

import com.telcel.util.Base64;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.logging.Level;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.external.authentication.IAuthenticationExternal;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dao.IUserDao;

import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author VI7FC37
 */
@Component
@Qualifier("externalAuth")
public class AuthenticationExternal implements IAuthenticationExternal {    
    @Autowired
    @Qualifier("userDao")
    private IUserDao userDao;
    
    String llaveSecretaAES="";
    String salAES="";

    @Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.NEVER)
    @Override
    public String encriptarAcceso(String acceso) {
        try {
            llaveSecretaAES=userDao.obtenerEnco(1);
            salAES=userDao.obtenerEnco(2); 
            byte[] iv = new byte[16];
            IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
            SecretKeyFactory llave = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            KeySpec keySpec = new PBEKeySpec(llaveSecretaAES.toCharArray(), salAES.getBytes(), 1000, 128);
            SecretKey llaveTemp = llave.generateSecret(keySpec);
            SecretKeySpec secretKey = new SecretKeySpec(llaveTemp.getEncoded(), "AES");
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivParameterSpec);
            return String.valueOf(Base64.encodeBytes(cipher.doFinal(acceso.getBytes("UTF-8"))));
        } catch (InvalidAlgorithmParameterException e) {
            System.err.println("Error al tratar de encriptar texto: "+e);
        } catch (InvalidKeyException e) {
            System.err.println("Error al tratar de encriptar texto: "+e);
        } catch (NoSuchAlgorithmException e) {
            System.err.println("Error al tratar de encriptar texto: "+e);
        } catch (InvalidKeySpecException e) {
            System.err.println("Error al tratar de encriptar texto: "+e);
        } catch (NoSuchPaddingException e) {            
            System.err.println("Error al tratar de encriptar texto: "+e);
        } catch (UnsupportedEncodingException e) {            
            System.err.println("Error al tratar de encriptar texto: "+e);
        } catch (IllegalBlockSizeException e) {            
            System.err.println("Error al tratar de encriptar texto: "+e);
        } catch (BadPaddingException e) {            
            System.err.println("Error al tratar de encriptar texto: "+e);
        }
        return null;
    }

    @Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.NEVER)
    @Override
    public String desencriptarAcceso(String textoExcriptado) {
        byte[] iv = new byte[16];
        try {
            llaveSecretaAES=userDao.obtenerEnco(1);
            salAES=userDao.obtenerEnco(2); 
            IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
            SecretKeyFactory llave = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            KeySpec keySpec = new PBEKeySpec(llaveSecretaAES.toCharArray(), salAES.getBytes(), 1000, 128);
            SecretKey llaveTemp = llave.generateSecret(keySpec);
            SecretKeySpec secretKey = new SecretKeySpec(llaveTemp.getEncoded(), "AES");
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, secretKey, ivParameterSpec);
            return new String(cipher.doFinal(Base64.decode(textoExcriptado)));
        } catch (InvalidAlgorithmParameterException e) {
            System.err.println("Error al tratar de encriptar texto: "+e);
        } catch (InvalidKeyException e) {
            System.err.println("Error al tratar de encriptar texto: "+e);
        } catch (NoSuchAlgorithmException e) {
            System.err.println("Error al tratar de encriptar texto: "+e);
        } catch (InvalidKeySpecException e) {
            System.err.println("Error al tratar de encriptar texto: "+e);
        } catch (NoSuchPaddingException e) {            
            System.err.println("Error al tratar de encriptar texto: "+e);
        } catch (IllegalBlockSizeException e) {            
            System.err.println("Error al tratar de encriptar texto: "+e);
        } catch (BadPaddingException e) {            
            System.err.println("Error al tratar de encriptar texto: "+e);
        } catch (IOException ex) {
            LogManager.getLogger(AuthenticationExternal.class.getName()).error(ex);
        }
        return null;
    }
    
    @Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.NEVER)
    @Override
    public int consultaExistenciaUsuarioExterno(String usuario){
       return userDao.consultaExistenciaUsuarioExterno(usuario);
    }
    
    @Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.NEVER)
    @Override
    public String validacionAcceso(String usuario, String acceso) {
        if (acceso != null && !acceso.isEmpty() && !acceso.equals("")) {
            String accesoComparativo = userDao.consultaAccesoUsuarioExterno(usuario),
            accesoIngresado = encriptarAcceso(acceso),
            identificadorUsuario = userDao.obtieneIdenUsuario(usuario);
            if (accesoComparativo.equals(accesoIngresado)) {
                userDao.actualizaNumeroDeIntentos(0, identificadorUsuario);
                return "";
            } else {
                int intentoFallido = userDao.obtieneIntentosFallidos(usuario);                
                intentoFallido = intentoFallido + 1;
                if (intentoFallido == userDao.obtieneMaximoIntentosPermitidos()) {
                    //Actualizar a estado de bloqueo al tercer intento fallido                    
                    userDao.actualizaUsuarioABloqueo(identificadorUsuario);
                    userDao.actualizaNumeroDeIntentos(intentoFallido, identificadorUsuario);
                } else {
                    userDao.actualizaNumeroDeIntentos(intentoFallido, identificadorUsuario);
                }
                return "Las credenciales ingresadas no son correctas";
            }
        } else {
            return "La contrase\u00F1a se encuentra vac\u00EDa";
        }
    }
}

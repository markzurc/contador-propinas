package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.error.ErrorSEGWeb;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.OVITUtils;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.mapper.MapperCustomFactory;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcApli;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcRol;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcTipoRol;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segrCapliCrolRapti;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ApplicationVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.IRolBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolAclVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolApplicationVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolTypeVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.rol.dao.IRolDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.rol.dao.dto.RolAclDto;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * 
 * <h1>RolBusinessImpl</h1>
 * <p>
 * IRolBusiness interface implementation
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 30/03/2015
 *
 */
@Service("rolBusiness")
@Scope("prototype")
public class RolBusinessImpl extends MapperCustomFactory implements IRolBusiness{

	@Autowired
	@Qualifier("rolDao")
	private IRolDao rolDao;
	
	private Logger logger = LogManager.getLogger(RolBusinessImpl.class);
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public RolVo createRol(RolVo rolVo, List<RolAclVo> lstRolAclVos) throws TransactionalOVITException {
		
		T7segcRol tsegcRol;
		List<Integer> listIdAplicacionRol;
		List<T7segrCapliCrolRapti> lstTsegrRolAcls;
		
		logger.info("Ejecutando RolBusinessImpl.createRol");
		logger.info("Inicia validacion de objeto RolVo");
		if(!validateRolVo(rolVo)){
			logger.info("El objeto RolVo es incorrecto");
			throw new TransactionalOVITException(ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getCodeError(),
					ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getMessageError());
		}
		
		if(OVITUtils.isEmptyList(lstRolAclVos)){
			logger.info("La lista con los ACL's no puede ser vacia");
			throw new TransactionalOVITException(ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getCodeError(),
					ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getMessageError());
		}
		
		tsegcRol = getMapper().map(rolVo, T7segcRol.class);
		
		listIdAplicacionRol = rolVo.getListIdAplicacion();
		List<T7segcApli> lstApplication = new ArrayList<T7segcApli>(0);
		
		
		if (!OVITUtils.isEmptyList(listIdAplicacionRol)) {
			for (Integer idApplication : listIdAplicacionRol) {
				T7segcApli tsegcAplicacion = new T7segcApli();
				tsegcAplicacion.setIdAplicacion(idApplication);
				lstApplication.add(tsegcAplicacion);
			}
		}
		
		tsegcRol.setTsegcAplicacions(lstApplication);
		
		logger.info("Realizando Insert del objeto Rol");
		try{
			rolDao.createRol(tsegcRol);
			lstTsegrRolAcls = new ArrayList<T7segrCapliCrolRapti>(lstRolAclVos.size());
			
			for(RolAclVo rolAclVoTemp : lstRolAclVos){
				rolAclVoTemp.setIdRol(tsegcRol.getIdRol());
				lstTsegrRolAcls.add(getMapper().map(rolAclVoTemp, T7segrCapliCrolRapti.class));
			}
			rolDao.createRolRestriction(lstTsegrRolAcls);
		}catch(Exception e){
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E01_ERROR_INSERT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E01_ERROR_INSERT.getMessageError()));
			logger.error("Error al ejecutar RolBusinessImpl.createRol" + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E01_ERROR_INSERT.getCodeError(),ErrorSEGWeb.E01_ERROR_INSERT.getMessageError());
		}
		rolVo = getMapper().map(tsegcRol, RolVo.class);
		rolVo.setListIdAplicacion(listIdAplicacionRol);
		return rolVo;
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public boolean updateRol(RolVo rolVo,  List<RolAclVo> lstRolAclVos) throws TransactionalOVITException {
		T7segcRol tsegcRol;
		List<Integer> listIdAplicacionRol;
		
		logger.info("Ejecutando RolBusinessImpl.updateRol");
		logger.info("Inicia validacion de objeto RolVo");
		if(!validateRolVo(rolVo)||rolVo.getIdRol() ==null){
			logger.info("El objeto RolVo es incorrecto");
			return false;
		}
		
		tsegcRol = getMapper().map(rolVo, T7segcRol.class);
		
		listIdAplicacionRol = rolVo.getListIdAplicacion();
		List<T7segcApli> lstApplication = new ArrayList<T7segcApli>(0);
		if (!OVITUtils.isEmptyList(listIdAplicacionRol)) {
			for (Integer idApplication : listIdAplicacionRol) {
				T7segcApli tsegcAplicacion = new T7segcApli();
				tsegcAplicacion.setIdAplicacion(idApplication);
				lstApplication.add(tsegcAplicacion);
			}
		}
		tsegcRol.setTsegcAplicacions(lstApplication);
		
		try{
			List<T7segrCapliCrolRapti> lstTsegrRolAcls;
			
			rolDao.updateRol(tsegcRol);
			if(!OVITUtils.isEmptyList(lstRolAclVos)){
				T7segrCapliCrolRapti tsegrRolAcl = new T7segrCapliCrolRapti();
				tsegrRolAcl.setIdRol(rolVo.getIdRol());
				rolDao.deleteRolRestriction(tsegrRolAcl);
				
				lstTsegrRolAcls = new ArrayList<T7segrCapliCrolRapti>(lstRolAclVos.size());
				
				for(RolAclVo rolAclVoTemp : lstRolAclVos){
					rolAclVoTemp.setIdRol(tsegcRol.getIdRol());
					lstTsegrRolAcls.add(getMapper().map(rolAclVoTemp, T7segrCapliCrolRapti.class));
				}
				rolDao.createRolRestriction(lstTsegrRolAcls);
				
			}
		}catch(Exception e){
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError()));
			logger.error("Error al ejecutar RolBusinessImpl.updateRol: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError(),ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError());
		}
		return true;
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public RolApplicationVo findByWithApplications(RolVo rolVo) throws TransactionalOVITException {
		T7segcRol tsegcRol;
		List <Integer> listIdApplicationRol;
		
		logger.info("Ejecutando RolBusinessImpl.findBy");
		tsegcRol = getMapper().map(rolVo, T7segcRol.class);
		
		listIdApplicationRol = rolVo.getListIdAplicacion();
		List<T7segcApli> lstApplication = new ArrayList<T7segcApli>(0);
		
		if (!OVITUtils.isEmptyList(listIdApplicationRol)) {
			for (Integer idApplication : listIdApplicationRol) {
				T7segcApli tsegcAplicacion = new T7segcApli();
				tsegcAplicacion.setIdAplicacion(idApplication);
				lstApplication.add(tsegcAplicacion);
			}
		}
		
		tsegcRol.setTsegcAplicacions(lstApplication);
		try{
			List<T7segcRol> lstTsegcRol = null;
			HashMap<RolVo,List<ApplicationVo>> rolApplication;
			
			lstTsegcRol = rolDao.findByWithApplications(tsegcRol);
			
			rolApplication = new HashMap<RolVo, List<ApplicationVo>>(lstTsegcRol.size());
			if(!OVITUtils.isEmptyList(lstTsegcRol)){
				for(T7segcRol tsegcRolTemp : lstTsegcRol){
					RolVo rolVoTemp;
					rolVoTemp = getMapper().map(tsegcRolTemp, RolVo.class);
					List<ApplicationVo> lstIdApplicationTemp = new ArrayList<ApplicationVo>(tsegcRolTemp.getTsegcAplicacions().size());
					for(T7segcApli tsegcAplicacionTemp : tsegcRolTemp.getTsegcAplicacions()){
						ApplicationVo applicationVo = getMapper().map(tsegcAplicacionTemp, ApplicationVo.class); 
						lstIdApplicationTemp.add(applicationVo);
					}
					rolApplication.put(rolVoTemp, lstIdApplicationTemp);
				}
			}
			return new RolApplicationVo(rolApplication);
		}catch(Exception e){
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar RolBusinessImpl.findByWithApplicationsl: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public List<RolVo> findByWithoutApplications(RolVo rolVo) throws TransactionalOVITException {
		T7segcRol tsegcRol;
		List <Integer> listIdAplicacionRol;
		
		logger.info("Ejecutando RolBusinessImpl.findBy");
		tsegcRol = getMapper().map(rolVo, T7segcRol.class);
		
		listIdAplicacionRol = rolVo.getListIdAplicacion();
		List<T7segcApli> lstApplication = new ArrayList<T7segcApli>(0);
		
		if (!OVITUtils.isEmptyList(listIdAplicacionRol)) {
			for (Integer idApplication : listIdAplicacionRol) {
				T7segcApli tsegcAplicacion = new T7segcApli();
				tsegcAplicacion.setIdAplicacion(idApplication);
				lstApplication.add(tsegcAplicacion);
			}
		}
		
		tsegcRol.setTsegcAplicacions(lstApplication);
		try{
			List <RolVo> lstRolVo;
			List<T7segcRol> lstTsegcRol = null;
			lstTsegcRol = rolDao.findBy(tsegcRol);
			lstRolVo = new ArrayList<RolVo>(lstTsegcRol.size());
			if(!OVITUtils.isEmptyList(lstTsegcRol)){
				for(T7segcRol tsegcRolTemp : lstTsegcRol){
					RolVo rolVoTemp;
					rolVoTemp = getMapper().map(tsegcRolTemp, RolVo.class);
					lstRolVo.add(rolVoTemp);
				}
			}
			return lstRolVo;
		}catch(Exception e){
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar RolBusinessImpl.findByWithoutApplications: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public List<RolAclVo> findByRolAcl(Integer idRol, Integer idAplicacion) throws TransactionalOVITException{
		logger.info("Ejecutando RolBusinessImpl.findByRolAcl");
		
		try {
			List<RolAclVo> lstRolAclVos;
			List<RolAclDto> lstRolAclDtos = rolDao.findByRolAcl(idRol, idAplicacion);
			
			if(OVITUtils.isEmptyList(lstRolAclDtos)){
				return null;
			}
			lstRolAclVos = getMapper().mapAsList(lstRolAclDtos, RolAclVo.class);
			return lstRolAclVos;
		}catch(Exception e){
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar RolBusinessImpl.findByRolAcl: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),
					ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public List<RolTypeVo> getRoltype() throws TransactionalOVITException{
		logger.info("Ejecutando RolBusinessImpl.getRoltype");
		List<RolTypeVo> lstRolTypeVos = null;
		List<T7segcTipoRol> lstTsegcTipoRols = null;
		
		try {
			lstTsegcTipoRols = rolDao.getRoltype();
			if(OVITUtils.isEmptyList(lstTsegcTipoRols)){
				return null;
			}
			lstRolTypeVos = getMapper().mapAsList(lstTsegcTipoRols, RolTypeVo.class);
		} catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar RolBusinessImpl.getRoltype: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),
					ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
		return lstRolTypeVos;
	}
	
	private boolean validateRolVo(RolVo rolVo){
		if(OVITUtils.isEmptyList(rolVo.getListIdAplicacion())){
			logger.info("RolVo.idAplicacion nulo");
			return false;
		}
		if(OVITUtils.isEmptyString(rolVo.getNombre())){
			logger.info("RolVo.nombre vac�o o nulo");
			return false;
		}
		if(OVITUtils.isEmptyString(rolVo.getDescripcion())){
			logger.info("RolVo.descripcion vac�o o nulo");
			return false;
		}
		if(rolVo.getIdTipoRol() == null){
			logger.info("RolVo.tipo nulo");
			return false;
		}
		return true;
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public boolean isInUse(Integer idRol) throws TransactionalOVITException {
		logger.info("Ejecutando RolBusinessImpl.getRoltype");
		
		try {
			int rolCount = rolDao.isInUse(idRol);
			if(rolCount > 0){
				return true;
			}else{
				return false;
			}
		} catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar RolBusinessImpl.isInUse: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),
					ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public List<T7segcRol> getRoles() {
		return rolDao.getRoles();
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public String getRoltype(Integer idRol) throws TransactionalOVITException{
		logger.info("Ejecutando RolBusinessImpl.getRoltype(idRol)");
		String tsegcTipoRol = null;
		
		try {
			tsegcTipoRol = rolDao.getRoltype(idRol);
			logger.info("respuesta sql: " + tsegcTipoRol);
			if (tsegcTipoRol == null) {
				logger.info("es null: ");
				return null;
			}
		} catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar RolBusinessImpl.getRoltype: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),
					ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
		return tsegcTipoRol;
	}
	
}

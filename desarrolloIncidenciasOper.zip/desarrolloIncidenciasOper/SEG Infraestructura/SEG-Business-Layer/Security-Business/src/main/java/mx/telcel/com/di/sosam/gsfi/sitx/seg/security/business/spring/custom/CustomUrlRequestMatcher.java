package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.spring.custom;

import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.web.util.UrlUtils;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.util.Assert;

/**
 *
 * <h1>CustomUrlRequestMatcher</h1>
 * <p>
 *
 * </p> @author chcastro
 * @version 1.0
 * @since 29/04/2015
 *
 */
public class CustomUrlRequestMatcher implements RequestMatcher, Serializable {

    private static final long serialVersionUID = 1057543067952528760L;
    private final String filterProcessesUrl;
    private String respuesta;

    /**
     *
     * @param filterProcessesUrl
     */
    public CustomUrlRequestMatcher(String filterProcessesUrl) {
        Assert.hasLength(filterProcessesUrl, "filterProcessesUrl must be specified");
        Assert.isTrue(UrlUtils.isValidRedirectUrl(filterProcessesUrl), filterProcessesUrl + " isn't a valid redirect URL");
        this.filterProcessesUrl = filterProcessesUrl;
    }

    @Override
    public boolean matches(HttpServletRequest request) {
        if (request.getQueryString() != null && request.getRequestURI().equals("/SEG-Infraestructura/app/j_spring_security_check")) {
            respuesta = "";
        } else if (request.getQueryString() != null && request.getQueryString().contains("idSolicitud")) {
            respuesta = request.getQueryString();
        }
        String uri = request.getRequestURI();
        int pathParamIndex = uri.indexOf(';');

        if (pathParamIndex > 0) {
            uri = uri.substring(0, pathParamIndex);
        }

        if ("".equals(request.getContextPath())) {
            return uri.endsWith(filterProcessesUrl);
        }

        return uri.endsWith(request.getContextPath() + filterProcessesUrl);
    }

    public String invocaRespuestaIndicadorParametro() {
        return respuesta;
    }
    
    public void reestableceRespuestaIndicadorParametro(){
        respuesta = "";
    }
}

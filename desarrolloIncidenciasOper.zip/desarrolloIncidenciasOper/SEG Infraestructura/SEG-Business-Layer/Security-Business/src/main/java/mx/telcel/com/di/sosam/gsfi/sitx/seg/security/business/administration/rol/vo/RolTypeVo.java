package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * <h1>RolTypeVo</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 13/05/2015
 */
@XmlRootElement
public class RolTypeVo implements Serializable {

	private static final long serialVersionUID = -7234861696336859713L;
	
	private Integer idTipoRol;
	private String descripcion;
	
	public RolTypeVo() {
	}
	
	/**
	 * 
	 * @param idTipoRol
	 * @param descripcion
	 */
	public RolTypeVo(Integer idTipoRol, String descripcion) {
		super();
		this.idTipoRol = idTipoRol;
		this.descripcion = descripcion;
	}

	/**
	 * @return the idTipoRol
	 */
	@XmlElement(nillable = true)
	public Integer getIdTipoRol() {
		return idTipoRol;
	}

	/**
	 * @param idTipoRol the idTipoRol to set
	 */
	public void setIdTipoRol(Integer idTipoRol) {
		this.idTipoRol = idTipoRol;
	}

	/**
	 * @return the descripcion
	 */
	@XmlElement(nillable = true)
	public String getDescripcion() {
		return descripcion;
	}

	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RolTypeVo [idTipoRol=");
		builder.append(idTipoRol);
		builder.append(", descripcion=");
		builder.append(descripcion);
		builder.append("]");
		return builder.toString();
	}

}

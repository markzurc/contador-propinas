package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * <h1>RolAclVo</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 13/05/2015
 */
@XmlRootElement
public class RolAclVo implements Serializable{

	private static final long serialVersionUID = -523981615351329858L;

	private Integer idRol;
	private Integer idAplicacion;
	private Integer idComponente;
	private String flujo;
	private Integer idPadre;
	private String nombre;
	private Integer idTipoComponente;
	private Character permiso;
	private String valorComponente;
	private Integer nivel;
	
	public RolAclVo() {
	}

	/**
	 * @param idRol
	 * @param idAplicacion
	 * @param idComponente
	 * @param flujo
	 * @param idPadre
	 * @param nombre
	 * @param idTipoComponente
	 * @param permiso
	 * @param valorComponente
	 * @param nivel
	 */
	public RolAclVo(Integer idRol, Integer idAplicacion, Integer idComponente,
			String flujo, Integer idPadre, String nombre,
			Integer idTipoComponente, Character permiso,
			String valorComponente, Integer nivel) {
		super();
		this.idRol = idRol;
		this.idAplicacion = idAplicacion;
		this.idComponente = idComponente;
		this.flujo = flujo;
		this.idPadre = idPadre;
		this.nombre = nombre;
		this.idTipoComponente = idTipoComponente;
		this.permiso = permiso;
		this.valorComponente = valorComponente;
		this.nivel = nivel;
	}

	/**
	 * @return the idRol
	 */
	@XmlElement(nillable = true)
	public Integer getIdRol() {
		return idRol;
	}
	/**
	 * @param idRol the idRol to set
	 */
	public void setIdRol(Integer idRol) {
		this.idRol = idRol;
	}
	/**
	 * @return the idAplicacion
	 */
	@XmlElement(nillable = true)
	public Integer getIdAplicacion() {
		return idAplicacion;
	}
	/**
	 * @param idAplicacion the idAplicacion to set
	 */
	public void setIdAplicacion(Integer idAplicacion) {
		this.idAplicacion = idAplicacion;
	}
	/**
	 * @return the idComponente
	 */
	@XmlElement(nillable = true)
	public Integer getIdComponente() {
		return idComponente;
	}
	/**
	 * @param idComponente the idComponente to set
	 */
	public void setIdComponente(Integer idComponente) {
		this.idComponente = idComponente;
	}
	/**
	 * @return the flujo
	 */
	@XmlElement(nillable = true)
	public String getFlujo() {
		return flujo;
	}
	/**
	 * @param flujo the flujo to set
	 */
	public void setFlujo(String flujo) {
		this.flujo = flujo;
	}
	/**
	 * @return the idPadre
	 */
	@XmlElement(nillable = true)
	public Integer getIdPadre() {
		return idPadre;
	}
	/**
	 * @param idPadre the idPadre to set
	 */
	public void setIdPadre(Integer idPadre) {
		this.idPadre = idPadre;
	}
	/**
	 * @return the nombre
	 */
	@XmlElement(nillable = true)
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @return the tipoComponente
	 */
	@XmlElement(nillable = true)
	public Integer getIdTipoComponente() {
		return idTipoComponente;
	}
	/**
	 * @param tipoComponente the tipoComponente to set
	 */
	public void setIdTipoComponente(Integer idTipoComponente) {
		this.idTipoComponente = idTipoComponente;
	}
	/**
	 * @return the permiso
	 */
	@XmlElement(nillable = true)
	public Character getPermiso() {
		return permiso;
	}
	/**
	 * @param permiso the permiso to set
	 */
	public void setPermiso(Character permiso) {
		this.permiso = permiso;
	}


	

	/**
	 * @return the valorComponente
	 */
	@XmlElement(nillable = true)
	public String getValorComponente() {
		return valorComponente;
	}



	/**
	 * @param valorComponente the valorComponente to set
	 */
	public void setValorComponente(String valorComponente) {
		this.valorComponente = valorComponente;
	}

	/**
	 * @return the nivel
	 */
	@XmlElement(nillable = true)
	public Integer getNivel() {
		return nivel;
	}

	/**
	 * @param nivel the nivel to set
	 */
	public void setNivel(Integer nivel) {
		this.nivel = nivel;
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RolAclVo [idRol=");
		builder.append(idRol);
		builder.append(", idAplicacion=");
		builder.append(idAplicacion);
		builder.append(", idComponente=");
		builder.append(idComponente);
		builder.append(", flujo=");
		builder.append(flujo);
		builder.append(", idPadre=");
		builder.append(idPadre);
		builder.append(", nombre=");
		builder.append(nombre);
		builder.append(", idTipoComponente=");
		builder.append(idTipoComponente);
		builder.append(", permiso=");
		builder.append(permiso);
		builder.append(", valorComponente=");
		builder.append(valorComponente);
		builder.append(", nivel=");
		builder.append(nivel);
		builder.append("]");
		return builder.toString();
	}

}

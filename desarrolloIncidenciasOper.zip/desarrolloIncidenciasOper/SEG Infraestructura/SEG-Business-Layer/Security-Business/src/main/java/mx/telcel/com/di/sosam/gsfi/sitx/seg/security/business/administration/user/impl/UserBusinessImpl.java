package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.validation.ConstraintViolation;

import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.bitacora.sox.IBitacoraSoxBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.error.ErrorSEGWeb;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.ISendMailBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.exception.SendingMailOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.mail.vo.MessageVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.spring.session.details.UserDetailsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.OVITUtils;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.IConfigurationUtilsBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.identifier.ConfigOvitIdentifierEnum;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.configuration.vo.ConfigurationUtilsVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.business.utils.mapper.MapperCustomFactory;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.application.thirdparty.IApplicationMethods;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.application.thirdparty.request.ApplicationGenericRequest;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segbHistPass;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segcRol;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoDatoUsuaExte;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoPass;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.T7segoUsua;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.TsegcDatosexternoId;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.entity.security.TsegcPasswordId;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.common.data.exception.TransactionalOVITException;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.application.vo.ApplicationVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.email.vo.CorreoNotiVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.email.vo.CorreoPropVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rol.vo.RolAclVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.rolaccion.vo.RolAccionVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.IUserBusiness;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ExternalDataVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ExternalUserFindVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ExternalUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.InternalDataVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.InternalUserFindVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.InternalUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.ReportUserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.UserContraVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.user.vo.UserVo;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.email.dto.CorreoNotiDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.email.dto.CorreoPropDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.rolaccion.dto.ReportRolAccionDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dao.IUserDao;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.DocumentoDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.EstatusDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.ExternalUserFindDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.InternalUserFindDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.OperadorDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.ReportUserDto;
import mx.telcel.com.di.sosam.gsfi.sitx.seg.security.data.administration.user.dto.UserDetailsDto;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.telcel.security.Crypt;

/**
 * 
 * <h1>UserBusinessImpl</h1>
 * <p>
 * </p>
 * @author chcastro
 * @version 1.0
 * @since 15/04/2015
 *
 */

@Service("userBusiness")
@Scope("prototype")
public class UserBusinessImpl extends MapperCustomFactory implements IUserBusiness{
	
	private static final int EXTERNAL = 1;
	private static final int REASON_NEW = 0;
	private static final int REASON_RESET = 1;
	public static final String IMAGE_PNG = "png";
	
	
	@Autowired
	private ApplicationContext appContext;
	
	@Autowired
	@Qualifier("userDao")
	private IUserDao userDao;
	
	@Autowired
	@Qualifier("configurationtUtilsBusiness")
	private IConfigurationUtilsBusiness configurationUtilsBusiness;
	
	@Autowired
	@Qualifier("sendMailBusiness")
	private ISendMailBusiness sendMailBusiness;
	
	@Autowired
	@Qualifier("bitacoraSox")
	private IBitacoraSoxBusiness bitacoraSoxBusiness;
	
	private Logger logger = LogManager.getLogger(UserBusinessImpl.class);
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public ExternalUserVo createUser(ExternalUserVo userTypeVo, 
			List<? super ApplicationGenericRequest> listRequest)
			throws TransactionalOVITException, SendingMailOVITException {
		logger.info("Ejecutando UserBusinessImpl.createUser");
		
		UserVo userVo = null;
		ExternalDataVo externalDataVo = null;
		T7segoDatoUsuaExte tsegcDatosexterno = null;
		T7segoPass tsegcPassword = null;
		String strMail = null;
		MessageVo messageVo = null;
		
		try{
			if(userTypeVo instanceof ExternalUserVo){
				T7segoUsua tsegcUsuario = null;
				
				userVo = userTypeVo.getUserVo();
				externalDataVo = userTypeVo.getExternalDataVo();
				validateUserData(userVo);
				validateUserData(externalDataVo);
				tsegcUsuario = userDao.validateLogIn(externalDataVo.getNumeroEmpleado());
				if(tsegcUsuario != null){
					throw new TransactionalOVITException(ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getCodeError(),
							ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getMessageError());
				}
				tsegcDatosexterno = getMapper().map(externalDataVo, T7segoDatoUsuaExte.class);
				strMail = externalDataVo.getCorreo();
				String strPwdEncrypt = encryptPassword(UUID.randomUUID().toString().substring(0, 8));
				tsegcPassword = new T7segoPass(null, strPwdEncrypt, 0, new Date());
					
				tsegcUsuario = getMapper().map(userVo, T7segoUsua.class);
				T7segcRol tsegcRol = new T7segcRol(userVo.getIdRol());
				
				tsegcUsuario.setTsegcRol(tsegcRol);
				
				userDao.createUser(tsegcUsuario, tsegcPassword, tsegcDatosexterno);
				userVo.setIdUsuario(tsegcUsuario.getIdUsuario());
			}
			if(!OVITUtils.isEmptyList(listRequest)){
				for(Object appRequest: listRequest){
					IApplicationMethods appMethods;
					String beanName = ((ApplicationGenericRequest) appRequest).getBeanNameSpring();
					appMethods = (IApplicationMethods) appContext.getBean(beanName);
					appMethods.setSession(userDao.getSession());
					appMethods.executeInsert(appRequest);
				}
			}
			if(UUID.randomUUID().toString().substring(0, 8) != null){
				messageVo = sendMailBusiness.getNewUserMessage();
				List<String> addressTo = new ArrayList<String>(1);
				addressTo.add(strMail);
				String message = messageVo.getValor()
						.replaceAll("#\\{usuario\\}", externalDataVo.getNumeroEmpleado())
						.replaceAll("#\\{password\\}", UUID.randomUUID().toString().substring(0, 8));
				String asunto = messageVo.getAsunto()
						.replaceAll("#\\{usuario\\}", externalDataVo.getNumeroEmpleado());
				ConfigurationUtilsVo footer = configurationUtilsBusiness
						.getConstantOfDataBase(ConfigOvitIdentifierEnum.IMAGES_MAIL.IMG_FOOTER);
				ConfigurationUtilsVo banner = configurationUtilsBusiness
						.getConstantOfDataBase(ConfigOvitIdentifierEnum.IMAGES_MAIL.IMG_BANNER);
				byte[] footerImage = sendMailBusiness.getWebImage(footer.getValor(), IMAGE_PNG);
				byte[] bannerImage = sendMailBusiness.getWebImage(banner.getValor(), IMAGE_PNG);
				sendMailBusiness.senMailTo(addressTo, null, null, asunto, message,bannerImage,footerImage);
			}
			return userTypeVo;
		}catch(SendingMailOVITException e){
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E05_ERROR_ENVIAR_CORREO.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E05_ERROR_ENVIAR_CORREO.getMessageError()));
			logger.error("Error al ejecutar UserBusinessImpl.createUser: " + e);
			throw new SendingMailOVITException(ErrorSEGWeb.E05_ERROR_ENVIAR_CORREO.getCodeError(),
					ErrorSEGWeb.E05_ERROR_ENVIAR_CORREO.getMessageError());
		}catch(Exception e){
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E01_ERROR_INSERT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E01_ERROR_INSERT.getMessageError()));
			logger.error("Error al ejecutar UserBusinessImpl.createUser: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E01_ERROR_INSERT.getCodeError(),
					ErrorSEGWeb.E01_ERROR_INSERT.getMessageError());
		}
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public void updateUser(ExternalUserVo userTypeVo)
			throws TransactionalOVITException {
		logger.info("Ejecutando UserBusinessImpl.createUser");
		
		UserVo userVo = null;
		ExternalDataVo externalDataVo = null;
		T7segoDatoUsuaExte tsegcDatosexterno = null;
		
		try{
			userVo = userTypeVo.getUserVo();
			externalDataVo = userTypeVo.getExternalDataVo();
		
			validateUserData(userVo);
		
			validateUserData(externalDataVo);
			tsegcDatosexterno = getMapper().map(externalDataVo, T7segoDatoUsuaExte.class);
			tsegcDatosexterno.setId(new TsegcDatosexternoId(userVo.getIdUsuario()));
				
		
			T7segoUsua tsegcUsuario = null;
			tsegcUsuario = userDao.validateLogIn(externalDataVo.getNumeroEmpleado());
			if(tsegcUsuario == null){
				throw new TransactionalOVITException(ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getCodeError(),
						ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getMessageError());
			}
			userDao.getSession().evict(tsegcUsuario);
			tsegcUsuario = getMapper().map(userVo, T7segoUsua.class);
			T7segcRol tsegcRol = new T7segcRol(userVo.getIdRol());
			
			tsegcUsuario.setTsegcRol(tsegcRol);
			userDao.updateUser(tsegcUsuario, tsegcDatosexterno);
		}catch(Exception e){
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError()));
			logger.error("Error al ejecutar UserBusinessImpl.updateUser: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError(),
					ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError());
		}
		
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public ExternalUserFindVo findExternalUserById(Integer idUsuario)
			throws TransactionalOVITException {
		
		logger.info("Ejecutando UserBusinessImpl.findExternalUserById");
		try{
			ExternalUserFindDto externalUserFindDto;
			UserVo userVo;
			ExternalDataVo externalDataUser;
			InternalUserVo responsibleUser;
			List<RolAclVo> rolAclVo;
			List<ApplicationVo> applicationVo;
			UserVo userVoResponsible;
			InternalDataVo internalDataVo;
			ExternalUserFindVo externalUserFindVo;
			
			if(idUsuario == null){
				logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
						.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
				throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
			}
			
			externalUserFindDto = userDao.findExternalUserById(idUsuario);
			userVo = getMapper().map(externalUserFindDto.getTsegcUsuario(), UserVo.class);
			userVo.setIdRol(externalUserFindDto.getTsegcUsuario().getTsegcRol().getIdRol());
			userVo.setNumeroEmpleado(externalUserFindDto.getTsegcDatosexterno().getNumeroEmpleado());
			externalDataUser = getMapper().map(externalUserFindDto.getTsegcDatosexterno(), ExternalDataVo.class);
			userVoResponsible = getMapper().map(externalUserFindDto.getTsegcUsuarioResponsable(), UserVo.class);
			internalDataVo = getMapper().map(externalUserFindDto.getTsegcDatosinterno(), InternalDataVo.class);
			responsibleUser = new InternalUserVo(userVoResponsible, internalDataVo);
			rolAclVo = getMapper().mapAsList(externalUserFindDto.getTsegrRolAcl(), RolAclVo.class);
			applicationVo = getMapper().mapAsList(externalUserFindDto.getTsegcAplicacions(), ApplicationVo.class);
			
			externalUserFindVo = new ExternalUserFindVo(userVo, externalDataUser, responsibleUser, rolAclVo, applicationVo);
			
			return externalUserFindVo;
		}catch(Exception e){
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar UserBusinessImpl.findExternalUserById: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public InternalUserFindVo findInternalUserById(Integer idUsuario)
			throws TransactionalOVITException {
		logger.info("Ejecutando UserBusinessImpl.findExternalUserById");
		try{
			InternalUserFindDto internalUserFindDto;
			UserVo userVo;
			InternalDataVo internalDataVo;
			List<RolAclVo> rolAclVo;
			List<ApplicationVo> applicationVo;
			InternalUserFindVo internalUserFindVo;
			
			if(idUsuario == null){
				logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
						.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
				throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
			}
			
			internalUserFindDto = userDao.findInternalUserById(idUsuario);
			userVo = getMapper().map(internalUserFindDto.getTsegcUsuario(), UserVo.class);
			userDao.getSession().evict(internalUserFindDto.getTsegcUsuario());
			userVo.setIdRol(internalUserFindDto.getTsegcRol().getIdRol());
			internalDataVo = getMapper().map(internalUserFindDto.getTsegcDatosinterno(), InternalDataVo.class);
			userDao.getSession().evict(internalUserFindDto.getTsegcDatosinterno());
			rolAclVo = getMapper().mapAsList(internalUserFindDto.getTsegrRolAcl(), RolAclVo.class);
			applicationVo = getMapper().mapAsList(internalUserFindDto.getTsegcAplicacions(), ApplicationVo.class);
			
			internalUserFindVo = new InternalUserFindVo(userVo, internalDataVo, rolAclVo, applicationVo);
			
			return internalUserFindVo;
		}catch(Exception e){
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar UserBusinessImpl.findInternalUserById: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
	}
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public int updatePassword(Integer idUsuario, String password, Integer estatus) throws TransactionalOVITException{
		logger.info("Ejecutando UserBusinessImpl.updatePassword");
		try{
			T7segoUsua tsegcUsuario = userDao.findSimpleUserById(idUsuario);
			T7segoPass tsegcPassword = new T7segoPass(new TsegcPasswordId(idUsuario), password, 0, new Date());
			if(tsegcUsuario.getIdEstatus() == IUserBusiness.STATUS_RESET || 
				tsegcUsuario.getIdEstatus() == IUserBusiness.STATUS_NEW){
				userDao.updatePassword(tsegcPassword, REASON_RESET);
			}else{
				userDao.updatePassword(tsegcPassword, REASON_NEW);
			}
			tsegcUsuario.setIdEstatus(estatus);
			return IUserBusiness.UPDATE_PASS_CORRECT;
		}catch(Exception e){
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError()));
			logger.error("Error al ejecutar UserBusinessImpl.updatePassword: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError(),
					ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError());
		}
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public int validatePassword (Integer idUsuario, String password, String newPassword) throws TransactionalOVITException {
		logger.info("Ejecutando UserBusinessImpl.validatePassword");
		if(idUsuario == null){
			throw new TransactionalOVITException(ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getCodeError(),
					ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getMessageError());
		}
		try {
			T7segoUsua tsegcUsuario = userDao.findSimpleUserById(idUsuario);
			int resComparePass = comparePassword(tsegcUsuario, password);
			ConfigurationUtilsVo configurationUtilsVo = null;
			if(resComparePass != PASSWORD_CORRECT){
				return resComparePass;
			}
			if(password.equals(newPassword)){
				return PASSWORD_SAME_ACTUAL;
			}
			configurationUtilsBusiness.setSession(userDao.getSession());
			configurationUtilsVo = configurationUtilsBusiness.
					getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.NUM_PASS_NOT_REUSABLE);
			int notReusable = Integer.parseInt(configurationUtilsVo.getValor());
			List<T7segbHistPass> lstHistoricoContras = userDao.findLastPasswords(idUsuario, notReusable);
			if(!OVITUtils.isEmptyList(lstHistoricoContras)){
				for(T7segbHistPass tempHistoricopassword : lstHistoricoContras){
					if(newPassword.equals(tempHistoricopassword.getId().getContra())){
						return IUserBusiness.PASSWORD_NUM_VALIDATION;
					}
				}
			}
			return resComparePass;
		} catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar UserBusinessImpl.validatePassword: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),
					ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public UserDetailsVo validateLogIn(String userName, String password)
			throws TransactionalOVITException {
		logger.info("Ejecutando UserBusinessImpl.validateLogIn");
		UserDetailsVo userDetailsVo = null;
		UserDetailsDto userDetailsDto = null;
		if(OVITUtils.isEmptyString(userName)){
			throw new TransactionalOVITException(ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getCodeError(),
					ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getMessageError());
		}
		try {
			T7segoUsua tsegcUsuario = userDao.validateLogIn(userName);
			userDetailsVo = new UserDetailsVo();
			if(tsegcUsuario == null){
				userDetailsVo.setEstatusLogin(USER_NOT_FOUND);
				return userDetailsVo;
			}
			
			int estatusUser = tsegcUsuario.getIdEstatus();
			userDetailsVo = getMapper().map(tsegcUsuario, UserDetailsVo.class);
			if(estatusUser == STATUS_LOCKED){
				userDetailsVo.setEstatusLogin(USER_LOCKED);
				return userDetailsVo;
			} else if (estatusUser == STATUS_DROP) {
				userDetailsVo.setEstatusLogin(USER_DROP);
				return userDetailsVo;
			}
			
//			if(tsegcUsuario.getIdTipoUsuario() == EXTERNAL){
//				int response = comparePassword(tsegcUsuario, password);
//				
//				switch (response) {
//					case PASSWORD_CORRECT:
//						userDetailsDto = userDao.
//							findUserdetail(tsegcUsuario.getIdUsuario());
//						tsegcUsuario.setFechaLogueo(new Date());
//						userDetailsVo = getMapper().map(userDetailsDto, UserDetailsVo.class);
//						if(estatusUser == STATUS_NEW){
//							userDetailsVo.setEstatusLogin(USER_EXTERNAL_NEW);
//							return userDetailsVo;
//						}
//						if(estatusUser == STATUS_RESET){
//							userDetailsVo.setEstatusLogin(USER_EXTERNAL_RESET);
//							return userDetailsVo;
//						}
//						userDetailsVo.setEstatusLogin(USER_EXTERNAL_CORRECT_PASS);
//						return userDetailsVo;
//					case PASSWORD_WRONG:
//						userDetailsVo = getMapper().map(tsegcUsuario, UserDetailsVo.class);
//						userDetailsVo.setEstatusLogin(USER_EXTERNAL_WRONG_PASS);
//						return userDetailsVo;
//				}
//			}
			userDetailsDto = userDao.
					findUserdetail(tsegcUsuario.getIdUsuario());
			Map<String, String> componentes = userDao.findComponentesByRol(userDetailsDto.getIdRol());
				userDetailsVo = getMapper().map(userDetailsDto, UserDetailsVo.class);
			userDetailsVo.setEstatusLogin(USER_INTERNAL);
			userDetailsVo.setComponentes(componentes);
			return userDetailsVo;
		} catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar UserBusinessImpl.validateLogIn: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),
					ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public void resetPassword(Integer idUsuario)
			throws TransactionalOVITException, SendingMailOVITException {
		logger.info("Ejecutando UserBusinessImpl.resetPassword");
		
		T7segoDatoUsuaExte tsegcDatosexterno = userDao.findExternalData(idUsuario);
		
		if(tsegcDatosexterno == null){
			throw new TransactionalOVITException(ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getCodeError(),
					ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getMessageError());
		}
		
		try {
			
			String strMail = tsegcDatosexterno.getCorreo();
			String strPwdEncrypt = encryptPassword(UUID.randomUUID().toString().substring(0, 8));
			T7segoPass tsegcPassword = new T7segoPass(new TsegcPasswordId(idUsuario), strPwdEncrypt, 
					0, new Date());
			userDao.updatePassword(tsegcPassword, REASON_NEW);
			if(UUID.randomUUID().toString().substring(0, 8) != null){
				sendMailBusiness.setSession(userDao.getSession());
				MessageVo messageVo = sendMailBusiness.getResetPasswordMessage();
				List<String> addressTo = new ArrayList<String>(1);
				addressTo.add(strMail);
				String message = messageVo.getValor()
						.replaceAll("#\\{usuario\\}",  tsegcDatosexterno.getNumeroEmpleado())
						.replaceAll("#\\{password\\}", UUID.randomUUID().toString().substring(0, 8));
				String asunto = messageVo.getAsunto()
						.replaceAll("#\\{usuario\\}", tsegcDatosexterno.getNumeroEmpleado());
				ConfigurationUtilsVo footer = configurationUtilsBusiness
						.getConstantOfDataBase(ConfigOvitIdentifierEnum.IMAGES_MAIL.IMG_FOOTER);
				ConfigurationUtilsVo banner = configurationUtilsBusiness
						.getConstantOfDataBase(ConfigOvitIdentifierEnum.IMAGES_MAIL.IMG_BANNER);
				byte[] footerImage = sendMailBusiness.getWebImage(footer.getValor(), IMAGE_PNG);
				byte[] bannerImage = sendMailBusiness.getWebImage(banner.getValor(), IMAGE_PNG);
				sendMailBusiness.senMailTo(addressTo, null, null, asunto, message, bannerImage, footerImage);
			}
			
		}catch(SendingMailOVITException e){
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E05_ERROR_ENVIAR_CORREO.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E05_ERROR_ENVIAR_CORREO.getMessageError()));
			logger.error("Error al ejecutar UserBusinessImpl.resetPassword: " + e);
			throw new SendingMailOVITException(ErrorSEGWeb.E05_ERROR_ENVIAR_CORREO.getCodeError(),
					ErrorSEGWeb.E05_ERROR_ENVIAR_CORREO.getMessageError());
		} catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError()));
			logger.error("Error al ejecutar UserBusinessImpl.resetPassword: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError(),
					ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError());
		}
		
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public void updateStatus(Integer idUsuario, Integer idEstatus)
			throws TransactionalOVITException {
		logger.info("Ejecutando UserBusinessImpl.updateStatus");
		try {
			userDao.updateStatus(idUsuario, idEstatus);
		} catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError()));
			logger.error("Error al ejecutar UserBusinessImpl.updateStatus: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError(),
					ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError());
		}
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public void updateLoginDate(Integer idUsuario)
			throws TransactionalOVITException {
		logger.info("Ejecutando UserBusinessImpl.updateLoginDate");
		try {
			userDao.updateLoginDate(idUsuario);
		} catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError()));
			logger.error("Error al ejecutar UserBusinessImpl.updateLoginDate: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E02_ERROR_UPDATE.getCodeError(),
					ErrorSEGWeb.E02_ERROR_UPDATE.getMessageError());
		}
		
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public UserContraVo obtainUserPasswordInfo(Integer idUsuario)
			throws TransactionalOVITException {
		logger.info("Ejecutando UserBusinessImpl.obtainUserPasswordInfo");
		if(idUsuario == null){
			throw new TransactionalOVITException(ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getCodeError(),
					ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getMessageError());
		}
		UserContraVo userContraVo = null;
		try{
			T7segoPass tsegcPassword = userDao.findPassword(idUsuario);
			userContraVo = getMapper().map(tsegcPassword, UserContraVo.class);
			userContraVo.setIdUsuario(tsegcPassword.getId().getIdUsuario());
			
			return userContraVo;
		} catch (Exception e) {
			logger.error("Descripcion del Error: Codigo: ".concat(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError())
					.concat("Mensaje: ").concat(ErrorSEGWeb.E03_ERROR_SELECT.getMessageError()));
			logger.error("Error al ejecutar UserBusinessImpl.obtainUserPasswordInfo: " + e);
			throw new TransactionalOVITException(ErrorSEGWeb.E03_ERROR_SELECT.getCodeError(),
					ErrorSEGWeb.E03_ERROR_SELECT.getMessageError());
		}
		
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public void updateUserApplicationList(
			List<? super ApplicationGenericRequest> listRequest)
			throws TransactionalOVITException {
		if(!OVITUtils.isEmptyList(listRequest)){
			for(Object appRequest: listRequest){
				IApplicationMethods appMethods;
				String beanName = ((ApplicationGenericRequest) appRequest).getBeanNameSpring();
				appMethods = (IApplicationMethods) appContext.getBean(beanName);
				appMethods.executeUpdate(appRequest);
			}
		}
		
	}
	
	private <T> void validateUserData(T objectValidate) throws TransactionalOVITException{
		Set<ConstraintViolation<T>> externalDataVoViolations = getValidator().validate(objectValidate);
		if(!OVITUtils.isEmptyList(externalDataVoViolations)){
			for(ConstraintViolation<T> tempViolation : externalDataVoViolations){
				logger.error("Error al validar UserVO: ".concat(tempViolation.getMessage()));
			}
			throw new TransactionalOVITException(ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getCodeError(),
					ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getMessageError());
		}
	}
	
	private String encryptPassword(String password) throws TransactionalOVITException{
		configurationUtilsBusiness.setSession(userDao.getSession());
		ConfigurationUtilsVo configUtilVoIdApp  = configurationUtilsBusiness.
				getConstantOfDataBase(ConfigOvitIdentifierEnum.LDAP.ID_APP);
		Crypt crypt = new Crypt(configUtilVoIdApp.getValor());
		String strPasswordCrypt = crypt.encrypt(password.getBytes());
		return strPasswordCrypt;
	}
	
	private int comparePassword(T7segoUsua tsegcUsuario, String password)
			throws TransactionalOVITException {
		logger.info("Ejecutando UserBusinessImpl.validatePassword");
		if(tsegcUsuario == null){
			throw new TransactionalOVITException(ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getCodeError(),
					ErrorSEGWeb.E04_ERROR_VALIDATION_DATA.getMessageError());
		}
		Integer idUsuario = tsegcUsuario.getIdUsuario();
		T7segoPass tsegcPassword = userDao.findPassword(idUsuario);
		ConfigurationUtilsVo configUtilsVo = null;
		configurationUtilsBusiness.setSession(userDao.getSession());
		configUtilsVo = configurationUtilsBusiness.
				getConstantOfDataBase(ConfigOvitIdentifierEnum.PARAMETERS_SEG.NUM_ATTEMPT_BLOQ);
		int intentos = Integer.parseInt(configUtilsVo.getValor());
		if(tsegcPassword.getIntentos()>=intentos){
			return PASSWORD_EXCEEDED;
		}
		if(password.equals(tsegcPassword.getPassword())){
			if(tsegcPassword.getIntentos()>0){
				tsegcPassword.setIntentos(0);
			}
			tsegcUsuario.setFechaLogueo(new Date());
			return PASSWORD_CORRECT;
		} else {
			tsegcPassword.setIntentos(tsegcPassword.getIntentos() + 1);
			if (tsegcPassword.getIntentos() >= intentos) {
				tsegcUsuario.setIdEstatus(STATUS_LOCKED);
			}
			return PASSWORD_WRONG;
		}
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public List<RolAccionVo> findRolAccionByRol(Integer rol) throws TransactionalOVITException {
		logger.info("Ejecutando UserBusinessImpl.findRolAccionByRol");
		List<ReportRolAccionDto> lstReportRolAccionDto = userDao.findRolAccionByRol(rol);
		List<RolAccionVo> lstReportRolAccionVos = getMapper().mapAsList(lstReportRolAccionDto, RolAccionVo.class);
		return lstReportRolAccionVos;
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public List<CorreoNotiVo> findAllCorrNotiByProd(Long producto) throws TransactionalOVITException {
		logger.info("Ejecutando UserBusinessImpl.findAllCorrNotiByProdDesc");
		List<CorreoNotiDto> lstCorreoNotiDto = userDao.findAllCorrNotiByProd(producto);
		List<CorreoNotiVo> lstCorreoNotiVo = getMapper().mapAsList(lstCorreoNotiDto, CorreoNotiVo.class);
		return lstCorreoNotiVo;
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public List<CorreoPropVo> findAllCorrProp() throws TransactionalOVITException {
		logger.info("Ejecutando UserBusinessImpl.findAllCorrProp");
		List<CorreoPropDto> lstCorreoPropDto = userDao.findAllCorrProp();
		List<CorreoPropVo> lstCorreoPropVo = getMapper().mapAsList(lstCorreoPropDto, CorreoPropVo.class);
		return lstCorreoPropVo;
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public List<String> findAllCorrAuto(Long rolAutorizador) throws TransactionalOVITException {
		logger.info("Ejecutando UserBusinessImpl.findAllCorrAuto");
		List<String> lstCorreoAuto = userDao.findAllCorrAuto(rolAutorizador);
		return lstCorreoAuto;
	}
		
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public UserDetailsDto findUserdetailByEmpleado(String idEmpleado) {
		UserDetailsDto usuario = userDao.findUserdetailByEmpleado(idEmpleado);
	return usuario;
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public List<String> getAllCorreoGrupoRol(List<Integer> grupoRol) {
		List<String> listCorreoGrupoRol = userDao.getAllCorreoGrupoRol(grupoRol);
		return listCorreoGrupoRol;
	}

/////////////////////////////////////////////

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public boolean actualizarUsuarioAdmin(ReportUserDto reportUserDto, String pass) {
		boolean resp = userDao.actualizarUsuarioAdmin(reportUserDto, pass);
		return resp;
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public boolean altaUsuarioAdmin(ReportUserDto reportUserDto, String pass) {
		boolean resp = userDao.altaUsuarioAdmin(reportUserDto, pass);
		return resp;
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public boolean requiereCambioPass(String rol) {
		boolean resp = userDao.requiereCambioPass(rol);
		return resp;
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public boolean altaPass(ReportUserDto reportUserDto) {
		boolean resp = false;
		resp = userDao.altaPass(reportUserDto);
		return resp;
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public boolean altaRolUsuario(ReportUserDto reportUserDto) {
		boolean resp = false;
		resp = userDao.altaRolUsuario(reportUserDto);
		return resp;
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public boolean guardarDocumento(String ruta, String name, Integer idUsuario) {
		boolean resp = userDao.guardarDocumento(ruta, name, idUsuario);
		return resp;
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public boolean altaDocumento(String ruta, String name, Integer idUsuario) {
		boolean resp = userDao.altaDocumento(ruta, name, idUsuario);
		return resp;
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<DocumentoDto> obtenerDocumentos(Integer idUsuario) {
		List<DocumentoDto> resp = userDao.obtenerDocumentos(idUsuario);
		return resp;
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<OperadorDto> obtenerEmpresas() {
		List<OperadorDto> resp = userDao.obtenerEmpresas();
		return resp;
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public String obtenerOperadorUsuario(Integer idUsuario) {
		String resp = userDao.obtenerOperadorUsuario(idUsuario);
		return resp;
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<EstatusDto> obtenerEstatus() {
		List<EstatusDto> resp = userDao.obtenerEstatus();
		return resp;
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public boolean eliminarDoc(Integer idDoc) {
		boolean resp = userDao.eliminarDoc(idDoc);
		return resp;
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public List<ReportUserVo> findAllReportUsers()
			throws TransactionalOVITException {
		logger.info("Ejecutando UserBusinessImpl.findAllReportUsers");
		List<ReportUserDto> lstReportUserDto = userDao.findAllReportUsers();
		List<ReportUserVo> lstReportUserVos = getMapper().mapAsList(lstReportUserDto, ReportUserVo.class);
		return lstReportUserVos;
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public List<ReportUserVo> findReportUsersConcesionario()
			throws TransactionalOVITException {
		logger.info("Ejecutando UserBusinessImpl.findAllReportUsers");
		List<ReportUserDto> lstReportUserDto = userDao.findReportUsersConcesionario();
		List<ReportUserVo> lstReportUserVos = getMapper().mapAsList(lstReportUserDto, ReportUserVo.class);
		return lstReportUserVos;
	}

	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public String idArchivosUsuario() {
		return userDao.idArchivosUsuario();
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public List<ReportUserVo> getUsersConcesionarioByOp(String operadorUsuario) throws TransactionalOVITException{
		logger.info("Ejecutando UserBusinessImpl.getUsersConcesionarioByOp");
		List<ReportUserDto> lstReportUserDto = userDao.getUsersConcesionarioByOp(operadorUsuario);
		List<ReportUserVo> lstReportUserVos = getMapper().mapAsList(lstReportUserDto, ReportUserVo.class);
		return lstReportUserVos;
	}
 
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public int getCountUsersConcesionarioByOp(String seleccionadoConcesionario) {
		return userDao.getCountUsersConcesionarioByOp(seleccionadoConcesionario);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public String getPassUser(int idUsuario) {
		return userDao.getPassUser(idUsuario);
	}
	
	@Transactional(value = "transactionManagerOVITAPP", rollbackFor = Exception.class, propagation=Propagation.REQUIRED)
	@Override
	public String getEstadoUser(int idUsuario) {
		return userDao.getEstadoUser(idUsuario);
	}
	
	
}
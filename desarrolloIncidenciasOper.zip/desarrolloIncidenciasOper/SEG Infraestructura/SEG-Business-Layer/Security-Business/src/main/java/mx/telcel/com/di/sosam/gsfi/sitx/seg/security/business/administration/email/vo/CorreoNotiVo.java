package mx.telcel.com.di.sosam.gsfi.sitx.seg.security.business.administration.email.vo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CorreoNotiVo implements Serializable{

	private static final long serialVersionUID = -1728903903414084728L;
	
	private Integer producto;
	private String productoDesc;
	private String correoDest;
	private String correoCc;
	private Integer estado;
	
	@NotNull
	@XmlElement(nillable = true)
	public Integer getProducto() {
		return producto;
	}
	
	public void setProducto(Integer producto) {
		this.producto = producto;
	}
	
	@NotNull
	@XmlElement(nillable = true)
	public String getProductoDesc() {
		return productoDesc;
	}
	
	public void setProductoDesc(String productoDesc) {
		this.productoDesc = productoDesc;
	}
	
	@NotNull
	@XmlElement(nillable = true)
	public String getCorreoDest() {
		return correoDest;
	}
	
	public void setCorreoDest(String correoDest) {
		this.correoDest = correoDest;
	}
	
	@NotNull
	@XmlElement(nillable = true)
	public String getCorreoCc() {
		return correoCc;
	}
	
	public void setCorreoCc(String correoCc) {
		this.correoCc = correoCc;
	}
	
	@NotNull
	@XmlElement(nillable = true)
	public Integer getEstado() {
		return estado;
	}
	
	public void setEstado(Integer estado) {
		this.estado = estado;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CorreoNotiVo [producto=");
		builder.append(producto);
		builder.append(", productoDesc=");
		builder.append(productoDesc);
		builder.append(", correoDest=");
		builder.append(correoDest);
		builder.append(", correoCc=");
		builder.append(correoCc);
		builder.append(", estado=");
		builder.append(estado);
		builder.append("]");
		return builder.toString();
	}

}
